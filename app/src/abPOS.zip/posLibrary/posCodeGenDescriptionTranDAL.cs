using System;
using System.Data;
using System.Data.SqlClient;
using System.Collections.Generic;

namespace posLibrary
{
	/// <summary>
	/// Class for posCodeGenDescriptionTran
	/// </summary>
	public class posCodeGenDescriptionTranDAL
	{
		#region Properties
		public int CodeGenDescriptionTranId { get; set; }
		public string Description { get; set; }
		public short linktoCodeGenMasterId { get; set; }
		#endregion

		#region Class Methods
		private bool SetClassPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
		{
			if (sqlRdr.Read())
			{
				this.CodeGenDescriptionTranId = Convert.ToInt32(sqlRdr["CodeGenDescriptionTranId"]);
				this.Description = Convert.ToString(sqlRdr["Description"]);
				this.linktoCodeGenMasterId = Convert.ToInt16(sqlRdr["linktoCodeGenMasterId"]);
				return true;
			}
			return false;
		}

		private List<posCodeGenDescriptionTranDAL> SetListPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
		{
			List<posCodeGenDescriptionTranDAL> lstCodeGenDescriptionTran = new List<posCodeGenDescriptionTranDAL>();
			posCodeGenDescriptionTranDAL objCodeGenDescriptionTran = null;
			while (sqlRdr.Read())
			{
				objCodeGenDescriptionTran = new posCodeGenDescriptionTranDAL();
				objCodeGenDescriptionTran.CodeGenDescriptionTranId = Convert.ToInt32(sqlRdr["CodeGenDescriptionTranId"]);
				objCodeGenDescriptionTran.Description = Convert.ToString(sqlRdr["Description"]);
				objCodeGenDescriptionTran.linktoCodeGenMasterId = Convert.ToInt16(sqlRdr["linktoCodeGenMasterId"]);
				lstCodeGenDescriptionTran.Add(objCodeGenDescriptionTran);
			}
			return lstCodeGenDescriptionTran;
		}
		#endregion

		#region Insert
		public posRecordStatus InsertCodeGenDescriptionTran()
		{
			SqlConnection SqlCon = null;
			SqlCommand SqlCmd = null;
			try
			{
				SqlCon = posObjectFactoryDAL.CreateConnection();
				SqlCmd = new SqlCommand("posCodeGenDescriptionTran_Insert", SqlCon);
				SqlCmd.CommandType = CommandType.StoredProcedure;

				SqlCmd.Parameters.Add("@CodeGenDescriptionTranId", SqlDbType.Int).Direction = ParameterDirection.Output;
				SqlCmd.Parameters.Add("@Description", SqlDbType.VarChar).Value = this.Description;
				SqlCmd.Parameters.Add("@linktoCodeGenMasterId", SqlDbType.SmallInt).Value = this.linktoCodeGenMasterId;
				SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

				SqlCon.Open();
				SqlCmd.ExecuteNonQuery();
				SqlCon.Close();

				this.CodeGenDescriptionTranId = Convert.ToInt32(SqlCmd.Parameters["@CodeGenDescriptionTranId"].Value);
				posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
				return rs;
			}
			catch (Exception ex)
			{
				posGlobalsDAL.SaveError(ex);
				return posRecordStatus.Error;
			}
			finally
			{
				posObjectFactoryDAL.DisposeCommand(SqlCmd);
				posObjectFactoryDAL.DisposeConnection(SqlCon);
			}
		}
		#endregion

		#region Update
		public posRecordStatus UpdateCodeGenDescriptionTran()
		{
			SqlConnection SqlCon = null;
			SqlCommand SqlCmd = null;
			try
			{
				SqlCon = posObjectFactoryDAL.CreateConnection();
				SqlCmd = new SqlCommand("posCodeGenDescriptionTran_Update", SqlCon);
				SqlCmd.CommandType = CommandType.StoredProcedure;

				SqlCmd.Parameters.Add("@CodeGenDescriptionTranId", SqlDbType.Int).Value = this.CodeGenDescriptionTranId;
				SqlCmd.Parameters.Add("@Description", SqlDbType.VarChar).Value = this.Description;
				SqlCmd.Parameters.Add("@linktoCodeGenMasterId", SqlDbType.SmallInt).Value = this.linktoCodeGenMasterId;
				SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

				SqlCon.Open();
				SqlCmd.ExecuteNonQuery();
				SqlCon.Close();

				posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
				return rs;
			}
			catch (Exception ex)
			{
				posGlobalsDAL.SaveError(ex);
				return posRecordStatus.Error;
			}
			finally
			{
				posObjectFactoryDAL.DisposeCommand(SqlCmd);
				posObjectFactoryDAL.DisposeConnection(SqlCon);
			}
		}
		#endregion

		#region Delete
		public posRecordStatus DeleteCodeGenDescriptionTran()
		{
			SqlConnection SqlCon = null;
			SqlCommand SqlCmd = null;
			try
			{
				SqlCon = posObjectFactoryDAL.CreateConnection();
				SqlCmd = new SqlCommand("posCodeGenDescriptionTran_Delete", SqlCon);
				SqlCmd.CommandType = CommandType.StoredProcedure;

				SqlCmd.Parameters.Add("@CodeGenDescriptionTranId", SqlDbType.Int).Value = this.CodeGenDescriptionTranId;
				SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

				SqlCon.Open();
				SqlCmd.ExecuteNonQuery();
				SqlCon.Close();

				posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
				return rs;
			}
			catch (Exception ex)
			{
				posGlobalsDAL.SaveError(ex);
				return posRecordStatus.Error;
			}
			finally
			{
				posObjectFactoryDAL.DisposeCommand(SqlCmd);
				posObjectFactoryDAL.DisposeConnection(SqlCon);
			}
		}
		#endregion

		#region Select
		public bool SelectCodeGenDescriptionTran()
		{
			SqlConnection SqlCon = null;
			SqlCommand SqlCmd = null;
			SqlDataReader SqlRdr = null;
			try
			{
				SqlCon = posObjectFactoryDAL.CreateConnection();
				SqlCmd = new SqlCommand("posCodeGenDescriptionTran_Select", SqlCon);
				SqlCmd.CommandType = CommandType.StoredProcedure;

				SqlCmd.Parameters.Add("@CodeGenDescriptionTranId", SqlDbType.Int).Value = this.CodeGenDescriptionTranId;

				SqlCon.Open();
				SqlRdr = SqlCmd.ExecuteReader();
				bool IsSelected = SetClassPropertiesFromSqlDataReader(SqlRdr);
				SqlRdr.Close();
				SqlCon.Close();

				return IsSelected;
			}
			catch (Exception ex)
			{
				posGlobalsDAL.SaveError(ex);
				return false;
			}
			finally
			{
				posObjectFactoryDAL.DisposeDataReader(SqlRdr);
				posObjectFactoryDAL.DisposeCommand(SqlCmd);
				posObjectFactoryDAL.DisposeConnection(SqlCon);
			}
		}
		#endregion

		#region SelectAll

		public List<posCodeGenDescriptionTranDAL> SelectAllCodeGenDescriptionTran(SqlConnection sqlCon = null)
		{
			SqlConnection SqlCon = null;
			SqlCommand SqlCmd = null;
			SqlDataReader SqlRdr = null;
			try
			{
				if (sqlCon == null)
				{
					SqlCon = posObjectFactoryDAL.CreateConnection();
					SqlCmd = new SqlCommand("posCodeGenDescriptionTran_SelectAll", SqlCon);
				}
				else
				{
					SqlCmd = new SqlCommand("posCodeGenDescriptionTran_SelectAll", sqlCon);
				}
				SqlCmd.CommandType = CommandType.StoredProcedure;

				SqlCmd.Parameters.Add("@linktoCodeGenMasterId", SqlDbType.SmallInt).Value = this.linktoCodeGenMasterId;

				if (sqlCon == null)
				{
					SqlCon.Open();
				}
				SqlRdr = SqlCmd.ExecuteReader();
				List<posCodeGenDescriptionTranDAL> lstCodeGenDescriptionTranDAL = SetListPropertiesFromSqlDataReader(SqlRdr);
				SqlRdr.Close();
				if (sqlCon == null)
				{
					SqlCon.Close();
				}

				return lstCodeGenDescriptionTranDAL;
			}
			catch (Exception ex)
			{
				posGlobalsDAL.SaveError(ex);
				return null;
			}
			finally
			{
				posObjectFactoryDAL.DisposeDataReader(SqlRdr);
				posObjectFactoryDAL.DisposeCommand(SqlCmd);
				if (sqlCon == null)
				{
					posObjectFactoryDAL.DisposeConnection(SqlCon);
				}
			}
		}
		#endregion
	}
}
