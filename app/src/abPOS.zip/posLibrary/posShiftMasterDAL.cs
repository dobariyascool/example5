using System;
using System.Data;
using System.Data.SqlClient;
using System.Collections.Generic;

namespace posLibrary
{
    /// <summary>
    /// Class for posShiftMaster
    /// </summary>
    public class posShiftMasterDAL
    {
        #region Properties
        public int ShiftMasterId { get; set; }
        public short linktoUserMasterId { get; set; }
        public DateTime SoftwareStartDateTime { get; set; }
        public DateTime SystemStartDateTine { get; set; }
        public DateTime? SoftwareEndDateTime { get; set; }
        public DateTime? SystemEndDateTime { get; set; }
        public double OpeningBalance { get; set; }
        public double ClosingBalance { get; set; }
        public bool IsClosed { get; set; }
        public string SystemName { get; set; }

        
        // Extra
        public string Username { get; set; }
        public string PaymentType { get; set; }
        public short PersonsVisited { get; set; }
        public double AmountPaid { get; set; }
        #endregion

        #region Class Methods
        private bool SetClassPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            if (sqlRdr.Read())
            {
                this.ShiftMasterId = Convert.ToInt32(sqlRdr["ShiftMasterId"]);
                this.linktoUserMasterId = Convert.ToInt16(sqlRdr["linktoUserMasterId"]);
                this.SoftwareStartDateTime = Convert.ToDateTime(sqlRdr["SoftwareStartDateTime"]);
                this.SystemStartDateTine = Convert.ToDateTime(sqlRdr["SystemStartDateTine"]);
                if (sqlRdr["SoftwareEndDateTime"] != DBNull.Value)
                {
                    this.SoftwareEndDateTime = Convert.ToDateTime(sqlRdr["SoftwareEndDateTime"]);
                }
                if (sqlRdr["SystemEndDateTime"] != DBNull.Value)
                {
                    this.SystemEndDateTime = Convert.ToDateTime(sqlRdr["SystemEndDateTime"]);
                }
                this.OpeningBalance = Convert.ToDouble(sqlRdr["OpeningBalance"]);
                this.ClosingBalance = Convert.ToDouble(sqlRdr["ClosingBalance"]);
                this.IsClosed = Convert.ToBoolean(sqlRdr["IsClosed"]);
                this.SystemName = Convert.ToString(sqlRdr["SystemName"]);

                /// Extra
                this.Username = Convert.ToString(sqlRdr["Username"]);

                return true;
            }
            return false;
        }
        #endregion

        #region Insert
        public posRecordStatus InsertShiftMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posShiftMaster_Insert", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@ShiftMasterId", SqlDbType.Int).Direction = ParameterDirection.Output;
                SqlCmd.Parameters.Add("@linktoUserMasterId", SqlDbType.SmallInt).Value = this.linktoUserMasterId;
                SqlCmd.Parameters.Add("@SoftwareStartDateTime", SqlDbType.DateTime).Value = this.SoftwareStartDateTime;
                SqlCmd.Parameters.Add("@SystemStartDateTine", SqlDbType.DateTime).Value = this.SystemStartDateTine;
                SqlCmd.Parameters.Add("@OpeningBalance", SqlDbType.Money).Value = this.OpeningBalance;
                SqlCmd.Parameters.Add("@ClosingBalance", SqlDbType.Money).Value = this.ClosingBalance;
                SqlCmd.Parameters.Add("@IsClosed", SqlDbType.Bit).Value = this.IsClosed;
                SqlCmd.Parameters.Add("@SystemName", SqlDbType.VarChar).Value = this.SystemName;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                this.ShiftMasterId = Convert.ToInt32(SqlCmd.Parameters["@ShiftMasterId"].Value);
                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region Update
        public posRecordStatus UpdateShiftMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posShiftMaster_Update", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@ShiftMasterId", SqlDbType.Int).Value = this.ShiftMasterId;
                SqlCmd.Parameters.Add("@SoftwareEndDateTime", SqlDbType.DateTime).Value = this.SoftwareEndDateTime;
                SqlCmd.Parameters.Add("@SystemEndDateTime", SqlDbType.DateTime).Value = this.SystemEndDateTime;
                SqlCmd.Parameters.Add("@ClosingBalance", SqlDbType.Money).Value = this.ClosingBalance;
                SqlCmd.Parameters.Add("@IsClosed", SqlDbType.Bit).Value = this.IsClosed;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region Select
        public bool SelectShiftMasterBylinktoUserMasterId()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posShiftMasterBylinktoUserMasterId_Select", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@linktoUserMasterId", SqlDbType.Int).Value = this.linktoUserMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                bool IsSelected = SetClassPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                return IsSelected;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return false;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region Select All
        public List<posShiftMasterDAL> SelectAllShiftMasterShiftEndReport(short linktoBusinessMasterId)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader sqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posShiftMasterShiftEndReport_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@linktoUserMasterId", SqlDbType.SmallInt).Value = this.linktoUserMasterId;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = linktoBusinessMasterId;
                SqlCmd.Parameters.Add("@PersonsVisited", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                sqlRdr = SqlCmd.ExecuteReader();

                List<posShiftMasterDAL> lstShiftMasterDAL = new List<posShiftMasterDAL>();
                posShiftMasterDAL objShiftMasterDAL = null;
                while (sqlRdr.Read())
                {
                    objShiftMasterDAL = new posShiftMasterDAL();
                    if (sqlRdr["AmountPaid"] != DBNull.Value)
                    {
                        objShiftMasterDAL.AmountPaid = Convert.ToDouble(sqlRdr["AmountPaid"]);
                    }
                    if (sqlRdr["PaymentTypeCategory"] != DBNull.Value)
                    {
                        objShiftMasterDAL.PaymentType = Convert.ToString(sqlRdr["PaymentTypeCategory"]);
                    }
                    lstShiftMasterDAL.Add(objShiftMasterDAL);
                }
                sqlRdr.Close();

                this.PersonsVisited = Convert.ToInt16(SqlCmd.Parameters["@PersonsVisited"].Value);

                return lstShiftMasterDAL;

            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(sqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion
    }
}
