using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace posLibrary
{
    /// <summary>
    /// Class for labUserRightsTran
    /// </summary>
    public class posUserRightsTranDAL
    {
        #region Properties
        public int UserRightsTranId { get; set; }
        public short linktoUserRightsMasterId { get; set; }
        public short linktoRoleMasterId { get; set; }
        #endregion

        #region Class Methods
        private List<posUserRightsTranDAL> SetListPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            List<posUserRightsTranDAL> lstUserRightsTran = new List<posUserRightsTranDAL>();
            posUserRightsTranDAL objUserRightsTran = null;
            while (sqlRdr.Read())
            {
                objUserRightsTran = new posUserRightsTranDAL();
                objUserRightsTran.UserRightsTranId = Convert.ToInt32(sqlRdr["UserRightsTranId"]);
                objUserRightsTran.linktoUserRightsMasterId = Convert.ToInt16(sqlRdr["linktoUserRightsMasterId"]);
                objUserRightsTran.linktoRoleMasterId = Convert.ToInt16(sqlRdr["linktoRoleMasterId"]);
                lstUserRightsTran.Add(objUserRightsTran);
            }
            return lstUserRightsTran;
        }
        #endregion

        #region InsertAll
        public posRecordStatus InsertAllUserRightsTran(string ids, SqlConnection SqlCon, SqlTransaction SqlTran)
        {
            SqlCommand SqlCmd = null;
            try
            {
                SqlCmd = new SqlCommand("posUserRightsTran_InsertAll", SqlCon, SqlTran);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@ids", SqlDbType.VarChar).Value = ids;
                SqlCmd.Parameters.Add("@linktoRoleMasterId", SqlDbType.SmallInt).Value = this.linktoRoleMasterId;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCmd.ExecuteNonQuery();

                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
            }
        }
        #endregion

        #region UpdateAll
        public posRecordStatus UpdateAllUserRightsTran(string ids, SqlConnection SqlCon, SqlTransaction SqlTran)
        {
            SqlCommand SqlCmd = null;
            try
            {
                SqlCmd = new SqlCommand("posUserRightsTran_UpdateAll", SqlCon, SqlTran);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@ids", SqlDbType.VarChar).Value = ids;
                SqlCmd.Parameters.Add("@linktoRoleMasterId", SqlDbType.SmallInt).Value = this.linktoRoleMasterId;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCmd.ExecuteNonQuery();

                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
            }
        }
        #endregion    

        #region SelectAll
        public List<posUserRightsTranDAL> SelectAllUserRightsTranRoleWise()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posUserRightsTranRoleWise_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@linktoRoleMasterId", SqlDbType.SmallInt).Value = this.linktoRoleMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<posUserRightsTranDAL> lstUserRightsTranDAL = SetListPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                return lstUserRightsTranDAL;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion
    }
}
