using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace posLibrary
{
	/// <summary>
	/// Class for posIssueItemTran
	/// </summary>
	public class posIssueItemTranDAL
	{
		#region Properties
		public int IssueItemTranId { get; set; }
		public int linktoIssueItemMasterId { get; set; }
		public int linktoItemMasterId { get; set; }
		public short linktoUnitMasterId { get; set; }
		public double Quantity { get; set; }

		/// Extra
		public int IssueItem { get; set; }
		public string Item { get; set; }
		public string Unit { get; set; }
		#endregion

		#region Class Methods
		private List<posIssueItemTranDAL> SetListPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
		{
			List<posIssueItemTranDAL> lstIssueItemTran = new List<posIssueItemTranDAL>();
			posIssueItemTranDAL objIssueItemTran = null;
			while (sqlRdr.Read())
			{
				objIssueItemTran = new posIssueItemTranDAL();
				objIssueItemTran.IssueItemTranId = Convert.ToInt32(sqlRdr["IssueItemTranId"]);
				objIssueItemTran.linktoIssueItemMasterId = Convert.ToInt32(sqlRdr["linktoIssueItemMasterId"]);
				objIssueItemTran.linktoItemMasterId = Convert.ToInt32(sqlRdr["linktoItemMasterId"]);
				objIssueItemTran.linktoUnitMasterId = Convert.ToInt16(sqlRdr["linktoUnitMasterId"]);
				objIssueItemTran.Quantity = Convert.ToDouble(sqlRdr["Quantity"]);

				/// Extra
				objIssueItemTran.IssueItem = Convert.ToInt32(sqlRdr["IssueItem"]);
				objIssueItemTran.Item = Convert.ToString(sqlRdr["Item"]);
				objIssueItemTran.Unit = Convert.ToString(sqlRdr["Unit"]);
				lstIssueItemTran.Add(objIssueItemTran);
			}
			return lstIssueItemTran;
		}
		#endregion

		#region Insert
		public posRecordStatus InsertIssueItemTran(SqlTransaction sqlTran,SqlConnection sqlCon)
		{
			//SqlConnection SqlCon = null;
			SqlCommand SqlCmd = null;
			try
			{
              
				//SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posIssueItemTran_Insert", sqlCon, sqlTran);
				SqlCmd.CommandType = CommandType.StoredProcedure;

				SqlCmd.Parameters.Add("@IssueItemTranId", SqlDbType.Int).Direction = ParameterDirection.Output;
				SqlCmd.Parameters.Add("@linktoIssueItemMasterId", SqlDbType.Int).Value = this.linktoIssueItemMasterId;
				SqlCmd.Parameters.Add("@linktoItemMasterId", SqlDbType.Int).Value = this.linktoItemMasterId;
				SqlCmd.Parameters.Add("@linktoUnitMasterId", SqlDbType.SmallInt).Value = this.linktoUnitMasterId;
				SqlCmd.Parameters.Add("@Quantity", SqlDbType.Decimal).Value = this.Quantity;
				SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

				//SqlCon.Open();
				SqlCmd.ExecuteNonQuery();
				//SqlCon.Close();

				this.IssueItemTranId = Convert.ToInt32(SqlCmd.Parameters["@IssueItemTranId"].Value);
				posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
				return rs;
			}
			catch (Exception ex)
			{
				posGlobalsDAL.SaveError(ex);
				return posRecordStatus.Error;
			}
			finally
			{
				posObjectFactoryDAL.DisposeCommand(SqlCmd);
				//posObjectFactoryDAL.DisposeConnection(SqlCon);
			}
		}
		#endregion

	    #region Delete
		public posRecordStatus DeleteIssueItemTran(SqlTransaction sqlTran,SqlConnection SqlCon)
		{
			//SqlConnection SqlCon = null;
			SqlCommand SqlCmd = null;
			try
			{
				//SqlCon = posObjectFactoryDAL.CreateConnection();
				SqlCmd = new SqlCommand("posIssueItemTran_Delete", SqlCon,sqlTran);
				SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@linktoIssueItemMasterId", SqlDbType.Int).Value = this.linktoIssueItemMasterId;
				SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

				//SqlCon.Open();
				SqlCmd.ExecuteNonQuery();
				//SqlCon.Close();

				posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
				return rs;
			}
			catch (Exception ex)
			{
				posGlobalsDAL.SaveError(ex);
				return posRecordStatus.Error;
			}
			finally
			{
				posObjectFactoryDAL.DisposeCommand(SqlCmd);
				//posObjectFactoryDAL.DisposeConnection(SqlCon);
			}
		}
		#endregion

		#region SelectAll
		public List<posIssueItemTranDAL> SelectAllIssueItemTran()
		{
			SqlConnection SqlCon = null;
			SqlCommand SqlCmd = null;
			SqlDataReader SqlRdr = null;
			try
			{
				SqlCon = posObjectFactoryDAL.CreateConnection();
				SqlCmd = new SqlCommand("posIssueItemTran_SelectAll", SqlCon);
				SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@linktoIssueItemMasterId", SqlDbType.SmallInt).Value = this.linktoIssueItemMasterId;

				SqlCon.Open();
				SqlRdr = SqlCmd.ExecuteReader();
				List<posIssueItemTranDAL> lstIssueItemTranDAL = SetListPropertiesFromSqlDataReader(SqlRdr);
				SqlRdr.Close();
				SqlCon.Close();

				return lstIssueItemTranDAL;
			}
			catch (Exception ex)
			{
				posGlobalsDAL.SaveError(ex);
				return null;
			}
			finally
			{
				posObjectFactoryDAL.DisposeDataReader(SqlRdr);
				posObjectFactoryDAL.DisposeCommand(SqlCmd);
				posObjectFactoryDAL.DisposeConnection(SqlCon);
			}
		}
		#endregion
	}
}
