using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace posLibrary
{
    /// <summary>
    /// Class for posRateCaptionMaster
    /// </summary>
    public class posRateCaptionMasterDAL
    {
        #region Properties
        public short RateCaptionMasterId { get; set; }
        public string RateName { get; set; }
        public string RateCaption { get; set; }
        public short linktoBusinessMasterId { get; set; }
        public short RateIndex { get; set; }
        public bool IsEnabled { get; set; }
        #endregion

        #region Class Methods

        private List<posRateCaptionMasterDAL> SetListPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            List<posRateCaptionMasterDAL> lstRateCaptionMaster = new List<posRateCaptionMasterDAL>();
            posRateCaptionMasterDAL objRateCaptionMaster = null;
            while (sqlRdr.Read())
            {
                objRateCaptionMaster = new posRateCaptionMasterDAL();
                objRateCaptionMaster.RateCaptionMasterId = Convert.ToInt16(sqlRdr["RateCaptionMasterId"]);
                objRateCaptionMaster.RateName = Convert.ToString(sqlRdr["RateName"]);
                objRateCaptionMaster.RateCaption = Convert.ToString(sqlRdr["RateCaption"]);
                objRateCaptionMaster.linktoBusinessMasterId = Convert.ToInt16(sqlRdr["linktoBusinessMasterId"]);
                objRateCaptionMaster.RateIndex = Convert.ToInt16(sqlRdr["RateIndex"]);
                objRateCaptionMaster.IsEnabled = Convert.ToBoolean(sqlRdr["IsEnabled"]);
                lstRateCaptionMaster.Add(objRateCaptionMaster);
            }
            return lstRateCaptionMaster;
        }
        #endregion

        #region Insert
        public posRecordStatus InsertRateCaptionMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posRateCaptionMaster_Insert", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@RateCaptionMasterId", SqlDbType.SmallInt).Direction = ParameterDirection.Output;
                SqlCmd.Parameters.Add("@RateName", SqlDbType.VarChar).Value = this.RateName;
                SqlCmd.Parameters.Add("@RateCaption", SqlDbType.VarChar).Value = this.RateCaption;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCmd.Parameters.Add("@RateIndex", SqlDbType.SmallInt).Value = this.RateIndex;
                SqlCmd.Parameters.Add("@IsEnabled", SqlDbType.Bit).Value = this.IsEnabled;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                this.RateCaptionMasterId = Convert.ToInt16(SqlCmd.Parameters["@RateCaptionMasterId"].Value);
                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region SelectAll

        public List<posRateCaptionMasterDAL> SelectAllRateCaptionMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posRateCaptionMaster_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<posRateCaptionMasterDAL> lstRateCaptionMasterDAL = SetListPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                return lstRateCaptionMasterDAL;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion
    }
}
