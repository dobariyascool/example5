using System;
using System.Data;
using System.Data.SqlClient;
using System.Collections.Generic;

namespace posLibrary
{
	/// <summary>
	/// Class for posSalesItemModifierTran
	/// </summary>
	public class posSalesItemModifierTranDAL
	{
		#region Properties
		public long SalesItemModifierTranId { get; set; }
		public long linktoSalesItemTranId { get; set; }
        public int linktoItemMasterId { get; set; }
		public double Rate { get; set; }
		#endregion

		#region Insert
        public static posRecordStatus InsertSalesItemModifierTran(List<posItemMasterDAL> lstSaleItemModifierTranDAL, long linktoSaleItemTranId, SqlConnection SqlCon, SqlTransaction SqlTran)
		{			
			SqlCommand SqlCmd = null;
            posRecordStatus rs = posRecordStatus.Error;
			try
			{				
				SqlCmd = new SqlCommand("posSalesItemModifierTran_Insert", SqlCon,SqlTran);
				SqlCmd.CommandType = CommandType.StoredProcedure;
                if (lstSaleItemModifierTranDAL != null || lstSaleItemModifierTranDAL.Count > 0)
                {
                    foreach (posItemMasterDAL objItemMasterDAL in lstSaleItemModifierTranDAL)
                    {
                        SqlCmd.Parameters.Clear();
                        SqlCmd.Parameters.Add("@SalesItemModifierTranId", SqlDbType.BigInt).Direction = ParameterDirection.Output;
                        SqlCmd.Parameters.Add("@linktoSalesItemTranId", SqlDbType.BigInt).Value = linktoSaleItemTranId;
                        SqlCmd.Parameters.Add("@linktoItemMasterId", SqlDbType.Int).Value = Convert.ToInt16(objItemMasterDAL.ItemModifierMasterIds);
                        SqlCmd.Parameters.Add("@Rate", SqlDbType.Money).Value = objItemMasterDAL.ActualSaleRate;
                        SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                        SqlCmd.ExecuteNonQuery();

                        rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;

                        if (rs != posRecordStatus.Success)
                        {
                            return posRecordStatus.Error;
                        }
                    }
                }
				return rs;
			}
			catch (Exception ex)
			{
				posGlobalsDAL.SaveError(ex);
				return posRecordStatus.Error;
			}
			finally
			{
				posObjectFactoryDAL.DisposeCommand(SqlCmd);
			}
		}

        public static posRecordStatus InsertSalesItemModifierTran(List<posOrderItemDAL> lstSalesItemModifierTranDAL, long linktoSalesItemTranId, SqlConnection SqlCon, SqlTransaction SqlTran)
        {
            SqlCommand SqlCmd = null;
            posRecordStatus rs = posRecordStatus.Error;
            try
            {
                SqlCmd = new SqlCommand("posSalesItemModifierTran_Insert", SqlCon, SqlTran);
                SqlCmd.CommandType = CommandType.StoredProcedure;
                if (lstSalesItemModifierTranDAL != null || lstSalesItemModifierTranDAL.Count > 0)
                {
                    foreach (posOrderItemDAL objItemMasterDAL in lstSalesItemModifierTranDAL)
                    {
                        SqlCmd.Parameters.Clear();
                        SqlCmd.Parameters.Add("@SalesItemModifierTranId", SqlDbType.BigInt).Direction = ParameterDirection.Output;
                        SqlCmd.Parameters.Add("@linktoSalesItemTranId", SqlDbType.BigInt).Value = linktoSalesItemTranId;
                        SqlCmd.Parameters.Add("@linktoItemMasterId", SqlDbType.Int).Value = Convert.ToInt16(objItemMasterDAL.linktoItemMasterIdModifier);
                        SqlCmd.Parameters.Add("@Rate", SqlDbType.Money).Value = objItemMasterDAL.MRP;
                        SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                        SqlCmd.ExecuteNonQuery();

                        rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                        if (rs != posRecordStatus.Success)
                        {
                            return posRecordStatus.Error;
                        }
                    }
                }
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
            }
        }
		#endregion
		
		#region Delete
        public static posRecordStatus DeleteSalesItemModifierTran(long linktoSalesItemTranId, SqlConnection SqlCon, SqlTransaction SqlTran)
		{
			SqlCommand SqlCmd = null;
			try
			{				
				SqlCmd = new SqlCommand("posSalesItemModifierTran_Delete", SqlCon,SqlTran);
				SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@linktoSalesItemTranId", SqlDbType.BigInt).Value = linktoSalesItemTranId;
				SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

				SqlCmd.ExecuteNonQuery();
			
				posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
				return rs;
			}
			catch (Exception ex)
			{
				posGlobalsDAL.SaveError(ex);
				return posRecordStatus.Error;
			}
			finally
			{
				posObjectFactoryDAL.DisposeCommand(SqlCmd);				
			}
		}
		#endregion
	
	}
}
