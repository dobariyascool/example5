using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace posLibrary
{
	/// <summary>
	/// Class for posItemRemarkMaster
	/// </summary>
	public class posItemRemarkMasterDAL
	{
		#region Properties
		public short ItemRemarkMasterId { get; set; }
		public string ItemRemark { get; set; }
		public short linktoBusinessMasterId { get; set; }

		/// Extra
		public string Business { get; set; }
		#endregion

		#region Class Methods
		private List<posItemRemarkMasterDAL> SetListPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
		{
			List<posItemRemarkMasterDAL> lstItemRemarkMaster = new List<posItemRemarkMasterDAL>();
			posItemRemarkMasterDAL objItemRemarkMaster = null;
			while (sqlRdr.Read())
			{
				objItemRemarkMaster = new posItemRemarkMasterDAL();
				objItemRemarkMaster.ItemRemarkMasterId = Convert.ToInt16(sqlRdr["ItemRemarkMasterId"]);
				objItemRemarkMaster.ItemRemark = Convert.ToString(sqlRdr["ItemRemark"]);
				objItemRemarkMaster.linktoBusinessMasterId = Convert.ToInt16(sqlRdr["linktoBusinessMasterId"]);

				/// Extra
				objItemRemarkMaster.Business = Convert.ToString(sqlRdr["Business"]);
				lstItemRemarkMaster.Add(objItemRemarkMaster);
			}
			return lstItemRemarkMaster;
		}
		#endregion

		#region Insert
		public posRecordStatus InsertItemRemarkMaster()
		{
			SqlConnection SqlCon = null;
			SqlCommand SqlCmd = null;
			try
			{
				SqlCon = posObjectFactoryDAL.CreateConnection();
				SqlCmd = new SqlCommand("posItemRemarkMaster_Insert", SqlCon);
				SqlCmd.CommandType = CommandType.StoredProcedure;

				SqlCmd.Parameters.Add("@ItemRemarkMasterId", SqlDbType.SmallInt).Direction = ParameterDirection.Output;
				SqlCmd.Parameters.Add("@ItemRemark", SqlDbType.VarChar).Value = this.ItemRemark;
				SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
				SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

				SqlCon.Open();
				SqlCmd.ExecuteNonQuery();
				SqlCon.Close();

				this.ItemRemarkMasterId = Convert.ToInt16(SqlCmd.Parameters["@ItemRemarkMasterId"].Value);
				posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
				return rs;
			}
			catch (Exception ex)
			{
				posGlobalsDAL.SaveError(ex);
				return posRecordStatus.Error;
			}
			finally
			{
				posObjectFactoryDAL.DisposeCommand(SqlCmd);
				posObjectFactoryDAL.DisposeConnection(SqlCon);
			}
		}
		#endregion	

		#region Delete
		public posRecordStatus DeleteItemRemarkMaster()
		{
			SqlConnection SqlCon = null;
			SqlCommand SqlCmd = null;
			try
			{
				SqlCon = posObjectFactoryDAL.CreateConnection();
				SqlCmd = new SqlCommand("posItemRemarkMaster_Delete", SqlCon);
				SqlCmd.CommandType = CommandType.StoredProcedure;

				SqlCmd.Parameters.Add("@ItemRemarkMasterId", SqlDbType.SmallInt).Value = this.ItemRemarkMasterId;
				SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

				SqlCon.Open();
				SqlCmd.ExecuteNonQuery();
				SqlCon.Close();

				posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
				return rs;
			}
			catch (Exception ex)
			{
				posGlobalsDAL.SaveError(ex);
				return posRecordStatus.Error;
			}
			finally
			{
				posObjectFactoryDAL.DisposeCommand(SqlCmd);
				posObjectFactoryDAL.DisposeConnection(SqlCon);
			}
		}
		#endregion

		#region SelectAll
		public List<posItemRemarkMasterDAL> SelectAllItemRemarkMaster()
		{
			SqlConnection SqlCon = null;
			SqlCommand SqlCmd = null;
			SqlDataReader SqlRdr = null;
			try
			{
				SqlCon = posObjectFactoryDAL.CreateConnection();
				SqlCmd = new SqlCommand("posItemRemarkMaster_SelectAll", SqlCon);
				SqlCmd.CommandType = CommandType.StoredProcedure;


                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;

				SqlCon.Open();
				SqlRdr = SqlCmd.ExecuteReader();
				List<posItemRemarkMasterDAL> lstItemRemarkMasterDAL = SetListPropertiesFromSqlDataReader(SqlRdr);
				SqlRdr.Close();
				SqlCon.Close();

				return lstItemRemarkMasterDAL;
			}
			catch (Exception ex)
			{
				posGlobalsDAL.SaveError(ex);
				return null;
			}
			finally
			{
				posObjectFactoryDAL.DisposeDataReader(SqlRdr);
				posObjectFactoryDAL.DisposeCommand(SqlCmd);
				posObjectFactoryDAL.DisposeConnection(SqlCon);
			}
		}		
		#endregion
	}
}
