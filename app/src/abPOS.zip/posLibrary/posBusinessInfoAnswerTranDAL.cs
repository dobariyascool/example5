using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace posLibrary
{
    /// <summary>
    /// Class for posBusinessInfoAnswerTran
    /// </summary>
    public class posBusinessInfoAnswerTranDAL
    {
        #region Properties
        public int BusinessInfoAnswerTranId { get; set; }
        public short linktoBusinessMasterId { get; set; }
        public int linktoBusinessInfoQuestionMasterId { get; set; }
        public int? linktoBusinessInfoAnswerMasterId { get; set; }
        public string Answer { get; set; }
        public DateTime CreateDateTime { get; set; }
        public short linktoUserMasterIdCreatedBy { get; set; }
        #endregion

        #region Insert
        public posRecordStatus InsertBusinessInfoAnswerTran(List<posBusinessInfoAnswerTranDAL> lstBusinessInfoAnswerTran)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlTransaction SqlTran = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCon.Open();
                SqlTran = SqlCon.BeginTransaction();
                SqlCmd = new SqlCommand("posBusinessInfoAnswerTran_Delete", SqlCon, SqlTran);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCmd.ExecuteNonQuery();

                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;

                if (rs != posRecordStatus.Success)
                {
                    SqlTran.Rollback();
                    SqlCon.Close();
                    return rs;
                }
                SqlCmd = new SqlCommand("posBusinessInfoAnswerTran_Insert", SqlCon, SqlTran);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                posRecordStatus rstatus = posRecordStatus.Error;
                foreach (posBusinessInfoAnswerTranDAL obj in lstBusinessInfoAnswerTran)
                {
                    SqlCmd.Parameters.Clear();
                    SqlCmd.Parameters.Add("@BusinessInfoAnswerTranId", SqlDbType.Int).Direction = ParameterDirection.Output;
                    SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = obj.linktoBusinessMasterId;
                    SqlCmd.Parameters.Add("@linktoBusinessInfoQuestionMasterId", SqlDbType.Int).Value = obj.linktoBusinessInfoQuestionMasterId;
                    SqlCmd.Parameters.Add("@linktoBusinessInfoAnswerMasterId", SqlDbType.Int).Value = obj.linktoBusinessInfoAnswerMasterId;
                    SqlCmd.Parameters.Add("@Answer", SqlDbType.VarChar).Value = obj.Answer;
                    SqlCmd.Parameters.Add("@CreateDateTime", SqlDbType.DateTime).Value = obj.CreateDateTime;
                    SqlCmd.Parameters.Add("@linktoUserMasterIdCreatedBy", SqlDbType.SmallInt).Value = obj.linktoUserMasterIdCreatedBy;
                    SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                    obj.BusinessInfoAnswerTranId = Convert.ToInt32(SqlCmd.Parameters["@BusinessInfoAnswerTranId"].Value);

                    SqlCmd.ExecuteNonQuery();
                    rstatus = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                    if (rstatus != posRecordStatus.Success)
                    {
                        SqlTran.Rollback();
                        SqlCon.Close();
                        return rs;
                    }
                }
                SqlTran.Commit();
                SqlCon.Close();
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
                posObjectFactoryDAL.DisposeTransaction(SqlTran);
            }
        }
        #endregion
    }
}
