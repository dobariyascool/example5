﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace posLibrary
{
    /// <summary>
    /// Class for posFeedbackTypeMaster
    /// </summary>
    public class posFeedbackTypeMasterDAL
    {
        #region Properties
        public short FeedbackTypeMasterId { get; set; }
        public string FeedbackType { get; set; }
        #endregion

        #region Class Methods
        private List<posFeedbackTypeMasterDAL> SetListPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            List<posFeedbackTypeMasterDAL> lstFeedbackTypeMaster = new List<posFeedbackTypeMasterDAL>();
            posFeedbackTypeMasterDAL objFeedbackTypeMaster = null;
            while (sqlRdr.Read())
            {
                objFeedbackTypeMaster = new posFeedbackTypeMasterDAL();
                objFeedbackTypeMaster.FeedbackTypeMasterId = Convert.ToInt16(sqlRdr["FeedbackTypeMasterId"]);
                objFeedbackTypeMaster.FeedbackType = Convert.ToString(sqlRdr["FeedbackType"]);
                lstFeedbackTypeMaster.Add(objFeedbackTypeMaster);
            }
            return lstFeedbackTypeMaster;
        }
        #endregion
    }
}
