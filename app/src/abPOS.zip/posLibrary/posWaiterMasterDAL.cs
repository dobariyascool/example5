using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace posLibrary
{
    /// <summary>
    /// Class for posWaiterMaster
    /// </summary>
    public class posWaiterMasterDAL
    {
        #region Properties
        public int WaiterMasterId { get; set; }
        public string ShortName { get; set; }
        public string WaiterName { get; set; }
        public short? linktoUserMasterId { get; set; }
        public string Description { get; set; }
        public bool IsEnabled { get; set; }
        public bool IsDeleted { get; set; }
        public DateTime CreateDateTime { get; set; }
        public short linktoUserMasterIdCreatedBy { get; set; }
        public DateTime? UpdateDateTime { get; set; }
        public short? linktoUserMasterIdUpdatedBy { get; set; }
        public short linktoBusinessMasterId { get; set; }
        public short WaiterType { get; set; }
        public bool? IsOut { get; set; }
        public DateTime? InOutDateTime { get; set; }

        // Extra
        public string NameWithOutTime { get; set; }
        public string NameWitInTime { get; set; }
        public string WaiterTypeText { get; set; }
        #endregion

        #region Class Methods
        private bool SetClassPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            if (sqlRdr.Read())
            {
                this.WaiterMasterId = Convert.ToInt32(sqlRdr["WaiterMasterId"]);
                this.ShortName = Convert.ToString(sqlRdr["ShortName"]);
                this.WaiterName = Convert.ToString(sqlRdr["WaiterName"]);
                if (sqlRdr["linktoUserMasterId"] != DBNull.Value)
                {
                    this.linktoUserMasterId = Convert.ToInt16(sqlRdr["linktoUserMasterId"]);
                }
                this.Description = Convert.ToString(sqlRdr["Description"]);
                this.IsEnabled = Convert.ToBoolean(sqlRdr["IsEnabled"]);
                this.IsDeleted = Convert.ToBoolean(sqlRdr["IsDeleted"]);
                this.CreateDateTime = Convert.ToDateTime(sqlRdr["CreateDateTime"]);
                this.linktoUserMasterIdCreatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdCreatedBy"]);
                if (sqlRdr["UpdateDateTime"] != DBNull.Value)
                {
                    this.UpdateDateTime = Convert.ToDateTime(sqlRdr["UpdateDateTime"]);
                }
                if (sqlRdr["linktoUserMasterIdUpdatedBy"] != DBNull.Value)
                {
                    this.linktoUserMasterIdUpdatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdUpdatedBy"]);
                }
                if (sqlRdr["IsOut"] != DBNull.Value)
                {
                    this.IsOut = Convert.ToBoolean(sqlRdr["IsOut"]);
                }
                if (sqlRdr["InOutDateTime"] != DBNull.Value)
                {
                    this.InOutDateTime = Convert.ToDateTime(sqlRdr["InOutDateTime"]);
                }

                return true;
            }
            return false;
        }

        private List<posWaiterMasterDAL> SetListPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            List<posWaiterMasterDAL> lstWaiterMaster = new List<posWaiterMasterDAL>();
            posWaiterMasterDAL objWaiterMaster = null;
            while (sqlRdr.Read())
            {
                objWaiterMaster = new posWaiterMasterDAL();
                objWaiterMaster.WaiterMasterId = Convert.ToInt32(sqlRdr["WaiterMasterId"]);
                objWaiterMaster.ShortName = Convert.ToString(sqlRdr["ShortName"]);
                objWaiterMaster.WaiterName = Convert.ToString(sqlRdr["WaiterName"]);
                if (sqlRdr["linktoUserMasterId"] != DBNull.Value)
                {
                    objWaiterMaster.linktoUserMasterId = Convert.ToInt16(sqlRdr["linktoUserMasterId"]);
                }
                objWaiterMaster.Description = Convert.ToString(sqlRdr["Description"]);
                objWaiterMaster.IsEnabled = Convert.ToBoolean(sqlRdr["IsEnabled"]);
                objWaiterMaster.IsDeleted = Convert.ToBoolean(sqlRdr["IsDeleted"]);
                objWaiterMaster.CreateDateTime = Convert.ToDateTime(sqlRdr["CreateDateTime"]);
                objWaiterMaster.linktoUserMasterIdCreatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdCreatedBy"]);
                if (sqlRdr["UpdateDateTime"] != DBNull.Value)
                {
                    objWaiterMaster.UpdateDateTime = Convert.ToDateTime(sqlRdr["UpdateDateTime"]);
                }
                if (sqlRdr["linktoUserMasterIdUpdatedBy"] != DBNull.Value)
                {
                    objWaiterMaster.linktoUserMasterIdUpdatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdUpdatedBy"]);
                }
                if (sqlRdr["InOutDateTime"] != DBNull.Value)
                {
                    objWaiterMaster.InOutDateTime = Convert.ToDateTime(sqlRdr["InOutDateTime"]);
                }

                if (sqlRdr["IsOut"] != DBNull.Value)
                {
                    objWaiterMaster.IsOut = Convert.ToBoolean(sqlRdr["IsOut"]);
                }
                if (Convert.ToBoolean(objWaiterMaster.IsOut))
                {
                    objWaiterMaster.NameWithOutTime = InTimeCalculation(objWaiterMaster.WaiterName, Convert.ToDateTime(objWaiterMaster.InOutDateTime));
                }
                else
                {
                    objWaiterMaster.NameWitInTime = InTimeCalculation(objWaiterMaster.WaiterName, Convert.ToDateTime(objWaiterMaster.InOutDateTime));
                }

                lstWaiterMaster.Add(objWaiterMaster);
            }
            return lstWaiterMaster;
        }
        #endregion

        #region Insert
        public posRecordStatus InsertWaiterMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posWaiterMaster_Insert", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@WaiterMasterId", SqlDbType.Int).Direction = ParameterDirection.Output;
                SqlCmd.Parameters.Add("@ShortName", SqlDbType.VarChar).Value = this.ShortName;
                SqlCmd.Parameters.Add("@WaiterName", SqlDbType.VarChar).Value = this.WaiterName;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCmd.Parameters.Add("@Description", SqlDbType.VarChar).Value = this.Description;
                SqlCmd.Parameters.Add("@WaiterType", SqlDbType.SmallInt).Value = this.WaiterType;
                SqlCmd.Parameters.Add("@IsEnabled", SqlDbType.Bit).Value = this.IsEnabled;
                SqlCmd.Parameters.Add("@IsDeleted", SqlDbType.Bit).Value = this.IsDeleted;
                SqlCmd.Parameters.Add("@CreateDateTime", SqlDbType.DateTime).Value = this.CreateDateTime;
                SqlCmd.Parameters.Add("@linktoUserMasterIdCreatedBy", SqlDbType.SmallInt).Value = this.linktoUserMasterIdCreatedBy;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                this.WaiterMasterId = Convert.ToInt32(SqlCmd.Parameters["@WaiterMasterId"].Value);
                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public posRecordStatus InsertWaiterMaster(List<posWaiterMasterDAL> lstWaiterMasterDAL, SqlConnection SqlCon, SqlTransaction SqlTran)
        {
            SqlCommand SqlCmd = null;
            try
            {
                posRecordStatus rs = posRecordStatus.Error;
                SqlCmd = new SqlCommand("posWaiterMaster_Insert", SqlCon, SqlTran);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                foreach (posWaiterMasterDAL objWaiterMaster in lstWaiterMasterDAL)
                {
                    SqlCmd.Parameters.Clear();
                    SqlCmd.Parameters.Add("@WaiterMasterId", SqlDbType.Int).Direction = ParameterDirection.Output;
                    SqlCmd.Parameters.Add("@ShortName", SqlDbType.VarChar).Value = objWaiterMaster.ShortName;
                    SqlCmd.Parameters.Add("@WaiterName", SqlDbType.VarChar).Value = objWaiterMaster.WaiterName;
                    SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                    SqlCmd.Parameters.Add("@Description", SqlDbType.VarChar).Value = objWaiterMaster.Description;
                    SqlCmd.Parameters.Add("@WaiterType", SqlDbType.SmallInt).Value = objWaiterMaster.WaiterType;
                    SqlCmd.Parameters.Add("@IsEnabled", SqlDbType.Bit).Value = objWaiterMaster.IsEnabled;
                    SqlCmd.Parameters.Add("@IsDeleted", SqlDbType.Bit).Value = objWaiterMaster.IsDeleted;
                    SqlCmd.Parameters.Add("@CreateDateTime", SqlDbType.DateTime).Value = objWaiterMaster.CreateDateTime;
                    SqlCmd.Parameters.Add("@linktoUserMasterIdCreatedBy", SqlDbType.SmallInt).Value = this.linktoUserMasterIdCreatedBy;
                    SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                    SqlCmd.ExecuteNonQuery();

                    this.WaiterMasterId = Convert.ToInt32(SqlCmd.Parameters["@WaiterMasterId"].Value);
                    rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                    if (rs != posRecordStatus.Success)
                    {
                        return rs;
                    }
                }
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
            }
        }
        #endregion

        #region Update
        public posRecordStatus UpdateWaiterMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posWaiterMaster_Update", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@WaiterMasterId", SqlDbType.Int).Value = this.WaiterMasterId;
                SqlCmd.Parameters.Add("@ShortName", SqlDbType.VarChar).Value = this.ShortName;
                SqlCmd.Parameters.Add("@WaiterName", SqlDbType.VarChar).Value = this.WaiterName;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCmd.Parameters.Add("@WaiterType", SqlDbType.SmallInt).Value = this.WaiterType;
                SqlCmd.Parameters.Add("@Description", SqlDbType.VarChar).Value = this.Description;
                SqlCmd.Parameters.Add("@IsEnabled", SqlDbType.Bit).Value = this.IsEnabled;
                SqlCmd.Parameters.Add("@IsDeleted", SqlDbType.Bit).Value = this.IsDeleted;
                SqlCmd.Parameters.Add("@UpdateDateTime", SqlDbType.DateTime).Value = this.UpdateDateTime;
                SqlCmd.Parameters.Add("@linktoUserMasterIdUpdatedBy", SqlDbType.SmallInt).Value = this.linktoUserMasterIdUpdatedBy;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public static posRecordStatus UpdateWaiterMasterbyHomeDeliveryOrders(int waiterMasterId, bool isOut, SqlConnection SqlCon, SqlTransaction SqlTran)
        {

            SqlCommand SqlCmd = null;
            try
            {
                SqlCmd = new SqlCommand("posWaiterMasterByHomeDeliveryOrders_Update", SqlCon, SqlTran);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@WaiterMasterId", SqlDbType.Int).Value = waiterMasterId;
                SqlCmd.Parameters.Add("@IsOut", SqlDbType.Bit).Value = isOut;
                SqlCmd.Parameters.Add("@InOutDateTime", SqlDbType.DateTime).Value = posGlobalsDAL.GetCurrentDateTime();
                SqlCmd.Parameters.Add("@UpdateDateTime", SqlDbType.DateTime).Value = posGlobalsDAL.GetCurrentDateTime();
                SqlCmd.Parameters.Add("@linktoUserMasterIdUpdatedBy", SqlDbType.SmallInt).Value = posGlobalsDAL.UserInfo.UserMasterId;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCmd.ExecuteNonQuery();

                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
            }
        }

        public posRecordStatus UpdateWaiterMasterIsOutStatus()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posWaiterMasterIsOut_Update", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@WaiterMasterId", SqlDbType.Int).Value = this.WaiterMasterId;
                SqlCmd.Parameters.Add("@IsOut", SqlDbType.Bit).Value = this.IsOut;
                SqlCmd.Parameters.Add("@InOutDateTime", SqlDbType.DateTime).Value = posGlobalsDAL.GetCurrentDateTime();
                SqlCmd.Parameters.Add("@UpdateDateTime", SqlDbType.DateTime).Value = posGlobalsDAL.GetCurrentDateTime();
                SqlCmd.Parameters.Add("@linktoUserMasterIdUpdatedBy", SqlDbType.SmallInt).Value = posGlobalsDAL.UserInfo.UserMasterId;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public static posRecordStatus UpdateWaiterMasterRemoveUsers(SqlConnection sqlCon, SqlTransaction sqlTran)
        {
            SqlCommand SqlCmd = null;
            try
            {
                SqlCmd = new SqlCommand("posWaiterMasterRemoveUsers_Update", sqlCon, sqlTran);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCmd.ExecuteNonQuery();

                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
            }
        }

        public static posRecordStatus UpdateWaiterMasterUserMasterId(List<posWaiterMasterDAL> lstWaiterMasterDAL)
        {
            SqlTransaction SqlTran = null;
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posWaiterMasterUserMasterId_Update", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCon.Open();
                SqlTran = SqlCon.BeginTransaction();
                SqlCmd.Transaction = SqlTran;

                posRecordStatus rs = posRecordStatus.Error;
                rs = UpdateWaiterMasterRemoveUsers(SqlCon, SqlTran);
                if (rs != posRecordStatus.Success)
                {
                    SqlTran.Rollback();
                    return rs;
                }

                foreach (posWaiterMasterDAL obj in lstWaiterMasterDAL)
                {
                    SqlCmd.Parameters.Clear();
                    SqlCmd.Parameters.Add("@WaiterMasterId", SqlDbType.Int).Value = obj.WaiterMasterId;
                    SqlCmd.Parameters.Add("@linktoUserMasterId", SqlDbType.SmallInt).Value = obj.linktoUserMasterId;
                    SqlCmd.Parameters.Add("@UpdateDateTime", SqlDbType.DateTime).Value = obj.UpdateDateTime;
                    SqlCmd.Parameters.Add("@linktoUserMasterIdUpdatedBy", SqlDbType.SmallInt).Value = obj.linktoUserMasterIdUpdatedBy;
                    SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                    SqlCmd.ExecuteNonQuery();

                    rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                    if (rs != posRecordStatus.Success)
                    {
                        SqlTran.Rollback();
                    }
                }

                SqlTran.Commit();
                SqlCon.Close();
                return rs;
            }
            catch (Exception ex)
            {
                if (SqlTran != null)
                {
                    SqlTran.Rollback();
                }
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeTransaction(SqlTran);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region DeleteAll
        public static posRecordStatus DeleteAllWaiterMaster(string waiterMasterIds, posWaiterType waiterType)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();

                SqlCmd = new SqlCommand("posWaiterMaster_DeleteAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@WaiterMasterIds", SqlDbType.VarChar).Value = waiterMasterIds;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;
                if (waiterType == posWaiterType.Waiter)
                {
                    SqlCmd.Parameters.Add("@WaiterType", SqlDbType.Int).Value = posWaiterType.Waiter.GetHashCode();
                }
                else
                {
                    SqlCmd.Parameters.Add("@WaiterType", SqlDbType.Int).Value = posWaiterType.Captain.GetHashCode();
                }

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region Select
        public bool SelectWaiterMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posWaiterMaster_Select", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@WaiterMasterId", SqlDbType.Int).Value = this.WaiterMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                bool IsSelected = SetClassPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                return IsSelected;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return false;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region SelectAll
        public List<posWaiterMasterDAL> SelectAllWaiterMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posWaiterMaster_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@IsEnabled", SqlDbType.Bit).Value = this.IsEnabled;
                if (!String.IsNullOrEmpty(this.WaiterName))
                {
                    SqlCmd.Parameters.Add("@WaiterName", SqlDbType.VarChar).Value = this.WaiterName;
                }
                SqlCmd.Parameters.Add("@WaiterType", SqlDbType.SmallInt).Value = this.WaiterType;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<posWaiterMasterDAL> lstWaiterMasterDAL = SetListPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                return lstWaiterMasterDAL;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public static List<posWaiterMasterDAL> SelectAllWaiterMasterWaiterName(short? waiterType, short linktoBusinessMasterId)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posWaiterMasterWaiterName_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;
                if (waiterType != null)
                {
                    SqlCmd.Parameters.Add("@WaiterType", SqlDbType.SmallInt).Value = waiterType;
                }
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = linktoBusinessMasterId;
                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<posWaiterMasterDAL> lstWaiterMasterDAL = new List<posWaiterMasterDAL>();
                posWaiterMasterDAL objWaiterMasterDAL = null;
                while (SqlRdr.Read())
                {
                    objWaiterMasterDAL = new posWaiterMasterDAL();
                    objWaiterMasterDAL.WaiterMasterId = Convert.ToInt32(SqlRdr["WaiterMasterId"]);
                    objWaiterMasterDAL.WaiterName = Convert.ToString(SqlRdr["WaiterName"]);
                    objWaiterMasterDAL.WaiterType = Convert.ToInt16(SqlRdr["WaiterType"]);

                    lstWaiterMasterDAL.Add(objWaiterMasterDAL);
                }
                SqlRdr.Close();
                SqlCon.Close();

                return lstWaiterMasterDAL;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region Private Functions
        private string InTimeCalculation(string waiterName, DateTime inOutTime)
        {
            TimeSpan NewTime = posGlobalsDAL.GetCurrentDateTime() - inOutTime;
            return waiterName + " (" + NewTime.Hours.ToString("00") + ":" + NewTime.Minutes.ToString("00") + ")";
        }
        #endregion
    }
}
