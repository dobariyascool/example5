using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace posLibrary
{
	/// <summary>
	/// Class for posStockAdjustmentMaster
	/// </summary>
	public class posStockAdjustmentMasterDAL
	{
		#region Properties
		public int StockAdjustmentMasterId { get; set; }
		public string VoucherNumber { get; set; }
		public DateTime AdjustmentDate { get; set; }
		public short linktoDepartmentMasterId { get; set; }
		public string Remark { get; set; }
		public DateTime CreateDateTime { get; set; }
		public short linktoUserMasterIdCreatedBy { get; set; }
		public DateTime? UpdateDateTime { get; set; }
		public short? linktoUserMasterIdUpdatedBy { get; set; }

		/// Extra
		public string Department { get; set; }
        public List<posStockAdjustmentItemTranDAL> lstStockAdjustmentItemTranDAL { get; set; }
		#endregion

		#region Class Methods
		private bool SetClassPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
		{
			if (sqlRdr.Read())
			{
				this.StockAdjustmentMasterId = Convert.ToInt32(sqlRdr["StockAdjustmentMasterId"]);
				this.VoucherNumber = Convert.ToString(sqlRdr["VoucherNumber"]);
				this.AdjustmentDate = Convert.ToDateTime(sqlRdr["AdjustmentDate"]);
				this.linktoDepartmentMasterId = Convert.ToInt16(sqlRdr["linktoDepartmentMasterId"]);
				this.Remark = Convert.ToString(sqlRdr["Remark"]);
				this.CreateDateTime = Convert.ToDateTime(sqlRdr["CreateDateTime"]);
				this.linktoUserMasterIdCreatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdCreatedBy"]);
				if (sqlRdr["UpdateDateTime"] != DBNull.Value)
				{
					this.UpdateDateTime = Convert.ToDateTime(sqlRdr["UpdateDateTime"]);
				}
				if (sqlRdr["linktoUserMasterIdUpdatedBy"] != DBNull.Value)
				{
					this.linktoUserMasterIdUpdatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdUpdatedBy"]);
				}

				/// Extra
				this.Department = Convert.ToString(sqlRdr["Department"]);
				return true;
			}
			return false;
		}

		private List<posStockAdjustmentMasterDAL> SetListPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
		{
			List<posStockAdjustmentMasterDAL> lstStockAdjustmentMaster = new List<posStockAdjustmentMasterDAL>();
			posStockAdjustmentMasterDAL objStockAdjustmentMaster = null;
			while (sqlRdr.Read())
			{
				objStockAdjustmentMaster = new posStockAdjustmentMasterDAL();
				objStockAdjustmentMaster.StockAdjustmentMasterId = Convert.ToInt32(sqlRdr["StockAdjustmentMasterId"]);
				objStockAdjustmentMaster.VoucherNumber = Convert.ToString(sqlRdr["VoucherNumber"]);
				objStockAdjustmentMaster.AdjustmentDate = Convert.ToDateTime(sqlRdr["AdjustmentDate"]);
				objStockAdjustmentMaster.linktoDepartmentMasterId = Convert.ToInt16(sqlRdr["linktoDepartmentMasterId"]);
				objStockAdjustmentMaster.Remark = Convert.ToString(sqlRdr["Remark"]);
				objStockAdjustmentMaster.CreateDateTime = Convert.ToDateTime(sqlRdr["CreateDateTime"]);
				objStockAdjustmentMaster.linktoUserMasterIdCreatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdCreatedBy"]);
				if (sqlRdr["UpdateDateTime"] != DBNull.Value)
				{
					objStockAdjustmentMaster.UpdateDateTime = Convert.ToDateTime(sqlRdr["UpdateDateTime"]);
				}
				if (sqlRdr["linktoUserMasterIdUpdatedBy"] != DBNull.Value)
				{
					objStockAdjustmentMaster.linktoUserMasterIdUpdatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdUpdatedBy"]);
				}

				/// Extra
				objStockAdjustmentMaster.Department = Convert.ToString(sqlRdr["Department"]);
				lstStockAdjustmentMaster.Add(objStockAdjustmentMaster);
			}
			return lstStockAdjustmentMaster;
		}
		#endregion

		#region Insert
		public posRecordStatus InsertStockAdjustmentMaster()
		{
			SqlConnection SqlCon = null;
			SqlCommand SqlCmd = null;
            SqlTransaction SqlTran = null;
			try
			{
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCon.Open();
                SqlTran = SqlCon.BeginTransaction();
				SqlCmd = new SqlCommand("posStockAdjustmentMaster_Insert", SqlCon,SqlTran);
				SqlCmd.CommandType = CommandType.StoredProcedure;

				SqlCmd.Parameters.Add("@StockAdjustmentMasterId", SqlDbType.Int).Direction = ParameterDirection.Output;
				SqlCmd.Parameters.Add("@VoucherNumber", SqlDbType.VarChar).Value = this.VoucherNumber;
				SqlCmd.Parameters.Add("@AdjustmentDate", SqlDbType.Date).Value = this.AdjustmentDate;
				SqlCmd.Parameters.Add("@linktoDepartmentMasterId", SqlDbType.SmallInt).Value = this.linktoDepartmentMasterId;
				SqlCmd.Parameters.Add("@Remark", SqlDbType.VarChar).Value = this.Remark;
				SqlCmd.Parameters.Add("@CreateDateTime", SqlDbType.DateTime).Value = this.CreateDateTime;
				SqlCmd.Parameters.Add("@linktoUserMasterIdCreatedBy", SqlDbType.SmallInt).Value = this.linktoUserMasterIdCreatedBy;
				SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

				SqlCmd.ExecuteNonQuery();
			
				this.StockAdjustmentMasterId = Convert.ToInt32(SqlCmd.Parameters["@StockAdjustmentMasterId"].Value);
				posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;

                if (rs == posRecordStatus.Success)
                {
                    if (posStockAdjustmentItemTranDAL.InsertStockAdjustmentItemTran(this.lstStockAdjustmentItemTranDAL, this.StockAdjustmentMasterId, SqlCon, SqlTran) == posRecordStatus.Error)
                    {
                        SqlTran.Rollback();
                        return posRecordStatus.Error;
                    }
                }
                else
                {
                    SqlTran.Rollback();
                    return posRecordStatus.Error;
                }
                SqlTran.Commit();
                SqlCon.Close();
                return rs;
            }
			catch (Exception ex)
			{
				posGlobalsDAL.SaveError(ex);
				return posRecordStatus.Error;
			}
			finally
			{
				posObjectFactoryDAL.DisposeCommand(SqlCmd);
				posObjectFactoryDAL.DisposeConnection(SqlCon);
			}
		}
		#endregion

		#region Update
		public posRecordStatus UpdateStockAdjustmentMaster()
		{
			SqlConnection SqlCon = null;
			SqlCommand SqlCmd = null;
            SqlTransaction SqlTran = null;
			try
			{
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCon.Open();
                SqlTran = SqlCon.BeginTransaction();
				SqlCmd = new SqlCommand("posStockAdjustmentMaster_Update", SqlCon,SqlTran);
				SqlCmd.CommandType = CommandType.StoredProcedure;

				SqlCmd.Parameters.Add("@StockAdjustmentMasterId", SqlDbType.Int).Value = this.StockAdjustmentMasterId;
				SqlCmd.Parameters.Add("@VoucherNumber", SqlDbType.VarChar).Value = this.VoucherNumber;
				SqlCmd.Parameters.Add("@AdjustmentDate", SqlDbType.Date).Value = this.AdjustmentDate;
				SqlCmd.Parameters.Add("@linktoDepartmentMasterId", SqlDbType.SmallInt).Value = this.linktoDepartmentMasterId;
				SqlCmd.Parameters.Add("@Remark", SqlDbType.VarChar).Value = this.Remark;
				SqlCmd.Parameters.Add("@UpdateDateTime", SqlDbType.DateTime).Value = this.UpdateDateTime;
				SqlCmd.Parameters.Add("@linktoUserMasterIdUpdatedBy", SqlDbType.SmallInt).Value = this.linktoUserMasterIdUpdatedBy;
				SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

				SqlCmd.ExecuteNonQuery();
				
				posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;

                if (rs == posRecordStatus.Success)
                {
                    if (posStockAdjustmentItemTranDAL.InsertStockAdjustmentItemTran(this.lstStockAdjustmentItemTranDAL, this.StockAdjustmentMasterId, SqlCon, SqlTran) == posRecordStatus.Error)
                    {
                        SqlTran.Rollback();
                        return posRecordStatus.Error;
                    }
                }
                else
                {
                    SqlTran.Rollback();
                    return posRecordStatus.Error;
                }
                SqlTran.Commit();
                SqlCon.Close();
				return rs;
			}
			catch (Exception ex)
			{
				posGlobalsDAL.SaveError(ex);
				return posRecordStatus.Error;
			}
			finally
			{
				posObjectFactoryDAL.DisposeCommand(SqlCmd);
				posObjectFactoryDAL.DisposeConnection(SqlCon);
			}
		}
		#endregion

		#region DeleteAll
		public static posRecordStatus DeleteAllStockAdjustmentMaster(string stockAdjustmentMasterIds)
		{
			SqlConnection SqlCon = null;
			SqlCommand SqlCmd = null;
			try
			{
				SqlCon = posObjectFactoryDAL.CreateConnection();
				SqlCmd = new SqlCommand("posStockAdjustmentMaster_DeleteAll", SqlCon);
				SqlCmd.CommandType = CommandType.StoredProcedure;

				SqlCmd.Parameters.Add("@StockAdjustmentMasterIds", SqlDbType.VarChar).Value = stockAdjustmentMasterIds;
				SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

				SqlCon.Open();
				SqlCmd.ExecuteNonQuery();
				SqlCon.Close();

				posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
				return rs;
			}
			catch (Exception ex)
			{
				posGlobalsDAL.SaveError(ex);
				return posRecordStatus.Error;
			}
			finally
			{
				posObjectFactoryDAL.DisposeCommand(SqlCmd);
				posObjectFactoryDAL.DisposeConnection(SqlCon);
			}
		}
		#endregion

		#region Select
		public bool SelectStockAdjustmentMaster()
		{
			SqlConnection SqlCon = null;
			SqlCommand SqlCmd = null;
			SqlDataReader SqlRdr = null;
			try
			{
				SqlCon = posObjectFactoryDAL.CreateConnection();
				SqlCmd = new SqlCommand("posStockAdjustmentMaster_Select", SqlCon);
				SqlCmd.CommandType = CommandType.StoredProcedure;

				SqlCmd.Parameters.Add("@StockAdjustmentMasterId", SqlDbType.Int).Value = this.StockAdjustmentMasterId;

				SqlCon.Open();
				SqlRdr = SqlCmd.ExecuteReader();
				bool IsSelected = SetClassPropertiesFromSqlDataReader(SqlRdr);
				SqlRdr.Close();
				SqlCon.Close();

				return IsSelected;
			}
			catch (Exception ex)
			{
				posGlobalsDAL.SaveError(ex);
				return false;
			}
			finally
			{
				posObjectFactoryDAL.DisposeDataReader(SqlRdr);
				posObjectFactoryDAL.DisposeCommand(SqlCmd);
				posObjectFactoryDAL.DisposeConnection(SqlCon);
			}
		}
		#endregion

		#region SelectAll
		public List<posStockAdjustmentMasterDAL> SelectAllStockAdjustmentMaster()
		{
			SqlConnection SqlCon = null;
			SqlCommand SqlCmd = null;
			SqlDataReader SqlRdr = null;
			try
			{
				SqlCon = posObjectFactoryDAL.CreateConnection();
				SqlCmd = new SqlCommand("posStockAdjustmentMaster_SelectAll", SqlCon);
				SqlCmd.CommandType = CommandType.StoredProcedure;

				SqlCmd.Parameters.Add("@VoucherNumber", SqlDbType.VarChar).Value = this.VoucherNumber;
				if (this.AdjustmentDate != new DateTime())
				{
					SqlCmd.Parameters.Add("@AdjustmentDate", SqlDbType.Date).Value = this.AdjustmentDate;
				}

				SqlCon.Open();
				SqlRdr = SqlCmd.ExecuteReader();
				List<posStockAdjustmentMasterDAL> lstStockAdjustmentMasterDAL = SetListPropertiesFromSqlDataReader(SqlRdr);
				SqlRdr.Close();
				SqlCon.Close();

				return lstStockAdjustmentMasterDAL;
			}
			catch (Exception ex)
			{
				posGlobalsDAL.SaveError(ex);
				return null;
			}
			finally
			{
				posObjectFactoryDAL.DisposeDataReader(SqlRdr);
				posObjectFactoryDAL.DisposeCommand(SqlCmd);
				posObjectFactoryDAL.DisposeConnection(SqlCon);
			}
		}
		#endregion
	}
}
