using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace posLibrary
{
    /// <summary>
    /// Class for posWaiterNotificationTran
    /// </summary>
    public class posWaiterNotificationTranDAL
    {
        #region Properties
        public long WaiterNotificationTranId { get; set; }
        public long linktoWaiterNotificationMasterId { get; set; }
        public short linktoUserMasterId { get; set; }

        /// Extra
        public long WaiterNotification { get; set; }
        public string User { get; set; }
        #endregion

        #region Insert
        public posRecordStatus InsertWaiterNotificationTran()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posWaiterNotificationTran_Insert", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@WaiterNotificationTranId", SqlDbType.BigInt).Direction = ParameterDirection.Output;
                SqlCmd.Parameters.Add("@linktoWaiterNotificationMasterId", SqlDbType.BigInt).Value = this.linktoWaiterNotificationMasterId;
                SqlCmd.Parameters.Add("@linktoUserMasterId", SqlDbType.SmallInt).Value = this.linktoUserMasterId;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                this.WaiterNotificationTranId = Convert.ToInt16(SqlCmd.Parameters["@WaiterNotificationTranId"].Value);
                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion
    }
}
