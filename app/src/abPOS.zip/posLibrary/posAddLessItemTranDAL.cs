using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace posLibrary
{
    /// <summary>
    /// Class for posAddLessItemTran
    /// </summary>
    public class posAddLessItemTranDAL
    {
        #region Properties
        public int AddLessItemTranId { get; set; }
        public short linktoAddLessMasterId { get; set; }
        public int linktoItemMasterId { get; set; }
        #endregion

        #region Class Methods
        private List<posAddLessItemTranDAL> SetListPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            List<posAddLessItemTranDAL> lstAddLessItemTran = new List<posAddLessItemTranDAL>();
            posAddLessItemTranDAL objAddLessItemTran = null;
            while (sqlRdr.Read())
            {
                objAddLessItemTran = new posAddLessItemTranDAL();
                objAddLessItemTran.AddLessItemTranId = Convert.ToInt32(sqlRdr["AddLessItemTranId"]);
                objAddLessItemTran.linktoAddLessMasterId = Convert.ToInt16(sqlRdr["linktoAddLessMasterId"]);
                objAddLessItemTran.linktoItemMasterId = Convert.ToInt32(sqlRdr["linktoItemMasterId"]);
                lstAddLessItemTran.Add(objAddLessItemTran);
            }
            return lstAddLessItemTran;
        }
        #endregion

        #region Insert
        public posRecordStatus InsertAllAddLessItemTran(string linktoItemMasterIds, SqlConnection SqlCon, SqlTransaction sqlTran)
        {
            SqlCommand SqlCmd = null;
            try
            {
                SqlCmd = new SqlCommand("posAddLessItemTran_InsertAll", SqlCon, sqlTran);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@linktoAddLessMasterId", SqlDbType.SmallInt).Value = this.linktoAddLessMasterId;
                SqlCmd.Parameters.Add("@linktoItemMasterIds", SqlDbType.VarChar).Value = linktoItemMasterIds;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCmd.ExecuteNonQuery();

                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
            }
        }
        #endregion

        #region Delete
        public posRecordStatus DeleteAddLessItemTran(SqlConnection SqlCon, SqlTransaction sqlTran)
        {
            SqlCommand SqlCmd = null;
            try
            {
                SqlCmd = new SqlCommand("posAddLessItemTran_Delete", SqlCon, sqlTran);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@linktoAddLessMasterId", SqlDbType.Int).Value = this.linktoAddLessMasterId;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCmd.ExecuteNonQuery();

                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
            }
        }
        #endregion

        #region SelectAll
        public List<posAddLessItemTranDAL> SelectAllAddLessItemTran()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posAddLessItemTran_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@linktoAddLessMasterId", SqlDbType.SmallInt).Value = this.linktoAddLessMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<posAddLessItemTranDAL> lstAddLessItemTranDAL = SetListPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                return lstAddLessItemTranDAL;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion
    }
}
