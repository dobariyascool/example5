using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace posLibrary
{
    /// <summary>
    /// Class for posOrderItemModifierTran
    /// </summary>
    public class posOrderItemModifierTranDAL
    {
        #region Properties
        public long OrderItemModifierTranId { get; set; }
        public long linktoOrderItemTranId { get; set; }
        public int linktoItemMasterId { get; set; }
        public double Rate { get; set; }
        #endregion

        #region Insert
        public static posRecordStatus InsertOrderItemModifierTran(List<posOrderItemDAL> lstOrderItemModifierTranDAL, int linktoOrderItemTranId, SqlConnection SqlCon, SqlTransaction SqlTran)
        {
            SqlCommand SqlCmd = null;
            posRecordStatus rs = posRecordStatus.Error;
            try
            {
                SqlCmd = new SqlCommand("posOrderItemModifierTran_Insert", SqlCon, SqlTran);
                SqlCmd.CommandType = CommandType.StoredProcedure;
                if (lstOrderItemModifierTranDAL != null || lstOrderItemModifierTranDAL.Count > 0)
                {
                    foreach (posOrderItemDAL objItemMasterDAL in lstOrderItemModifierTranDAL)
                    {
                        SqlCmd.Parameters.Clear();
                        SqlCmd.Parameters.Add("@OrderItemModifierTranId", SqlDbType.BigInt).Direction = ParameterDirection.Output;
                        SqlCmd.Parameters.Add("@linktoOrderItemTranId", SqlDbType.BigInt).Value = linktoOrderItemTranId;
                        SqlCmd.Parameters.Add("@linktoItemMasterId", SqlDbType.Int).Value = Convert.ToInt16(objItemMasterDAL.linktoItemMasterIdModifier);
                        SqlCmd.Parameters.Add("@Rate", SqlDbType.Money).Value = objItemMasterDAL.MRP;
                        SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                        SqlCmd.ExecuteNonQuery();

                        rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                        if (rs != posRecordStatus.Success)
                        {
                            return posRecordStatus.Error;
                        }
                    }
                }
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
            }
        }
        #endregion

        #region Delete
        public static posRecordStatus DeleteOrderItemModifierTran(int linktoOrderItemTranId, SqlConnection SqlCon, SqlTransaction SqlTran)
        {
            SqlCommand SqlCmd = null;
            try
            {
                SqlCmd = new SqlCommand("posOrderItemModifierTran_Delete", SqlCon, SqlTran);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@linktoOrderItemTranId", SqlDbType.BigInt).Value = linktoOrderItemTranId;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCmd.ExecuteNonQuery();

                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
            }
        }
        #endregion
    }
}
