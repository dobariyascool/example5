using System;
using System.Data;
using System.Data.SqlClient;
using System.Collections.Generic;
using System.Linq;
using System.IO;

namespace posLibrary
{
    /// <summary>
    /// Class for posSalesItemTran
    /// </summary>
    public class posSalesItemTranDAL
    {
        #region Properties
        public long SalesItemTranId { get; set; }
        public long linktoSalesMasterId { get; set; }
        public int linktoItemMasterId { get; set; }
        public short linktoUnitMasterId { get; set; }
        public string ItemCode { get; set; }
        public string ItemName { get; set; }
        public int Quantity { get; set; }
        public double Rate { get; set; }
        public double DiscountPercentage { get; set; }
        public double DiscountAmount { get; set; }
        public double Tax { get; set; }
        public bool IsRateTaxInclusive { get; set; }
        public double PurchaseRate { get; set; }
        public short ItemPoint { get; set; }
        public short DeductedPoint { get; set; }
        public string ItemRemark { get; set; }
        public short? linktoOrderStatusMasterId { get; set; }
        public DateTime CreateDateTime { get; set; }
        public short linktoUserMasterIdCreatedBy { get; set; }
        public DateTime? UpdateDateTime { get; set; }
        public short? linktoUserMasterIdUpdatedBy { get; set; }

        /// Extra
        public long Sales { get; set; }
        public string Unit { get; set; }
        public string OrderStatus { get; set; }
        public string CategoryName { get; set; }
        public double TotalRate { get; set; }
        public double TotalCost { get; set; }
        public string ItemMasterIds { get; set; }
        public string CategoryMasterIds { get; set; }
        public double TotalProfitOrLoss { get; set; }
        public string BillDateString { get; set; }
        public double NetAmount { get; set; }

        public string BillNumber { get; set; }
        public short TMPItemRemark { get; set; }
        public Byte[] Barcode { get; set; }
        #endregion

        #region Insert
        public static posRecordStatus InsertSalesItemTran(List<posItemMasterDAL> lstSaleItemTranDAL, List<posItemMasterDAL> lstSaleItemModifierTranDAL, long linktoSalesMasterId, short? linktoOrderStatusMasterId, DateTime CreateDateTime, short linktoUserMasterIdCreatedBy, SqlConnection SqlCon, SqlTransaction SqlTran)
        {
            SqlCommand SqlCmd = null;
            posRecordStatus rs = posRecordStatus.Error;
            try
            {
                SqlCmd = new SqlCommand("posSalesItemTran_Insert", SqlCon, SqlTran);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                if (lstSaleItemTranDAL != null || lstSaleItemTranDAL.Count > 0)
                {
                    foreach (posItemMasterDAL objItemMasterDAL in lstSaleItemTranDAL)
                    {
                        SqlCmd.Parameters.Clear();
                        SqlCmd.Parameters.Add("@SalesItemTranId", SqlDbType.BigInt).Direction = ParameterDirection.Output;
                        SqlCmd.Parameters.Add("@linktoSalesMasterId", SqlDbType.BigInt).Value = linktoSalesMasterId;
                        SqlCmd.Parameters.Add("@linktoItemMasterId", SqlDbType.Int).Value = objItemMasterDAL.ItemMasterId;
                        SqlCmd.Parameters.Add("@ItemCode", SqlDbType.VarChar).Value = objItemMasterDAL.ItemCode;
                        SqlCmd.Parameters.Add("@ItemName", SqlDbType.VarChar).Value = objItemMasterDAL.ItemName;
                        SqlCmd.Parameters.Add("@Quantity", SqlDbType.SmallInt).Value = objItemMasterDAL.Quantity;
                        SqlCmd.Parameters.Add("@Rate", SqlDbType.Money).Value = objItemMasterDAL.ActualSaleRate;
                        SqlCmd.Parameters.Add("@DiscountPercentage", SqlDbType.Decimal).Value = 0;
                        SqlCmd.Parameters.Add("@DiscountAmount", SqlDbType.Money).Value = 0;
                        SqlCmd.Parameters.Add("@Tax", SqlDbType.Money).Value = 0;
                        SqlCmd.Parameters.Add("@ItemPoint", SqlDbType.SmallInt).Value = 0;
                        SqlCmd.Parameters.Add("@DeductedPoint", SqlDbType.SmallInt).Value = 0;
                        SqlCmd.Parameters.Add("@ItemRemark", SqlDbType.VarChar).Value = objItemMasterDAL.Remark;
                        SqlCmd.Parameters.Add("@linktoOrderStatusMasterId", SqlDbType.SmallInt).Value = linktoOrderStatusMasterId;
                        SqlCmd.Parameters.Add("@CreateDateTime", SqlDbType.DateTime).Value = CreateDateTime;
                        SqlCmd.Parameters.Add("@linktoUserMasterIdCreatedBy", SqlDbType.SmallInt).Value = linktoUserMasterIdCreatedBy;
                        SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                        SqlCmd.ExecuteNonQuery();

                        rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                        long SalesItemTranId = Convert.ToInt64(SqlCmd.Parameters["@SalesItemTranId"].Value);
                        if (rs == posRecordStatus.Success)
                        {
                            List<posItemMasterDAL> lstSaleItemModifierTranDAL2 = new List<posItemMasterDAL>();
                            lstSaleItemModifierTranDAL2 = lstSaleItemModifierTranDAL.Where(i => i.ItemMasterId == objItemMasterDAL.ItemMasterId && i.KOTItemId == objItemMasterDAL.KOTItemId).ToList();
                            if (lstSaleItemModifierTranDAL2.Count > 0)
                            {
                                if (posSalesItemModifierTranDAL.DeleteSalesItemModifierTran(SalesItemTranId, SqlCon, SqlTran) == posRecordStatus.Success)
                                {
                                    if (posSalesItemModifierTranDAL.InsertSalesItemModifierTran(lstSaleItemModifierTranDAL2, SalesItemTranId, SqlCon, SqlTran) == posRecordStatus.Error)
                                    {
                                        //SqlTran.Rollback();
                                        return posRecordStatus.Error;
                                    }
                                }
                                else
                                {
                                    // SqlTran.Rollback();
                                    return posRecordStatus.Error;
                                }
                            }
                        }
                        else
                        {
                            return posRecordStatus.Error;
                        }
                    }
                }
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
            }
        }

        public static posRecordStatus InsertSalesItemTran(List<posOrderItemDAL> lstSalesItemTranDAL, List<posOrderItemDAL> lstSalesItemModifierTranDAL, long linktoSalesMasterId, short? RateIndex, short? linktoOrderStatusMasterId, DateTime CreateDateTime, short linktoUserMasterIdCreatedBy, SqlConnection SqlCon, SqlTransaction SqlTran)
        {
            SqlCommand SqlCmd = null;
            posRecordStatus rs = posRecordStatus.Error;
            //double discountItemRate = 0;

            try
            {
                SqlCmd = new SqlCommand("posSalesItemTranWithAllTax_Insert", SqlCon, SqlTran);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                if (lstSalesItemTranDAL != null || lstSalesItemTranDAL.Count > 0)
                {
                    foreach (posOrderItemDAL objItemMasterDAL in lstSalesItemTranDAL)
                    {
                        SqlCmd.Parameters.Clear();
                        SqlCmd.Parameters.Add("@SalesItemTranId", SqlDbType.BigInt).Direction = ParameterDirection.Output;
                        SqlCmd.Parameters.Add("@linktoSalesMasterId", SqlDbType.BigInt).Value = linktoSalesMasterId;
                        SqlCmd.Parameters.Add("@linktoItemMasterId", SqlDbType.Int).Value = objItemMasterDAL.ItemMasterId;
                        SqlCmd.Parameters.Add("@ItemName", SqlDbType.VarChar).Value = objItemMasterDAL.ItemName;
                        SqlCmd.Parameters.Add("@Quantity", SqlDbType.SmallInt).Value = objItemMasterDAL.Quantity;
                        SqlCmd.Parameters.Add("@Rate", SqlDbType.Money).Value = objItemMasterDAL.SaleRate;
                        //if (RateIndex == null)
                        //{
                        //    SqlCmd.Parameters.Add("@Rate", SqlDbType.Money).Value = objItemMasterDAL.MRP;
                        //    double.TryParse(objItemMasterDAL.MRP.ToString(), out discountItemRate);
                        //}
                        //else
                        //{
                        //    switch (RateIndex)
                        //    {
                        //        case 1:
                        //            SqlCmd.Parameters.Add("@Rate", SqlDbType.Money).Value = objItemMasterDAL.Rate1;
                        //            discountItemRate = objItemMasterDAL.Rate1;
                        //            break;
                        //        case 2:
                        //            SqlCmd.Parameters.Add("@Rate", SqlDbType.Money).Value = objItemMasterDAL.Rate2;
                        //            discountItemRate = objItemMasterDAL.Rate2;
                        //            break;
                        //        case 3:
                        //            SqlCmd.Parameters.Add("@Rate", SqlDbType.Money).Value = objItemMasterDAL.Rate3;
                        //            discountItemRate = objItemMasterDAL.Rate3;
                        //            break;
                        //        case 4:
                        //            SqlCmd.Parameters.Add("@Rate", SqlDbType.Money).Value = objItemMasterDAL.Rate4;
                        //            discountItemRate = objItemMasterDAL.Rate4;
                        //            break;
                        //        case 5:
                        //            SqlCmd.Parameters.Add("@Rate", SqlDbType.Money).Value = objItemMasterDAL.Rate5;
                        //            discountItemRate = objItemMasterDAL.Rate5;
                        //            break;
                        //    }
                        //}

                        if (objItemMasterDAL.IsDiscountPercentage)
                        {
                            //discountItemRate = (discountItemRate * objItemMasterDAL.DiscountPercentage) / 100;
                            SqlCmd.Parameters.Add("@DiscountPercentage", SqlDbType.Money).Value = objItemMasterDAL.DiscountPercentage;
                            //SqlCmd.Parameters.Add("@DiscountAmount", SqlDbType.Money).Value = discountItemRate;
                            SqlCmd.Parameters.Add("@DiscountAmount", SqlDbType.Money).Value = (objItemMasterDAL.SaleRate * objItemMasterDAL.DiscountPercentage) / 100;
                        }
                        else
                        {
                            SqlCmd.Parameters.Add("@DiscountPercentage", SqlDbType.Money).Value = 0;
                            SqlCmd.Parameters.Add("@DiscountAmount", SqlDbType.Money).Value = objItemMasterDAL.DiscountPercentage;
                        }
                        SqlCmd.Parameters.Add("@IsRateTaxInclusive", SqlDbType.Bit).Value = objItemMasterDAL.IsRateTaxInclusive;
                        SqlCmd.Parameters.Add("@Tax1", SqlDbType.Money).Value = objItemMasterDAL.TaxAmt1;
                        SqlCmd.Parameters.Add("@Tax2", SqlDbType.Money).Value = objItemMasterDAL.TaxAmt2;
                        SqlCmd.Parameters.Add("@Tax3", SqlDbType.Money).Value = objItemMasterDAL.TaxAmt3;
                        SqlCmd.Parameters.Add("@Tax4", SqlDbType.Money).Value = objItemMasterDAL.TaxAmt4;
                        SqlCmd.Parameters.Add("@Tax5", SqlDbType.Money).Value = objItemMasterDAL.TaxAmt5;
                        SqlCmd.Parameters.Add("@AddLessAmount", SqlDbType.Money).Value = objItemMasterDAL.AddLessAmount;
                        SqlCmd.Parameters.Add("@ItemPoint", SqlDbType.SmallInt).Value = 0;
                        SqlCmd.Parameters.Add("@DeductedPoint", SqlDbType.SmallInt).Value = 0;
                        string Remark = string.Empty;
                        if (!string.IsNullOrEmpty(objItemMasterDAL.Remark))
                        {
                            Remark += objItemMasterDAL.Remark;
                        }
                        if (!string.IsNullOrEmpty(objItemMasterDAL.ItemOptions))
                        {
                            if (!string.IsNullOrEmpty(Remark))
                            {
                                Remark += ", ";
                            }
                            Remark += objItemMasterDAL.Remark;
                        }
                        SqlCmd.Parameters.Add("@ItemRemark", SqlDbType.VarChar).Value = Remark;
                        SqlCmd.Parameters.Add("@linktoOrderStatusMasterId", SqlDbType.SmallInt).Value = linktoOrderStatusMasterId;
                        SqlCmd.Parameters.Add("@CreateDateTime", SqlDbType.DateTime).Value = CreateDateTime;
                        SqlCmd.Parameters.Add("@linktoUserMasterIdCreatedBy", SqlDbType.SmallInt).Value = linktoUserMasterIdCreatedBy;
                        SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;
                        SqlCmd.ExecuteNonQuery();

                        rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                        long SalesItemTranId = Convert.ToInt64(SqlCmd.Parameters["@SalesItemTranId"].Value);
                        if (rs != posRecordStatus.Success)
                        {
                            return rs;
                        }

                        List<posOrderItemDAL> lstSalesItemModifierTranDAL2 = new List<posOrderItemDAL>();

                        lstSalesItemModifierTranDAL2 = lstSalesItemModifierTranDAL.Where(i => i.ItemMasterId == objItemMasterDAL.ItemMasterId && i.OrderId == objItemMasterDAL.OrderId).ToList();

                        if (lstSalesItemModifierTranDAL2.Count > 0)
                        {
                            rs = posSalesItemModifierTranDAL.DeleteSalesItemModifierTran(SalesItemTranId, SqlCon, SqlTran);

                            if (rs != posRecordStatus.Success)
                            {
                                return rs;
                            }

                            rs = posSalesItemModifierTranDAL.InsertSalesItemModifierTran(lstSalesItemModifierTranDAL2, SalesItemTranId, SqlCon, SqlTran);
                            if (rs != posRecordStatus.Success)
                            {
                                return rs;
                            }
                        }
                    }
                }
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
            }
        }
        #endregion

        #region Delete
        public static posRecordStatus DeleteSalesItemTran(long linktoSalesMasterId, SqlConnection SqlCon, SqlTransaction SqlTran)
        {
            SqlCommand SqlCmd = null;
            try
            {
                SqlCmd = new SqlCommand("posSalesItemTran_Delete", SqlCon, SqlTran);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@linktoSalesMasterId", SqlDbType.BigInt).Value = linktoSalesMasterId;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCmd.ExecuteNonQuery();

                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
            }
        }
        #endregion

        #region SelectAll
        public List<posSalesItemTranDAL> SelectAllSalesItemTranByItemReport(short linktoCounterMasterId, short linktoBusinessMasterId, DateTime FromDate, DateTime ToDate)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posSalesItemTranByItemReport_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@FromDate", SqlDbType.DateTime).Value = FromDate;
                SqlCmd.Parameters.Add("@ToDate", SqlDbType.DateTime).Value = ToDate;
                SqlCmd.Parameters.Add("@CounterMasterId", SqlDbType.SmallInt).Value = linktoCounterMasterId;
                SqlCmd.Parameters.Add("@linktoBussinessMasterId", SqlDbType.SmallInt).Value = linktoBusinessMasterId;
                SqlCmd.Parameters.Add("@CategoryMasterIds", SqlDbType.VarChar).Value = this.CategoryMasterIds;
                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();

                List<posSalesItemTranDAL> lstSalesItemTranDAL = new List<posSalesItemTranDAL>();
                posSalesItemTranDAL objSalesItemTran = null;
                Zen.Barcode.Code128BarcodeDraw obj;
                while (SqlRdr.Read())
                {
                    obj = new Zen.Barcode.Code128BarcodeDraw(Zen.Barcode.Code128Checksum.Instance);
                    objSalesItemTran = new posSalesItemTranDAL();
                    objSalesItemTran.CategoryName = Convert.ToString(SqlRdr["CategoryName"]);
                    objSalesItemTran.ItemName = Convert.ToString(SqlRdr["ItemName"]);
                    objSalesItemTran.ItemCode = Convert.ToString(SqlRdr["ItemCode"]);
                    objSalesItemTran.Quantity = Convert.ToInt32(SqlRdr["Quantity"]);
                    objSalesItemTran.TotalRate = Convert.ToDouble(SqlRdr["TotalRate"]);
                    objSalesItemTran.DiscountAmount = Convert.ToDouble(SqlRdr["DiscountAmount"]);
                    objSalesItemTran.Tax = Convert.ToDouble(SqlRdr["Tax"]);
                    objSalesItemTran.NetAmount = Convert.ToDouble(SqlRdr["NetAmount"]);
                    //Barcode Testing 
                    objSalesItemTran.Barcode = posGlobalsDAL.ImageToByteArray(obj.Draw("12345", 20));
                    lstSalesItemTranDAL.Add(objSalesItemTran);

                }
                SqlRdr.Close();
                SqlCon.Close();

                return lstSalesItemTranDAL;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public List<posSalesItemTranDAL> SelectAllSalesItemTranProfitORLoss(short linktoCounterMasterId, DateTime FromDate, DateTime ToDate, int linktoBusinessMasterId)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posSalesItemTranProfitORLoss_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@FromDate", SqlDbType.DateTime).Value = FromDate;
                SqlCmd.Parameters.Add("@ToDate", SqlDbType.DateTime).Value = ToDate;
                SqlCmd.Parameters.Add("@linktoCounterMasterId", SqlDbType.SmallInt).Value = linktoCounterMasterId;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.Int).Value = linktoBusinessMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();

                List<posSalesItemTranDAL> lstSalesItemTranDAL = new List<posSalesItemTranDAL>();
                posSalesItemTranDAL objSalesItemTran = null;
                while (SqlRdr.Read())
                {
                    objSalesItemTran = new posSalesItemTranDAL();

                    objSalesItemTran.ItemName = Convert.ToString(SqlRdr["ItemName"]);
                    objSalesItemTran.ItemCode = Convert.ToString(SqlRdr["ItemCode"]);
                    objSalesItemTran.Quantity = Convert.ToInt32(SqlRdr["Quantity"]);
                    objSalesItemTran.PurchaseRate = Convert.ToDouble(SqlRdr["PurchaseRate"]);
                    objSalesItemTran.TotalRate = Convert.ToDouble(SqlRdr["TotalRate"]);
                    objSalesItemTran.Rate = Convert.ToDouble(SqlRdr["Rate"]);
                    objSalesItemTran.TotalCost = Convert.ToDouble(SqlRdr["TotalCost"]);
                    objSalesItemTran.TotalProfitOrLoss = Convert.ToDouble(SqlRdr["ProfitORLoss"]);
                    objSalesItemTran.BillDateString = Convert.ToString(SqlRdr["BillDateTime"]);

                    lstSalesItemTranDAL.Add(objSalesItemTran);
                }
                SqlRdr.Close();
                SqlCon.Close();

                return lstSalesItemTranDAL;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public List<posSalesItemTranDAL> SelectAllSalesItemTranMostSaleItemWiseChart(short linktoBusinessMasterId)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posSalesItemTranMostSaleItemsChart_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = linktoBusinessMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();

                List<posSalesItemTranDAL> lstSalesItemTranDAL = new List<posSalesItemTranDAL>();
                posSalesItemTranDAL objSalesItemTran = null;
                while (SqlRdr.Read())
                {
                    objSalesItemTran = new posSalesItemTranDAL();

                    objSalesItemTran.ItemName = Convert.ToString(SqlRdr["ItemName"]);
                    objSalesItemTran.linktoItemMasterId = Convert.ToInt16(SqlRdr["linktoItemMasterId"]);

                    lstSalesItemTranDAL.Add(objSalesItemTran);
                }
                SqlRdr.Close();
                SqlCon.Close();

                return lstSalesItemTranDAL;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public List<posSalesItemTranDAL> SelectAllSalesMasterComparisonReportItemWise(short linktoBusinessMasterId, short option, short DayOfWeek, DateTime FromDate, DateTime ToDate)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posSalesMasterComparisonReportItemWise_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@FromDate", SqlDbType.DateTime).Value = FromDate;
                SqlCmd.Parameters.Add("@ToDate", SqlDbType.DateTime).Value = ToDate;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = linktoBusinessMasterId;
                SqlCmd.Parameters.Add("@ItemMasterIds", SqlDbType.VarChar).Value = ItemMasterIds;
                SqlCmd.Parameters.Add("@Option", SqlDbType.SmallInt).Value = option;
                SqlCmd.Parameters.Add("@DayOfWeek", SqlDbType.SmallInt).Value = DayOfWeek;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<posSalesItemTranDAL> lstSalesItemTranDAL = new List<posSalesItemTranDAL>();
                posSalesItemTranDAL objSalesItemTranDAL = null;
                while (SqlRdr.Read())
                {
                    objSalesItemTranDAL = new posSalesItemTranDAL();
                    objSalesItemTranDAL.BillDateString = Convert.ToString(SqlRdr["BillDate"]);
                    if (SqlRdr["NetAmount"] != DBNull.Value)
                    {
                        objSalesItemTranDAL.NetAmount = Convert.ToDouble(SqlRdr["NetAmount"]);
                    }
                    if (SqlRdr["Quantity"] != DBNull.Value)
                    {
                        objSalesItemTranDAL.Quantity = Convert.ToInt32(SqlRdr["Quantity"]);
                    }
                    if (SqlRdr["ItemMasterId"] != DBNull.Value)
                    {
                        objSalesItemTranDAL.linktoItemMasterId = Convert.ToInt32(SqlRdr["ItemMasterId"]);
                    }
                    if (SqlRdr["ItemName"] != DBNull.Value)
                    {
                        objSalesItemTranDAL.ItemName = Convert.ToString(SqlRdr["ItemName"]);
                    }


                    lstSalesItemTranDAL.Add(objSalesItemTranDAL);
                }
                SqlRdr.Close();
                SqlCon.Close();

                return lstSalesItemTranDAL;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public List<posSalesItemTranDAL> SelectAllSalesMasterComparisonReportCategoryWise(short linktoBusinessMasterId, short option, short DayOfWeek, DateTime FromDate, DateTime ToDate)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posSalesMasterComparisonReportCategoryWise_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@FromDate", SqlDbType.DateTime).Value = FromDate;
                SqlCmd.Parameters.Add("@ToDate", SqlDbType.DateTime).Value = ToDate;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = linktoBusinessMasterId;
                SqlCmd.Parameters.Add("@CategoryMasterIds", SqlDbType.VarChar).Value = CategoryMasterIds;
                SqlCmd.Parameters.Add("@Option", SqlDbType.SmallInt).Value = option;
                SqlCmd.Parameters.Add("@DayOfWeek", SqlDbType.SmallInt).Value = DayOfWeek;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<posSalesItemTranDAL> lstSalesItemTranDAL = new List<posSalesItemTranDAL>();
                posSalesItemTranDAL objSalesItemTranDAL = null;
                while (SqlRdr.Read())
                {
                    objSalesItemTranDAL = new posSalesItemTranDAL();
                    objSalesItemTranDAL.BillDateString = Convert.ToString(SqlRdr["BillDate"]);
                    if (SqlRdr["NetAmount"] != DBNull.Value)
                    {
                        objSalesItemTranDAL.NetAmount = Convert.ToDouble(SqlRdr["NetAmount"]);
                    }
                    if (SqlRdr["Quantity"] != DBNull.Value)
                    {
                        objSalesItemTranDAL.Quantity = Convert.ToInt32(SqlRdr["Quantity"]);
                    }
                    if (SqlRdr["CategoryMasterId"] != DBNull.Value)
                    {
                        objSalesItemTranDAL.CategoryMasterIds = Convert.ToString(SqlRdr["CategoryMasterId"]);
                    }
                    if (SqlRdr["CategoryName"] != DBNull.Value)
                    {
                        objSalesItemTranDAL.CategoryName = Convert.ToString(SqlRdr["CategoryName"]);
                    }
                    lstSalesItemTranDAL.Add(objSalesItemTranDAL);
                }
                SqlRdr.Close();
                SqlCon.Close();

                return lstSalesItemTranDAL;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public List<posSalesItemTranDAL> SelectAllSalesMasterComparisonReport(short linktoBusinessMasterId, short option, short DayOfWeek, DateTime FromDate, DateTime ToDate)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posSalesMasterComparisonReport_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@FromDate", SqlDbType.DateTime).Value = FromDate;
                SqlCmd.Parameters.Add("@ToDate", SqlDbType.DateTime).Value = ToDate;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = linktoBusinessMasterId;
                SqlCmd.Parameters.Add("@Option", SqlDbType.SmallInt).Value = option;
                SqlCmd.Parameters.Add("@DayOfWeek", SqlDbType.SmallInt).Value = DayOfWeek;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<posSalesItemTranDAL> lstSalesItemTranDAL = new List<posSalesItemTranDAL>();
                posSalesItemTranDAL objSalesItemTranDAL = null;
                while (SqlRdr.Read())
                {
                    objSalesItemTranDAL = new posSalesItemTranDAL();
                    objSalesItemTranDAL.BillDateString = Convert.ToString(SqlRdr["BillDate"]);
                    if (SqlRdr["NetAmount"] != DBNull.Value)
                    {
                        objSalesItemTranDAL.NetAmount = Convert.ToDouble(SqlRdr["NetAmount"]);
                    }
                    lstSalesItemTranDAL.Add(objSalesItemTranDAL);
                }
                SqlRdr.Close();
                SqlCon.Close();

                return lstSalesItemTranDAL;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public List<posSalesItemTranDAL> SelectAllSalesItemTranKOTPrintBySalesMasterIdReport()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posSalesItemTranBillPrint_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;


                SqlCmd.Parameters.Add("@linktoSalesMasterId", SqlDbType.SmallInt).Value = this.linktoSalesMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();

                List<posSalesItemTranDAL> lstSalesItemTran = new List<posSalesItemTranDAL>();
                posSalesItemTranDAL objSalesItemTran = null;
                while (SqlRdr.Read())
                {
                    objSalesItemTran = new posSalesItemTranDAL();

                    objSalesItemTran.ItemName = Convert.ToString(SqlRdr["ItemName"]);
                    objSalesItemTran.Quantity = Convert.ToInt16(SqlRdr["Quantity"]);
                    objSalesItemTran.Rate = Convert.ToInt16(SqlRdr["Rate"]);
                    objSalesItemTran.linktoItemMasterId = Convert.ToInt16(SqlRdr["linktoItemMasterId"]);
                    objSalesItemTran.TMPItemRemark = Convert.ToInt16(SqlRdr["Item"]);

                    lstSalesItemTran.Add(objSalesItemTran);
                }
                SqlRdr.Close();
                SqlCon.Close();

                return lstSalesItemTran;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion
    }
}
