﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace posLibrary
{
    /// <summary>
    /// Class for posItemCategoryTran
    /// </summary>

    public class posItemCategoryTranDAL
    {
        #region Properties
        public int ItemCategoryTranId { get; set; }
        public int linktoItemMasterId { get; set; }
        public short linktoCategoryMasterId { get; set; }

        /// Extra
        public string CategoryName { get; set; }
        public string Description { get; set; }
        public int CategoryMasterId { get; set; }
        public Boolean IsSelected { get; set; }
        public Boolean IsRawMaterial { get; set; }

        #endregion

        #region Class Methods
        private List<posItemCategoryTranDAL> SetListPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            List<posItemCategoryTranDAL> lstItemCategoryTran = new List<posItemCategoryTranDAL>();
            posItemCategoryTranDAL objItemCategoryTran = null;
            while (sqlRdr.Read())
            {
                objItemCategoryTran = new posItemCategoryTranDAL();
                if (sqlRdr["ItemCategoryTranId"] != DBNull.Value)
                {
                    objItemCategoryTran.ItemCategoryTranId = Convert.ToInt32(sqlRdr["ItemCategoryTranId"]);
                    objItemCategoryTran.IsSelected = true;
                }
                else
                {
                    objItemCategoryTran.IsSelected = false;
                }
                if (sqlRdr["linktoItemMasterId"] != DBNull.Value)
                {
                    objItemCategoryTran.linktoItemMasterId = Convert.ToInt32(sqlRdr["linktoItemMasterId"]);
                }
                if (sqlRdr["linktoCategoryMasterId"] != DBNull.Value)
                {
                    objItemCategoryTran.linktoCategoryMasterId = Convert.ToInt16(sqlRdr["linktoCategoryMasterId"]);
                }

                /// Extra
                objItemCategoryTran.CategoryName = Convert.ToString(sqlRdr["CategoryName"]);
                objItemCategoryTran.Description = Convert.ToString(sqlRdr["Description"]);
                objItemCategoryTran.CategoryMasterId = Convert.ToInt32(sqlRdr["CategoryMasterId"]);
                lstItemCategoryTran.Add(objItemCategoryTran);
            }
            return lstItemCategoryTran;
        }
        #endregion

        #region Insert
        public static posRecordStatus InsertItemCategoryTran(string itemCategoryTranIds, int itemMasterId, SqlConnection sqlCon, SqlTransaction sqlTran)
        {
            SqlCommand SqlCmd = null;
            try
            {
                SqlCmd = new SqlCommand("posItemCategoryTran_Insert", sqlCon, sqlTran);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@ItemCategoryTranIds", SqlDbType.VarChar).Value = itemCategoryTranIds;
                SqlCmd.Parameters.Add("@ItemMasterId", SqlDbType.Int).Value = itemMasterId;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCmd.ExecuteNonQuery();

                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
            }
        }
        #endregion

        #region SelectAll
        public List<posItemCategoryTranDAL> SelectAllItemCategoryTran(short linktoBusinessMasterId)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posItemCategoryTran_SelectAll", SqlCon);
                SqlCmd.Parameters.Add("@IsRawMaterial", SqlDbType.Bit).Value = IsRawMaterial;
                SqlCmd.Parameters.Add("@linktoItemMasterId", SqlDbType.Int).Value = linktoItemMasterId;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.Int).Value = linktoBusinessMasterId;
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<posItemCategoryTranDAL> lstItemCategoryTranDAL = SetListPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                return lstItemCategoryTranDAL;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion
    }
}