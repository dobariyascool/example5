using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace posLibrary
{
    /// <summary>
    /// Class for posStockAdjustmentItemTran
    /// </summary>
    public class posStockAdjustmentItemTranDAL
    {
        #region Properties
        public int StockAdjustmentItemTranId { get; set; }
        public int linktoStockAdjustmentMasterId { get; set; }
        public int linktoItemMasterId { get; set; }
        public short linktoUnitMasterId { get; set; }
        public double Quantity { get; set; }

        /// Extra

        public string Item { get; set; }
        public string Unit { get; set; }
        #endregion

        #region Class Methods
        private List<posStockAdjustmentItemTranDAL> SetListPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            List<posStockAdjustmentItemTranDAL> lstStockAdjustmentItemTran = new List<posStockAdjustmentItemTranDAL>();
            posStockAdjustmentItemTranDAL objStockAdjustmentItemTran = null;
            while (sqlRdr.Read())
            {
                objStockAdjustmentItemTran = new posStockAdjustmentItemTranDAL();
                objStockAdjustmentItemTran.StockAdjustmentItemTranId = Convert.ToInt32(sqlRdr["StockAdjustmentItemTranId"]);
                objStockAdjustmentItemTran.linktoStockAdjustmentMasterId = Convert.ToInt32(sqlRdr["linktoStockAdjustmentMasterId"]);
                objStockAdjustmentItemTran.linktoItemMasterId = Convert.ToInt32(sqlRdr["linktoItemMasterId"]);
                objStockAdjustmentItemTran.linktoUnitMasterId = Convert.ToInt16(sqlRdr["linktoUnitMasterId"]);
                objStockAdjustmentItemTran.Quantity = Convert.ToDouble(sqlRdr["Quantity"]);

                /// Extra

                objStockAdjustmentItemTran.Item = Convert.ToString(sqlRdr["Item"]);
                objStockAdjustmentItemTran.Unit = Convert.ToString(sqlRdr["Unit"]);
                lstStockAdjustmentItemTran.Add(objStockAdjustmentItemTran);
            }
            return lstStockAdjustmentItemTran;
        }
        #endregion

        #region Insert
        public static posRecordStatus InsertStockAdjustmentItemTran(List<posStockAdjustmentItemTranDAL> lstStockAdjustmentItemTranDAL, int linktoStockAdjustmentMasterId, SqlConnection SqlCon, SqlTransaction SqlTran)
        {
            SqlCommand SqlCmd = null;
            posRecordStatus rs = posRecordStatus.Error;
            try
            {

                SqlCmd = new SqlCommand("posStockAdjustmentItemTran_Insert", SqlCon, SqlTran);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                posStockAdjustmentItemTranDAL objStockAdjustmentItemTranDAL1 = new posStockAdjustmentItemTranDAL();
                objStockAdjustmentItemTranDAL1.linktoStockAdjustmentMasterId = linktoStockAdjustmentMasterId;
                rs = objStockAdjustmentItemTranDAL1.DeleteStockAdjustmentItemTran(SqlCon, SqlTran);

                if (rs == posRecordStatus.Success)
                {
                    if (lstStockAdjustmentItemTranDAL != null || lstStockAdjustmentItemTranDAL.Count > 0)
                    {
                        foreach (posStockAdjustmentItemTranDAL objStockAdjustmentItemTranDAL in lstStockAdjustmentItemTranDAL)
                        {
                            SqlCmd.Parameters.Clear();
                            SqlCmd.Parameters.Add("@StockAdjustmentItemTranId", SqlDbType.Int).Direction = ParameterDirection.Output;
                            SqlCmd.Parameters.Add("@linktoStockAdjustmentMasterId", SqlDbType.Int).Value = linktoStockAdjustmentMasterId;
                            SqlCmd.Parameters.Add("@linktoItemMasterId", SqlDbType.Int).Value = objStockAdjustmentItemTranDAL.linktoItemMasterId;
                            SqlCmd.Parameters.Add("@linktoUnitMasterId", SqlDbType.SmallInt).Value = objStockAdjustmentItemTranDAL.linktoUnitMasterId;
                            SqlCmd.Parameters.Add("@Quantity", SqlDbType.Decimal).Value = objStockAdjustmentItemTranDAL.Quantity;
                            SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;
                            SqlCmd.ExecuteNonQuery();
                            // objStockAdjustmentItemTranDAL.StockAdjustmentItemTranId = Convert.ToInt32(SqlCmd.Parameters["@StockAdjustmentItemTranId"].Value);
                            rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                            if (rs != posRecordStatus.Success)
                            {
                                return rs;
                            }
                        }
                    }
                }
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
            }
        }
        #endregion

        #region Delete
        public posRecordStatus DeleteStockAdjustmentItemTran(SqlConnection SqlCon, SqlTransaction SqlTran)
        {
            SqlCommand SqlCmd = null;
            try
            {

                SqlCmd = new SqlCommand("posStockAdjustmentItemTran_Delete", SqlCon, SqlTran);
                SqlCmd.CommandType = CommandType.StoredProcedure;
                SqlCmd.Parameters.Add("@linktoStockAdjustmentMasterId", SqlDbType.Int).Value = this.linktoStockAdjustmentMasterId;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;
                SqlCmd.ExecuteNonQuery();


                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);

            }
        }
        #endregion

        #region SelectAll
        public List<posStockAdjustmentItemTranDAL> SelectAllStockAdjustmentItemTran()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posStockAdjustmentItemTran_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@linktoStockAdjustmentMasterId", SqlDbType.Int).Value = this.linktoStockAdjustmentMasterId;


                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<posStockAdjustmentItemTranDAL> lstStockAdjustmentItemTranDAL = SetListPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                return lstStockAdjustmentItemTranDAL;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion
    }
}
