using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace posLibrary
{
    /// <summary>
    /// Class for posSupplierMaster
    /// </summary>
    public class posSupplierMasterDAL
    {
        #region Properties
        public short SupplierMasterId { get; set; }
        public string ShortName { get; set; }
        public string SupplierName { get; set; }
        public string Description { get; set; }
        public string ContactPersonName { get; set; }
        public string Designation { get; set; }
        public string Address { get; set; }
        public short? linktoCountryMasterId { get; set; }
        public short? linktoStateMasterId { get; set; }
        public int? linktoCityMasterId { get; set; }
        public string ZipCode { get; set; }
        public string Phone1 { get; set; }
        public string Phone2 { get; set; }
        public string Email1 { get; set; }
        public string Email2 { get; set; }
        public string Fax { get; set; }
        public bool? IsCredit { get; set; }
        public double OpeningBalance { get; set; }
        public short CreditDays { get; set; }
        public double CreditBalance { get; set; }
        public double CreditLimit { get; set; }
        public double Tax { get; set; }
        public short linktoBusinessMasterId { get; set; }
        public bool IsEnabled { get; set; }
        public bool IsDeleted { get; set; }
        public DateTime CreateDateTime { get; set; }
        public short linktoUserMasterIdCreatedBy { get; set; }
        public DateTime? UpdateDateTime { get; set; }
        public short? linktoUserMasterIdUpdatedBy { get; set; }

        /// Extra
        public string Country { get; set; }
        public string State { get; set; }
        public string City { get; set; }
        #endregion

        #region Class Methods
        private bool SetClassPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            if (sqlRdr.Read())
            {
                this.SupplierMasterId = Convert.ToInt16(sqlRdr["SupplierMasterId"]);
                this.ShortName = Convert.ToString(sqlRdr["ShortName"]);
                this.SupplierName = Convert.ToString(sqlRdr["SupplierName"]);
                this.Description = Convert.ToString(sqlRdr["Description"]);
                this.ContactPersonName = Convert.ToString(sqlRdr["ContactPersonName"]);
                this.Designation = Convert.ToString(sqlRdr["Designation"]);
                this.Address = Convert.ToString(sqlRdr["Address"]);
                if (sqlRdr["linktoCountryMasterId"] != DBNull.Value)
                {
                    this.linktoCountryMasterId = Convert.ToInt16(sqlRdr["linktoCountryMasterId"]);
                }
                if (sqlRdr["linktoStateMasterId"] != DBNull.Value)
                {
                    this.linktoStateMasterId = Convert.ToInt16(sqlRdr["linktoStateMasterId"]);
                }
                if (sqlRdr["linktoCityMasterId"] != DBNull.Value)
                {
                    this.linktoCityMasterId = Convert.ToInt32(sqlRdr["linktoCityMasterId"]);
                }
                this.ZipCode = Convert.ToString(sqlRdr["ZipCode"]);
                this.Phone1 = Convert.ToString(sqlRdr["Phone1"]);
                this.Phone2 = Convert.ToString(sqlRdr["Phone2"]);
                this.Email1 = Convert.ToString(sqlRdr["Email1"]);
                this.Email2 = Convert.ToString(sqlRdr["Email2"]);
                this.Fax = Convert.ToString(sqlRdr["Fax"]);
                if (sqlRdr["IsCredit"] != DBNull.Value)
                {
                    this.IsCredit = Convert.ToBoolean(sqlRdr["IsCredit"]);
                }
                this.OpeningBalance = Convert.ToDouble(sqlRdr["OpeningBalance"]);
                this.CreditDays = Convert.ToInt16(sqlRdr["CreditDays"]);
                this.CreditBalance = Convert.ToDouble(sqlRdr["CreditBalance"]);
                this.CreditLimit = Convert.ToDouble(sqlRdr["CreditLimit"]);
                this.Tax = Convert.ToDouble(sqlRdr["Tax"]);
                this.linktoBusinessMasterId = Convert.ToInt16(sqlRdr["linktoBusinessMasterId"]);
                this.IsEnabled = Convert.ToBoolean(sqlRdr["IsEnabled"]);
                this.IsDeleted = Convert.ToBoolean(sqlRdr["IsDeleted"]);
                this.CreateDateTime = Convert.ToDateTime(sqlRdr["CreateDateTime"]);
                this.linktoUserMasterIdCreatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdCreatedBy"]);
                if (sqlRdr["UpdateDateTime"] != DBNull.Value)
                {
                    this.UpdateDateTime = Convert.ToDateTime(sqlRdr["UpdateDateTime"]);
                }
                if (sqlRdr["linktoUserMasterIdUpdatedBy"] != DBNull.Value)
                {
                    this.linktoUserMasterIdUpdatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdUpdatedBy"]);
                }

                /// Extra
                this.Country = Convert.ToString(sqlRdr["Country"]);
                this.State = Convert.ToString(sqlRdr["State"]);
                this.City = Convert.ToString(sqlRdr["City"]);
                return true;
            }
            return false;
        }

        private List<posSupplierMasterDAL> SetListPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            List<posSupplierMasterDAL> lstSupplierMaster = new List<posSupplierMasterDAL>();
            posSupplierMasterDAL objSupplierMaster = null;
            while (sqlRdr.Read())
            {
                objSupplierMaster = new posSupplierMasterDAL();
                objSupplierMaster.SupplierMasterId = Convert.ToInt16(sqlRdr["SupplierMasterId"]);
                objSupplierMaster.ShortName = Convert.ToString(sqlRdr["ShortName"]);
                objSupplierMaster.SupplierName = Convert.ToString(sqlRdr["SupplierName"]);
                objSupplierMaster.Description = Convert.ToString(sqlRdr["Description"]);
                objSupplierMaster.ContactPersonName = Convert.ToString(sqlRdr["ContactPersonName"]);
                objSupplierMaster.Designation = Convert.ToString(sqlRdr["Designation"]);
                objSupplierMaster.Address = Convert.ToString(sqlRdr["Address"]);
                if (sqlRdr["linktoCountryMasterId"] != DBNull.Value)
                {
                    objSupplierMaster.linktoCountryMasterId = Convert.ToInt16(sqlRdr["linktoCountryMasterId"]);
                }
                if (sqlRdr["linktoStateMasterId"] != DBNull.Value)
                {
                    objSupplierMaster.linktoStateMasterId = Convert.ToInt16(sqlRdr["linktoStateMasterId"]);
                }
                if (sqlRdr["linktoCityMasterId"] != DBNull.Value)
                {
                    objSupplierMaster.linktoCityMasterId = Convert.ToInt32(sqlRdr["linktoCityMasterId"]);
                }
                objSupplierMaster.ZipCode = Convert.ToString(sqlRdr["ZipCode"]);
                objSupplierMaster.Phone1 = Convert.ToString(sqlRdr["Phone1"]);
                objSupplierMaster.Phone2 = Convert.ToString(sqlRdr["Phone2"]);
                objSupplierMaster.Email1 = Convert.ToString(sqlRdr["Email1"]);
                objSupplierMaster.Email2 = Convert.ToString(sqlRdr["Email2"]);
                objSupplierMaster.Fax = Convert.ToString(sqlRdr["Fax"]);
                if (sqlRdr["IsCredit"] != DBNull.Value)
                {
                    objSupplierMaster.IsCredit = Convert.ToBoolean(sqlRdr["IsCredit"]);
                }
                objSupplierMaster.OpeningBalance = Convert.ToDouble(sqlRdr["OpeningBalance"]);
                objSupplierMaster.CreditDays = Convert.ToInt16(sqlRdr["CreditDays"]);
                objSupplierMaster.CreditBalance = Convert.ToDouble(sqlRdr["CreditBalance"]);
                objSupplierMaster.CreditLimit = Convert.ToDouble(sqlRdr["CreditLimit"]);
                objSupplierMaster.Tax = Convert.ToDouble(sqlRdr["Tax"]);
                objSupplierMaster.linktoBusinessMasterId = Convert.ToInt16(sqlRdr["linktoBusinessMasterId"]);
                objSupplierMaster.IsEnabled = Convert.ToBoolean(sqlRdr["IsEnabled"]);
                objSupplierMaster.IsDeleted = Convert.ToBoolean(sqlRdr["IsDeleted"]);
                objSupplierMaster.CreateDateTime = Convert.ToDateTime(sqlRdr["CreateDateTime"]);
                objSupplierMaster.linktoUserMasterIdCreatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdCreatedBy"]);
                if (sqlRdr["UpdateDateTime"] != DBNull.Value)
                {
                    objSupplierMaster.UpdateDateTime = Convert.ToDateTime(sqlRdr["UpdateDateTime"]);
                }
                if (sqlRdr["linktoUserMasterIdUpdatedBy"] != DBNull.Value)
                {
                    objSupplierMaster.linktoUserMasterIdUpdatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdUpdatedBy"]);
                }

                /// Extra
                objSupplierMaster.Country = Convert.ToString(sqlRdr["Country"]);
                objSupplierMaster.State = Convert.ToString(sqlRdr["State"]);
                objSupplierMaster.City = Convert.ToString(sqlRdr["City"]);
                lstSupplierMaster.Add(objSupplierMaster);
            }
            return lstSupplierMaster;
        }
        #endregion

        #region Insert
        public posRecordStatus InsertSupplierMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posSupplierMaster_Insert", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@SupplierMasterId", SqlDbType.SmallInt).Direction = ParameterDirection.Output;
                SqlCmd.Parameters.Add("@ShortName", SqlDbType.VarChar).Value = this.ShortName;
                SqlCmd.Parameters.Add("@SupplierName", SqlDbType.VarChar).Value = this.SupplierName;
                SqlCmd.Parameters.Add("@Description", SqlDbType.VarChar).Value = this.Description;
                SqlCmd.Parameters.Add("@ContactPersonName", SqlDbType.VarChar).Value = this.ContactPersonName;
                SqlCmd.Parameters.Add("@Designation", SqlDbType.VarChar).Value = this.Designation;
                SqlCmd.Parameters.Add("@Address", SqlDbType.VarChar).Value = this.Address;
                SqlCmd.Parameters.Add("@linktoCountryMasterId", SqlDbType.SmallInt).Value = this.linktoCountryMasterId;
                SqlCmd.Parameters.Add("@linktoStateMasterId", SqlDbType.SmallInt).Value = this.linktoStateMasterId;
                SqlCmd.Parameters.Add("@linktoCityMasterId", SqlDbType.Int).Value = this.linktoCityMasterId;
                SqlCmd.Parameters.Add("@ZipCode", SqlDbType.VarChar).Value = this.ZipCode;
                SqlCmd.Parameters.Add("@Phone1", SqlDbType.VarChar).Value = this.Phone1;
                SqlCmd.Parameters.Add("@Phone2", SqlDbType.VarChar).Value = this.Phone2;
                SqlCmd.Parameters.Add("@Email1", SqlDbType.VarChar).Value = this.Email1;
                SqlCmd.Parameters.Add("@Email2", SqlDbType.VarChar).Value = this.Email2;
                SqlCmd.Parameters.Add("@Fax", SqlDbType.VarChar).Value = this.Fax;
                SqlCmd.Parameters.Add("@IsCredit", SqlDbType.Bit).Value = this.IsCredit;
                SqlCmd.Parameters.Add("@OpeningBalance", SqlDbType.Money).Value = this.OpeningBalance;
                SqlCmd.Parameters.Add("@CreditDays", SqlDbType.SmallInt).Value = this.CreditDays;
                SqlCmd.Parameters.Add("@CreditBalance", SqlDbType.Money).Value = this.CreditBalance;
                SqlCmd.Parameters.Add("@CreditLimit", SqlDbType.Money).Value = this.CreditLimit;
                SqlCmd.Parameters.Add("@Tax", SqlDbType.Money).Value = this.Tax;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCmd.Parameters.Add("@IsEnabled", SqlDbType.Bit).Value = this.IsEnabled;
                SqlCmd.Parameters.Add("@IsDeleted", SqlDbType.Bit).Value = this.IsDeleted;
                SqlCmd.Parameters.Add("@CreateDateTime", SqlDbType.DateTime).Value = this.CreateDateTime;
                SqlCmd.Parameters.Add("@linktoUserMasterIdCreatedBy", SqlDbType.SmallInt).Value = this.linktoUserMasterIdCreatedBy;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                this.SupplierMasterId = Convert.ToInt16(SqlCmd.Parameters["@SupplierMasterId"].Value);
                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region Update
        public posRecordStatus UpdateSupplierMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posSupplierMaster_Update", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@SupplierMasterId", SqlDbType.SmallInt).Value = this.SupplierMasterId;
                SqlCmd.Parameters.Add("@ShortName", SqlDbType.VarChar).Value = this.ShortName;
                SqlCmd.Parameters.Add("@SupplierName", SqlDbType.VarChar).Value = this.SupplierName;
                SqlCmd.Parameters.Add("@Description", SqlDbType.VarChar).Value = this.Description;
                SqlCmd.Parameters.Add("@ContactPersonName", SqlDbType.VarChar).Value = this.ContactPersonName;
                SqlCmd.Parameters.Add("@Designation", SqlDbType.VarChar).Value = this.Designation;
                SqlCmd.Parameters.Add("@Address", SqlDbType.VarChar).Value = this.Address;
                SqlCmd.Parameters.Add("@linktoCountryMasterId", SqlDbType.SmallInt).Value = this.linktoCountryMasterId;
                SqlCmd.Parameters.Add("@linktoStateMasterId", SqlDbType.SmallInt).Value = this.linktoStateMasterId;
                SqlCmd.Parameters.Add("@linktoCityMasterId", SqlDbType.Int).Value = this.linktoCityMasterId;
                SqlCmd.Parameters.Add("@ZipCode", SqlDbType.VarChar).Value = this.ZipCode;
                SqlCmd.Parameters.Add("@Phone1", SqlDbType.VarChar).Value = this.Phone1;
                SqlCmd.Parameters.Add("@Phone2", SqlDbType.VarChar).Value = this.Phone2;
                SqlCmd.Parameters.Add("@Email1", SqlDbType.VarChar).Value = this.Email1;
                SqlCmd.Parameters.Add("@Email2", SqlDbType.VarChar).Value = this.Email2;
                SqlCmd.Parameters.Add("@Fax", SqlDbType.VarChar).Value = this.Fax;
                SqlCmd.Parameters.Add("@IsCredit", SqlDbType.Bit).Value = this.IsCredit;
                SqlCmd.Parameters.Add("@OpeningBalance", SqlDbType.Money).Value = this.OpeningBalance;
                SqlCmd.Parameters.Add("@CreditDays", SqlDbType.SmallInt).Value = this.CreditDays;
                SqlCmd.Parameters.Add("@CreditBalance", SqlDbType.Money).Value = this.CreditBalance;
                SqlCmd.Parameters.Add("@CreditLimit", SqlDbType.Money).Value = this.CreditLimit;
                SqlCmd.Parameters.Add("@Tax", SqlDbType.Money).Value = this.Tax;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCmd.Parameters.Add("@IsEnabled", SqlDbType.Bit).Value = this.IsEnabled;
                SqlCmd.Parameters.Add("@IsDeleted", SqlDbType.Bit).Value = this.IsDeleted;
                SqlCmd.Parameters.Add("@UpdateDateTime", SqlDbType.DateTime).Value = this.UpdateDateTime;
                SqlCmd.Parameters.Add("@linktoUserMasterIdUpdatedBy", SqlDbType.SmallInt).Value = this.linktoUserMasterIdUpdatedBy;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region DeleteAll
        public static posRecordStatus DeleteAllSupplierMaster(string supplierMasterIds, short linktoUserMasterIdUpdatedBy, DateTime UpdateDateTime)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posSupplierMaster_DeleteAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@SupplierMasterIds", SqlDbType.VarChar).Value = supplierMasterIds;
                SqlCmd.Parameters.Add("@UpdateDateTime", SqlDbType.DateTime).Value = UpdateDateTime;
                SqlCmd.Parameters.Add("@linktoUserMasterIdUpdatedBy", SqlDbType.SmallInt).Value = linktoUserMasterIdUpdatedBy;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region Select
        public bool SelectSupplierMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posSupplierMaster_Select", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@SupplierMasterId", SqlDbType.SmallInt).Value = this.SupplierMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                bool IsSelected = SetClassPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                return IsSelected;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return false;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region SelectAll
        public List<posSupplierMasterDAL> SelectAllSupplierMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posSupplierMaster_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;
                SqlCmd.Parameters.Add("@SupplierName", SqlDbType.VarChar).Value = this.SupplierName;
                SqlCmd.Parameters.Add("@Phone1", SqlDbType.VarChar).Value = this.Phone1;
                SqlCmd.Parameters.Add("@IsCredit", SqlDbType.Bit).Value = this.IsCredit;
                SqlCmd.Parameters.Add("@IsEnabled", SqlDbType.Bit).Value = this.IsEnabled;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<posSupplierMasterDAL> lstSupplierMasterDAL = SetListPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                return lstSupplierMasterDAL;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public static List<posSupplierMasterDAL> SelectAllSupplierMasterSupplierName(short linktoBusinessMasterId)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posSupplierMasterSupplierName_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = linktoBusinessMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<posSupplierMasterDAL> lstSupplierMasterDAL = new List<posSupplierMasterDAL>();
                posSupplierMasterDAL objSupplierMasterDAL = null;
                while (SqlRdr.Read())
                {
                    objSupplierMasterDAL = new posSupplierMasterDAL();
                    objSupplierMasterDAL.SupplierMasterId = Convert.ToInt16(SqlRdr["SupplierMasterId"]);
                    objSupplierMasterDAL.SupplierName = Convert.ToString(SqlRdr["SupplierName"]);
                    lstSupplierMasterDAL.Add(objSupplierMasterDAL);
                }
                SqlRdr.Close();
                SqlCon.Close();

                return lstSupplierMasterDAL;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion
    }
}
