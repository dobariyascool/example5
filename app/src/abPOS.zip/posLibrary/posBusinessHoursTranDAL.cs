using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace posLibrary
{
    /// <summary>
    /// Class for posBusinessHoursTran
    /// </summary>
    public class posBusinessHoursTranDAL
    {
        #region Properties
        public short BusinessHoursTranId { get; set; }
        public short DayOfWeek { get; set; }
        public TimeSpan OpeningTime { get; set; }
        public TimeSpan ClosingTime { get; set; }
        public TimeSpan? BreakStartTime { get; set; }
        public TimeSpan? BreakEndTime { get; set; }
        public short linktoBusinessMasterId { get; set; }

        /// Extra
        public string Business { get; set; }
        #endregion

        #region Class Methods
        private List<posBusinessHoursTranDAL> SetListPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            List<posBusinessHoursTranDAL> lstBusinessHoursTran = new List<posBusinessHoursTranDAL>();
            posBusinessHoursTranDAL objBusinessHoursTran = null;
            while (sqlRdr.Read())
            {
                objBusinessHoursTran = new posBusinessHoursTranDAL();
                objBusinessHoursTran.BusinessHoursTranId = Convert.ToInt16(sqlRdr["BusinessHoursTranId"]);
                objBusinessHoursTran.DayOfWeek = Convert.ToInt16(sqlRdr["DayOfWeek"]);
                objBusinessHoursTran.OpeningTime = TimeSpan.Parse(sqlRdr["OpeningTime"].ToString());
                objBusinessHoursTran.ClosingTime = TimeSpan.Parse(sqlRdr["ClosingTime"].ToString());
                if (sqlRdr["BreakStartTime"] != DBNull.Value)
                {
                    objBusinessHoursTran.BreakStartTime = TimeSpan.Parse(sqlRdr["BreakStartTime"].ToString());
                }
                if (sqlRdr["BreakEndTime"] != DBNull.Value)
                {
                    objBusinessHoursTran.BreakEndTime = TimeSpan.Parse(sqlRdr["BreakEndTime"].ToString());
                }
                objBusinessHoursTran.linktoBusinessMasterId = Convert.ToInt16(sqlRdr["linktoBusinessMasterId"]);

                /// Extra
                objBusinessHoursTran.Business = Convert.ToString(sqlRdr["Business"]);
                lstBusinessHoursTran.Add(objBusinessHoursTran);
            }
            return lstBusinessHoursTran;
        }
        #endregion        

        #region Update
        public posRecordStatus UpdateBusinessHoursTran(List<posBusinessHoursTranDAL> lstBusinessHoursTran)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlTransaction SqlTran = null;
            posRecordStatus rs = posRecordStatus.Error;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCon.Open();
                SqlTran = SqlCon.BeginTransaction();
                SqlCmd = new SqlCommand("posBusinessHoursTran_Update", SqlCon, SqlTran);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                foreach (posBusinessHoursTranDAL obj in lstBusinessHoursTran)
                {
                    SqlCmd.Parameters.Clear();
                    SqlCmd.Parameters.Add("@BusinessHoursTranId", SqlDbType.SmallInt).Value = obj.BusinessHoursTranId;
                    SqlCmd.Parameters.Add("@DayOfWeek", SqlDbType.SmallInt).Value = obj.DayOfWeek;
                    SqlCmd.Parameters.Add("@OpeningTime", SqlDbType.Time).Value = obj.OpeningTime;
                    SqlCmd.Parameters.Add("@ClosingTime", SqlDbType.Time).Value = obj.ClosingTime;
                    SqlCmd.Parameters.Add("@BreakStartTime", SqlDbType.Time).Value = obj.BreakStartTime;
                    SqlCmd.Parameters.Add("@BreakEndTime", SqlDbType.Time).Value = obj.BreakEndTime;
                    SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = obj.linktoBusinessMasterId;
                    SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                    SqlCmd.ExecuteNonQuery();
                    rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;

                    if (rs != posRecordStatus.Success)
                    {
                        SqlTran.Rollback();
                        SqlCon.Close();
                        return rs;
                    }
                }
                SqlTran.Commit();
                SqlCon.Close();
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion        
        
        #region SelectAll
        public List<posBusinessHoursTranDAL> SelectAllBusinessHoursTranBusinessWise()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posBusinessHoursTranBusinessWise_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<posBusinessHoursTranDAL> lstBusinessHoursTranDAL = SetListPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                return lstBusinessHoursTranDAL;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion
    }
}
