using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace posLibrary
{
    /// <summary>
    /// Class for posPaymentTypeMaster
    /// </summary>
    public class posPaymentTypeMasterDAL
    {
        #region Properties
        public short PaymentTypeMasterId { get; set; }
        public string ShortName { get; set; }
        public string PaymentType { get; set; }
        public string Description { get; set; }
        public short linktoPaymentTypeCategoryMasterId { get; set; }
        public bool IsEnabled { get; set; }
        public short linktoBusinessMasterId { get; set; }
        public short linktoUserMasterIdCreatedBy { get; set; }
        public DateTime CreateDateTime { get; set; }
        public short? linktoUserMasterIdUpdatedBy { get; set; }
        public DateTime? UpdateDateTime { get; set; }
        public bool IsDefault { get; set; }

        /// Extra
        public string PaymentTypeCategory { get; set; }
        #endregion

        #region Class Methods
        private bool SetClassPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            if (sqlRdr.Read())
            {
                this.PaymentTypeMasterId = Convert.ToInt16(sqlRdr["PaymentTypeMasterId"]);
                this.ShortName = Convert.ToString(sqlRdr["ShortName"]);
                this.PaymentType = Convert.ToString(sqlRdr["PaymentType"]);
                this.Description = Convert.ToString(sqlRdr["Description"]);
                this.linktoPaymentTypeCategoryMasterId = Convert.ToInt16(sqlRdr["linktoPaymentTypeCategoryMasterId"]);
                this.IsEnabled = Convert.ToBoolean(sqlRdr["IsEnabled"]);
                this.linktoBusinessMasterId = Convert.ToInt16(sqlRdr["linktoBusinessMasterId"]);
                this.linktoUserMasterIdCreatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdCreatedBy"]);
                this.CreateDateTime = Convert.ToDateTime(sqlRdr["CreateDateTime"]);
                if (sqlRdr["linktoUserMasterIdUpdatedBy"] != DBNull.Value)
                {
                    this.linktoUserMasterIdUpdatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdUpdatedBy"]);
                }
                if (sqlRdr["UpdateDateTime"] != DBNull.Value)
                {
                    this.UpdateDateTime = Convert.ToDateTime(sqlRdr["UpdateDateTime"]);
                }

                /// Extra
                this.PaymentTypeCategory = Convert.ToString(sqlRdr["PaymenTypeCategory"]);
                return true;
            }
            return false;
        }

        private List<posPaymentTypeMasterDAL> SetListPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            List<posPaymentTypeMasterDAL> lstPaymentTypeMaster = new List<posPaymentTypeMasterDAL>();
            posPaymentTypeMasterDAL objPaymentTypeMaster = null;
            while (sqlRdr.Read())
            {
                objPaymentTypeMaster = new posPaymentTypeMasterDAL();
                objPaymentTypeMaster.PaymentTypeMasterId = Convert.ToInt16(sqlRdr["PaymentTypeMasterId"]);
                objPaymentTypeMaster.ShortName = Convert.ToString(sqlRdr["ShortName"]);
                objPaymentTypeMaster.PaymentType = Convert.ToString(sqlRdr["PaymentType"]);
                objPaymentTypeMaster.Description = Convert.ToString(sqlRdr["Description"]);
                objPaymentTypeMaster.linktoPaymentTypeCategoryMasterId = Convert.ToInt16(sqlRdr["linktoPaymentTypeCategoryMasterId"]);
                objPaymentTypeMaster.IsEnabled = Convert.ToBoolean(sqlRdr["IsEnabled"]);
                objPaymentTypeMaster.linktoBusinessMasterId = Convert.ToInt16(sqlRdr["linktoBusinessMasterId"]);
                objPaymentTypeMaster.linktoUserMasterIdCreatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdCreatedBy"]);
                objPaymentTypeMaster.CreateDateTime = Convert.ToDateTime(sqlRdr["CreateDateTime"]);
                if (sqlRdr["linktoUserMasterIdUpdatedBy"] != DBNull.Value)
                {
                    objPaymentTypeMaster.linktoUserMasterIdUpdatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdUpdatedBy"]);
                }
                if (sqlRdr["UpdateDateTime"] != DBNull.Value)
                {
                    objPaymentTypeMaster.UpdateDateTime = Convert.ToDateTime(sqlRdr["UpdateDateTime"]);
                }
                objPaymentTypeMaster.IsDefault = Convert.ToBoolean(sqlRdr["IsDefault"]);
                /// Extra
                objPaymentTypeMaster.PaymentTypeCategory = Convert.ToString(sqlRdr["PaymentTypeCategory"]);
                lstPaymentTypeMaster.Add(objPaymentTypeMaster);
            }
            return lstPaymentTypeMaster;
        }
        #endregion

        #region Insert
        public posRecordStatus InsertPaymentTypeMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posPaymentTypeMaster_Insert", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@PaymentTypeMasterId", SqlDbType.SmallInt).Direction = ParameterDirection.Output;
                SqlCmd.Parameters.Add("@ShortName", SqlDbType.VarChar).Value = this.ShortName;
                SqlCmd.Parameters.Add("@PaymentType", SqlDbType.VarChar).Value = this.PaymentType;
                SqlCmd.Parameters.Add("@Description", SqlDbType.VarChar).Value = this.Description;
                SqlCmd.Parameters.Add("@linktoPaymentTypeCategoryMasterId", SqlDbType.SmallInt).Value = this.linktoPaymentTypeCategoryMasterId;
                SqlCmd.Parameters.Add("@IsEnabled", SqlDbType.Bit).Value = this.IsEnabled;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCmd.Parameters.Add("@linktoUserMasterIdCreatedBy", SqlDbType.SmallInt).Value = this.linktoUserMasterIdCreatedBy;
                SqlCmd.Parameters.Add("@CreateDateTime", SqlDbType.DateTime).Value = this.CreateDateTime;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                this.PaymentTypeMasterId = Convert.ToInt16(SqlCmd.Parameters["@PaymentTypeMasterId"].Value);
                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region Update
        public posRecordStatus UpdatePaymentTypeMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posPaymentTypeMaster_Update", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@PaymentTypeMasterId", SqlDbType.SmallInt).Value = this.PaymentTypeMasterId;
                SqlCmd.Parameters.Add("@ShortName", SqlDbType.VarChar).Value = this.ShortName;
                SqlCmd.Parameters.Add("@PaymentType", SqlDbType.VarChar).Value = this.PaymentType;
                SqlCmd.Parameters.Add("@Description", SqlDbType.VarChar).Value = this.Description;
                SqlCmd.Parameters.Add("@linktoPaymentTypeCategoryMasterId", SqlDbType.SmallInt).Value = this.linktoPaymentTypeCategoryMasterId;
                SqlCmd.Parameters.Add("@IsEnabled", SqlDbType.Bit).Value = this.IsEnabled;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCmd.Parameters.Add("@linktoUserMasterIdUpdatedBy", SqlDbType.SmallInt).Value = this.linktoUserMasterIdUpdatedBy;
                SqlCmd.Parameters.Add("@UpdateDateTime", SqlDbType.DateTime).Value = this.UpdateDateTime;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region DeleteAll
        public static posRecordStatus DeleteAllPaymentTypeMaster(string paymentTypeMasterIds)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posPaymentTypeMaster_DeleteAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@PaymentTypeMasterIds", SqlDbType.VarChar).Value = paymentTypeMasterIds;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region Select
        public bool SelectPaymentTypeMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posPaymentTypeMaster_Select", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@PaymentTypeMasterId", SqlDbType.SmallInt).Value = this.PaymentTypeMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                bool IsSelected = SetClassPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                return IsSelected;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return false;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region SelectAll
        public List<posPaymentTypeMasterDAL> SelectAllPaymentTypeMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posPaymentTypeMaster_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@IsEnabled", SqlDbType.Bit).Value = this.IsEnabled;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<posPaymentTypeMasterDAL> lstPaymentTypeMasterDAL = SetListPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                return lstPaymentTypeMasterDAL;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public static List<posPaymentTypeMasterDAL> SelectAllPaymentTypeMasterPaymentType(short linktoBusinessMasterId)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posPaymentTypeMasterPaymentType_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = linktoBusinessMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<posPaymentTypeMasterDAL> lstPaymentTypeMasterDAL = new List<posPaymentTypeMasterDAL>();
                posPaymentTypeMasterDAL objPaymentTypeMasterDAL = null;
                while (SqlRdr.Read())
                {
                    objPaymentTypeMasterDAL = new posPaymentTypeMasterDAL();
                    objPaymentTypeMasterDAL.PaymentTypeMasterId = Convert.ToInt16(SqlRdr["PaymentTypeMasterId"]);
                    objPaymentTypeMasterDAL.PaymentType = Convert.ToString(SqlRdr["PaymentType"]);
                    lstPaymentTypeMasterDAL.Add(objPaymentTypeMasterDAL);
                }
                SqlRdr.Close();
                SqlCon.Close();

                return lstPaymentTypeMasterDAL;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion
    }
}
