using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace posLibrary
{
    /// <summary>
    /// Class for labBackupMaster
    /// </summary>
    public class posBackupMasterDAL
    {
        #region Properties
        public int BackupMasterId { get; set; }
        public DateTime BackupDateTime { get; set; }
        public string BackupPath { get; set; }
        public bool IsAutoBackup { get; set; }
        public short linktoCounterMasterId { get; set; }
        #endregion

        #region Class Methods
        private List<posBackupMasterDAL> SetListPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            List<posBackupMasterDAL> lstBackupMaster = new List<posBackupMasterDAL>();
            posBackupMasterDAL objBackupMaster = null;
            while (sqlRdr.Read())
            {
                objBackupMaster = new posBackupMasterDAL();
                objBackupMaster.BackupMasterId = Convert.ToInt32(sqlRdr["BackupMasterId"]);
                objBackupMaster.BackupDateTime = Convert.ToDateTime(sqlRdr["BackupDateTime"]);
                objBackupMaster.BackupPath = Convert.ToString(sqlRdr["BackupPath"]);
                objBackupMaster.IsAutoBackup = Convert.ToBoolean(sqlRdr["IsAutoBackup"]);
                objBackupMaster.linktoCounterMasterId = Convert.ToInt16(sqlRdr["linktoCounterMasterId"]);
                lstBackupMaster.Add(objBackupMaster);
            }
            return lstBackupMaster;
        }
        #endregion

        #region Insert
        public posRecordStatus InsertBackupMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posBackupMaster_Insert", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@BackupMasterId", SqlDbType.Int).Direction = ParameterDirection.Output;
                SqlCmd.Parameters.Add("@BackupDateTime", SqlDbType.DateTime).Value = this.BackupDateTime;
                SqlCmd.Parameters.Add("@BackupPath", SqlDbType.VarChar).Value = this.BackupPath;
                SqlCmd.Parameters.Add("@IsAutoBackup", SqlDbType.Bit).Value = this.IsAutoBackup;
                SqlCmd.Parameters.Add("@linktoCounterMasterId", SqlDbType.SmallInt).Value = this.linktoCounterMasterId;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                this.BackupMasterId = Convert.ToInt32(SqlCmd.Parameters["@BackupMasterId"].Value);
                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region Delete
        public posRecordStatus DeleteBackupMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posBackupMaster_Delete", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@BackupMasterId", SqlDbType.Int).Value = this.BackupMasterId;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion 

        #region SelectAll
        public List<posBackupMasterDAL> SelectAllBackupMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posBackupMaster_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;


                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<posBackupMasterDAL> lstBackupMasterDAL = SetListPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                return lstBackupMasterDAL;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion
    }
}
