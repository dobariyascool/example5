using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace posLibrary
{
    /// <summary>
    /// Class for posCustomerInvoiceMaster
    /// </summary>
    public class posCustomerInvoiceMasterDAL
    {
        #region Properties
        public int CustomerInvoiceMasterId { get; set; }
        public int linktoCustomerMasterId { get; set; }
        public string InvoiceNo { get; set; }
        public DateTime InvoiceDate { get; set; }
        public DateTime DueDate { get; set; }
        public string Remark { get; set; }
        public double TotalAmount { get; set; }
        public bool IsDeleted { get; set; }
        public DateTime CreateDateTime { get; set; }
        public short linktoUserMasterIdCreatedBy { get; set; }
        public DateTime? UpdateDateTime { get; set; }
        public short? linktoUserMasterIdUpdatedBy { get; set; }

      
        /// Extra
        public string Customer { get; set; }
        public string InvoiceNoWithAmount { get; set; }
        public bool IsPayment { get; set; }
        #endregion

        #region Class Methods
        private bool SetClassPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            if (sqlRdr.Read())
            {
                this.CustomerInvoiceMasterId = Convert.ToInt32(sqlRdr["CustomerInvoiceMasterId"]);
                this.linktoCustomerMasterId = Convert.ToInt32(sqlRdr["linktoCustomerMasterId"]);
                this.InvoiceNo = Convert.ToString(sqlRdr["InvoiceNo"]);
                this.InvoiceDate = Convert.ToDateTime(sqlRdr["InvoiceDate"]);
                this.DueDate = Convert.ToDateTime(sqlRdr["DueDate"]);
                this.Remark = Convert.ToString(sqlRdr["Remark"]);
                this.TotalAmount = Convert.ToDouble(sqlRdr["TotalAmount"]);
                this.IsDeleted = Convert.ToBoolean(sqlRdr["IsDeleted"]);
                this.CreateDateTime = Convert.ToDateTime(sqlRdr["CreateDateTime"]);
                this.linktoUserMasterIdCreatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdCreatedBy"]);
                if (sqlRdr["UpdateDateTime"] != DBNull.Value)
                {
                    this.UpdateDateTime = Convert.ToDateTime(sqlRdr["UpdateDateTime"]);
                }
                if (sqlRdr["linktoUserMasterIdUpdatedBy"] != DBNull.Value)
                {
                    this.linktoUserMasterIdUpdatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdUpdatedBy"]);
                }

                /// Extra
                this.Customer = Convert.ToString(sqlRdr["Customer"]);
                return true;
            }
            return false;
        }

        private List<posCustomerInvoiceMasterDAL> SetListPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            List<posCustomerInvoiceMasterDAL> lstCustomerInvoiceMaster = new List<posCustomerInvoiceMasterDAL>();
            posCustomerInvoiceMasterDAL objCustomerInvoiceMaster = null;
            while (sqlRdr.Read())
            {
                objCustomerInvoiceMaster = new posCustomerInvoiceMasterDAL();
                objCustomerInvoiceMaster.CustomerInvoiceMasterId = Convert.ToInt32(sqlRdr["CustomerInvoiceMasterId"]);
                objCustomerInvoiceMaster.linktoCustomerMasterId = Convert.ToInt32(sqlRdr["linktoCustomerMasterId"]);
                objCustomerInvoiceMaster.InvoiceNo = Convert.ToString(sqlRdr["InvoiceNo"]);
                objCustomerInvoiceMaster.InvoiceDate = Convert.ToDateTime(sqlRdr["InvoiceDate"]);
                objCustomerInvoiceMaster.DueDate = Convert.ToDateTime(sqlRdr["DueDate"]);
                objCustomerInvoiceMaster.Remark = Convert.ToString(sqlRdr["Remark"]);
                objCustomerInvoiceMaster.TotalAmount = Convert.ToDouble(sqlRdr["TotalAmount"]);
                objCustomerInvoiceMaster.IsDeleted = Convert.ToBoolean(sqlRdr["IsDeleted"]);
                objCustomerInvoiceMaster.CreateDateTime = Convert.ToDateTime(sqlRdr["CreateDateTime"]);
                objCustomerInvoiceMaster.linktoUserMasterIdCreatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdCreatedBy"]);
                if (sqlRdr["UpdateDateTime"] != DBNull.Value)
                {
                    objCustomerInvoiceMaster.UpdateDateTime = Convert.ToDateTime(sqlRdr["UpdateDateTime"]);
                }
                if (sqlRdr["linktoUserMasterIdUpdatedBy"] != DBNull.Value)
                {
                    objCustomerInvoiceMaster.linktoUserMasterIdUpdatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdUpdatedBy"]);
                }

                /// Extra
                objCustomerInvoiceMaster.Customer = Convert.ToString(sqlRdr["Customer"]);
                objCustomerInvoiceMaster.IsPayment = Convert.ToBoolean(sqlRdr["IsPayment"]);
                lstCustomerInvoiceMaster.Add(objCustomerInvoiceMaster);
            }
            return lstCustomerInvoiceMaster;
        }
        #endregion

        #region Insert
        public posRecordStatus InsertCustomerInvoiceMaster(List<posCustomerInvoiceTranDAL> lstCustomerInvoiceTran)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlTransaction SqlTran = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCon.Open();
                SqlTran = SqlCon.BeginTransaction();
                SqlCmd = new SqlCommand("posCustomerInvoiceMaster_Insert", SqlCon, SqlTran);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@CustomerInvoiceMasterId", SqlDbType.Int).Direction = ParameterDirection.Output;
                SqlCmd.Parameters.Add("@linktoCustomerMasterId", SqlDbType.Int).Value = this.linktoCustomerMasterId;
                SqlCmd.Parameters.Add("@InvoiceNo", SqlDbType.VarChar).Value = this.InvoiceNo;
                SqlCmd.Parameters.Add("@InvoiceDate", SqlDbType.DateTime).Value = this.InvoiceDate;
                SqlCmd.Parameters.Add("@DueDate", SqlDbType.DateTime).Value = this.DueDate;
                SqlCmd.Parameters.Add("@Remark", SqlDbType.VarChar).Value = this.Remark;
                SqlCmd.Parameters.Add("@TotalAmount", SqlDbType.Money).Value = this.TotalAmount;
                SqlCmd.Parameters.Add("@IsDeleted", SqlDbType.Bit).Value = this.IsDeleted;
                SqlCmd.Parameters.Add("@CreateDateTime", SqlDbType.DateTime).Value = this.CreateDateTime;
                SqlCmd.Parameters.Add("@linktoUserMasterIdCreatedBy", SqlDbType.SmallInt).Value = this.linktoUserMasterIdCreatedBy;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCmd.ExecuteNonQuery();
                this.CustomerInvoiceMasterId = Convert.ToInt32(SqlCmd.Parameters["@CustomerInvoiceMasterId"].Value);
                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;

                if (rs != posRecordStatus.Success)
                {
                    SqlTran.Rollback();
                    SqlCon.Close();
                    return rs;
                }
                foreach (posCustomerInvoiceTranDAL objCustomerInvoiceTranDAL in lstCustomerInvoiceTran)
                {
                    objCustomerInvoiceTranDAL.linktoCustomerInvoiceMasterId = this.CustomerInvoiceMasterId;
                    rs = objCustomerInvoiceTranDAL.InsertCustomerInvoiceTran(SqlCon, SqlTran);
                    if (rs != posRecordStatus.Success)
                    {
                        SqlTran.Rollback();
                        SqlCon.Close();
                        return rs;
                    }
                }
                SqlTran.Commit();
                SqlCon.Close();
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
                posObjectFactoryDAL.DisposeTransaction(SqlTran);
            }
        }
        #endregion

        #region DeleteAll
        public posRecordStatus DeleteAllCustomerInvoiceMaster(string customerInvoiceMasterIds, short linktoUserMasterIdUpdatedBy)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posCustomerInvoiceMaster_DeleteAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@CustomerInvoiceMasterIds", SqlDbType.VarChar).Value = customerInvoiceMasterIds;
                SqlCmd.Parameters.Add("@UpdateDateTime", SqlDbType.DateTime).Value = this.UpdateDateTime;
                SqlCmd.Parameters.Add("@linktoUserMasterIdUpdatedBy", SqlDbType.SmallInt).Value = this.linktoUserMasterIdUpdatedBy;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region Select
        public bool SelectCustomerInvoiceReaminPayment(int CustomerPaymentTranId)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posCustomerInvoiceRemaingPaymentAmount_Select", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@CustomerInvoiceMasterId", SqlDbType.Int).Value = this.CustomerInvoiceMasterId;
                SqlCmd.Parameters.Add("@CustomerPaymentTranId", SqlDbType.Int).Value = CustomerPaymentTranId;

                SqlCon.Open();
                bool IsSelected = false;
                object ReminingPayment = SqlCmd.ExecuteScalar();
                if (ReminingPayment != DBNull.Value)
                {
                    this.TotalAmount = Convert.ToDouble(ReminingPayment);
                    IsSelected = true;
                }
                SqlCon.Close();
                return IsSelected;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return false;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region SelectAll
        public List<posCustomerInvoiceMasterDAL> SelectAllCustomerInvoiceMaster(DateTime FromDate, DateTime ToDate)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
           
            try
            {
              
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posCustomerInvoiceMaster_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;
                
                SqlCmd.Parameters.Add("@linktoCustomerMasterId", SqlDbType.Int).Value = this.linktoCustomerMasterId;

                SqlCmd.Parameters.Add("@FromDate", SqlDbType.DateTime).Value = FromDate;
                SqlCmd.Parameters.Add("@ToDate", SqlDbType.DateTime).Value = ToDate;
                SqlCmd.Parameters.Add("@InvoiceNo", SqlDbType.VarChar).Value = this.InvoiceNo;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<posCustomerInvoiceMasterDAL> lstCustomerInvoiceMasterDAL = SetListPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                return lstCustomerInvoiceMasterDAL;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public static List<posCustomerInvoiceMasterDAL> SelectAllCustomerInvoiceMasterInvoiceNo(int linkToCusomerMasterId, DateTime FromDate, DateTime ToDate)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posCustomerInvoiceMasterInvoiceNo_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@linktoCustomerMasterId", SqlDbType.Int).Value = linkToCusomerMasterId;
                SqlCmd.Parameters.Add("@FromDate", SqlDbType.DateTime).Value = FromDate;
                SqlCmd.Parameters.Add("@ToDate", SqlDbType.DateTime).Value = ToDate;
              
                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<posCustomerInvoiceMasterDAL> lstCustomerInvoiceMasterDAL = new List<posCustomerInvoiceMasterDAL>();
                posCustomerInvoiceMasterDAL objCustomerInvoiceMasterDAL = null;
                while (SqlRdr.Read())
                {
                    objCustomerInvoiceMasterDAL = new posCustomerInvoiceMasterDAL();
                    objCustomerInvoiceMasterDAL.CustomerInvoiceMasterId = Convert.ToInt32(SqlRdr["CustomerInvoiceMasterId"]);
                    objCustomerInvoiceMasterDAL.InvoiceNoWithAmount = Convert.ToString(SqlRdr["InvoiceNo"]) + " (Rs. " + Convert.ToDouble(SqlRdr["TotalAmount"]).ToString("0.00") + ")";
                    objCustomerInvoiceMasterDAL.InvoiceNo = Convert.ToString(SqlRdr["InvoiceNo"]);
                    lstCustomerInvoiceMasterDAL.Add(objCustomerInvoiceMasterDAL);
                }
                SqlRdr.Close();
                SqlCon.Close();

                return lstCustomerInvoiceMasterDAL;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion
    }
}

