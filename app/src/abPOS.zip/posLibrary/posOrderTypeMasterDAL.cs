using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;


namespace posLibrary
{
    /// <summary>
    /// Class for posOrderTypeMaster
    /// </summary>
    public class posOrderTypeMasterDAL
    {
        #region Properties
        public short OrderTypeMasterId { get; set; }
        public string OrderType { get; set; }
        public short linktoBusinessTypeMasterId { get; set; }
        #endregion

        #region Class Methods
        private List<posOrderTypeMasterDAL> SetListPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            List<posOrderTypeMasterDAL> lstOrderTypeMaster = new List<posOrderTypeMasterDAL>();
            posOrderTypeMasterDAL objOrderTypeMaster = null;

            while (sqlRdr.Read())
            {
                objOrderTypeMaster = new posOrderTypeMasterDAL();
                objOrderTypeMaster.OrderTypeMasterId = Convert.ToInt16(sqlRdr["OrderTypeMasterId"]);
                objOrderTypeMaster.OrderType = Convert.ToString(sqlRdr["OrderType"]);
                objOrderTypeMaster.linktoBusinessTypeMasterId = Convert.ToInt16(sqlRdr["linktoBusinessTypeMasterId"]);
                lstOrderTypeMaster.Add(objOrderTypeMaster);
            }
            return lstOrderTypeMaster;
        }
        #endregion

        #region SelectAll
        public List<posOrderTypeMasterDAL> SelectAllOrderTypeMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posOrderTypeMaster_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<posOrderTypeMasterDAL> lstOrderTypeMasterDAL = SetListPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                return lstOrderTypeMasterDAL;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public static List<posOrderTypeMasterDAL> SelectAllOrderTypeMasterOrderType(short linktoBusinessMasterId)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posOrderTypeMasterOrderType_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@linktoBusinessTypeMasterId", SqlDbType.SmallInt).Value = linktoBusinessMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<posOrderTypeMasterDAL> lstOrderTypeMasterDAL = new List<posOrderTypeMasterDAL>();
                posOrderTypeMasterDAL objOrderTypeMasterDAL = null;
                while (SqlRdr.Read())
                {
                    objOrderTypeMasterDAL = new posOrderTypeMasterDAL();
                    objOrderTypeMasterDAL.OrderTypeMasterId = Convert.ToInt16(SqlRdr["OrderTypeMasterId"]);
                    objOrderTypeMasterDAL.OrderType = Convert.ToString(SqlRdr["OrderType"]);
                    lstOrderTypeMasterDAL.Add(objOrderTypeMasterDAL);
                }
                SqlRdr.Close();
                SqlCon.Close();

                return lstOrderTypeMasterDAL;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion
    }
}
