using System;
using System.Data;
using System.Data.SqlClient;
using System.Collections.Generic;

namespace posLibrary
{
	/// <summary>
	/// Class for posCodeGenMaster
	/// </summary>
	public class posCodeGenMasterDAL
	{
		#region Properties
		public short CodeGenMasterId { get; set; }
		public string CodeGen { get; set; }
		public string Description { get; set; }
		public DateTime? CodeGenDate { get; set; }
		public TimeSpan CodeGenTime { get; set; }
		public double Salary { get; set; }
		public double? Amount { get; set; }
		public string ImageName { get; set; }
		public string Color { get; set; }
		public short? StarRating { get; set; }
		public int linktoCodeGenUserMasterIdCreatedBy { get; set; }
		public DateTime CreateDateTime { get; set; }
		public int? linktoCodeGenUserMasterIdUpdatedBy { get; set; }
		public DateTime? UpdateDateTime { get; set; }
		public bool IsEnabled { get; set; }
		#endregion

		#region Class Methods
		private bool SetClassPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
		{
			if (sqlRdr.Read())
			{
				this.CodeGenMasterId = Convert.ToInt16(sqlRdr["CodeGenMasterId"]);
				this.CodeGen = Convert.ToString(sqlRdr["CodeGen"]);
				this.Description = Convert.ToString(sqlRdr["Description"]);
				if (sqlRdr["CodeGenDate"] != DBNull.Value)
				{
					this.CodeGenDate = Convert.ToDateTime(sqlRdr["CodeGenDate"]);
				}
				this.CodeGenTime = TimeSpan.Parse(sqlRdr["CodeGenTime"].ToString());
				this.Salary = Convert.ToDouble(sqlRdr["Salary"]);
				if (sqlRdr["Amount"] != DBNull.Value)
				{
					this.Amount = Convert.ToDouble(sqlRdr["Amount"]);
				}
				this.ImageName = Convert.ToString(sqlRdr["ImageName"]);
				this.Color = Convert.ToString(sqlRdr["Color"]);
				if (sqlRdr["StarRating"] != DBNull.Value)
				{
					this.StarRating = Convert.ToInt16(sqlRdr["StarRating"]);
				}
				this.linktoCodeGenUserMasterIdCreatedBy = Convert.ToInt32(sqlRdr["linktoCodeGenUserMasterIdCreatedBy"]);
				this.CreateDateTime = Convert.ToDateTime(sqlRdr["CreateDateTime"]);
				if (sqlRdr["linktoCodeGenUserMasterIdUpdatedBy"] != DBNull.Value)
				{
					this.linktoCodeGenUserMasterIdUpdatedBy = Convert.ToInt32(sqlRdr["linktoCodeGenUserMasterIdUpdatedBy"]);
				}
				if (sqlRdr["UpdateDateTime"] != DBNull.Value)
				{
					this.UpdateDateTime = Convert.ToDateTime(sqlRdr["UpdateDateTime"]);
				}
				this.IsEnabled = Convert.ToBoolean(sqlRdr["IsEnabled"]);
				return true;
			}
			return false;
		}

		private List<posCodeGenMasterDAL> SetListPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
		{
			List<posCodeGenMasterDAL> lstCodeGenMaster = new List<posCodeGenMasterDAL>();
			posCodeGenMasterDAL objCodeGenMaster = null;
			while (sqlRdr.Read())
			{
				objCodeGenMaster = new posCodeGenMasterDAL();
				objCodeGenMaster.CodeGenMasterId = Convert.ToInt16(sqlRdr["CodeGenMasterId"]);
				objCodeGenMaster.CodeGen = Convert.ToString(sqlRdr["CodeGen"]);
				objCodeGenMaster.Description = Convert.ToString(sqlRdr["Description"]);
				if (sqlRdr["CodeGenDate"] != DBNull.Value)
				{
					objCodeGenMaster.CodeGenDate = Convert.ToDateTime(sqlRdr["CodeGenDate"]);
				}
				objCodeGenMaster.CodeGenTime = TimeSpan.Parse(sqlRdr["CodeGenTime"].ToString());
				objCodeGenMaster.Salary = Convert.ToDouble(sqlRdr["Salary"]);
				if (sqlRdr["Amount"] != DBNull.Value)
				{
					objCodeGenMaster.Amount = Convert.ToDouble(sqlRdr["Amount"]);
				}
				objCodeGenMaster.ImageName = Convert.ToString(sqlRdr["ImageName"]);
				objCodeGenMaster.Color = Convert.ToString(sqlRdr["Color"]);
				if (sqlRdr["StarRating"] != DBNull.Value)
				{
					objCodeGenMaster.StarRating = Convert.ToInt16(sqlRdr["StarRating"]);
				}
				objCodeGenMaster.linktoCodeGenUserMasterIdCreatedBy = Convert.ToInt32(sqlRdr["linktoCodeGenUserMasterIdCreatedBy"]);
				objCodeGenMaster.CreateDateTime = Convert.ToDateTime(sqlRdr["CreateDateTime"]);
				if (sqlRdr["linktoCodeGenUserMasterIdUpdatedBy"] != DBNull.Value)
				{
					objCodeGenMaster.linktoCodeGenUserMasterIdUpdatedBy = Convert.ToInt32(sqlRdr["linktoCodeGenUserMasterIdUpdatedBy"]);
				}
				if (sqlRdr["UpdateDateTime"] != DBNull.Value)
				{
					objCodeGenMaster.UpdateDateTime = Convert.ToDateTime(sqlRdr["UpdateDateTime"]);
				}
				objCodeGenMaster.IsEnabled = Convert.ToBoolean(sqlRdr["IsEnabled"]);
				lstCodeGenMaster.Add(objCodeGenMaster);
			}
			return lstCodeGenMaster;
		}
		#endregion

		#region Insert
		public posRecordStatus InsertCodeGenMaster()
		{
			SqlConnection SqlCon = null;
			SqlCommand SqlCmd = null;
			try
			{
				SqlCon = posObjectFactoryDAL.CreateConnection();
				SqlCmd = new SqlCommand("posCodeGenMaster_Insert", SqlCon);
				SqlCmd.CommandType = CommandType.StoredProcedure;

				SqlCmd.Parameters.Add("@CodeGenMasterId", SqlDbType.SmallInt).Direction = ParameterDirection.Output;
				SqlCmd.Parameters.Add("@CodeGen", SqlDbType.VarChar).Value = this.CodeGen;
				SqlCmd.Parameters.Add("@Description", SqlDbType.VarChar).Value = this.Description;
				SqlCmd.Parameters.Add("@CodeGenDate", SqlDbType.Date).Value = this.CodeGenDate;
				SqlCmd.Parameters.Add("@CodeGenTime", SqlDbType.Time).Value = this.CodeGenTime;
				SqlCmd.Parameters.Add("@Salary", SqlDbType.Decimal).Value = this.Salary;
				SqlCmd.Parameters.Add("@Amount", SqlDbType.Money).Value = this.Amount;
				SqlCmd.Parameters.Add("@ImageName", SqlDbType.VarChar).Value = this.ImageName;
				SqlCmd.Parameters.Add("@Color", SqlDbType.VarChar).Value = this.Color;
				SqlCmd.Parameters.Add("@StarRating", SqlDbType.SmallInt).Value = this.StarRating;
				SqlCmd.Parameters.Add("@linktoCodeGenUserMasterIdCreatedBy", SqlDbType.Int).Value = this.linktoCodeGenUserMasterIdCreatedBy;
				SqlCmd.Parameters.Add("@CreateDateTime", SqlDbType.DateTime).Value = this.CreateDateTime;
				SqlCmd.Parameters.Add("@IsEnabled", SqlDbType.Bit).Value = this.IsEnabled;
				SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

				SqlCon.Open();
				SqlCmd.ExecuteNonQuery();
				SqlCon.Close();

				this.CodeGenMasterId = Convert.ToInt16(SqlCmd.Parameters["@CodeGenMasterId"].Value);
				posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
				return rs;
			}
			catch (Exception ex)
			{
				posGlobalsDAL.SaveError(ex);
				return posRecordStatus.Error;
			}
			finally
			{
				posObjectFactoryDAL.DisposeCommand(SqlCmd);
				posObjectFactoryDAL.DisposeConnection(SqlCon);
			}
		}
		#endregion

		#region Update
		public posRecordStatus UpdateCodeGenMaster()
		{
			SqlConnection SqlCon = null;
			SqlCommand SqlCmd = null;
			try
			{
				SqlCon = posObjectFactoryDAL.CreateConnection();
				SqlCmd = new SqlCommand("posCodeGenMaster_Update", SqlCon);
				SqlCmd.CommandType = CommandType.StoredProcedure;

				SqlCmd.Parameters.Add("@CodeGenMasterId", SqlDbType.SmallInt).Value = this.CodeGenMasterId;
				SqlCmd.Parameters.Add("@CodeGen", SqlDbType.VarChar).Value = this.CodeGen;
				SqlCmd.Parameters.Add("@Description", SqlDbType.VarChar).Value = this.Description;
				SqlCmd.Parameters.Add("@CodeGenDate", SqlDbType.Date).Value = this.CodeGenDate;
				SqlCmd.Parameters.Add("@CodeGenTime", SqlDbType.Time).Value = this.CodeGenTime;
				SqlCmd.Parameters.Add("@Salary", SqlDbType.Decimal).Value = this.Salary;
				SqlCmd.Parameters.Add("@Amount", SqlDbType.Money).Value = this.Amount;
				SqlCmd.Parameters.Add("@ImageName", SqlDbType.VarChar).Value = this.ImageName;
				SqlCmd.Parameters.Add("@Color", SqlDbType.VarChar).Value = this.Color;
				SqlCmd.Parameters.Add("@StarRating", SqlDbType.SmallInt).Value = this.StarRating;
				SqlCmd.Parameters.Add("@linktoCodeGenUserMasterIdUpdatedBy", SqlDbType.Int).Value = this.linktoCodeGenUserMasterIdUpdatedBy;
				SqlCmd.Parameters.Add("@UpdateDateTime", SqlDbType.DateTime).Value = this.UpdateDateTime;
				SqlCmd.Parameters.Add("@IsEnabled", SqlDbType.Bit).Value = this.IsEnabled;
				SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

				SqlCon.Open();
				SqlCmd.ExecuteNonQuery();
				SqlCon.Close();

				posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
				return rs;
			}
			catch (Exception ex)
			{
				posGlobalsDAL.SaveError(ex);
				return posRecordStatus.Error;
			}
			finally
			{
				posObjectFactoryDAL.DisposeCommand(SqlCmd);
				posObjectFactoryDAL.DisposeConnection(SqlCon);
			}
		}
		#endregion

		#region Delete
		public posRecordStatus DeleteCodeGenMaster()
		{
			SqlConnection SqlCon = null;
			SqlCommand SqlCmd = null;
			try
			{
				SqlCon = posObjectFactoryDAL.CreateConnection();
				SqlCmd = new SqlCommand("posCodeGenMaster_Delete", SqlCon);
				SqlCmd.CommandType = CommandType.StoredProcedure;

				SqlCmd.Parameters.Add("@CodeGenMasterId", SqlDbType.SmallInt).Value = this.CodeGenMasterId;
				SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

				SqlCon.Open();
				SqlCmd.ExecuteNonQuery();
				SqlCon.Close();

				posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
				return rs;
			}
			catch (Exception ex)
			{
				posGlobalsDAL.SaveError(ex);
				return posRecordStatus.Error;
			}
			finally
			{
				posObjectFactoryDAL.DisposeCommand(SqlCmd);
				posObjectFactoryDAL.DisposeConnection(SqlCon);
			}
		}
		#endregion

		#region Select
		public bool SelectCodeGenMaster()
		{
			SqlConnection SqlCon = null;
			SqlCommand SqlCmd = null;
			SqlDataReader SqlRdr = null;
			try
			{
				SqlCon = posObjectFactoryDAL.CreateConnection();
				SqlCmd = new SqlCommand("posCodeGenMaster_Select", SqlCon);
				SqlCmd.CommandType = CommandType.StoredProcedure;

				SqlCmd.Parameters.Add("@CodeGenMasterId", SqlDbType.SmallInt).Value = this.CodeGenMasterId;

				SqlCon.Open();
				SqlRdr = SqlCmd.ExecuteReader();
				bool IsSelected = SetClassPropertiesFromSqlDataReader(SqlRdr);
				SqlRdr.Close();
				SqlCon.Close();

				return IsSelected;
			}
			catch (Exception ex)
			{
				posGlobalsDAL.SaveError(ex);
				return false;
			}
			finally
			{
				posObjectFactoryDAL.DisposeDataReader(SqlRdr);
				posObjectFactoryDAL.DisposeCommand(SqlCmd);
				posObjectFactoryDAL.DisposeConnection(SqlCon);
			}
		}
		#endregion

		#region SelectAll

		public List<posCodeGenMasterDAL> SelectAllCodeGenMaster()
		{
			SqlConnection SqlCon = null;
			SqlCommand SqlCmd = null;
			SqlDataReader SqlRdr = null;
			try
			{
				SqlCon = posObjectFactoryDAL.CreateConnection();
				SqlCmd = new SqlCommand("posCodeGenMaster_SelectAll", SqlCon);
				SqlCmd.CommandType = CommandType.StoredProcedure;

				SqlCmd.Parameters.Add("@CodeGen", SqlDbType.VarChar).Value = this.CodeGen;
				SqlCmd.Parameters.Add("@CodeGenDate", SqlDbType.Date).Value = this.CodeGenDate;
				SqlCmd.Parameters.Add("@StarRating", SqlDbType.SmallInt).Value = this.StarRating;
				SqlCmd.Parameters.Add("@IsEnabled", SqlDbType.Bit).Value = this.IsEnabled;

				SqlCon.Open();
				SqlRdr = SqlCmd.ExecuteReader();
				List<posCodeGenMasterDAL> lstCodeGenMasterDAL = SetListPropertiesFromSqlDataReader(SqlRdr);
				SqlRdr.Close();
				SqlCon.Close();

				return lstCodeGenMasterDAL;
			}
			catch (Exception ex)
			{
				posGlobalsDAL.SaveError(ex);
				return null;
			}
			finally
			{
				posObjectFactoryDAL.DisposeDataReader(SqlRdr);
				posObjectFactoryDAL.DisposeCommand(SqlCmd);
				posObjectFactoryDAL.DisposeConnection(SqlCon);
			}
		}

		public static List<posCodeGenMasterDAL> SelectAllCodeGenMasterCodeGen()
		{
			SqlConnection SqlCon = null;
			SqlCommand SqlCmd = null;
			SqlDataReader SqlRdr = null;
			try
			{
				SqlCon = posObjectFactoryDAL.CreateConnection();
				SqlCmd = new SqlCommand("posCodeGenMasterCodeGen_SelectAll", SqlCon);
				SqlCmd.CommandType = CommandType.StoredProcedure;

				SqlCon.Open();
				SqlRdr = SqlCmd.ExecuteReader();
				List<posCodeGenMasterDAL> lstCodeGenMasterDAL = new List<posCodeGenMasterDAL>();
				posCodeGenMasterDAL objCodeGenMasterDAL = null;
				while (SqlRdr.Read())
				{
					objCodeGenMasterDAL = new posCodeGenMasterDAL();
					objCodeGenMasterDAL.CodeGenMasterId = Convert.ToInt16(SqlRdr["CodeGenMasterId"]);
					objCodeGenMasterDAL.CodeGen = Convert.ToString(SqlRdr["CodeGen"]);
					lstCodeGenMasterDAL.Add(objCodeGenMasterDAL);
				}
				SqlRdr.Close();
				SqlCon.Close();

				return lstCodeGenMasterDAL;
			}
			catch (Exception ex)
			{
				posGlobalsDAL.SaveError(ex);
				return null;
			}
			finally
			{
				posObjectFactoryDAL.DisposeDataReader(SqlRdr);
				posObjectFactoryDAL.DisposeCommand(SqlCmd);
				posObjectFactoryDAL.DisposeConnection(SqlCon);
			}
		}
		#endregion
	}
}
