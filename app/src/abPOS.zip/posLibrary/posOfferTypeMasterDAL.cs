using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace posLibrary
{
	/// <summary>
	/// Class for posOfferTypeMaster
	/// </summary>
	public class posOfferTypeMasterDAL
	{
		#region Properties
		public short OfferTypeMasterId { get; set; }
		public string OfferType { get; set; }
		public string Description { get; set; }
		#endregion

		#region SelectAll

		public static List<posOfferTypeMasterDAL> SelectAllOfferTypeMasterOfferType()
		{
			SqlConnection SqlCon = null;
			SqlCommand SqlCmd = null;
			SqlDataReader SqlRdr = null;
			try
			{
				SqlCon = posObjectFactoryDAL.CreateConnection();
				SqlCmd = new SqlCommand("posOfferTypeMasterOfferType_SelectAll", SqlCon);
				SqlCmd.CommandType = CommandType.StoredProcedure;

				SqlCon.Open();
				SqlRdr = SqlCmd.ExecuteReader();
				List<posOfferTypeMasterDAL> lstOfferTypeMasterDAL = new List<posOfferTypeMasterDAL>();
				posOfferTypeMasterDAL objOfferTypeMasterDAL = null;
				while (SqlRdr.Read())
				{
					objOfferTypeMasterDAL = new posOfferTypeMasterDAL();
					objOfferTypeMasterDAL.OfferTypeMasterId = Convert.ToInt16(SqlRdr["OfferTypeMasterId"]);
					objOfferTypeMasterDAL.OfferType = Convert.ToString(SqlRdr["OfferType"]);
					lstOfferTypeMasterDAL.Add(objOfferTypeMasterDAL);
				}
				SqlRdr.Close();
				SqlCon.Close();

				return lstOfferTypeMasterDAL;
			}
			catch (Exception ex)
			{
				posGlobalsDAL.SaveError(ex);
				return null;
			}
			finally
			{
				posObjectFactoryDAL.DisposeDataReader(SqlRdr);
				posObjectFactoryDAL.DisposeCommand(SqlCmd);
				posObjectFactoryDAL.DisposeConnection(SqlCon);
			}
		}
		#endregion
	}
}
