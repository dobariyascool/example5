using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace posLibrary
{
    /// <summary>
    /// Class for posOfferMaster
    /// </summary>
    public class posOfferMasterDAL
    {
        #region Properties
        public int OfferMasterId { get; set; }
        public short linktoOfferTypeMasterId { get; set; }
        public string OfferTitle { get; set; }
        public string OfferContent { get; set; }
        public DateTime? FromDate { get; set; }
        public DateTime? ToDate { get; set; }
        public TimeSpan? FromTime { get; set; }
        public TimeSpan? ToTime { get; set; }
        public double? MinimumBillAmount { get; set; }
        public double Discount { get; set; }
        public bool IsDiscountPercentage { get; set; }
        public short? OfferLimit { get; set; }
        public int? RedeemCount { get; set; }
        public string OfferCode { get; set; }
        public string ImagePhysicalName { get; set; }
        public DateTime CreateDateTime { get; set; }
        public short linktoUserMasterIdCreatedBy { get; set; }
        public DateTime? UpdateDateTime { get; set; }
        public short? linktoUserMasterIdUpdatedBy { get; set; }
        public short linktoBusinessMasterId { get; set; }
        public int linktoCustomerMasterId { get; set; }
        public string TermsAndConditions { get; set; }
        public bool IsEnabled { get; set; }
        public bool IsDeleted { get; set; }
        public bool IsForCustomers { get; set; }
        public bool IsUnconditional { get; set; }
        public string linktoOrderTypeMasterIds { get; set; }
        public bool IsOnline { get; set; }
        public bool IsForApp { get; set; }
        public bool IsForAllDays { get; set; }
        public bool IsNotApplicableWithOtherOffers { get; set; }

        /// Extra
        public string OfferType { get; set; }
        public string Business { get; set; }

        public string DiscountWithType { get; set; }
        public short? linktoCounterMasterId { get; set; }
        public string TimeDuration { get; set; }
        public int BuyItemCount { get; set; }
        public int GetItemCount { get; set; }
        public List<posOfferCodesTranDAL> lstOfferCodesTranDAL { get; set; }
        public List<posOfferItemsTranDAL> lstOfferItemsTranDAL { get; set; }
        public List<posOfferDaysTranDAL> lstOfferDaysTranDAL { get; set; }

        // Image Property
        public string xs_ImagePhysicalName { get; set; }
        public string sm_ImagePhysicalName { get; set; }
        public string md_ImagePhysicalName { get; set; }
        public string lg_ImagePhysicalName { get; set; }
        public string xl_ImagePhysicalName { get; set; }
        public string ValidDays { get; set; }
        public string ValidItems { get; set; }
        public string ValidBuyItems { get; set; }
        public string ValidGetItems { get; set; }

        #endregion

        #region Class Methods
        private bool SetClassPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            if (sqlRdr.Read())
            {
                this.OfferMasterId = Convert.ToInt32(sqlRdr["OfferMasterId"]);
                this.linktoOfferTypeMasterId = Convert.ToInt16(sqlRdr["linktoOfferTypeMasterId"]);
                if (sqlRdr["linktoOrderTypeMasterIds"] != DBNull.Value)
                {
                    this.linktoOrderTypeMasterIds = Convert.ToString(sqlRdr["linktoOrderTypeMasterIds"]);
                }
                this.OfferTitle = Convert.ToString(sqlRdr["OfferTitle"]);
                this.OfferContent = Convert.ToString(sqlRdr["OfferContent"]);
                if (sqlRdr["FromDate"] != DBNull.Value)
                {
                    this.FromDate = Convert.ToDateTime(sqlRdr["FromDate"]);
                }
                if (sqlRdr["ToDate"] != DBNull.Value)
                {
                    this.ToDate = Convert.ToDateTime(sqlRdr["ToDate"]);
                }
                if (sqlRdr["FromTime"] != DBNull.Value)
                {
                    this.FromTime = TimeSpan.Parse(sqlRdr["FromTime"].ToString());
                }
                if (sqlRdr["ToTime"] != DBNull.Value)
                {
                    this.ToTime = TimeSpan.Parse(sqlRdr["ToTime"].ToString());
                }
                if (sqlRdr["MinimumBillAmount"] != DBNull.Value)
                {
                    this.MinimumBillAmount = Convert.ToDouble(sqlRdr["MinimumBillAmount"]);
                }
                this.Discount = Convert.ToDouble(sqlRdr["Discount"]);
                this.IsDiscountPercentage = Convert.ToBoolean(sqlRdr["IsDiscountPercentage"]);
                //if (sqlRdr["OfferLimit"] != DBNull.Value)
                //{
                //    this.OfferLimit = Convert.ToInt16(sqlRdr["OfferLimit"]);
                //}
                if (sqlRdr["RedeemCount"] != DBNull.Value)
                {
                    this.RedeemCount = Convert.ToInt32(sqlRdr["RedeemCount"]);
                }
                this.OfferCode = Convert.ToString(sqlRdr["OfferCode"]);

                this.CreateDateTime = Convert.ToDateTime(sqlRdr["CreateDateTime"]);
                this.linktoUserMasterIdCreatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdCreatedBy"]);
                if (sqlRdr["UpdateDateTime"] != DBNull.Value)
                {
                    this.UpdateDateTime = Convert.ToDateTime(sqlRdr["UpdateDateTime"]);
                }
                if (sqlRdr["linktoUserMasterIdUpdatedBy"] != DBNull.Value)
                {
                    this.linktoUserMasterIdUpdatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdUpdatedBy"]);
                }
                this.linktoBusinessMasterId = Convert.ToInt16(sqlRdr["linktoBusinessMasterId"]);
                this.TermsAndConditions = Convert.ToString(sqlRdr["TermsAndConditions"]);
                this.IsEnabled = Convert.ToBoolean(sqlRdr["IsEnabled"]);
                this.IsDeleted = Convert.ToBoolean(sqlRdr["IsDeleted"]);
                this.IsForCustomers = Convert.ToBoolean(sqlRdr["IsForCustomers"]);
                // this.IsUnconditional = Convert.ToBoolean(sqlRdr["IsUnconditional"]);
                if (sqlRdr["BuyItemCount"] != DBNull.Value)
                {
                    this.BuyItemCount = Convert.ToInt32(sqlRdr["BuyItemCount"]);
                }
                if (sqlRdr["GetItemCount"] != DBNull.Value)
                {
                    this.GetItemCount = Convert.ToInt32(sqlRdr["GetItemCount"]);
                }
                this.IsForAllDays = Convert.ToBoolean(sqlRdr["IsForAllDays"]);
                this.IsOnline = Convert.ToBoolean(sqlRdr["IsOnline"]);
                this.IsForApp = Convert.ToBoolean(sqlRdr["IsForApp"]);
                this.IsNotApplicableWithOtherOffers = Convert.ToBoolean(sqlRdr["IsNotApplicableWithOtherOffers"]);


                /// Extra
                this.OfferType = Convert.ToString(sqlRdr["OfferType"]);
                this.Business = Convert.ToString(sqlRdr["Business"]);
                if (sqlRdr["ImagePhysicalName"] != DBNull.Value)
                {
                    this.ImagePhysicalName = Convert.ToString(sqlRdr["ImagePhysicalName"]);

                    this.xs_ImagePhysicalName = "xs_" + Convert.ToString(sqlRdr["ImagePhysicalName"]);
                    this.sm_ImagePhysicalName = "sm_" + Convert.ToString(sqlRdr["ImagePhysicalName"]);
                    this.md_ImagePhysicalName = "md_" + Convert.ToString(sqlRdr["ImagePhysicalName"]);
                    this.lg_ImagePhysicalName = "lg_" + Convert.ToString(sqlRdr["ImagePhysicalName"]);
                    this.xl_ImagePhysicalName = "xl_" + Convert.ToString(sqlRdr["ImagePhysicalName"]);

                }
                else
                {
                    this.ImagePhysicalName = Convert.ToString(sqlRdr["ImagePhysicalName"]);

                    this.xs_ImagePhysicalName = "img/NoImage.png";
                    this.sm_ImagePhysicalName = "img/NoImage.png";
                    this.md_ImagePhysicalName = "img/NoImage.png";
                    this.lg_ImagePhysicalName = "img/NoImage.png";
                    this.xl_ImagePhysicalName = "img/NoImage.png";

                }
                if (sqlRdr["ValidDays"] != DBNull.Value)
                {
                    this.ValidDays = Convert.ToString(sqlRdr["ValidDays"]);
                }
                if (sqlRdr["ValidItems"] != DBNull.Value)
                {
                    this.ValidItems = Convert.ToString(sqlRdr["ValidItems"]);
                }
                if (sqlRdr["ValidBuyItems"] != DBNull.Value)
                {
                    this.ValidBuyItems = Convert.ToString(sqlRdr["ValidBuyItems"]);
                }
                if (sqlRdr["ValidGetItems"] != DBNull.Value)
                {
                    this.ValidGetItems = Convert.ToString(sqlRdr["ValidGetItems"]);
                }
                return true;
            }
            return false;
        }

        private List<posOfferMasterDAL> SetListPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            List<posOfferMasterDAL> lstOfferMaster = new List<posOfferMasterDAL>();
            posOfferMasterDAL objOfferMaster = null;
            while (sqlRdr.Read())
            {
                objOfferMaster = new posOfferMasterDAL();
                objOfferMaster.OfferMasterId = Convert.ToInt32(sqlRdr["OfferMasterId"]);
                objOfferMaster.linktoOfferTypeMasterId = Convert.ToInt16(sqlRdr["linktoOfferTypeMasterId"]);
                if (sqlRdr["linktoOrderTypeMasterIds"] != DBNull.Value)
                {
                    objOfferMaster.linktoOrderTypeMasterIds = Convert.ToString(sqlRdr["linktoOrderTypeMasterIds"]);
                }
                objOfferMaster.OfferTitle = Convert.ToString(sqlRdr["OfferTitle"]);
                objOfferMaster.OfferContent = Convert.ToString(sqlRdr["OfferContent"]);
                if (sqlRdr["FromDate"] != DBNull.Value)
                {
                    objOfferMaster.FromDate = Convert.ToDateTime(sqlRdr["FromDate"]);
                }
                if (sqlRdr["ToDate"] != DBNull.Value)
                {
                    objOfferMaster.ToDate = Convert.ToDateTime(sqlRdr["ToDate"]);
                }
                if (sqlRdr["FromTime"] != DBNull.Value)
                {
                    objOfferMaster.FromTime = TimeSpan.Parse(sqlRdr["FromTime"].ToString());
                }
                if (sqlRdr["ToTime"] != DBNull.Value)
                {
                    objOfferMaster.ToTime = TimeSpan.Parse(sqlRdr["ToTime"].ToString());
                }
                if (sqlRdr["MinimumBillAmount"] != DBNull.Value)
                {
                    objOfferMaster.MinimumBillAmount = Convert.ToDouble(sqlRdr["MinimumBillAmount"]);
                }
                objOfferMaster.Discount = Convert.ToDouble(sqlRdr["Discount"]);

                objOfferMaster.IsDiscountPercentage = Convert.ToBoolean(sqlRdr["IsDiscountPercentage"]);
                //if (sqlRdr["OfferLimit"] != DBNull.Value)
                //{
                //    objOfferMaster.OfferLimit = Convert.ToInt16(sqlRdr["OfferLimit"]);
                //}
                if (sqlRdr["RedeemCount"] != DBNull.Value)
                {
                    objOfferMaster.RedeemCount = Convert.ToInt32(sqlRdr["RedeemCount"]);
                }
                objOfferMaster.OfferCode = Convert.ToString(sqlRdr["OfferCode"]);
                objOfferMaster.ImagePhysicalName = Convert.ToString(sqlRdr["ImagePhysicalName"]);
                objOfferMaster.CreateDateTime = Convert.ToDateTime(sqlRdr["CreateDateTime"]);
                objOfferMaster.linktoUserMasterIdCreatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdCreatedBy"]);
                if (sqlRdr["UpdateDateTime"] != DBNull.Value)
                {
                    objOfferMaster.UpdateDateTime = Convert.ToDateTime(sqlRdr["UpdateDateTime"]);
                }
                if (sqlRdr["linktoUserMasterIdUpdatedBy"] != DBNull.Value)
                {
                    objOfferMaster.linktoUserMasterIdUpdatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdUpdatedBy"]);
                }
                objOfferMaster.linktoBusinessMasterId = Convert.ToInt16(sqlRdr["linktoBusinessMasterId"]);
                objOfferMaster.TermsAndConditions = Convert.ToString(sqlRdr["TermsAndConditions"]);
                objOfferMaster.IsEnabled = Convert.ToBoolean(sqlRdr["IsEnabled"]);
                objOfferMaster.IsDeleted = Convert.ToBoolean(sqlRdr["IsDeleted"]);
                objOfferMaster.IsForCustomers = Convert.ToBoolean(sqlRdr["IsForCustomers"]);
                //  objOfferMaster.IsUnconditional = Convert.ToBoolean(sqlRdr["IsUnconditional"]);

                /// Extra
                objOfferMaster.OfferType = Convert.ToString(sqlRdr["OfferType"]);
                objOfferMaster.Business = Convert.ToString(sqlRdr["Business"]);
                if (objOfferMaster.IsDiscountPercentage)
                {
                    objOfferMaster.DiscountWithType = objOfferMaster.Discount + " %";
                }
                else
                {
                    objOfferMaster.DiscountWithType = objOfferMaster.Discount + " Rs.";
                }
                if (sqlRdr["ImagePhysicalName"] != DBNull.Value)
                {
                    objOfferMaster.ImagePhysicalName = Convert.ToString(sqlRdr["ImagePhysicalName"]);

                    objOfferMaster.xs_ImagePhysicalName = "xs_" + Convert.ToString(sqlRdr["ImagePhysicalName"]);
                    objOfferMaster.sm_ImagePhysicalName = "sm_" + Convert.ToString(sqlRdr["ImagePhysicalName"]);
                    objOfferMaster.md_ImagePhysicalName = "md_" + Convert.ToString(sqlRdr["ImagePhysicalName"]);
                    objOfferMaster.lg_ImagePhysicalName = "lg_" + Convert.ToString(sqlRdr["ImagePhysicalName"]);
                    objOfferMaster.xl_ImagePhysicalName = "xl_" + Convert.ToString(sqlRdr["ImagePhysicalName"]);
                }
                else
                {
                    objOfferMaster.ImagePhysicalName = Convert.ToString(sqlRdr["ImagePhysicalName"]);

                    objOfferMaster.xs_ImagePhysicalName = "img/NoImage.png";
                    objOfferMaster.sm_ImagePhysicalName = "img/NoImage.png";
                    objOfferMaster.md_ImagePhysicalName = "img/NoImage.png";
                    objOfferMaster.lg_ImagePhysicalName = "img/NoImage.png";
                    objOfferMaster.xl_ImagePhysicalName = "img/NoImage.png";
                }
                lstOfferMaster.Add(objOfferMaster);
            }
            return lstOfferMaster;
        }
        #endregion

        #region Insert
        public posRecordStatus InsertOfferMaster()
        {
            SqlConnection SqlCon = null;
            SqlTransaction SqlTran = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCon.Open();
                SqlTran = SqlCon.BeginTransaction();
                SqlCmd = new SqlCommand("posOfferMaster_Insert", SqlCon, SqlTran);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@OfferMasterId", SqlDbType.Int).Direction = ParameterDirection.Output;
                SqlCmd.Parameters.Add("@linktoOfferTypeMasterId", SqlDbType.SmallInt).Value = this.linktoOfferTypeMasterId;
                SqlCmd.Parameters.Add("@OfferTitle", SqlDbType.VarChar).Value = this.OfferTitle;
                SqlCmd.Parameters.Add("@OfferContent", SqlDbType.VarChar).Value = this.OfferContent;
                SqlCmd.Parameters.Add("@FromDate", SqlDbType.Date).Value = this.FromDate;
                SqlCmd.Parameters.Add("@ToDate", SqlDbType.Date).Value = this.ToDate;
                SqlCmd.Parameters.Add("@FromTime", SqlDbType.Time).Value = this.FromTime;
                SqlCmd.Parameters.Add("@ToTime", SqlDbType.Time).Value = this.ToTime;
                SqlCmd.Parameters.Add("@MinimumBillAmount", SqlDbType.Money).Value = this.MinimumBillAmount;
                SqlCmd.Parameters.Add("@Discount", SqlDbType.Money).Value = this.Discount;
                SqlCmd.Parameters.Add("@IsDiscountPercentage", SqlDbType.Bit).Value = this.IsDiscountPercentage;
                SqlCmd.Parameters.Add("@RedeemCount", SqlDbType.Int).Value = this.RedeemCount;
                SqlCmd.Parameters.Add("@IsForApp", SqlDbType.Bit).Value = this.IsForApp;
                SqlCmd.Parameters.Add("@BuyItemCount", SqlDbType.Int).Value = this.BuyItemCount;
                SqlCmd.Parameters.Add("@GetItemCount", SqlDbType.Int).Value = this.GetItemCount;
                SqlCmd.Parameters.Add("@IsForAllDays", SqlDbType.Bit).Value = this.IsForAllDays;
                SqlCmd.Parameters.Add("@OfferCode", SqlDbType.VarChar).Value = this.OfferCode;
                SqlCmd.Parameters.Add("@ImagePhysicalName", SqlDbType.VarChar).Value = this.ImagePhysicalName;
                SqlCmd.Parameters.Add("@CreateDateTime", SqlDbType.DateTime).Value = this.CreateDateTime;
                SqlCmd.Parameters.Add("@linktoUserMasterIdCreatedBy", SqlDbType.SmallInt).Value = this.linktoUserMasterIdCreatedBy;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCmd.Parameters.Add("@TermsAndConditions", SqlDbType.VarChar).Value = this.TermsAndConditions;
                SqlCmd.Parameters.Add("@IsEnabled", SqlDbType.Bit).Value = this.IsEnabled;
                SqlCmd.Parameters.Add("@IsDeleted", SqlDbType.Bit).Value = this.IsDeleted;
                SqlCmd.Parameters.Add("@IsForCustomers", SqlDbType.Bit).Value = this.IsForCustomers;
                SqlCmd.Parameters.Add("@IsOnline", SqlDbType.Bit).Value = this.IsOnline;
                SqlCmd.Parameters.Add("@linktoOrderTypeMasterIds", SqlDbType.VarChar).Value = this.linktoOrderTypeMasterIds;
                SqlCmd.Parameters.Add("@linktoCounterMasterId", SqlDbType.SmallInt).Value = this.linktoCounterMasterId;
                SqlCmd.Parameters.Add("@IsNotApplicableWithOtherOffers", SqlDbType.Bit).Value = this.IsNotApplicableWithOtherOffers;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCmd.ExecuteNonQuery();

                this.OfferMasterId = Convert.ToInt32(SqlCmd.Parameters["@OfferMasterId"].Value);
                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                if (rs == posRecordStatus.Error || rs == posRecordStatus.RecordAlreadyExist)
                {
                    SqlTran.Rollback();
                    SqlCon.Close();
                    return rs;
                }

                if (IsForCustomers)
                {
                    foreach (posOfferCodesTranDAL objOfferCodesTran in lstOfferCodesTranDAL)
                    {
                        objOfferCodesTran.linktoOfferMasterId = this.OfferMasterId;
                        rs = objOfferCodesTran.InsertOfferCodesTran(SqlCon, SqlTran);

                        if (rs == posRecordStatus.Error)
                        {
                            SqlTran.Rollback();
                            SqlCon.Close();
                            return rs;
                        }
                    }
                }

                if (linktoOfferTypeMasterId != posOfferType.General_Offer.GetHashCode())
                {
                    foreach (posOfferItemsTranDAL objOfferItemsTran in lstOfferItemsTranDAL)
                    {
                        objOfferItemsTran.linktoOfferMasterId = this.OfferMasterId;
                        rs = objOfferItemsTran.InsertOfferItemsTran(SqlCon, SqlTran);

                        if (rs == posRecordStatus.Error)
                        {
                            SqlTran.Rollback();
                            SqlCon.Close();
                            return rs;
                        }
                    }
                }

                if (!IsForAllDays)
                {
                    foreach (posOfferDaysTranDAL objOfferDaysTran in lstOfferDaysTranDAL)
                    {
                        objOfferDaysTran.linktoOfferMasterId = this.OfferMasterId;
                        rs = objOfferDaysTran.InsertOfferDaysTran(SqlCon, SqlTran);

                        if (rs == posRecordStatus.Error)
                        {
                            SqlTran.Rollback();
                            SqlCon.Close();
                            return rs;
                        }
                    }
                }
                SqlTran.Commit();
                SqlCon.Close();
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
                posObjectFactoryDAL.DisposeTransaction(SqlTran);
            }
        }
        #endregion

        #region Update
        public posRecordStatus UpdateOfferMaster()
        {
            SqlConnection SqlCon = null;
            SqlTransaction SqlTran = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCon.Open();
                SqlTran = SqlCon.BeginTransaction();
                SqlCmd = new SqlCommand("posOfferMaster_Update", SqlCon, SqlTran);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@OfferMasterId", SqlDbType.Int).Value = this.OfferMasterId;
                SqlCmd.Parameters.Add("@linktoOfferTypeMasterId", SqlDbType.SmallInt).Value = this.linktoOfferTypeMasterId;
                SqlCmd.Parameters.Add("@linktoOrderTypeMasterIds", SqlDbType.VarChar).Value = this.linktoOrderTypeMasterIds;
                SqlCmd.Parameters.Add("@OfferTitle", SqlDbType.VarChar).Value = this.OfferTitle;
                SqlCmd.Parameters.Add("@OfferContent", SqlDbType.VarChar).Value = this.OfferContent;
                SqlCmd.Parameters.Add("@FromDate", SqlDbType.Date).Value = this.FromDate;
                SqlCmd.Parameters.Add("@ToDate", SqlDbType.Date).Value = this.ToDate;
                SqlCmd.Parameters.Add("@FromTime", SqlDbType.Time).Value = this.FromTime;
                SqlCmd.Parameters.Add("@ToTime", SqlDbType.Time).Value = this.ToTime;
                SqlCmd.Parameters.Add("@MinimumBillAmount", SqlDbType.Money).Value = this.MinimumBillAmount;
                SqlCmd.Parameters.Add("@Discount", SqlDbType.Money).Value = this.Discount;
                SqlCmd.Parameters.Add("@IsDiscountPercentage", SqlDbType.Bit).Value = this.IsDiscountPercentage;
                SqlCmd.Parameters.Add("@BuyItemCount", SqlDbType.Int).Value = this.BuyItemCount;
                SqlCmd.Parameters.Add("@GetItemCount", SqlDbType.Int).Value = this.GetItemCount;
                SqlCmd.Parameters.Add("@OfferCode", SqlDbType.VarChar).Value = this.OfferCode;
                SqlCmd.Parameters.Add("@ImagePhysicalName", SqlDbType.VarChar).Value = this.ImagePhysicalName;
                SqlCmd.Parameters.Add("@UpdateDateTime", SqlDbType.DateTime).Value = this.UpdateDateTime;
                SqlCmd.Parameters.Add("@linktoUserMasterIdUpdatedBy", SqlDbType.SmallInt).Value = this.linktoUserMasterIdUpdatedBy;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCmd.Parameters.Add("@TermsAndConditions", SqlDbType.VarChar).Value = this.TermsAndConditions;
                SqlCmd.Parameters.Add("@IsEnabled", SqlDbType.Bit).Value = this.IsEnabled;
                SqlCmd.Parameters.Add("@IsDeleted", SqlDbType.Bit).Value = this.IsDeleted;
                SqlCmd.Parameters.Add("@IsForCustomers", SqlDbType.Bit).Value = this.IsForCustomers;
                SqlCmd.Parameters.Add("@IsOnline", SqlDbType.Bit).Value = this.IsOnline;
                SqlCmd.Parameters.Add("@IsForAllDays", SqlDbType.Bit).Value = this.IsForAllDays;
                SqlCmd.Parameters.Add("@IsForApp", SqlDbType.Bit).Value = this.IsForApp;
                SqlCmd.Parameters.Add("@linktoCounterMasterId", SqlDbType.SmallInt).Value = this.linktoCounterMasterId;
                SqlCmd.Parameters.Add("@IsNotApplicableWithOtherOffers", SqlDbType.Bit).Value = this.IsNotApplicableWithOtherOffers;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCmd.ExecuteNonQuery();

                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;

                if (rs == posRecordStatus.Error || rs == posRecordStatus.RecordAlreadyExist)
                {
                    SqlTran.Rollback();
                    SqlCon.Close();
                    return rs;
                }

                if (IsForCustomers)
                {
                    posOfferCodesTranDAL objOfferCodesTran = new posOfferCodesTranDAL();

                    objOfferCodesTran.linktoOfferMasterId = OfferMasterId;
                    rs = objOfferCodesTran.DeleteOfferCodesTran(SqlCon, SqlTran);

                    if (rs == posRecordStatus.Error)
                    {
                        SqlTran.Rollback();
                        SqlCon.Close();
                        return rs;
                    }

                    foreach (posOfferCodesTranDAL objOfferCodesTranDAL in lstOfferCodesTranDAL)
                    {
                        objOfferCodesTranDAL.linktoOfferMasterId = this.OfferMasterId;
                        rs = objOfferCodesTranDAL.InsertOfferCodesTran(SqlCon, SqlTran);

                        if (rs == posRecordStatus.Error)
                        {
                            SqlTran.Rollback();
                            SqlCon.Close();
                            return rs;
                        }
                    }
                }
                else
                {
                    posOfferCodesTranDAL objOfferCodesTran = new posOfferCodesTranDAL();
                    objOfferCodesTran.linktoOfferMasterId = OfferMasterId;
                    rs = objOfferCodesTran.DeleteOfferCodesTran(SqlCon, SqlTran);

                    if (rs == posRecordStatus.Error)
                    {
                        SqlTran.Rollback();
                        SqlCon.Close();
                        return rs;
                    }
                }

                if (linktoOfferTypeMasterId != posOfferType.General_Offer.GetHashCode())
                {
                    posOfferItemsTranDAL objOfferItemsTran = new posOfferItemsTranDAL();
                    objOfferItemsTran.linktoOfferMasterId = OfferMasterId;
                    rs = objOfferItemsTran.DeleteOfferItemsTran(SqlCon, SqlTran);

                    if (rs == posRecordStatus.Error)
                    {
                        SqlTran.Rollback();
                        SqlCon.Close();
                        return rs;
                    }

                    foreach (posOfferItemsTranDAL objOfferItemsTranDal in lstOfferItemsTranDAL)
                    {
                        objOfferItemsTranDal.linktoOfferMasterId = this.OfferMasterId;
                        rs = objOfferItemsTranDal.InsertOfferItemsTran(SqlCon, SqlTran);
                        if (rs == posRecordStatus.Error)
                        {
                            SqlTran.Rollback();
                            SqlCon.Close();
                            return rs;
                        }
                    }
                }
                else
                {
                    posOfferItemsTranDAL objOfferItemsTran = new posOfferItemsTranDAL();
                    objOfferItemsTran.linktoOfferMasterId = OfferMasterId;
                    rs = objOfferItemsTran.DeleteOfferItemsTran(SqlCon, SqlTran);

                    if (rs == posRecordStatus.Error)
                    {
                        SqlTran.Rollback();
                        SqlCon.Close();
                        return rs;
                    }
                }

                if (IsForAllDays)
                {
                    posOfferDaysTranDAL objOfferDaysTran = new posOfferDaysTranDAL();
                    objOfferDaysTran.linktoOfferMasterId = this.OfferMasterId;
                    rs = objOfferDaysTran.DeleteOfferDaysTran(SqlCon, SqlTran);
                    if (rs == posRecordStatus.Error)
                    {
                        SqlTran.Rollback();
                        SqlCon.Close();
                        return rs;
                    }
                }
                else
                {

                    foreach (posOfferDaysTranDAL objOfferDaysTran in lstOfferDaysTranDAL)
                    {
                        objOfferDaysTran.linktoOfferMasterId = this.OfferMasterId;
                        if (objOfferDaysTran.OfferDaysTranId > 0)
                        {
                            rs = objOfferDaysTran.UpdateOfferDaysTran(SqlCon, SqlTran);
                        }
                        else
                        {
                            rs = objOfferDaysTran.InsertOfferDaysTran(SqlCon, SqlTran);
                        }

                        if (rs == posRecordStatus.Error)
                        {
                            SqlTran.Rollback();
                            SqlCon.Close();
                            return rs;
                        }
                    }
                }
                SqlTran.Commit();
                SqlCon.Close();
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
                posObjectFactoryDAL.DisposeTransaction(SqlTran);
            }
        }
        #endregion

        #region DeleteAll
        public posRecordStatus DeleteAllOfferMaster(string offerMasterIds)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posOfferMaster_DeleteAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@OfferMasterIds", SqlDbType.VarChar).Value = offerMasterIds;
                SqlCmd.Parameters.Add("@UpdateDateTime", SqlDbType.DateTime).Value = this.UpdateDateTime;
                SqlCmd.Parameters.Add("@linktoUserMasterIdUpdatedBy", SqlDbType.SmallInt).Value = this.linktoUserMasterIdUpdatedBy;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region Select
        public bool SelectOfferMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posOfferMaster_Select", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@OfferMasterId", SqlDbType.Int).Value = this.OfferMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                bool IsSelected = SetClassPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                return IsSelected;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return false;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public bool SelectOfferMasterForKOT()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posOfferMasterForKOT_Select", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@OfferMasterId", SqlDbType.Int).Value = this.OfferMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                bool IsSelected = SetClassPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                return IsSelected;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return false;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public bool SelectOfferMasterOfferCodeVerification(short linktoOrderTypeMasterId)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posOfferMasterOfferCodeVerification_Select", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@OfferCode", SqlDbType.VarChar).Value = this.OfferCode;
                SqlCmd.Parameters.Add("@MinimumBillAmount", SqlDbType.Money).Value = this.MinimumBillAmount;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCmd.Parameters.Add("@linktoCustomerMasterId", SqlDbType.Int).Value = this.linktoCustomerMasterId;
                SqlCmd.Parameters.Add("@linktoOrderTypeMasterId", SqlDbType.SmallInt).Value = linktoOrderTypeMasterId;
                SqlCmd.Parameters.Add("@CurrentDate", SqlDbType.DateTime).Value = posGlobalsDAL.GetCurrentDateTime();

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                bool IsSelected = false;

                if (SqlRdr.Read())
                {
                    this.OfferMasterId = Convert.ToInt32(SqlRdr["OfferMasterId"]);
                    this.linktoOfferTypeMasterId = Convert.ToInt16(SqlRdr["linktoOfferTypeMasterId"]);
                    this.Discount = Convert.ToDouble(SqlRdr["Discount"]);
                    this.IsDiscountPercentage = Convert.ToBoolean(SqlRdr["IsDiscountPercentage"]);
                    if (SqlRdr["BuyItemCount"] != DBNull.Value)
                    {
                        this.BuyItemCount = Convert.ToInt32(SqlRdr["BuyItemCount"]);
                    }
                    if (SqlRdr["GetItemCount"] != DBNull.Value)
                    {
                        this.GetItemCount = Convert.ToInt32(SqlRdr["GetItemCount"]);
                    }

                    IsSelected = true;
                }
                SqlRdr.Close();
                SqlCon.Close();

                return IsSelected;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return false;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        #endregion

        #region SelectAll
        public List<posOfferMasterDAL> SelectAllOfferMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posOfferMaster_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@IsEnabled", SqlDbType.Bit).Value = this.IsEnabled;
                if (this.FromDate != new DateTime())
                {
                    SqlCmd.Parameters.Add("@FromDate", SqlDbType.Date).Value = this.FromDate;
                }
                if (this.ToDate != new DateTime())
                {
                    SqlCmd.Parameters.Add("@ToDate", SqlDbType.Date).Value = this.ToDate;
                }
                SqlCmd.Parameters.Add("@OfferTitle", SqlDbType.VarChar).Value = this.OfferTitle;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<posOfferMasterDAL> lstOfferMasterDAL = SetListPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                return lstOfferMasterDAL;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public List<posOfferMasterDAL> SelectAllValidOffers(short linktoOrderTypeMasterId)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader sqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posOfferMasterVerifiedOfferByDate_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@CurrentDate", SqlDbType.DateTime).Value = posGlobalsDAL.GetCurrentDateTime();
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCmd.Parameters.Add("@linktoOrderTypeMasterId", SqlDbType.SmallInt).Value = linktoOrderTypeMasterId;

                SqlCon.Open();
                sqlRdr = SqlCmd.ExecuteReader();
                posOfferMasterDAL objOfferMaster = null;
                List<posOfferMasterDAL> lstOfferMasterDAL = new List<posOfferMasterDAL>();
                while (sqlRdr.Read())
                {
                    objOfferMaster = new posOfferMasterDAL();
                    objOfferMaster.OfferMasterId = Convert.ToInt32(sqlRdr["OfferMasterId"]);
                    objOfferMaster.OfferTitle = Convert.ToString(sqlRdr["OfferTitle"]);
                    objOfferMaster.OfferContent = Convert.ToString(sqlRdr["OfferContent"]);
                    objOfferMaster.Discount = Convert.ToDouble(sqlRdr["Discount"]);
                    objOfferMaster.IsDiscountPercentage = Convert.ToBoolean(sqlRdr["IsDiscountPercentage"]);
                    if (objOfferMaster.IsDiscountPercentage)
                    {
                        objOfferMaster.DiscountWithType = objOfferMaster.Discount + " %";
                    }
                    else
                    {
                        objOfferMaster.DiscountWithType = objOfferMaster.Discount + " Rs.";
                    }
                    if (sqlRdr["MinimumBillAmount"] != DBNull.Value)
                    {
                        objOfferMaster.MinimumBillAmount = Convert.ToDouble(sqlRdr["MinimumBillAmount"]);
                    }
                    if (sqlRdr["ValidItems"] != DBNull.Value)
                    {
                        objOfferMaster.ValidItems = Convert.ToString(sqlRdr["ValidItems"]);
                    }
                    if (sqlRdr["ValidBuyItems"] != DBNull.Value)
                    {
                        //objOfferMaster.ValidBuyItems = "Buy " + Convert.ToString(sqlRdr["BuyItemCount"]) + " From " + Convert.ToString(sqlRdr["ValidBuyItems"]);
                        objOfferMaster.ValidBuyItems = Convert.ToString(sqlRdr["ValidBuyItems"]);
                    }
                    if (sqlRdr["ValidGetItems"] != DBNull.Value)
                    {
                        //objOfferMaster.ValidGetItems = "Get " + Convert.ToString(sqlRdr["GetItemCount"]) + " From " + Convert.ToString(sqlRdr["ValidGetItems"]);
                        objOfferMaster.ValidGetItems = Convert.ToString(sqlRdr["ValidGetItems"]);
                    }
                    if (sqlRdr["BuyItemCount"] != DBNull.Value)
                    {
                        objOfferMaster.BuyItemCount = Convert.ToInt32(sqlRdr["BuyItemCount"]);
                    }
                    if (sqlRdr["GetItemCount"] != DBNull.Value)
                    {
                        objOfferMaster.GetItemCount = Convert.ToInt32(sqlRdr["GetItemCount"]);
                    }
                    if (sqlRdr["IsNotApplicableWithOtherOffers"] != DBNull.Value)
                    {
                        objOfferMaster.IsNotApplicableWithOtherOffers = Convert.ToBoolean(sqlRdr["IsNotApplicableWithOtherOffers"]);
                    }

                    objOfferMaster.linktoOfferTypeMasterId = Convert.ToInt16(sqlRdr["linktoOfferTypeMasterId"]);

                    lstOfferMasterDAL.Add(objOfferMaster);
                }
                sqlRdr.Close();
                SqlCon.Close();

                return lstOfferMasterDAL;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(sqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public List<posOfferMasterDAL> SelectAllOfferMasterByFromDate()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posOfferMasterByFromDate_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@FromDate", SqlDbType.DateTime).Value = this.FromDate;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<posOfferMasterDAL> lstOfferMasterDAL = SetListPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                return lstOfferMasterDAL;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion
    }
}
