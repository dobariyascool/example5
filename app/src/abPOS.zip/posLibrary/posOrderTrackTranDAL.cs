﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace posLibrary
{
    public class posOrderTrackTranDAL
    {
        #region Properties
        public long OrderTrackTranId { get; set; }
        public long linktoOrderMasterId { get; set; }
        public short? linktoOrderStatusMasterId { get; set; }
        public DateTime UpdateDateTime { get; set; }
        public int linktoUserMasterIdUpdatedBy { get; set; }

        /// Extra
        public string BillNumber { get; set; }
        public long linktoSalesMasterId { get; set; }
        public string CustomerName { get; set; }
        public string Address { get; set; }
        public string City { get; set; }
        public string Area { get; set; }
        public string FullAddress { get; set; }
        public string Phone { get; set; }
        public string OrderMasterIds { get; set; }
        #endregion

        #region Insert
        public static posRecordStatus InsertOrderTrackTran(long linktoOrderMasterId, short? linktoOrderStatusMasterId, DateTime updateDateTime, short linktoUserMasterIdUpdatedBy, SqlConnection sqlCon, SqlTransaction sqlTran)
        {
            SqlCommand SqlCmd = null;
            try
            {
                SqlCmd = new SqlCommand("posOrderTrackTran_Insert", sqlCon, sqlTran);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@OrderTrackTranId", SqlDbType.BigInt).Direction = ParameterDirection.Output;
                SqlCmd.Parameters.Add("@linktoOrderMasterId", SqlDbType.BigInt).Value = linktoOrderMasterId;
                SqlCmd.Parameters.Add("@linktoOrderStatusMasterId", SqlDbType.SmallInt).Value = linktoOrderStatusMasterId;
                SqlCmd.Parameters.Add("@UpdateDateTime", SqlDbType.DateTime).Value = updateDateTime;
                SqlCmd.Parameters.Add("@linktoUserMasterIdUpdatedBy", SqlDbType.SmallInt).Value = linktoUserMasterIdUpdatedBy;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCmd.ExecuteNonQuery();

                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
            }
        }
        #endregion

        #region Update
        public posRecordStatus UpdateOrderTrackTran(short linktoWaiterMasterId, bool isOut)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlTransaction SqlTran = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCon.Open();
                SqlTran = SqlCon.BeginTransaction();
                SqlCmd = new SqlCommand("posOrderTrackTran_Update", SqlCon, SqlTran);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@OrderTrackTranId", SqlDbType.BigInt).Value = this.OrderTrackTranId;
                SqlCmd.Parameters.Add("@linktoOrderStatusMasterId", SqlDbType.SmallInt).Value = Convert.ToInt16(posOrderStatus.Dispached.GetHashCode());
                SqlCmd.Parameters.Add("@UpdateDateTime", SqlDbType.DateTime).Value = this.UpdateDateTime;
                SqlCmd.Parameters.Add("@linktoUserMasterIdUpdatedBy", SqlDbType.SmallInt).Value = this.linktoUserMasterIdUpdatedBy;
                //Extra
                SqlCmd.Parameters.Add("@OrderMasterIds", SqlDbType.VarChar).Value = this.OrderMasterIds;


                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCmd.ExecuteNonQuery();
                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                if (rs == posRecordStatus.Success)
                {
                    if (posOrderMasterDAL.UpdateOrderMasterByHomeDeliveryOrders(this.OrderMasterIds, linktoWaiterMasterId, SqlCon, SqlTran) == posRecordStatus.Error)
                    {
                        SqlTran.Rollback();
                        return posRecordStatus.Error;
                    }
                }
                if (rs == posRecordStatus.Success)
                {
                    if (posWaiterMasterDAL.UpdateWaiterMasterbyHomeDeliveryOrders(linktoWaiterMasterId, isOut, SqlCon, SqlTran) == posRecordStatus.Error)
                    {
                        SqlTran.Rollback();
                        return posRecordStatus.Error;
                    }
                }
                if (rs == posRecordStatus.Success)
                {
                    if (posSalesMasterDAL.UpdateSalesMasterByHomeDeliveryOrders(this.OrderMasterIds, linktoWaiterMasterId, SqlCon, SqlTran) == posRecordStatus.Error)
                    {
                        SqlTran.Rollback();
                        return posRecordStatus.Error;
                    }
                }
                else
                {
                    SqlTran.Rollback();
                    return posRecordStatus.Error;
                }

                SqlTran.Commit();
                SqlCon.Close();
                return rs;


            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region SelectAll

        public List<posOrderTrackTranDAL> SelectAllOrderTrackTran()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader sqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posOrderTrackTran_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@linktoOrderStatusMasterId", SqlDbType.SmallInt).Value = this.linktoOrderStatusMasterId;

                SqlCon.Open();
                sqlRdr = SqlCmd.ExecuteReader();
                List<posOrderTrackTranDAL> lstOrderTrackTran = new List<posOrderTrackTranDAL>();
                posOrderTrackTranDAL objOrderTrackTranDAL = null;
                while (sqlRdr.Read())
                {
                    objOrderTrackTranDAL = new posOrderTrackTranDAL();
                    if (sqlRdr["linktoOrderMasterId"] != DBNull.Value)
                    {
                        objOrderTrackTranDAL.linktoOrderMasterId = Convert.ToInt64(sqlRdr["linktoOrderMasterId"]);
                    }
                    objOrderTrackTranDAL.BillNumber = Convert.ToString(sqlRdr["BillNumber"]);
                    objOrderTrackTranDAL.linktoSalesMasterId = Convert.ToInt64(sqlRdr["linktoSalesMasterId"]);
                    objOrderTrackTranDAL.CustomerName = Convert.ToString(sqlRdr["CustomerName"]);

                    // DON'T CHANGE THE SEQUENCE OF BELOW THREE ADDRESS PARAMETERS.
                    if (!string.IsNullOrEmpty(Convert.ToString(sqlRdr["Address"])))
                    {
                        objOrderTrackTranDAL.Address = Convert.ToString(sqlRdr["Address"]);
                        objOrderTrackTranDAL.FullAddress = objOrderTrackTranDAL.Address + ",";
                    }
                    if (!string.IsNullOrEmpty(Convert.ToString(sqlRdr["Area"])))
                    {
                        objOrderTrackTranDAL.Area = Convert.ToString(sqlRdr["Area"]);
                        objOrderTrackTranDAL.FullAddress += objOrderTrackTranDAL.Area + ",";
                    }
                    if (!string.IsNullOrEmpty(Convert.ToString(sqlRdr["City"])))
                    {
                        objOrderTrackTranDAL.City = Convert.ToString(sqlRdr["City"]);
                        objOrderTrackTranDAL.FullAddress += objOrderTrackTranDAL.City;
                    }
                    objOrderTrackTranDAL.Phone = Convert.ToString(sqlRdr["Phone"]);
                    lstOrderTrackTran.Add(objOrderTrackTranDAL);

                }
                sqlRdr.Close();
                SqlCon.Close();

                return lstOrderTrackTran;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(sqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        #endregion
    }
}
