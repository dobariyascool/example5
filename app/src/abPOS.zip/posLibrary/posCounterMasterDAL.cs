using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace posLibrary
{
    /// <summary>
    /// Class for posCounterMaster
    /// </summary>
    public class posCounterMasterDAL
    {
        #region Properties
        public short CounterMasterId { get; set; }
        public string ShortName { get; set; }
        public string CounterName { get; set; }
        public string Description { get; set; }
        public string ImageName { get; set; }
        public string CounterColor { get; set; }
        public short linktoDepartmentMasterId { get; set; }
        public short linktoBusinessMasterId { get; set; }
        public bool IsEnabled { get; set; }
        public bool IsDeleted { get; set; }
        public DateTime CreateDateTime { get; set; }
        public short linktoUserMasterIdCreatedBy { get; set; }
        public DateTime? UpdateDateTime { get; set; }
        public short? linktoUserMasterIdUpdatedBy { get; set; }

        /// Extra
        public string Department { get; set; }
       

        public List<posCounterSettingValueTranDAL> lstCounterSettingValueTranDAL { get; set; }
        #endregion

        #region Class Methods
        private bool SetClassPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            if (sqlRdr.Read())
            {
                this.CounterMasterId = Convert.ToInt16(sqlRdr["CounterMasterId"]);
                this.ShortName = Convert.ToString(sqlRdr["ShortName"]);
                this.CounterName = Convert.ToString(sqlRdr["CounterName"]);
                this.Description = Convert.ToString(sqlRdr["Description"]);
                this.ImageName = Convert.ToString(sqlRdr["ImageName"]);
                this.CounterColor = Convert.ToString(sqlRdr["CounterColor"]);
                this.linktoDepartmentMasterId = Convert.ToInt16(sqlRdr["linktoDepartmentMasterId"]);
                this.linktoBusinessMasterId = Convert.ToInt16(sqlRdr["linktoBusinessMasterId"]);
                this.IsEnabled = Convert.ToBoolean(sqlRdr["IsEnabled"]);
                this.IsDeleted = Convert.ToBoolean(sqlRdr["IsDeleted"]);
                this.CreateDateTime = Convert.ToDateTime(sqlRdr["CreateDateTime"]);
                this.linktoUserMasterIdCreatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdCreatedBy"]);
                if (sqlRdr["UpdateDateTime"] != DBNull.Value)
                {
                    this.UpdateDateTime = Convert.ToDateTime(sqlRdr["UpdateDateTime"]);
                }
                if (sqlRdr["linktoUserMasterIdUpdatedBy"] != DBNull.Value)
                {
                    this.linktoUserMasterIdUpdatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdUpdatedBy"]);
                }

                /// Extra
                this.Department = Convert.ToString(sqlRdr["Department"]);
                return true;
            }
            return false;
        }

        private List<posCounterMasterDAL> SetListPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            List<posCounterMasterDAL> lstCounterMaster = new List<posCounterMasterDAL>();
            posCounterMasterDAL objCounterMaster = null;
            while (sqlRdr.Read())
            {
                objCounterMaster = new posCounterMasterDAL();
                objCounterMaster.CounterMasterId = Convert.ToInt16(sqlRdr["CounterMasterId"]);
                objCounterMaster.ShortName = Convert.ToString(sqlRdr["ShortName"]);
                objCounterMaster.CounterName = Convert.ToString(sqlRdr["CounterName"]);
                objCounterMaster.Description = Convert.ToString(sqlRdr["Description"]);
                objCounterMaster.ImageName = Convert.ToString(sqlRdr["ImageName"]);
                objCounterMaster.CounterColor = Convert.ToString(sqlRdr["CounterColor"]);
                objCounterMaster.linktoDepartmentMasterId = Convert.ToInt16(sqlRdr["linktoDepartmentMasterId"]);
                objCounterMaster.linktoBusinessMasterId = Convert.ToInt16(sqlRdr["linktoBusinessMasterId"]);
                objCounterMaster.IsEnabled = Convert.ToBoolean(sqlRdr["IsEnabled"]);
                objCounterMaster.IsDeleted = Convert.ToBoolean(sqlRdr["IsDeleted"]);
                objCounterMaster.CreateDateTime = Convert.ToDateTime(sqlRdr["CreateDateTime"]);
                objCounterMaster.linktoUserMasterIdCreatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdCreatedBy"]);
                if (sqlRdr["UpdateDateTime"] != DBNull.Value)
                {
                    objCounterMaster.UpdateDateTime = Convert.ToDateTime(sqlRdr["UpdateDateTime"]);
                }
                if (sqlRdr["linktoUserMasterIdUpdatedBy"] != DBNull.Value)
                {
                    objCounterMaster.linktoUserMasterIdUpdatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdUpdatedBy"]);
                }

                /// Extra
                objCounterMaster.Department = Convert.ToString(sqlRdr["Department"]);
                lstCounterMaster.Add(objCounterMaster);
            }
            return lstCounterMaster;
        }
        #endregion

        #region Insert
        public posRecordStatus InsertCounterMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlTransaction SqlTran = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCon.Open();
                SqlTran = SqlCon.BeginTransaction();
                SqlCmd = new SqlCommand("posCounterMaster_Insert", SqlCon, SqlTran);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@CounterMasterId", SqlDbType.SmallInt).Direction = ParameterDirection.Output;
                SqlCmd.Parameters.Add("@ShortName", SqlDbType.VarChar).Value = this.ShortName;
                SqlCmd.Parameters.Add("@CounterName", SqlDbType.VarChar).Value = this.CounterName;
                SqlCmd.Parameters.Add("@Description", SqlDbType.VarChar).Value = this.Description;
                SqlCmd.Parameters.Add("@ImageName", SqlDbType.VarChar).Value = this.ImageName;
                SqlCmd.Parameters.Add("@CounterColor", SqlDbType.VarChar).Value = this.CounterColor;
                SqlCmd.Parameters.Add("@linktoDepartmentMasterId", SqlDbType.SmallInt).Value = this.linktoDepartmentMasterId;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCmd.Parameters.Add("@IsEnabled", SqlDbType.Bit).Value = this.IsEnabled;
                SqlCmd.Parameters.Add("@IsDeleted", SqlDbType.Bit).Value = this.IsDeleted;
                SqlCmd.Parameters.Add("@CreateDateTime", SqlDbType.DateTime).Value = this.CreateDateTime;
                SqlCmd.Parameters.Add("@linktoUserMasterIdCreatedBy", SqlDbType.SmallInt).Value = this.linktoUserMasterIdCreatedBy;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCmd.ExecuteNonQuery();

                this.CounterMasterId = Convert.ToInt16(SqlCmd.Parameters["@CounterMasterId"].Value);
                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;

                if (rs == posRecordStatus.Success)
                {
                    if (posCounterSettingValueTranDAL.InsertCounterSettingValueTran(this.CounterMasterId, this.lstCounterSettingValueTranDAL, SqlCon, SqlTran) == posRecordStatus.Error)
                    {
                        SqlTran.Rollback();
                        return posRecordStatus.Error;
                    }
                }

                SqlTran.Commit();
                SqlCon.Close();
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
                posObjectFactoryDAL.DisposeTransaction(SqlTran);
            }
        }

        public posRecordStatus InsertCounterMaster(SqlConnection sqlCon, SqlTransaction sqlTran, List<posCounterMasterDAL> lstCounterMasterDAL)
        {
            SqlCommand SqlCmd = null;
            try
            {
                posRecordStatus rs = posRecordStatus.Error;

                SqlCmd = new SqlCommand("posCounterMaster_Insert", sqlCon, sqlTran);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                foreach (posCounterMasterDAL objCounterMasterDAL in lstCounterMasterDAL)
                {
                    SqlCmd.Parameters.Clear();
                    SqlCmd.Parameters.Add("@CounterMasterId", SqlDbType.SmallInt).Direction = ParameterDirection.Output;
                    SqlCmd.Parameters.Add("@ShortName", SqlDbType.VarChar).Value = objCounterMasterDAL.ShortName;
                    SqlCmd.Parameters.Add("@CounterName", SqlDbType.VarChar).Value = objCounterMasterDAL.CounterName;
                    SqlCmd.Parameters.Add("@Description", SqlDbType.VarChar).Value = objCounterMasterDAL.Description;
                    SqlCmd.Parameters.Add("@ImageName", SqlDbType.VarChar).Value = objCounterMasterDAL.ImageName;
                    SqlCmd.Parameters.Add("@CounterColor", SqlDbType.VarChar).Value = objCounterMasterDAL.CounterColor;
                    SqlCmd.Parameters.Add("@linktoDepartmentMasterId", SqlDbType.SmallInt).Value = this.linktoDepartmentMasterId;
                    SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                    SqlCmd.Parameters.Add("@IsEnabled", SqlDbType.Bit).Value = objCounterMasterDAL.IsEnabled;
                    SqlCmd.Parameters.Add("@IsDeleted", SqlDbType.Bit).Value = objCounterMasterDAL.IsDeleted;
                    SqlCmd.Parameters.Add("@CreateDateTime", SqlDbType.DateTime).Value = objCounterMasterDAL.CreateDateTime;
                    SqlCmd.Parameters.Add("@linktoUserMasterIdCreatedBy", SqlDbType.SmallInt).Value = this.linktoUserMasterIdCreatedBy;
                    SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                    SqlCmd.ExecuteNonQuery();

                    this.CounterMasterId = Convert.ToInt16(SqlCmd.Parameters["@CounterMasterId"].Value);
                    rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;

                    if (rs == posRecordStatus.Error)
                    {
                        return rs;
                    }

                    rs = posCounterSettingValueTranDAL.InsertCounterSettingValueTran(this.CounterMasterId, objCounterMasterDAL.lstCounterSettingValueTranDAL, sqlCon, sqlTran);

                    if (rs != posRecordStatus.Success)
                    {
                        return rs;
                    }
                }
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
            }
        }
        #endregion

        #region Update
        public posRecordStatus UpdateCounterMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlTransaction SqlTran = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCon.Open();
                SqlTran = SqlCon.BeginTransaction();
                SqlCmd = new SqlCommand("posCounterMaster_Update", SqlCon, SqlTran);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@CounterMasterId", SqlDbType.SmallInt).Value = this.CounterMasterId;
                SqlCmd.Parameters.Add("@ShortName", SqlDbType.VarChar).Value = this.ShortName;
                SqlCmd.Parameters.Add("@CounterName", SqlDbType.VarChar).Value = this.CounterName;
                SqlCmd.Parameters.Add("@Description", SqlDbType.VarChar).Value = this.Description;
                SqlCmd.Parameters.Add("@ImageName", SqlDbType.VarChar).Value = this.ImageName;
                SqlCmd.Parameters.Add("@CounterColor", SqlDbType.VarChar).Value = this.CounterColor;
                SqlCmd.Parameters.Add("@linktoDepartmentMasterId", SqlDbType.SmallInt).Value = this.linktoDepartmentMasterId;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCmd.Parameters.Add("@IsEnabled", SqlDbType.Bit).Value = this.IsEnabled;
                SqlCmd.Parameters.Add("@IsDeleted", SqlDbType.Bit).Value = this.IsDeleted;
                SqlCmd.Parameters.Add("@UpdateDateTime", SqlDbType.DateTime).Value = this.UpdateDateTime;
                SqlCmd.Parameters.Add("@linktoUserMasterIdUpdatedBy", SqlDbType.SmallInt).Value = this.linktoUserMasterIdUpdatedBy;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCmd.ExecuteNonQuery();

                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;

                if (rs == posRecordStatus.Success)
                {
                    posCounterSettingValueTranDAL objCounterSettingValueTran = new posCounterSettingValueTranDAL();
                    objCounterSettingValueTran.linktoCounterMasterId = this.CounterMasterId;
                    rs = objCounterSettingValueTran.DeleteCounterSettingValueTran(SqlCon, SqlTran);
                    if (rs != posRecordStatus.Success)
                    {
                        SqlTran.Rollback();
                        SqlCon.Close();
                        return rs;
                    }
                    else if (rs == posRecordStatus.Success)
                    {
                        if (posCounterSettingValueTranDAL.InsertCounterSettingValueTran(this.CounterMasterId, this.lstCounterSettingValueTranDAL, SqlCon, SqlTran) == posRecordStatus.Error)
                        {
                            SqlTran.Rollback();
                            return posRecordStatus.Error;
                        }
                    }
                }

                SqlTran.Commit();
                SqlCon.Close();
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
                posObjectFactoryDAL.DisposeTransaction(SqlTran);
            }
        }
        #endregion

        #region DeleteAll
        public static posRecordStatus DeleteAllCounterMaster(string counterMasterIds, short linktoUserMasterIdUpdatedBy, DateTime UpdateDateTime)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posCounterMaster_DeleteAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@CounterMasterIds", SqlDbType.VarChar).Value = counterMasterIds;
                SqlCmd.Parameters.Add("@UpdateDateTime", SqlDbType.DateTime).Value = UpdateDateTime;
                SqlCmd.Parameters.Add("@linktoUserMasterIdUpdatedBy", SqlDbType.SmallInt).Value = linktoUserMasterIdUpdatedBy;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region Select
        public bool SelectCounterMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posCounterMaster_Select", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@CounterMasterId", SqlDbType.SmallInt).Value = this.CounterMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                bool IsSelected = SetClassPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                return IsSelected;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return false;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region SelectAll
        public List<posCounterMasterDAL> SelectAllCounterMaster(short linktoUserMasterId)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posCounterMaster_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@IsEnabled", SqlDbType.Bit).Value = this.IsEnabled;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCmd.Parameters.Add("@linkToUserMasterId", SqlDbType.SmallInt).Value = linktoUserMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<posCounterMasterDAL> lstCounterMasterDAL = SetListPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                return lstCounterMasterDAL;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public static List<posCounterMasterDAL> SelectAllCounterMasterCounterName(short linktoBusinessMasterId, short? linktoUserMasterId)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posCounterMasterCounterName_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@linkToUserMasterId", SqlDbType.SmallInt).Value = linktoUserMasterId;
                SqlCmd.Parameters.Add("@linkToBusinessMasterId", SqlDbType.SmallInt).Value = linktoBusinessMasterId;
                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<posCounterMasterDAL> lstCounterMasterDAL = new List<posCounterMasterDAL>();
                posCounterMasterDAL objCounterMasterDAL = null;
                while (SqlRdr.Read())
                {
                    objCounterMasterDAL = new posCounterMasterDAL();
                    objCounterMasterDAL.CounterMasterId = Convert.ToInt16(SqlRdr["CounterMasterId"]);
                    objCounterMasterDAL.CounterName = Convert.ToString(SqlRdr["CounterName"]);
                    objCounterMasterDAL.CounterColor = Convert.ToString(SqlRdr["Color"]);

                   
                    lstCounterMasterDAL.Add(objCounterMasterDAL);
                }
                SqlRdr.Close();
                SqlCon.Close();

                return lstCounterMasterDAL;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion
    }
}
