using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace posLibrary
{
    /// <summary>
    /// Class for posItemOptionTran
    /// </summary>
    public class posItemOptionTranDAL
    {
        #region Properties
        public int ItemOptionTranId { get; set; }
        public int? linktoItemMasterId { get; set; }
        public int linktoOptionValueTranId { get; set; }
        public bool IsSelected { get; set; }
        public string OptionName { get; set; }
        public string OptionValue { get; set; }

        /// Extra
        public int linktoOptionMasterId { get; set; }
        #endregion

        #region Class Methods
        private List<posItemOptionTranDAL> SetListPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            List<posItemOptionTranDAL> lstItemOptionTran = new List<posItemOptionTranDAL>();
            posItemOptionTranDAL objItemOptionTran = null;
            while (sqlRdr.Read())
            {
                objItemOptionTran = new posItemOptionTranDAL();
                if (sqlRdr["ItemOptionTranId"] != DBNull.Value)
                {
                    objItemOptionTran.ItemOptionTranId = Convert.ToInt32(sqlRdr["ItemOptionTranId"]);
                    objItemOptionTran.IsSelected = true;
                }
                objItemOptionTran.linktoOptionValueTranId = Convert.ToInt32(sqlRdr["OptionValueTranId"]);

                /// Extra
                objItemOptionTran.OptionName = Convert.ToString(sqlRdr["OptionName"]);
                objItemOptionTran.OptionValue = Convert.ToString(sqlRdr["OptionValue"]);
                objItemOptionTran.linktoOptionMasterId = Convert.ToInt32(sqlRdr["linktoOptionMasterId"]);
                lstItemOptionTran.Add(objItemOptionTran);
            }
            return lstItemOptionTran;
        }
        #endregion

        #region Insert
        public posRecordStatus InsertItemOptionTran(SqlConnection SqlCon, SqlTransaction sqlTran)
        {
            SqlCommand SqlCmd = null;
            try
            {
                SqlCmd = new SqlCommand("posItemOptionTran_Insert", SqlCon, sqlTran);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@linktoItemMasterId", SqlDbType.Int).Value = this.linktoItemMasterId;
                SqlCmd.Parameters.Add("@linktoOptionValueTranId", SqlDbType.Int).Value = this.linktoOptionValueTranId;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCmd.ExecuteNonQuery();

                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
            }
        }
        #endregion

        #region DeleteAll
        public posRecordStatus DeleteAllItemOptionTranByItemMasterID(SqlConnection sqlCon, SqlTransaction sqlTRan)
        {
            SqlCommand SqlCmd = null;
            try
            {
                SqlCmd = new SqlCommand("posItemOptionTran_DeleteAll", sqlCon, sqlTRan);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@linktoItemMasterId", SqlDbType.SmallInt).Value = this.linktoItemMasterId;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCmd.ExecuteNonQuery();

                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
            }
        }
        #endregion

        #region SelectAll
        public List<posItemOptionTranDAL> SelectAllItemOptionTran(short linktoBusinessTypeMasterId)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posItemOptionTran_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@linktoItemMasterId", SqlDbType.SmallInt).Value = this.linktoItemMasterId;
                SqlCmd.Parameters.Add("@linktoBusinessTypeMasterId", SqlDbType.SmallInt).Value = linktoBusinessTypeMasterId;
                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<posItemOptionTranDAL> lstItemOptionTranDAL = SetListPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                return lstItemOptionTranDAL;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public List<posItemOptionTranDAL> SelectAllItemOptionTranByItemMastreId()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posItemOptionTranByItemMastreId_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@linktoItemMasterId", SqlDbType.SmallInt).Value = this.linktoItemMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<posItemOptionTranDAL> lstItemOptionTranDAL = SetListPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                return lstItemOptionTranDAL;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion
    }
}
