using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace posLibrary
{
    /// <summary>
    /// Class for posPurchaseMaster
    /// </summary>
    public class posPurchaseMasterDAL
    {
        #region Properties
        public int PurchaseMasterId { get; set; }
        public short linktoDepartmentMasterId { get; set; }
        public string VoucherNumber { get; set; }
        public DateTime PurchaseDate { get; set; }
        public short linktoSupplierMasterId { get; set; }
        public string InvoiceNumber { get; set; }
        public DateTime? InvoiceDate { get; set; }
        public double TotalAmount { get; set; }
        public double TotalTax { get; set; }
        public double TotalDiscount { get; set; }
        public double NetAmount { get; set; }
        public string Remark { get; set; }
        public DateTime CreateDateTime { get; set; }
        public short linktoUserMasterIdCreatedBy { get; set; }
        public DateTime? UpdateDateTime { get; set; }
        public short? linktoUserMasterIdUpdatedBy { get; set; }
        public short linktoBusinessMasterId { get; set; }
        /// Extra
        public string Department { get; set; }
        public string Supplier { get; set; }
        public string PurchaseDay { get; set; }
        public string TmpPurchaseDate { get; set; }
        public int linktoCategoryMasterId { get; set; }
        public string SupplierIds { get; set; }
        public string UnitName { get; set; }
        public string ItemName { get; set; }
        public double Rate { get; set; }
        public double Quantity { get; set; }
        public double Amount { get; set; }
        public string CategoryMasterIds { get; set; }
        public string ItemMasterIds { get; set; }

        #endregion

        #region Class Methods
        private bool SetClassPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            if (sqlRdr.Read())
            {
                this.PurchaseMasterId = Convert.ToInt32(sqlRdr["PurchaseMasterId"]);
                this.linktoDepartmentMasterId = Convert.ToInt16(sqlRdr["linktoDepartmentMasterId"]);
                this.VoucherNumber = Convert.ToString(sqlRdr["VoucherNumber"]);
                this.PurchaseDate = Convert.ToDateTime(sqlRdr["PurchaseDate"]);
                this.linktoSupplierMasterId = Convert.ToInt16(sqlRdr["linktoSupplierMasterId"]);
                this.InvoiceNumber = Convert.ToString(sqlRdr["InvoiceNumber"]);
                if (sqlRdr["InvoiceDate"] != DBNull.Value)
                {
                    this.InvoiceDate = Convert.ToDateTime(sqlRdr["InvoiceDate"]);
                }
                this.TotalAmount = Convert.ToDouble(sqlRdr["TotalAmount"]);
                this.TotalTax = Convert.ToDouble(sqlRdr["TotalTax"]);
                this.TotalDiscount = Convert.ToDouble(sqlRdr["TotalDiscount"]);
                this.NetAmount = Convert.ToDouble(sqlRdr["NetAmount"]);
                this.Remark = Convert.ToString(sqlRdr["Remark"]);
                this.CreateDateTime = Convert.ToDateTime(sqlRdr["CreateDateTime"]);
                this.linktoUserMasterIdCreatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdCreatedBy"]);
                if (sqlRdr["UpdateDateTime"] != DBNull.Value)
                {
                    this.UpdateDateTime = Convert.ToDateTime(sqlRdr["UpdateDateTime"]);
                }
                if (sqlRdr["linktoUserMasterIdUpdatedBy"] != DBNull.Value)
                {
                    this.linktoUserMasterIdUpdatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdUpdatedBy"]);
                }

                /// Extra
                this.Department = Convert.ToString(sqlRdr["Department"]);
                this.Supplier = Convert.ToString(sqlRdr["Supplier"]);
                return true;
            }
            return false;
        }

        private List<posPurchaseMasterDAL> SetListPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            List<posPurchaseMasterDAL> lstPurchaseMaster = new List<posPurchaseMasterDAL>();
            posPurchaseMasterDAL objPurchaseMaster = null;
            while (sqlRdr.Read())
            {
                objPurchaseMaster = new posPurchaseMasterDAL();
                objPurchaseMaster.PurchaseMasterId = Convert.ToInt32(sqlRdr["PurchaseMasterId"]);
                objPurchaseMaster.linktoDepartmentMasterId = Convert.ToInt16(sqlRdr["linktoDepartmentMasterId"]);
                objPurchaseMaster.VoucherNumber = Convert.ToString(sqlRdr["VoucherNumber"]);
                objPurchaseMaster.PurchaseDate = Convert.ToDateTime(sqlRdr["PurchaseDate"]);
                objPurchaseMaster.linktoSupplierMasterId = Convert.ToInt16(sqlRdr["linktoSupplierMasterId"]);
                objPurchaseMaster.InvoiceNumber = Convert.ToString(sqlRdr["InvoiceNumber"]);
                if (sqlRdr["InvoiceDate"] != DBNull.Value)
                {
                    objPurchaseMaster.InvoiceDate = Convert.ToDateTime(sqlRdr["InvoiceDate"]);
                }
                objPurchaseMaster.TotalAmount = Convert.ToDouble(sqlRdr["TotalAmount"]);
                objPurchaseMaster.TotalTax = Convert.ToDouble(sqlRdr["TotalTax"]);
                objPurchaseMaster.TotalDiscount = Convert.ToDouble(sqlRdr["TotalDiscount"]);
                objPurchaseMaster.NetAmount = Convert.ToDouble(sqlRdr["NetAmount"]);
                objPurchaseMaster.Remark = Convert.ToString(sqlRdr["Remark"]);
                objPurchaseMaster.CreateDateTime = Convert.ToDateTime(sqlRdr["CreateDateTime"]);
                objPurchaseMaster.linktoUserMasterIdCreatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdCreatedBy"]);
                if (sqlRdr["UpdateDateTime"] != DBNull.Value)
                {
                    objPurchaseMaster.UpdateDateTime = Convert.ToDateTime(sqlRdr["UpdateDateTime"]);
                }
                if (sqlRdr["linktoUserMasterIdUpdatedBy"] != DBNull.Value)
                {
                    objPurchaseMaster.linktoUserMasterIdUpdatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdUpdatedBy"]);
                }

                /// Extra
                objPurchaseMaster.Department = Convert.ToString(sqlRdr["Department"]);
                objPurchaseMaster.Supplier = Convert.ToString(sqlRdr["Supplier"]);
                lstPurchaseMaster.Add(objPurchaseMaster);
            }
            return lstPurchaseMaster;
        }
        #endregion

        #region Insert
        public posRecordStatus InsertPurchaseMaster(List<posPurchaseItemTranDAL> lstPurchaseItemTranDAL)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlTransaction sqlTran = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCon.Open();
                sqlTran = SqlCon.BeginTransaction();

                SqlCmd = new SqlCommand("posPurchaseMaster_Insert", SqlCon, sqlTran);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@PurchaseMasterId", SqlDbType.Int).Direction = ParameterDirection.Output;
                SqlCmd.Parameters.Add("@linktoDepartmentMasterId", SqlDbType.SmallInt).Value = this.linktoDepartmentMasterId;
                SqlCmd.Parameters.Add("@VoucherNumber", SqlDbType.VarChar).Value = this.VoucherNumber;
                SqlCmd.Parameters.Add("@PurchaseDate", SqlDbType.Date).Value = this.PurchaseDate;
                SqlCmd.Parameters.Add("@linktoSupplierMasterId", SqlDbType.SmallInt).Value = this.linktoSupplierMasterId;
                SqlCmd.Parameters.Add("@InvoiceNumber", SqlDbType.VarChar).Value = this.InvoiceNumber;
                SqlCmd.Parameters.Add("@InvoiceDate", SqlDbType.Date).Value = this.InvoiceDate;
                SqlCmd.Parameters.Add("@TotalAmount", SqlDbType.Money).Value = this.TotalAmount;
                SqlCmd.Parameters.Add("@TotalTax", SqlDbType.Money).Value = this.TotalTax;
                SqlCmd.Parameters.Add("@TotalDiscount", SqlDbType.Money).Value = this.TotalDiscount;
                SqlCmd.Parameters.Add("@NetAmount", SqlDbType.Money).Value = this.NetAmount;
                SqlCmd.Parameters.Add("@Remark", SqlDbType.VarChar).Value = this.Remark;
                SqlCmd.Parameters.Add("@CreateDateTime", SqlDbType.DateTime).Value = this.CreateDateTime;
                SqlCmd.Parameters.Add("@linktoUserMasterIdCreatedBy", SqlDbType.SmallInt).Value = this.linktoUserMasterIdCreatedBy;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCmd.ExecuteNonQuery();
                this.PurchaseMasterId = Convert.ToInt32(SqlCmd.Parameters["@PurchaseMasterId"].Value);
                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;


                if (rs != posRecordStatus.Success)
                {
                    sqlTran.Rollback();
                    SqlCon.Close();
                }
                else
                {
                    foreach (posPurchaseItemTranDAL objPurchaseItemTranDAL in lstPurchaseItemTranDAL)
                    {
                        objPurchaseItemTranDAL.linktoPurchaseMasterId = this.PurchaseMasterId;
                        posRecordStatus rs1 = objPurchaseItemTranDAL.InsertPurchaseItemTran(sqlTran, SqlCon);
                        if (rs1 != posRecordStatus.Success)
                        {
                            sqlTran.Rollback();
                            SqlCon.Close();
                            return rs1;
                        }
                    }
                    sqlTran.Commit();
                    SqlCon.Close();
                }
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region Update
        public posRecordStatus UpdatePurchaseMaster(List<posPurchaseItemTranDAL> lstPurchaseItemTranDAL)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlTransaction sqlTran = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCon.Open();
                sqlTran = SqlCon.BeginTransaction();
                SqlCmd = new SqlCommand("posPurchaseMaster_Update", SqlCon, sqlTran);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@PurchaseMasterId", SqlDbType.Int).Value = this.PurchaseMasterId;
                SqlCmd.Parameters.Add("@linktoDepartmentMasterId", SqlDbType.SmallInt).Value = this.linktoDepartmentMasterId;
                SqlCmd.Parameters.Add("@VoucherNumber", SqlDbType.VarChar).Value = this.VoucherNumber;
                SqlCmd.Parameters.Add("@PurchaseDate", SqlDbType.Date).Value = this.PurchaseDate;
                SqlCmd.Parameters.Add("@linktoSupplierMasterId", SqlDbType.SmallInt).Value = this.linktoSupplierMasterId;
                SqlCmd.Parameters.Add("@InvoiceNumber", SqlDbType.VarChar).Value = this.InvoiceNumber;
                SqlCmd.Parameters.Add("@InvoiceDate", SqlDbType.Date).Value = this.InvoiceDate;
                SqlCmd.Parameters.Add("@TotalAmount", SqlDbType.Money).Value = this.TotalAmount;
                SqlCmd.Parameters.Add("@TotalTax", SqlDbType.Money).Value = this.TotalTax;
                SqlCmd.Parameters.Add("@TotalDiscount", SqlDbType.Money).Value = this.TotalDiscount;
                SqlCmd.Parameters.Add("@NetAmount", SqlDbType.Money).Value = this.NetAmount;
                SqlCmd.Parameters.Add("@Remark", SqlDbType.VarChar).Value = this.Remark;
                SqlCmd.Parameters.Add("@UpdateDateTime", SqlDbType.DateTime).Value = this.UpdateDateTime;
                SqlCmd.Parameters.Add("@linktoUserMasterIdUpdatedBy", SqlDbType.SmallInt).Value = this.linktoUserMasterIdUpdatedBy;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCmd.ExecuteNonQuery();


                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;

                if (rs != posRecordStatus.Success)
                {
                    sqlTran.Rollback();
                    SqlCon.Close();
                }
                else
                {
                    posPurchaseItemTranDAL objPurchaseItemTran = new posPurchaseItemTranDAL();
                    objPurchaseItemTran.linktoPurchaseMasterId = this.PurchaseMasterId;
                    posRecordStatus rs1 = objPurchaseItemTran.DeletePurchaseItemTran(sqlTran, SqlCon);
                    if (rs1 == posRecordStatus.Success)
                    {
                        posRecordStatus rs2 = posRecordStatus.Error;
                        foreach (posPurchaseItemTranDAL objPurchaseItemTranDAL in lstPurchaseItemTranDAL)
                        {
                            objPurchaseItemTranDAL.linktoPurchaseMasterId = this.PurchaseMasterId;
                            rs2 = objPurchaseItemTranDAL.InsertPurchaseItemTran(sqlTran, SqlCon);
                            if (rs2 != posRecordStatus.Success)
                            {
                                sqlTran.Rollback();
                                SqlCon.Close();
                            }
                        }

                        if (rs == posRecordStatus.Success)
                        {
                            sqlTran.Commit();
                            SqlCon.Close();
                        }
                    }
                    else
                    {
                        sqlTran.Rollback();
                        SqlCon.Close();
                    }
                }
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region DeleteAll
        public static posRecordStatus DeleteAllPurchaseMaster(string purchaseMasterIds)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posPurchaseMaster_DeleteAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@PurchaseMasterIds", SqlDbType.VarChar).Value = purchaseMasterIds;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region Select
        public bool SelectPurchaseMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posPurchaseMaster_Select", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@PurchaseMasterId", SqlDbType.Int).Value = this.PurchaseMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                bool IsSelected = SetClassPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                return IsSelected;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return false;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public bool SelectPurchaseMasterReaminPayment()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posPurchaseMasterByRemaingPaymentAmount_Select", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@PurchaseMasterId", SqlDbType.Int).Value = this.PurchaseMasterId;

                SqlCon.Open();
                bool IsSelected = false;
                object ReminingPayment = SqlCmd.ExecuteScalar();
                //object TotalAmountData = SqlCmd.ExecuteScalar();
                if (ReminingPayment != DBNull.Value)
                {
                    this.NetAmount = Convert.ToDouble(ReminingPayment);
                    this.TotalAmount = Convert.ToDouble(ReminingPayment);
                    IsSelected = true;
                }
                SqlCon.Close();
                return IsSelected;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return false;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region SelectAll
        public List<posPurchaseMasterDAL> SelectAllPurchaseMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posPurchaseMaster_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@VoucherNumber", SqlDbType.VarChar).Value = this.VoucherNumber;
                if (this.PurchaseDate != new DateTime())
                {
                    SqlCmd.Parameters.Add("@PurchaseDate", SqlDbType.Date).Value = this.PurchaseDate;
                }
                if (this.linktoSupplierMasterId > 0)
                {
                    SqlCmd.Parameters.Add("@linktoSupplierMasterId", SqlDbType.SmallInt).Value = this.linktoSupplierMasterId;
                }
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<posPurchaseMasterDAL> lstPurchaseMasterDAL = SetListPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                return lstPurchaseMasterDAL;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public List<posPurchaseMasterDAL> SelectAllPurchaseMasterDayWiseReport(DateTime FromDate, DateTime ToDate)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader sqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posPurchaseMasterDayWiseReport_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@FromDate", SqlDbType.DateTime).Value = FromDate;
                SqlCmd.Parameters.Add("@ToDate", SqlDbType.DateTime).Value = ToDate;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCon.Open();
                sqlRdr = SqlCmd.ExecuteReader();
                List<posPurchaseMasterDAL> lstPurchaseMaster = new List<posPurchaseMasterDAL>();
                posPurchaseMasterDAL objPurchaseMaster = null;
                while (sqlRdr.Read())
                {
                    objPurchaseMaster = new posPurchaseMasterDAL();

                    objPurchaseMaster.TmpPurchaseDate = Convert.ToDateTime(sqlRdr["PurchaseDate"]).ToShortDateString();

                    objPurchaseMaster.TotalAmount = Convert.ToDouble(sqlRdr["TotalAmount"]);

                    /// Extra
                    objPurchaseMaster.PurchaseDay = Convert.ToString(sqlRdr["PurchaseDay"]);
                    lstPurchaseMaster.Add(objPurchaseMaster);
                }

                sqlRdr.Close();
                SqlCon.Close();

                return lstPurchaseMaster;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(sqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public List<posPurchaseMasterDAL> SelectAllPurchaseMasterCategoryWiseReport(DateTime FromDate, DateTime ToDate)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader sqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posPurchaseMasterCategoryWiseReport_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@FromDate", SqlDbType.DateTime).Value = FromDate;
                SqlCmd.Parameters.Add("@ToDate", SqlDbType.DateTime).Value = ToDate;
                SqlCmd.Parameters.Add("@CategoryMasterIds", SqlDbType.VarChar).Value = this.CategoryMasterIds;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCon.Open();
                sqlRdr = SqlCmd.ExecuteReader();
                List<posPurchaseMasterDAL> lstPurchaseMaster = new List<posPurchaseMasterDAL>();
                posPurchaseMasterDAL objPurchaseMaster = null;
                while (sqlRdr.Read())
                {
                    objPurchaseMaster = new posPurchaseMasterDAL();

                    objPurchaseMaster.Supplier = Convert.ToString(sqlRdr["SupplierName"]);

                    objPurchaseMaster.TotalAmount = Convert.ToDouble(sqlRdr["TotalAmount"]);

                    /// Extra
                    objPurchaseMaster.NetAmount = Convert.ToDouble(sqlRdr["NetAmount"]);
                    lstPurchaseMaster.Add(objPurchaseMaster);
                }

                sqlRdr.Close();
                SqlCon.Close();

                return lstPurchaseMaster;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(sqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public List<posPurchaseMasterDAL> SelectAllPurchaseMasterSupplierWiseReport(DateTime FromDate, DateTime ToDate)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader sqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posPurchaseMasterSupplierWiseReport_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@FromDate", SqlDbType.DateTime).Value = FromDate;
                SqlCmd.Parameters.Add("@ToDate", SqlDbType.DateTime).Value = ToDate;
                SqlCmd.Parameters.Add("@linktoCategoryMasterId", SqlDbType.SmallInt).Value = this.linktoCategoryMasterId;
                SqlCmd.Parameters.Add("@SupplierIds", SqlDbType.VarChar).Value = this.SupplierIds;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;

                SqlCon.Open();
                sqlRdr = SqlCmd.ExecuteReader();
                List<posPurchaseMasterDAL> lstPurchaseMaster = new List<posPurchaseMasterDAL>();
                posPurchaseMasterDAL objPurchaseMaster = null;
                while (sqlRdr.Read())
                {
                    objPurchaseMaster = new posPurchaseMasterDAL();

                    objPurchaseMaster.Supplier = Convert.ToString(sqlRdr["SupplierName"]);
                    objPurchaseMaster.UnitName = Convert.ToString(sqlRdr["UnitName"]);
                    objPurchaseMaster.ItemName = Convert.ToString(sqlRdr["ItemName"]);
                    objPurchaseMaster.Rate = Convert.ToDouble(sqlRdr["Rate"]);
                    objPurchaseMaster.Quantity = Convert.ToDouble(sqlRdr["Quantity"]);
                    objPurchaseMaster.Amount = Convert.ToDouble(sqlRdr["Amount"]);

                    lstPurchaseMaster.Add(objPurchaseMaster);
                }

                sqlRdr.Close();
                SqlCon.Close();

                return lstPurchaseMaster;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(sqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public List<posPurchaseMasterDAL> SelectAllPurchaseMasterPurchaseDateWiseDetailsReport(DateTime FromDate, DateTime ToDate, short linktoBusinessMasterId)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader sqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posPurchaseMasterPurchaseDateWisedetailReport_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@FromDate", SqlDbType.DateTime).Value = FromDate;
                SqlCmd.Parameters.Add("@ToDate", SqlDbType.DateTime).Value = ToDate;
                SqlCmd.Parameters.Add("@CategoryMasterIds", SqlDbType.VarChar).Value = this.CategoryMasterIds;
                SqlCmd.Parameters.Add("@linktoSuppliermasterId", SqlDbType.SmallInt).Value = this.linktoSupplierMasterId;
                SqlCmd.Parameters.Add("@ItemMasterIds", SqlDbType.VarChar).Value = this.ItemMasterIds;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = linktoBusinessMasterId;

                SqlCon.Open();
                sqlRdr = SqlCmd.ExecuteReader();
                List<posPurchaseMasterDAL> lstPurchaseMaster = new List<posPurchaseMasterDAL>();
                posPurchaseMasterDAL objPurchaseMaster = null;
                while (sqlRdr.Read())
                {
                    objPurchaseMaster = new posPurchaseMasterDAL();
                    objPurchaseMaster.PurchaseDay = Convert.ToDateTime(sqlRdr["PurchaseDate"]).ToShortDateString();
                    objPurchaseMaster.Department = Convert.ToString(sqlRdr["DepartmentName"]);
                    objPurchaseMaster.VoucherNumber = Convert.ToString(sqlRdr["VoucherNumber"]);
                    objPurchaseMaster.InvoiceNumber = Convert.ToString(sqlRdr["InvoiceNumber"]);
                    objPurchaseMaster.Supplier = Convert.ToString(sqlRdr["SupplierName"]);
                    objPurchaseMaster.UnitName = Convert.ToString(sqlRdr["UnitName"]);
                    objPurchaseMaster.ItemName = Convert.ToString(sqlRdr["ItemName"]);
                    objPurchaseMaster.Rate = Convert.ToDouble(sqlRdr["Rate"]);
                    objPurchaseMaster.Quantity = Convert.ToDouble(sqlRdr["Quantity"]);
                    objPurchaseMaster.TotalAmount = Convert.ToDouble(sqlRdr["TotalAmount"]);
                    objPurchaseMaster.TotalTax = Convert.ToDouble(sqlRdr["Tax"]);
                    objPurchaseMaster.TotalDiscount = Convert.ToDouble(sqlRdr["Discount"]);
                    objPurchaseMaster.NetAmount = Convert.ToDouble(sqlRdr["NetAmount"]);
                    lstPurchaseMaster.Add(objPurchaseMaster);
                }
                sqlRdr.Close();
                SqlCon.Close();

                return lstPurchaseMaster;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(sqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public List<posPurchaseMasterDAL> SelectAllPurchaseMasterBySupplierMasterId(DateTime FromDate, DateTime ToDate)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posPurchaseMasterBylinktoSupplierMasterId_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCmd.Parameters.Add("@linktoSupplierMasterId", SqlDbType.SmallInt).Value = this.linktoSupplierMasterId;
                SqlCmd.Parameters.Add("@FromDate", SqlDbType.DateTime).Value = FromDate;
                SqlCmd.Parameters.Add("@ToDate", SqlDbType.DateTime).Value = ToDate;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<posPurchaseMasterDAL> lstPurchaseMaster = new List<posPurchaseMasterDAL>();
                posPurchaseMasterDAL objPurchaseMaster = null;
                while (SqlRdr.Read())
                {
                    objPurchaseMaster = new posPurchaseMasterDAL();
                    objPurchaseMaster.PurchaseMasterId = Convert.ToInt32(SqlRdr["PurchaseMasterId"]);
                    objPurchaseMaster.VoucherNumber = Convert.ToString(SqlRdr["VoucherNumber"]) + " (Rs. " + Convert.ToDouble(SqlRdr["NetAmount"]).ToString("0.00") + ")";
                    objPurchaseMaster.NetAmount = Convert.ToDouble(SqlRdr["NetAmount"]);
                    lstPurchaseMaster.Add(objPurchaseMaster);
                }
                SqlRdr.Close();
                SqlCon.Close();
                return lstPurchaseMaster;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion
    }
}
