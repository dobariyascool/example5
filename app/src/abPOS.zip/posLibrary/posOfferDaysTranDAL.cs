using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace posLibrary
{
	/// <summary>
	/// Class for posOfferDaysTran
	/// </summary>
	public class posOfferDaysTranDAL
	{
		#region Properties
		public int OfferDaysTranId { get; set; }
		public int linktoOfferMasterId { get; set; }
		public short Day { get; set; }
		public TimeSpan FromTime { get; set; }
		public TimeSpan ToTime { get; set; }
		public bool IsEnabled { get; set; }

		/// Extra
		public string Offer { get; set; }
        public string DayName { get; set; }
		#endregion

		#region Class Methods
		private List<posOfferDaysTranDAL> SetListPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
		{
			List<posOfferDaysTranDAL> lstOfferDaysTran = new List<posOfferDaysTranDAL>();
			posOfferDaysTranDAL objOfferDaysTran = null;
			while (sqlRdr.Read())
			{
				objOfferDaysTran = new posOfferDaysTranDAL();
				objOfferDaysTran.OfferDaysTranId = Convert.ToInt32(sqlRdr["OfferDaysTranId"]);
				objOfferDaysTran.linktoOfferMasterId = Convert.ToInt32(sqlRdr["linktoOfferMasterId"]);
				objOfferDaysTran.Day = Convert.ToInt16(sqlRdr["Day"]);
				objOfferDaysTran.FromTime = TimeSpan.Parse(sqlRdr["FromTime"].ToString());
				objOfferDaysTran.ToTime = TimeSpan.Parse(sqlRdr["ToTime"].ToString());
				objOfferDaysTran.IsEnabled = Convert.ToBoolean(sqlRdr["IsEnabled"]);

				/// Extra
				objOfferDaysTran.Offer = Convert.ToString(sqlRdr["Offer"]);
				lstOfferDaysTran.Add(objOfferDaysTran);
			}
			return lstOfferDaysTran;
		}
		#endregion

		#region Insert
        public posRecordStatus InsertOfferDaysTran(SqlConnection SqlCon,SqlTransaction sqlTran)
		{
		    SqlCommand SqlCmd = null;
			try
			{
			    SqlCmd = new SqlCommand("posOfferDaysTran_Insert", SqlCon, sqlTran);
				SqlCmd.CommandType = CommandType.StoredProcedure;

				SqlCmd.Parameters.Add("@OfferDaysTranId", SqlDbType.Int).Direction = ParameterDirection.Output;
				SqlCmd.Parameters.Add("@linktoOfferMasterId", SqlDbType.Int).Value = this.linktoOfferMasterId;
				SqlCmd.Parameters.Add("@Day", SqlDbType.SmallInt).Value = this.Day;
				SqlCmd.Parameters.Add("@FromTime", SqlDbType.Time).Value = this.FromTime;
				SqlCmd.Parameters.Add("@ToTime", SqlDbType.Time).Value = this.ToTime;
				SqlCmd.Parameters.Add("@IsEnabled", SqlDbType.Bit).Value = this.IsEnabled;
				SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

				SqlCmd.ExecuteNonQuery();
			
				this.OfferDaysTranId = Convert.ToInt32(SqlCmd.Parameters["@OfferDaysTranId"].Value);
				posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
				return rs;
			}
			catch (Exception ex)
			{
				posGlobalsDAL.SaveError(ex);
				return posRecordStatus.Error;
			}
			finally
			{
				posObjectFactoryDAL.DisposeCommand(SqlCmd);
			}
		}
		#endregion

		#region Update
        public posRecordStatus UpdateOfferDaysTran(SqlConnection SqlCon,SqlTransaction sqlTran)
		{ 
			SqlCommand SqlCmd = null;
			try
			{ 
                SqlCmd = new SqlCommand("posOfferDaysTran_Update", SqlCon, sqlTran);
				SqlCmd.CommandType = CommandType.StoredProcedure;

				SqlCmd.Parameters.Add("@OfferDaysTranId", SqlDbType.Int).Value = this.OfferDaysTranId;
				SqlCmd.Parameters.Add("@linktoOfferMasterId", SqlDbType.Int).Value = this.linktoOfferMasterId;
				SqlCmd.Parameters.Add("@Day", SqlDbType.SmallInt).Value = this.Day;
				SqlCmd.Parameters.Add("@FromTime", SqlDbType.Time).Value = this.FromTime;
				SqlCmd.Parameters.Add("@ToTime", SqlDbType.Time).Value = this.ToTime;
				SqlCmd.Parameters.Add("@IsEnabled", SqlDbType.Bit).Value = this.IsEnabled;
				SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output; 

				SqlCmd.ExecuteNonQuery(); 

				posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
				return rs;
			}
			catch (Exception ex)
			{
				posGlobalsDAL.SaveError(ex);
				return posRecordStatus.Error;
			}
			finally
			{
				posObjectFactoryDAL.DisposeCommand(SqlCmd); 
			}
		}
		#endregion

		#region Delete
		public posRecordStatus DeleteOfferDaysTran(SqlConnection SqlCon,SqlTransaction SqlTran)
		{
			SqlCommand SqlCmd = null;
			try
			{
				SqlCmd = new SqlCommand("posOfferDaysTran_Delete", SqlCon,SqlTran);
				SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@linktoOfferMasterId", SqlDbType.Int).Value = this.linktoOfferMasterId;
				SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

				SqlCmd.ExecuteNonQuery();
			
				posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
				return rs;
			}
			catch (Exception ex)
			{
				posGlobalsDAL.SaveError(ex);
				return posRecordStatus.Error;
			}
			finally
			{
				posObjectFactoryDAL.DisposeCommand(SqlCmd);
			}
		}
		#endregion			

		#region SelectAll
		public List<posOfferDaysTranDAL> SelectAllOfferDaysTran()
		{
			SqlConnection SqlCon = null;
			SqlCommand SqlCmd = null;
			SqlDataReader SqlRdr = null;
			try
			{
				SqlCon = posObjectFactoryDAL.CreateConnection();
				SqlCmd = new SqlCommand("posOfferDaysTran_SelectAll", SqlCon);
				SqlCmd.CommandType = CommandType.StoredProcedure; 

                SqlCmd.Parameters.Add("@linktoOfferMasterId", SqlDbType.Int).Value = this.linktoOfferMasterId; 

				SqlCon.Open();
				SqlRdr = SqlCmd.ExecuteReader();
				List<posOfferDaysTranDAL> lstOfferDaysTranDAL = SetListPropertiesFromSqlDataReader(SqlRdr);
				SqlRdr.Close();
				SqlCon.Close();

				return lstOfferDaysTranDAL;
			}
			catch (Exception ex)
			{
				posGlobalsDAL.SaveError(ex);
				return null;
			}
			finally
			{
				posObjectFactoryDAL.DisposeDataReader(SqlRdr);
				posObjectFactoryDAL.DisposeCommand(SqlCmd);
				posObjectFactoryDAL.DisposeConnection(SqlCon);
			}
		}
     
		#endregion
	}
}
