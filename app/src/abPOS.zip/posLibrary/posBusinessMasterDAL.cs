using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace posLibrary
{
    /// <summary>
    /// Class for posBusinessMaster
    /// </summary>
    public class posBusinessMasterDAL
    {
        #region Properties
        public short BusinessMasterId { get; set; }
        public string BusinessName { get; set; }
        public string BusinessShortName { get; set; }
        public string Address { get; set; }
        public string Phone1 { get; set; }
        public string Phone2 { get; set; }
        public string Email { get; set; }
        public string Fax { get; set; }
        public string Website { get; set; }
        public short linktoCountryMasterId { get; set; }
        public short linktoStateMasterId { get; set; }
        public int linktoCityMasterId { get; set; }
        public string ZipCode { get; set; }
        public string ImageName { get; set; }
        public string ExtraText { get; set; }
        public string TIN { get; set; }
        public DateTime? TINRegistrationDate { get; set; }
        public string CST { get; set; }
        public DateTime? CSTRegistrationDate { get; set; }
        public string PAN { get; set; }
        public DateTime? PANRegistrationDate { get; set; }
        public string TDS { get; set; }
        public DateTime? TDSRegistrationDate { get; set; }
        public short linktoBusinessTypeMasterId { get; set; }
        public string UniqueId { get; set; }
        public bool IsEnabled { get; set; }

        /// Extra
        public string Country { get; set; }
        public string State { get; set; }
        public string City { get; set; }
        public string BusinessType { get; set; }
        #endregion

        #region Class Methods
        private bool SetClassPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            if (sqlRdr.Read())
            {
                this.BusinessMasterId = Convert.ToInt16(sqlRdr["BusinessMasterId"]);
                this.BusinessName = Convert.ToString(sqlRdr["BusinessName"]);
                this.BusinessShortName = Convert.ToString(sqlRdr["BusinessShortName"]);
                this.Address = Convert.ToString(sqlRdr["Address"]);
                this.Phone1 = Convert.ToString(sqlRdr["Phone1"]);
                this.Phone2 = Convert.ToString(sqlRdr["Phone2"]);
                this.Email = Convert.ToString(sqlRdr["Email"]);
                this.Fax = Convert.ToString(sqlRdr["Fax"]);
                this.Website = Convert.ToString(sqlRdr["Website"]);
                this.linktoCountryMasterId = Convert.ToInt16(sqlRdr["linktoCountryMasterId"]);
                this.linktoStateMasterId = Convert.ToInt16(sqlRdr["linktoStateMasterId"]);
                this.linktoCityMasterId = Convert.ToInt32(sqlRdr["linktoCityMasterId"]);
                this.ZipCode = Convert.ToString(sqlRdr["ZipCode"]);
                this.ImageName = Convert.ToString(sqlRdr["ImageName"]);
                this.ExtraText = Convert.ToString(sqlRdr["ExtraText"]);
                this.TIN = Convert.ToString(sqlRdr["TIN"]);
                if (sqlRdr["TINRegistrationDate"] != DBNull.Value)
                {
                    this.TINRegistrationDate = Convert.ToDateTime(sqlRdr["TINRegistrationDate"]);
                }
                this.CST = Convert.ToString(sqlRdr["CST"]);
                if (sqlRdr["CSTRegistrationDate"] != DBNull.Value)
                {
                    this.CSTRegistrationDate = Convert.ToDateTime(sqlRdr["CSTRegistrationDate"]);
                }
                this.PAN = Convert.ToString(sqlRdr["PAN"]);
                if (sqlRdr["PANRegistrationDate"] != DBNull.Value)
                {
                    this.PANRegistrationDate = Convert.ToDateTime(sqlRdr["PANRegistrationDate"]);
                }
                this.TDS = Convert.ToString(sqlRdr["TDS"]);
                if (sqlRdr["TDSRegistrationDate"] != DBNull.Value)
                {
                    this.TDSRegistrationDate = Convert.ToDateTime(sqlRdr["TDSRegistrationDate"]);
                }
                this.linktoBusinessTypeMasterId = Convert.ToInt16(sqlRdr["linktoBusinessTypeMasterId"]);
                this.UniqueId = Convert.ToString(sqlRdr["UniqueId"]);
                this.IsEnabled = Convert.ToBoolean(sqlRdr["IsEnabled"]);

                /// Extra
                this.Country = Convert.ToString(sqlRdr["Country"]);
                this.State = Convert.ToString(sqlRdr["State"]);
                this.City = Convert.ToString(sqlRdr["City"]);
                this.BusinessType = Convert.ToString(sqlRdr["BusinessType"]);
                return true;
            }
            return false;
        }

        private List<posBusinessMasterDAL> SetListPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            List<posBusinessMasterDAL> lstBusinessMaster = new List<posBusinessMasterDAL>();
            posBusinessMasterDAL objBusinessMaster = null;
            while (sqlRdr.Read())
            {
                objBusinessMaster = new posBusinessMasterDAL();
                objBusinessMaster.BusinessMasterId = Convert.ToInt16(sqlRdr["BusinessMasterId"]);
                objBusinessMaster.BusinessName = Convert.ToString(sqlRdr["BusinessName"]);
                objBusinessMaster.BusinessShortName = Convert.ToString(sqlRdr["BusinessShortName"]);
                objBusinessMaster.Address = Convert.ToString(sqlRdr["Address"]);
                objBusinessMaster.Phone1 = Convert.ToString(sqlRdr["Phone1"]);
                objBusinessMaster.Phone2 = Convert.ToString(sqlRdr["Phone2"]);
                objBusinessMaster.Email = Convert.ToString(sqlRdr["Email"]);
                objBusinessMaster.Fax = Convert.ToString(sqlRdr["Fax"]);
                objBusinessMaster.Website = Convert.ToString(sqlRdr["Website"]);
                objBusinessMaster.linktoCountryMasterId = Convert.ToInt16(sqlRdr["linktoCountryMasterId"]);
                objBusinessMaster.linktoStateMasterId = Convert.ToInt16(sqlRdr["linktoStateMasterId"]);
                objBusinessMaster.linktoCityMasterId = Convert.ToInt32(sqlRdr["linktoCityMasterId"]);
                objBusinessMaster.ZipCode = Convert.ToString(sqlRdr["ZipCode"]);
                objBusinessMaster.ImageName = Convert.ToString(sqlRdr["ImageName"]);
                objBusinessMaster.ExtraText = Convert.ToString(sqlRdr["ExtraText"]);
                objBusinessMaster.TIN = Convert.ToString(sqlRdr["TIN"]);
                if (sqlRdr["TINRegistrationDate"] != DBNull.Value)
                {
                    objBusinessMaster.TINRegistrationDate = Convert.ToDateTime(sqlRdr["TINRegistrationDate"]);
                }
                objBusinessMaster.CST = Convert.ToString(sqlRdr["CST"]);
                if (sqlRdr["CSTRegistrationDate"] != DBNull.Value)
                {
                    objBusinessMaster.CSTRegistrationDate = Convert.ToDateTime(sqlRdr["CSTRegistrationDate"]);
                }
                objBusinessMaster.PAN = Convert.ToString(sqlRdr["PAN"]);
                if (sqlRdr["PANRegistrationDate"] != DBNull.Value)
                {
                    objBusinessMaster.PANRegistrationDate = Convert.ToDateTime(sqlRdr["PANRegistrationDate"]);
                }
                objBusinessMaster.TDS = Convert.ToString(sqlRdr["TDS"]);
                if (sqlRdr["TDSRegistrationDate"] != DBNull.Value)
                {
                    objBusinessMaster.TDSRegistrationDate = Convert.ToDateTime(sqlRdr["TDSRegistrationDate"]);
                }
                objBusinessMaster.linktoBusinessTypeMasterId = Convert.ToInt16(sqlRdr["linktoBusinessTypeMasterId"]);
                objBusinessMaster.UniqueId = Convert.ToString(sqlRdr["UniqueId"]);
                objBusinessMaster.IsEnabled = Convert.ToBoolean(sqlRdr["IsEnabled"]);

                /// Extra
                objBusinessMaster.Country = Convert.ToString(sqlRdr["Country"]);
                objBusinessMaster.State = Convert.ToString(sqlRdr["State"]);
                objBusinessMaster.City = Convert.ToString(sqlRdr["City"]);
                objBusinessMaster.BusinessType = Convert.ToString(sqlRdr["BusinessType"]);
                lstBusinessMaster.Add(objBusinessMaster);
            }
            return lstBusinessMaster;
        }
        #endregion

        #region   Insert
        public posRecordStatus InsertBusinessMaster(List<posSettingMasterDAL> lstSettingMasterDAL, posFinancialYearMasterDAL objFinancialYearMasterDAL, List<posDepartmentMasterDAL> lstDepartmentMasterDAL, List<posCounterMasterDAL> lstCounterMasterDAL, List<posTableMasterDAL> lstTableMasterDAL, List<posCounterTableTranDAL> lstCounterTableTranDAL, List<posTaxMasterDAL> lstTaxMaster, List<posWaiterMasterDAL> lstWaiterMasterDAL, List<posUnitMasterDAL> lstUnitMasterDAL, List<posCategoryMasterDAL> lstCategoryMasterDAL)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlTransaction SqlTran = null;

            posSettingMasterDAL objSetingMasterDAL = null;
            posDepartmentMasterDAL objDepartmentMasterDAL = null;
            posCounterMasterDAL objCounterMasterDAL = null;
            posTableMasterDAL objTableMasterDAL = null;
            posCounterTableTranDAL objCounterTableTran = null;
            posTaxMasterDAL objTaxMaster = null;
            posWaiterMasterDAL objWaiterMasterDAL = null;
            posUnitMasterDAL objUnitMasterDAL = null;
            posCategoryMasterDAL objCategoryMasterDAL = null;

            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCon.Open();
                SqlTran = SqlCon.BeginTransaction();

                SqlCmd = new SqlCommand("posBusinessMaster_Insert", SqlCon, SqlTran);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@BusinessMasterId", SqlDbType.SmallInt).Direction = ParameterDirection.Output;
                SqlCmd.Parameters.Add("@BusinessName", SqlDbType.VarChar).Value = this.BusinessName;
                SqlCmd.Parameters.Add("@BusinessShortName", SqlDbType.VarChar).Value = this.BusinessShortName;
                SqlCmd.Parameters.Add("@linktoBusinessTypeMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessTypeMasterId;
                SqlCmd.Parameters.Add("@linktoCountryMasterId", SqlDbType.SmallInt).Value = this.linktoCountryMasterId;
                SqlCmd.Parameters.Add("@linktoStateMasterId", SqlDbType.SmallInt).Value = this.linktoStateMasterId;
                SqlCmd.Parameters.Add("@linktoCityMasterId", SqlDbType.Int).Value = this.linktoCityMasterId;
                SqlCmd.Parameters.Add("@UniqueId", SqlDbType.VarChar).Value = this.UniqueId;
                SqlCmd.Parameters.Add("@Address", SqlDbType.VarChar).Value = this.Address;
                SqlCmd.Parameters.Add("@Phone1", SqlDbType.VarChar).Value = this.Phone1;
                SqlCmd.Parameters.Add("@Phone2", SqlDbType.VarChar).Value = this.Phone2;
                SqlCmd.Parameters.Add("@Email", SqlDbType.VarChar).Value = this.Email;
                SqlCmd.Parameters.Add("@Fax", SqlDbType.VarChar).Value = this.Fax;
                SqlCmd.Parameters.Add("@Website", SqlDbType.VarChar).Value = this.Website;
                SqlCmd.Parameters.Add("@ZipCode", SqlDbType.VarChar).Value = this.ZipCode;
                SqlCmd.Parameters.Add("@ImageName", SqlDbType.VarChar).Value = this.ImageName;
                SqlCmd.Parameters.Add("@ExtraText", SqlDbType.VarChar).Value = this.ExtraText;
                SqlCmd.Parameters.Add("@TIN", SqlDbType.VarChar).Value = this.TIN;
                SqlCmd.Parameters.Add("@TINRegistrationDate", SqlDbType.Date).Value = this.TINRegistrationDate;
                SqlCmd.Parameters.Add("@CST", SqlDbType.VarChar).Value = this.CST;
                SqlCmd.Parameters.Add("@CSTRegistrationDate", SqlDbType.Date).Value = this.CSTRegistrationDate;
                SqlCmd.Parameters.Add("@PAN", SqlDbType.VarChar).Value = this.PAN;
                SqlCmd.Parameters.Add("@PANRegistrationDate", SqlDbType.Date).Value = this.PANRegistrationDate;
                SqlCmd.Parameters.Add("@TDS", SqlDbType.VarChar).Value = this.TDS;
                SqlCmd.Parameters.Add("@IsEnabled", SqlDbType.Bit).Value = this.IsEnabled;
                SqlCmd.Parameters.Add("@TDSRegistrationDate", SqlDbType.Date).Value = this.TDSRegistrationDate;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCmd.ExecuteNonQuery();

                this.BusinessMasterId = Convert.ToInt16(SqlCmd.Parameters["@BusinessMasterId"].Value);
                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                if (rs != posRecordStatus.Success)
                {
                    SqlTran.Rollback();
                    SqlCon.Close();
                    return rs;
                }

                // DEFAULT BUSINESS ENTRY
                short UserMasterId;
                rs = this.InsertAllBusinessMasterDefaults(SqlCon, SqlTran, out UserMasterId);
                if (rs != posRecordStatus.Success)
                {
                    SqlTran.Rollback();
                    SqlCon.Close();
                    return rs;
                }

                // SETTINGS
                objSetingMasterDAL = new posSettingMasterDAL();
                objSetingMasterDAL.linktoBusinessMasterId = this.BusinessMasterId;
                rs = objSetingMasterDAL.UpdateSettingMasterBySettingName(SqlCon, SqlTran, lstSettingMasterDAL);
                if (rs != posRecordStatus.Success)
                {
                    SqlTran.Rollback();
                    SqlCon.Close();
                    return rs;
                }

                // FINANCIALYEAR
                objFinancialYearMasterDAL.linktoBusinessMasterId = this.BusinessMasterId;
                rs = objFinancialYearMasterDAL.InsertFinancialYearMaster(SqlCon, SqlTran);
                if (rs != posRecordStatus.Success)
                {
                    SqlTran.Rollback();
                    SqlCon.Close();
                    return rs;
                }

                // DEPARTMENT
                objDepartmentMasterDAL = new posDepartmentMasterDAL();
                objDepartmentMasterDAL.linktoBusinessMasterId = this.BusinessMasterId;
                rs = objDepartmentMasterDAL.InsertDepartmentMaster(SqlCon, SqlTran, lstDepartmentMasterDAL);
                if (rs != posRecordStatus.Success)
                {
                    SqlTran.Rollback();
                    SqlCon.Close();
                    return rs;
                }

                // COUNTER
                objCounterMasterDAL = new posCounterMasterDAL();
                objCounterMasterDAL.linktoBusinessMasterId = this.BusinessMasterId;
                objCounterMasterDAL.linktoDepartmentMasterId = objDepartmentMasterDAL.DepartmentMasterId;
                objCounterMasterDAL.linktoUserMasterIdCreatedBy = UserMasterId;
                rs = objCounterMasterDAL.InsertCounterMaster(SqlCon, SqlTran, lstCounterMasterDAL);
                if (rs != posRecordStatus.Success)
                {
                    SqlTran.Rollback();
                    SqlCon.Close();
                    return rs;
                }

                // TABLE
                if (lstTableMasterDAL.Count > 0)
                {
                    objTableMasterDAL = new posTableMasterDAL();
                    objTableMasterDAL.linktoBusinessMasterId = this.BusinessMasterId;
                    objTableMasterDAL.linktoUserMasterIdCreatedBy = UserMasterId;
                    rs = objTableMasterDAL.InsertTableMaster(SqlCon, SqlTran, lstTableMasterDAL);
                    if (rs != posRecordStatus.Success)
                    {
                        SqlTran.Rollback();
                        SqlCon.Close();
                        return rs;
                    }
                }

                // TABLE ASSGINMENT
                if (lstCounterTableTranDAL.Count > 0)
                {
                    objCounterTableTran = new posCounterTableTranDAL();
                    rs = objCounterTableTran.InsertCounterTableTran(lstCounterTableTranDAL, this.BusinessMasterId, SqlCon, SqlTran);
                    if (rs != posRecordStatus.Success)
                    {
                        SqlTran.Rollback();
                        SqlCon.Close();
                        return rs;
                    }
                }

                // TAX
                objTaxMaster = new posTaxMasterDAL();
                objTaxMaster.linktoBusinessMasterId = this.BusinessMasterId;
                objTaxMaster.linktoUserMasterIdCreatedBy = UserMasterId;
                rs = objTaxMaster.InsertTaxMaster(SqlCon, SqlTran, lstTaxMaster);
                if (rs != posRecordStatus.Success)
                {
                    SqlTran.Rollback();
                    SqlCon.Close();
                    return rs;
                }

                // WAITER
                if (lstWaiterMasterDAL.Count > 0)
                {
                    objWaiterMasterDAL = new posWaiterMasterDAL();
                    objWaiterMasterDAL.linktoBusinessMasterId = this.BusinessMasterId;
                    objWaiterMasterDAL.linktoUserMasterIdCreatedBy = UserMasterId;
                    rs = objWaiterMasterDAL.InsertWaiterMaster(lstWaiterMasterDAL, SqlCon, SqlTran);
                    if (rs != posRecordStatus.Success)
                    {
                        SqlTran.Rollback();
                        SqlCon.Close();
                        return rs;
                    }
                }

                // UNIT
                if (lstUnitMasterDAL.Count > 0)
                {
                    objUnitMasterDAL = new posUnitMasterDAL();
                    objUnitMasterDAL.linktoBusinessMasterId = this.BusinessMasterId;
                    objUnitMasterDAL.linktoUserMasterIdCreatedBy = UserMasterId;
                    rs = objUnitMasterDAL.InsertUnitMasterUnits(SqlCon, SqlTran, lstUnitMasterDAL);
                    if (rs != posRecordStatus.Success)
                    {
                        SqlTran.Rollback();
                        SqlCon.Close();
                        return rs;
                    }
                }

                // CATEGORY
                if (lstCategoryMasterDAL.Count > 0)
                {
                    objCategoryMasterDAL = new posCategoryMasterDAL();
                    objCategoryMasterDAL.linktoBusinessMasterId = this.BusinessMasterId;
                    objCategoryMasterDAL.linktoUserMasterIdCreatedBy = UserMasterId;
                    rs = objCategoryMasterDAL.InsertCategoryMaster(lstCategoryMasterDAL, SqlCon, SqlTran);
                    if (rs != posRecordStatus.Success)
                    {
                        SqlTran.Rollback();
                        SqlCon.Close();
                        return rs;
                    }
                }

                SqlTran.Commit();
                SqlCon.Close();
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                objCounterMasterDAL = null;
                objDepartmentMasterDAL = null;
                objFinancialYearMasterDAL = null;
                objSetingMasterDAL = null;
                objTaxMaster = null;
                objUnitMasterDAL = null;
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public posRecordStatus InsertAllBusinessMasterDefaults(SqlConnection SqlCon, SqlTransaction SqlTran, out short userMasterId)
        {
            SqlCommand SqlCmd = null;

            userMasterId = 0;
            try
            {
                SqlCmd = new SqlCommand("posBusinessMasterDefaults_InsertAll", SqlCon, SqlTran);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@BusinessMasterId", SqlDbType.SmallInt).Value = this.BusinessMasterId;
                SqlCmd.Parameters.Add("@UserMasterId", SqlDbType.SmallInt).Direction = ParameterDirection.Output;
                SqlCmd.Parameters.Add("@CountryMasterId", SqlDbType.SmallInt).Value = this.linktoCountryMasterId;
                SqlCmd.Parameters.Add("@State", SqlDbType.VarChar).Value = this.State;
                SqlCmd.Parameters.Add("@City", SqlDbType.VarChar).Value = this.City;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCmd.ExecuteNonQuery();

                userMasterId = (short)SqlCmd.Parameters["@UserMasterId"].Value;

                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
            }
        }
        #endregion

        #region Update
        public posRecordStatus UpdateBusinessMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posBusinessMaster_Update", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@BusinessMasterId", SqlDbType.SmallInt).Value = this.BusinessMasterId;
                SqlCmd.Parameters.Add("@BusinessShortName", SqlDbType.VarChar).Value = this.BusinessShortName;
                SqlCmd.Parameters.Add("@Address", SqlDbType.VarChar).Value = this.Address;
                SqlCmd.Parameters.Add("@Phone1", SqlDbType.VarChar).Value = this.Phone1;
                SqlCmd.Parameters.Add("@Phone2", SqlDbType.VarChar).Value = this.Phone2;
                SqlCmd.Parameters.Add("@Email", SqlDbType.VarChar).Value = this.Email;
                SqlCmd.Parameters.Add("@Fax", SqlDbType.VarChar).Value = this.Fax;
                SqlCmd.Parameters.Add("@Website", SqlDbType.VarChar).Value = this.Website;
                SqlCmd.Parameters.Add("@ZipCode", SqlDbType.VarChar).Value = this.ZipCode;
                SqlCmd.Parameters.Add("@ImageName", SqlDbType.VarChar).Value = this.ImageName;
                SqlCmd.Parameters.Add("@ExtraText", SqlDbType.VarChar).Value = this.ExtraText;
                SqlCmd.Parameters.Add("@TIN", SqlDbType.VarChar).Value = this.TIN;
                SqlCmd.Parameters.Add("@TINRegistrationDate", SqlDbType.Date).Value = this.TINRegistrationDate;
                SqlCmd.Parameters.Add("@CST", SqlDbType.VarChar).Value = this.CST;
                SqlCmd.Parameters.Add("@CSTRegistrationDate", SqlDbType.Date).Value = this.CSTRegistrationDate;
                SqlCmd.Parameters.Add("@PAN", SqlDbType.VarChar).Value = this.PAN;
                SqlCmd.Parameters.Add("@PANRegistrationDate", SqlDbType.Date).Value = this.PANRegistrationDate;
                SqlCmd.Parameters.Add("@TDS", SqlDbType.VarChar).Value = this.TDS;
                SqlCmd.Parameters.Add("@TDSRegistrationDate", SqlDbType.Date).Value = this.TDSRegistrationDate;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region Select
        public bool SelectBusinessMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posBusinessMaster_Select", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@BusinessMasterId", SqlDbType.SmallInt).Value = this.BusinessMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                bool IsSelected = SetClassPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                return IsSelected;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return false;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public bool SelectBusinessMasterByUniqueId(string UniqueId)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posBusinessMasterByUniqueId_Select", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@UniqueId", SqlDbType.VarChar).Value = UniqueId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                bool IsSelected = false;
                while (SqlRdr.Read())
                {
                    this.UniqueId = Convert.ToString(SqlRdr["UniqueId"]);
                    if (!string.IsNullOrEmpty(this.UniqueId))
                    {
                        IsSelected = true;
                    }
                }
                SqlRdr.Close();
                SqlCon.Close();

                return IsSelected;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return false;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region SelectAll
        public List<posBusinessMasterDAL> SelectAllBusinessMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posBusinessMaster_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@IsEnabled", SqlDbType.Bit).Value = this.IsEnabled;
                if (BusinessMasterId > 0)
                {
                    SqlCmd.Parameters.Add("@BusinessMasterId", SqlDbType.SmallInt).Value = this.BusinessMasterId;
                }

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<posBusinessMasterDAL> lstBusinessMasterDAL = SetListPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                return lstBusinessMasterDAL;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion
    }
}
