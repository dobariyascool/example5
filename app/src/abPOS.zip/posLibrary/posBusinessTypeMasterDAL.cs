using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace posLibrary
{
    /// <summary>
    /// Class for posBusinessTypeMaster
    /// </summary>
    public class posBusinessTypeMasterDAL
    {
        #region Properties
        public short BusinessTypeMasterId { get; set; }
        public string BusinessType { get; set; }
        public string Description { get; set; }

        /// Extra
        #endregion

        #region Class Methods
        private List<posBusinessTypeMasterDAL> SetListPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            List<posBusinessTypeMasterDAL> lstBusinessTypeMaster = new List<posBusinessTypeMasterDAL>();
            posBusinessTypeMasterDAL objBusinessTypeMaster = null;
            while (sqlRdr.Read())
            {
                objBusinessTypeMaster = new posBusinessTypeMasterDAL();
                objBusinessTypeMaster.BusinessTypeMasterId = Convert.ToInt16(sqlRdr["BusinessTypeMasterId"]);
                objBusinessTypeMaster.BusinessType = Convert.ToString(sqlRdr["BusinessType"]);
                objBusinessTypeMaster.Description = Convert.ToString(sqlRdr["Description"]);

                /// Extra
                lstBusinessTypeMaster.Add(objBusinessTypeMaster);
            }
            return lstBusinessTypeMaster;
        }
        #endregion

        #region SelectAll
        public static List<posBusinessTypeMasterDAL> SelectAllBusinessTypeMasterBusinessType()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posBusinessTypeMasterBusinessType_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<posBusinessTypeMasterDAL> lstBusinessTypeMasterDAL = new List<posBusinessTypeMasterDAL>();
                posBusinessTypeMasterDAL objBusinessTypeMasterDAL = null;
                while (SqlRdr.Read())
                {
                    objBusinessTypeMasterDAL = new posBusinessTypeMasterDAL();
                    objBusinessTypeMasterDAL.BusinessTypeMasterId = Convert.ToInt16(SqlRdr["BusinessTypeMasterId"]);
                    objBusinessTypeMasterDAL.BusinessType = Convert.ToString(SqlRdr["BusinessType"]);
                    lstBusinessTypeMasterDAL.Add(objBusinessTypeMasterDAL);
                }
                SqlRdr.Close();
                SqlCon.Close();

                return lstBusinessTypeMasterDAL;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion
    }
}
