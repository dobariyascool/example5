using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace posLibrary
{
    /// <summary>
    /// Class for posCashBookMaster
    /// </summary>
    public class posCashBookMasterDAL
    {
        #region Properties
        public int CashBookMasterId { get; set; }
        public short linktoBusinessMasterId { get; set; }
        public int linktoAccountMasterIdCash { get; set; }
        public string CashBookNumber { get; set; }
        public DateTime CashBookDate { get; set; }
        public string VoucherNumber { get; set; }
        public bool? IsPaid { get; set; }
        public int linktoAccountMasterId { get; set; }
        public double Amount { get; set; }
        public string Remark { get; set; }
        public DateTime CreateDateTime { get; set; }
        public short linktoUserMasterIdCreatedBy { get; set; }
        public DateTime? UpdateDateTime { get; set; }
        public short? linktoUserMasterIdUpdatedBy { get; set; }

        /// Extra
        public string AccountCash { get; set; }
        public string Account { get; set; }
        public int AccountCashMasterId { get; set; }
        public int AccountMasterId { get; set; }
        public DateTime FromDate { get; set; }
        public DateTime ToDate { get; set; }
        public double DebitAmount { get; set; }
        public double CreditAmount { get; set; }
        #endregion

        #region Class Methods
        private bool SetClassPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            if (sqlRdr.Read())
            {
                this.CashBookMasterId = Convert.ToInt32(sqlRdr["CashBookMasterId"]);
                this.linktoBusinessMasterId = Convert.ToInt16(sqlRdr["linktoBusinessMasterId"]);
                this.linktoAccountMasterIdCash = Convert.ToInt32(sqlRdr["linktoAccountMasterIdCash"]);
                this.CashBookNumber = Convert.ToString(sqlRdr["CashBookNumber"]);
                this.CashBookDate = Convert.ToDateTime(sqlRdr["CashBookDate"]);
                this.VoucherNumber = Convert.ToString(sqlRdr["VoucherNumber"]);
                if (sqlRdr["IsPaid"] != DBNull.Value)
                {
                    this.IsPaid = Convert.ToBoolean(sqlRdr["IsPaid"]);
                }
                this.linktoAccountMasterId = Convert.ToInt32(sqlRdr["linktoAccountMasterId"]);
                this.Amount = Convert.ToDouble(sqlRdr["Amount"]);
                this.Remark = Convert.ToString(sqlRdr["Remark"]);
                this.CreateDateTime = Convert.ToDateTime(sqlRdr["CreateDateTime"]);
                this.linktoUserMasterIdCreatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdCreatedBy"]);
                if (sqlRdr["UpdateDateTime"] != DBNull.Value)
                {
                    this.UpdateDateTime = Convert.ToDateTime(sqlRdr["UpdateDateTime"]);
                }
                if (sqlRdr["linktoUserMasterIdUpdatedBy"] != DBNull.Value)
                {
                    this.linktoUserMasterIdUpdatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdUpdatedBy"]);
                }

                /// Extra
                this.AccountCash = Convert.ToString(sqlRdr["AccountCash"]);
                this.Account = Convert.ToString(sqlRdr["Account"]);
                this.AccountCashMasterId = Convert.ToInt32(sqlRdr["AccountCashMasterId"]);
                this.AccountMasterId = Convert.ToInt32(sqlRdr["AccountMasterId"]);
                return true;
            }
            return false;
        }

        private List<posCashBookMasterDAL> SetListPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            List<posCashBookMasterDAL> lstCashBookMaster = new List<posCashBookMasterDAL>();
            posCashBookMasterDAL objCashBookMaster = null;
            while (sqlRdr.Read())
            {
                objCashBookMaster = new posCashBookMasterDAL();
                objCashBookMaster.CashBookMasterId = Convert.ToInt32(sqlRdr["CashBookMasterId"]);
                objCashBookMaster.linktoBusinessMasterId = Convert.ToInt16(sqlRdr["linktoBusinessMasterId"]);
                objCashBookMaster.linktoAccountMasterIdCash = Convert.ToInt32(sqlRdr["linktoAccountMasterIdCash"]);
                objCashBookMaster.CashBookNumber = Convert.ToString(sqlRdr["CashBookNumber"]);
                objCashBookMaster.CashBookDate = Convert.ToDateTime(sqlRdr["CashBookDate"]);
                objCashBookMaster.VoucherNumber = Convert.ToString(sqlRdr["VoucherNumber"]);
                if (sqlRdr["IsPaid"] != DBNull.Value)
                {
                    objCashBookMaster.IsPaid = Convert.ToBoolean(sqlRdr["IsPaid"]);
                }
                objCashBookMaster.linktoAccountMasterId = Convert.ToInt32(sqlRdr["linktoAccountMasterId"]);
                objCashBookMaster.Amount = Convert.ToDouble(sqlRdr["Amount"]);
                objCashBookMaster.Remark = Convert.ToString(sqlRdr["Remark"]);
                objCashBookMaster.CreateDateTime = Convert.ToDateTime(sqlRdr["CreateDateTime"]);
                objCashBookMaster.linktoUserMasterIdCreatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdCreatedBy"]);
                if (sqlRdr["UpdateDateTime"] != DBNull.Value)
                {
                    objCashBookMaster.UpdateDateTime = Convert.ToDateTime(sqlRdr["UpdateDateTime"]);
                }
                if (sqlRdr["linktoUserMasterIdUpdatedBy"] != DBNull.Value)
                {
                    objCashBookMaster.linktoUserMasterIdUpdatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdUpdatedBy"]);
                }

                /// Extra
                objCashBookMaster.AccountCash = Convert.ToString(sqlRdr["AccountCash"]);
                objCashBookMaster.Account = Convert.ToString(sqlRdr["Account"]);
                lstCashBookMaster.Add(objCashBookMaster);
            }
            return lstCashBookMaster;
        }
        #endregion

        #region Insert
        public posRecordStatus InsertCashBookMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posCashBookMaster_Insert", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@CashBookMasterId", SqlDbType.Int).Direction = ParameterDirection.Output;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCmd.Parameters.Add("@linktoAccountMasterIdCash", SqlDbType.Int).Value = this.linktoAccountMasterIdCash;
                SqlCmd.Parameters.Add("@CashBookNumber", SqlDbType.VarChar).Value = this.CashBookNumber;
                SqlCmd.Parameters.Add("@CashBookDate", SqlDbType.Date).Value = this.CashBookDate;
                SqlCmd.Parameters.Add("@VoucherNumber", SqlDbType.VarChar).Value = this.VoucherNumber;
                SqlCmd.Parameters.Add("@IsPaid", SqlDbType.Bit).Value = this.IsPaid;
                SqlCmd.Parameters.Add("@linktoAccountMasterId", SqlDbType.Int).Value = this.linktoAccountMasterId;
                SqlCmd.Parameters.Add("@Amount", SqlDbType.Money).Value = this.Amount;
                SqlCmd.Parameters.Add("@Remark", SqlDbType.VarChar).Value = this.Remark;
                SqlCmd.Parameters.Add("@CreateDateTime", SqlDbType.DateTime).Value = this.CreateDateTime;
                SqlCmd.Parameters.Add("@linktoUserMasterIdCreatedBy", SqlDbType.SmallInt).Value = this.linktoUserMasterIdCreatedBy;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                this.CashBookMasterId = Convert.ToInt32(SqlCmd.Parameters["@CashBookMasterId"].Value);
                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region Update
        public posRecordStatus UpdateCashBookMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posCashBookMaster_Update", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@CashBookMasterId", SqlDbType.Int).Value = this.CashBookMasterId;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCmd.Parameters.Add("@linktoAccountMasterIdCash", SqlDbType.Int).Value = this.linktoAccountMasterIdCash;
                SqlCmd.Parameters.Add("@CashBookNumber", SqlDbType.VarChar).Value = this.CashBookNumber;
                SqlCmd.Parameters.Add("@CashBookDate", SqlDbType.Date).Value = this.CashBookDate;
                SqlCmd.Parameters.Add("@VoucherNumber", SqlDbType.VarChar).Value = this.VoucherNumber;
                SqlCmd.Parameters.Add("@IsPaid", SqlDbType.Bit).Value = this.IsPaid;
                SqlCmd.Parameters.Add("@linktoAccountMasterId", SqlDbType.Int).Value = this.linktoAccountMasterId;
                SqlCmd.Parameters.Add("@Amount", SqlDbType.Money).Value = this.Amount;
                SqlCmd.Parameters.Add("@Remark", SqlDbType.VarChar).Value = this.Remark;
                SqlCmd.Parameters.Add("@UpdateDateTime", SqlDbType.DateTime).Value = this.UpdateDateTime;
                SqlCmd.Parameters.Add("@linktoUserMasterIdUpdatedBy", SqlDbType.SmallInt).Value = this.linktoUserMasterIdUpdatedBy;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region DeleteAll
        public posRecordStatus DeleteAllCashBookMaster(string cashBookMasterIds)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posCashBookMaster_DeleteAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@CashBookMasterIds", SqlDbType.VarChar).Value = cashBookMasterIds;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region Select
        public bool SelectCashBookMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posCashBookMaster_Select", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@CashBookMasterId", SqlDbType.Int).Value = this.CashBookMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                bool IsSelected = SetClassPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                return IsSelected;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return false;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public string SelecMaxCashBookNumber()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posCashBookMasterMaxCashBookNumber_Select", SqlCon);
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                if (SqlRdr.Read())
                {
                    if (SqlRdr["CashBookNumber"] != DBNull.Value)
                    {
                        this.CashBookNumber = Convert.ToString(SqlRdr["CashBookNumber"]);
                    }
                    else
                    {
                        this.CashBookNumber = "1";
                    }
                }
                SqlRdr.Close();
                SqlCon.Close();

                return this.CashBookNumber;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region SelectAll
        public List<posCashBookMasterDAL> SelectAllCashBookMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posCashBookMaster_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                if (this.linktoAccountMasterIdCash > 0)
                {
                    SqlCmd.Parameters.Add("@linktoAccountMasterIdCash", SqlDbType.Int).Value = this.linktoAccountMasterIdCash;
                }
                if (this.CashBookDate != new DateTime())
                {
                    SqlCmd.Parameters.Add("@CashBookDate", SqlDbType.Date).Value = this.CashBookDate;
                }
                SqlCmd.Parameters.Add("@VoucherNumber", SqlDbType.VarChar).Value = this.VoucherNumber;
                SqlCmd.Parameters.Add("@IsPaid", SqlDbType.Bit).Value = this.IsPaid;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<posCashBookMasterDAL> lstCashBookMasterDAL = SetListPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                return lstCashBookMasterDAL;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public List<posCashBookMasterDAL> SelectAllCashBookMasterBankBookMasterForLedger()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posCashBookMasterBankBookMasterForLedger_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@linktoAccountMasterId", SqlDbType.Int).Value = this.linktoAccountMasterId;
                SqlCmd.Parameters.Add("@FromDate", SqlDbType.Date).Value = this.FromDate;
                SqlCmd.Parameters.Add("@ToDate", SqlDbType.Date).Value = this.ToDate;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<posCashBookMasterDAL> lstCashBookMaster = new List<posCashBookMasterDAL>();
                posCashBookMasterDAL objCashBookMaster = null;
                while (SqlRdr.Read())
                {
                    objCashBookMaster = new posCashBookMasterDAL();
                    objCashBookMaster.CashBookDate = Convert.ToDateTime(SqlRdr["CashBookDate"]);
                    objCashBookMaster.VoucherNumber = Convert.ToString(SqlRdr["VoucherNumber"]);
                    objCashBookMaster.linktoAccountMasterId = Convert.ToInt32(SqlRdr["linktoAccountMasterId"]);

                    /// Extra

                    objCashBookMaster.Account = Convert.ToString(SqlRdr["AccountName"]);
                    objCashBookMaster.DebitAmount = Convert.ToDouble(SqlRdr["DebitAmount"]);
                    objCashBookMaster.CreditAmount = Convert.ToDouble(SqlRdr["CreditAmount"]);
                    lstCashBookMaster.Add(objCashBookMaster);
                }

                SqlRdr.Close();
                SqlCon.Close();

                return lstCashBookMaster;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion
    }
}
