using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace posLibrary
{
    /// <summary>
    /// Class for posMiscIncomeCategoryMaster
    /// </summary>
    public class posMiscIncomeCategoryMasterDAL
    {
        #region Properties
        public short MiscIncomeCategoryMasterId { get; set; }
        public string CategoryName { get; set; }
        public string Description { get; set; }
        public bool IsEnabled { get; set; }
        public short linktoBusinessMasterId { get; set; }
        #endregion

        #region Class Methods
        private bool SetClassPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            if (sqlRdr.Read())
            {
                this.MiscIncomeCategoryMasterId = Convert.ToInt16(sqlRdr["MiscIncomeCategoryMasterId"]);
                this.CategoryName = Convert.ToString(sqlRdr["CategoryName"]);
                this.Description = Convert.ToString(sqlRdr["Description"]);
                this.IsEnabled = Convert.ToBoolean(sqlRdr["IsEnabled"]);
                return true;
            }
            return false;
        }

        private List<posMiscIncomeCategoryMasterDAL> SetListPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            List<posMiscIncomeCategoryMasterDAL> lstMiscIncomeCategoryMaster = new List<posMiscIncomeCategoryMasterDAL>();
            posMiscIncomeCategoryMasterDAL objMiscIncomeCategoryMaster = null;
            while (sqlRdr.Read())
            {
                objMiscIncomeCategoryMaster = new posMiscIncomeCategoryMasterDAL();
                objMiscIncomeCategoryMaster.MiscIncomeCategoryMasterId = Convert.ToInt16(sqlRdr["MiscIncomeCategoryMasterId"]);
                objMiscIncomeCategoryMaster.CategoryName = Convert.ToString(sqlRdr["CategoryName"]);
                objMiscIncomeCategoryMaster.Description = Convert.ToString(sqlRdr["Description"]);
                objMiscIncomeCategoryMaster.IsEnabled = Convert.ToBoolean(sqlRdr["IsEnabled"]);
                lstMiscIncomeCategoryMaster.Add(objMiscIncomeCategoryMaster);
            }
            return lstMiscIncomeCategoryMaster;
        }
        #endregion

        #region Insert
        public posRecordStatus InsertMiscIncomeCategoryMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posMiscIncomeCategoryMaster_Insert", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@MiscIncomeCategoryMasterId", SqlDbType.SmallInt).Direction = ParameterDirection.Output;
                SqlCmd.Parameters.Add("@CategoryName", SqlDbType.VarChar).Value = this.CategoryName;
                SqlCmd.Parameters.Add("@Description", SqlDbType.VarChar).Value = this.Description;
                SqlCmd.Parameters.Add("@IsEnabled", SqlDbType.Bit).Value = this.IsEnabled;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                this.MiscIncomeCategoryMasterId = Convert.ToInt16(SqlCmd.Parameters["@MiscIncomeCategoryMasterId"].Value);
                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region Update
        public posRecordStatus UpdateMiscIncomeCategoryMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posMiscIncomeCategoryMaster_Update", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@MiscIncomeCategoryMasterId", SqlDbType.SmallInt).Value = this.MiscIncomeCategoryMasterId;
                SqlCmd.Parameters.Add("@CategoryName", SqlDbType.VarChar).Value = this.CategoryName;
                SqlCmd.Parameters.Add("@Description", SqlDbType.VarChar).Value = this.Description;
                SqlCmd.Parameters.Add("@IsEnabled", SqlDbType.Bit).Value = this.IsEnabled;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region DeleteAll
        public static posRecordStatus DeleteAllMiscIncomeCategoryMaster(string miscIncomeCategoryMasterIds)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posMiscIncomeCategoryMaster_DeleteAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@MiscIncomeCategoryMasterIds", SqlDbType.VarChar).Value = miscIncomeCategoryMasterIds;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region Select
        public bool SelectMiscIncomeCategoryMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posMiscIncomeCategoryMaster_Select", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@MiscIncomeCategoryMasterId", SqlDbType.SmallInt).Value = this.MiscIncomeCategoryMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                bool IsSelected = SetClassPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                return IsSelected;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return false;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region SelectAll
        public List<posMiscIncomeCategoryMasterDAL> SelectAllMiscIncomeCategoryMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posMiscIncomeCategoryMaster_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@IsEnabled", SqlDbType.Bit).Value = this.IsEnabled;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<posMiscIncomeCategoryMasterDAL> lstMiscIncomeCategoryMasterDAL = SetListPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                return lstMiscIncomeCategoryMasterDAL;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public static List<posMiscIncomeCategoryMasterDAL> SelectAllMiscIncomeCategoryMasterCategoryName(short linktoBusinessMasterId)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posMiscIncomeCategoryMasterCategoryName_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = linktoBusinessMasterId;
                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<posMiscIncomeCategoryMasterDAL> lstMiscIncomeCategoryMasterDAL = new List<posMiscIncomeCategoryMasterDAL>();
                posMiscIncomeCategoryMasterDAL objMiscIncomeCategoryMasterDAL = null;
                while (SqlRdr.Read())
                {
                    objMiscIncomeCategoryMasterDAL = new posMiscIncomeCategoryMasterDAL();
                    objMiscIncomeCategoryMasterDAL.MiscIncomeCategoryMasterId = Convert.ToInt16(SqlRdr["MiscIncomeCategoryMasterId"]);
                    objMiscIncomeCategoryMasterDAL.CategoryName = Convert.ToString(SqlRdr["CategoryName"]);
                    lstMiscIncomeCategoryMasterDAL.Add(objMiscIncomeCategoryMasterDAL);
                }
                SqlRdr.Close();
                SqlCon.Close();

                return lstMiscIncomeCategoryMasterDAL;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion
    }
}
