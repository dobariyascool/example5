using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace posLibrary
{
    /// <summary>
    /// Class for posIssueItemMaster
    /// </summary>
    public class posIssueItemMasterDAL
    {
        #region Properties
        public int IssueItemMasterId { get; set; }
        public string IssueNumber { get; set; }
        public DateTime IssueDate { get; set; }
        public short linktoDepartmentMasterIdFrom { get; set; }
        public short linktoDepartmentMasterIdTo { get; set; }
        public string Remark { get; set; }
        public DateTime CreateDateTime { get; set; }
        public short linktoUserMasterIdCreatedBy { get; set; }
        public DateTime? UpdateDateTime { get; set; }
        public short? linktoUserMasterIdUpdatedBy { get; set; }
       
        /// Extra
        public string DepartmentFrom { get; set; }
        public string DepartmentTo { get; set; }
        public string ItemName { get; set; }
        public int Quantity { get; set; }
        public string Unit { get; set; }
        public string ItemMasterIds { get; set; }

        #endregion

        #region Class Methods
        private bool SetClassPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            if (sqlRdr.Read())
            {
                this.IssueItemMasterId = Convert.ToInt32(sqlRdr["IssueItemMasterId"]);
                this.IssueNumber = Convert.ToString(sqlRdr["IssueNumber"]);
                this.IssueDate = Convert.ToDateTime(sqlRdr["IssueDate"]);
                this.linktoDepartmentMasterIdFrom = Convert.ToInt16(sqlRdr["linktoDepartmentMasterIdFrom"]);
                this.linktoDepartmentMasterIdTo = Convert.ToInt16(sqlRdr["linktoDepartmentMasterIdTo"]);
                this.Remark = Convert.ToString(sqlRdr["Remark"]);
                this.CreateDateTime = Convert.ToDateTime(sqlRdr["CreateDateTime"]);
                this.linktoUserMasterIdCreatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdCreatedBy"]);
                if (sqlRdr["UpdateDateTime"] != DBNull.Value)
                {
                    this.UpdateDateTime = Convert.ToDateTime(sqlRdr["UpdateDateTime"]);
                }
                if (sqlRdr["linktoUserMasterIdUpdatedBy"] != DBNull.Value)
                {
                    this.linktoUserMasterIdUpdatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdUpdatedBy"]);
                }

                /// Extra
                this.DepartmentFrom = Convert.ToString(sqlRdr["DepartmentFrom"]);
                this.DepartmentTo = Convert.ToString(sqlRdr["DepartmentTo"]);


                return true;
            }
            return false;
        }

        private List<posIssueItemMasterDAL> SetListPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            List<posIssueItemMasterDAL> lstIssueItemMaster = new List<posIssueItemMasterDAL>();
            posIssueItemMasterDAL objIssueItemMaster = null;
            while (sqlRdr.Read())
            {
                objIssueItemMaster = new posIssueItemMasterDAL();
                objIssueItemMaster.IssueItemMasterId = Convert.ToInt32(sqlRdr["IssueItemMasterId"]);
                objIssueItemMaster.IssueNumber = Convert.ToString(sqlRdr["IssueNumber"]);
                objIssueItemMaster.IssueDate = Convert.ToDateTime(sqlRdr["IssueDate"]);
                objIssueItemMaster.linktoDepartmentMasterIdFrom = Convert.ToInt16(sqlRdr["linktoDepartmentMasterIdFrom"]);
                objIssueItemMaster.linktoDepartmentMasterIdTo = Convert.ToInt16(sqlRdr["linktoDepartmentMasterIdTo"]);
                objIssueItemMaster.Remark = Convert.ToString(sqlRdr["Remark"]);
                objIssueItemMaster.CreateDateTime = Convert.ToDateTime(sqlRdr["CreateDateTime"]);
                objIssueItemMaster.linktoUserMasterIdCreatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdCreatedBy"]);
                if (sqlRdr["UpdateDateTime"] != DBNull.Value)
                {
                    objIssueItemMaster.UpdateDateTime = Convert.ToDateTime(sqlRdr["UpdateDateTime"]);
                }
                if (sqlRdr["linktoUserMasterIdUpdatedBy"] != DBNull.Value)
                {
                    objIssueItemMaster.linktoUserMasterIdUpdatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdUpdatedBy"]);
                }

                /// Extra
                objIssueItemMaster.DepartmentFrom = Convert.ToString(sqlRdr["DepartmentFrom"]);
                objIssueItemMaster.DepartmentTo = Convert.ToString(sqlRdr["DepartmentTo"]);
                lstIssueItemMaster.Add(objIssueItemMaster);
            }
            return lstIssueItemMaster;
        }
        #endregion

        #region Insert
        public posRecordStatus InsertIssueItemMaster(List<posIssueItemTranDAL> lstIssueItemTranDAL)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlTransaction sqlTran = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCon.Open();
                sqlTran = SqlCon.BeginTransaction();
                SqlCmd = new SqlCommand("posIssueItemMaster_Insert", SqlCon, sqlTran);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@IssueItemMasterId", SqlDbType.Int).Direction = ParameterDirection.Output;
                SqlCmd.Parameters.Add("@IssueNumber", SqlDbType.VarChar).Value = this.IssueNumber;
                SqlCmd.Parameters.Add("@IssueDate", SqlDbType.Date).Value = this.IssueDate;
                SqlCmd.Parameters.Add("@linktoDepartmentMasterIdFrom", SqlDbType.SmallInt).Value = this.linktoDepartmentMasterIdFrom;
                SqlCmd.Parameters.Add("@linktoDepartmentMasterIdTo", SqlDbType.SmallInt).Value = this.linktoDepartmentMasterIdTo;
                SqlCmd.Parameters.Add("@Remark", SqlDbType.VarChar).Value = this.Remark;
                SqlCmd.Parameters.Add("@CreateDateTime", SqlDbType.DateTime).Value = this.CreateDateTime;
                SqlCmd.Parameters.Add("@linktoUserMasterIdCreatedBy", SqlDbType.SmallInt).Value = this.linktoUserMasterIdCreatedBy;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCmd.ExecuteNonQuery();

                this.IssueItemMasterId = Convert.ToInt32(SqlCmd.Parameters["@IssueItemMasterId"].Value);
                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                if (rs != posRecordStatus.Success)
                {
                    sqlTran.Rollback();
                    SqlCon.Close();
                }
                else
                {
                    posRecordStatus rs1 = posRecordStatus.Error;
                    foreach (posIssueItemTranDAL objIssueItemTranDAL in lstIssueItemTranDAL)
                    {
                        objIssueItemTranDAL.linktoIssueItemMasterId = this.IssueItemMasterId;
                        rs1 = objIssueItemTranDAL.InsertIssueItemTran(sqlTran, SqlCon);
                    }
                    if (rs1 != posRecordStatus.Success)
                    {
                        sqlTran.Rollback();
                        SqlCon.Close();
                    }
                    else
                    {
                        sqlTran.Commit();
                        SqlCon.Close();
                    }
                }
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region Update
        public posRecordStatus UpdateIssueItemMaster(List<posIssueItemTranDAL> lstIssueItemTranDAL)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlTransaction sqlTran = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCon.Open();
                sqlTran = SqlCon.BeginTransaction();
                SqlCmd = new SqlCommand("posIssueItemMaster_Update", SqlCon, sqlTran);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@IssueItemMasterId", SqlDbType.Int).Value = this.IssueItemMasterId;
                SqlCmd.Parameters.Add("@IssueNumber", SqlDbType.VarChar).Value = this.IssueNumber;
                SqlCmd.Parameters.Add("@IssueDate", SqlDbType.Date).Value = this.IssueDate;
                SqlCmd.Parameters.Add("@linktoDepartmentMasterIdFrom", SqlDbType.SmallInt).Value = this.linktoDepartmentMasterIdFrom;
                SqlCmd.Parameters.Add("@linktoDepartmentMasterIdTo", SqlDbType.SmallInt).Value = this.linktoDepartmentMasterIdTo;
                SqlCmd.Parameters.Add("@Remark", SqlDbType.VarChar).Value = this.Remark;
                SqlCmd.Parameters.Add("@UpdateDateTime", SqlDbType.DateTime).Value = this.UpdateDateTime;
                SqlCmd.Parameters.Add("@linktoUserMasterIdUpdatedBy", SqlDbType.SmallInt).Value = this.linktoUserMasterIdUpdatedBy;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCmd.ExecuteNonQuery();
                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;

                if (rs != posRecordStatus.Success)
                {
                    sqlTran.Rollback();
                    SqlCon.Close();
                }
                else
                {
                    posIssueItemTranDAL objIssueItemTran = new posIssueItemTranDAL();
                    objIssueItemTran.linktoIssueItemMasterId = this.IssueItemMasterId;
                    posRecordStatus rsDelete = objIssueItemTran.DeleteIssueItemTran(sqlTran, SqlCon);
                    if (rsDelete == posRecordStatus.Success)
                    {

                        posRecordStatus rs1 = posRecordStatus.Error;
                        foreach (posIssueItemTranDAL objIssueItemTranDAL in lstIssueItemTranDAL)
                        {
                            objIssueItemTranDAL.linktoIssueItemMasterId = this.IssueItemMasterId;
                            rs1 = objIssueItemTranDAL.InsertIssueItemTran(sqlTran, SqlCon);
                        }
                        if (rs1 != posRecordStatus.Success)
                        {
                            sqlTran.Rollback();
                            SqlCon.Close();
                        }
                        else
                        {
                            sqlTran.Commit();
                            SqlCon.Close();
                        }
                    }
                    else
                    {
                        sqlTran.Rollback();
                        SqlCon.Close();
                    }

                }
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region DeleteAll
        public static posRecordStatus DeleteAllIssueItemMaster(string issueItemMasterIds)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posIssueItemMaster_DeleteAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@IssueItemMasterIds", SqlDbType.VarChar).Value = issueItemMasterIds;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region Select
        public bool SelectIssueItemMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posIssueItemMaster_Select", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@IssueItemMasterId", SqlDbType.Int).Value = this.IssueItemMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                bool IsSelected = SetClassPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                return IsSelected;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return false;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        public posRecordStatus SelectIssueItemMasterVerified(int IssueItemMasterId)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posIssueItemMasterVerifiedByIssueNumber_Select", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@IssueItemMasterId", SqlDbType.Int).Value = IssueItemMasterId;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                SqlRdr.Close();
                SqlCon.Close();
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region SelectAll
        public List<posIssueItemMasterDAL> SelectAllIssueItemMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posIssueItemMaster_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@IssueNumber", SqlDbType.VarChar).Value = this.IssueNumber;
                if (this.IssueDate != new DateTime())
                {
                    SqlCmd.Parameters.Add("@IssueDate", SqlDbType.Date).Value = this.IssueDate;
                }
                if (this.linktoDepartmentMasterIdFrom > 0)
                {
                    SqlCmd.Parameters.Add("@linktoDepartmentMasterIdFrom", SqlDbType.SmallInt).Value = this.linktoDepartmentMasterIdFrom;
                }

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<posIssueItemMasterDAL> lstIssueItemMasterDAL = SetListPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                return lstIssueItemMasterDAL;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public List<posIssueItemMasterDAL> SelectAllIssueItemMasterIssuItems(DateTime FromDate, DateTime ToDate, short linktoBusinessMasterId)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader sqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posIssueMasterByIssueDate_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;


                SqlCmd.Parameters.Add("@FromDate", SqlDbType.DateTime).Value = FromDate;
                SqlCmd.Parameters.Add("@ToDate", SqlDbType.DateTime).Value = ToDate;
                SqlCmd.Parameters.Add("@ItemMasterIds", SqlDbType.VarChar).Value = this.ItemMasterIds;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = linktoBusinessMasterId;

                SqlCon.Open();
                sqlRdr = SqlCmd.ExecuteReader();
                List<posIssueItemMasterDAL> lstIssueItemMaster = new List<posIssueItemMasterDAL>();
                posIssueItemMasterDAL objIssueItemMaster = null;
                while (sqlRdr.Read())
                {
                    objIssueItemMaster = new posIssueItemMasterDAL();
                    objIssueItemMaster.IssueDate = Convert.ToDateTime(sqlRdr["IssueDate"]);
                    objIssueItemMaster.ItemName = Convert.ToString(sqlRdr["ItemName"]);
                    objIssueItemMaster.Quantity = Convert.ToInt32(sqlRdr["Quantity"]);
                    objIssueItemMaster.Unit = Convert.ToString(sqlRdr["UnitName"]);
                    objIssueItemMaster.DepartmentFrom = Convert.ToString(sqlRdr["DepartmentFrom"]);
                    objIssueItemMaster.DepartmentTo = Convert.ToString(sqlRdr["DepartmentTo"]);          
                    lstIssueItemMaster.Add(objIssueItemMaster);
                }

                sqlRdr.Close();
                SqlCon.Close();

                return lstIssueItemMaster;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(sqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion
    }
}
