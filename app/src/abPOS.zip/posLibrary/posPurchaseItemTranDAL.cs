using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace posLibrary
{
    /// <summary>
    /// Class for posPurchaseItemTran
    /// </summary>
    public class posPurchaseItemTranDAL
    {
        #region Properties
        public int PurchaseItemTranId { get; set; }
        public int linktoPurchaseMasterId { get; set; }
        public int linktoItemMasterId { get; set; }
        public double Quantity { get; set; }
        public short linktoUnitMasterId { get; set; }
        public double Rate { get; set; }
        public double Tax { get; set; }


        /// Extra
        public string Purchase { get; set; }
        public string Item { get; set; }
        public string Unit { get; set; }
        public double Discount { get; set; }
        public double TotalAmount { get; set; }
        #endregion

        #region Class Methods

        private List<posPurchaseItemTranDAL> SetListPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            List<posPurchaseItemTranDAL> lstPurchaseItemTran = new List<posPurchaseItemTranDAL>();
            posPurchaseItemTranDAL objPurchaseItemTran = null;
            while (sqlRdr.Read())
            {
                objPurchaseItemTran = new posPurchaseItemTranDAL();
                objPurchaseItemTran.PurchaseItemTranId = Convert.ToInt32(sqlRdr["PurchaseItemTranId"]);
                objPurchaseItemTran.linktoPurchaseMasterId = Convert.ToInt32(sqlRdr["linktoPurchaseMasterId"]);
                objPurchaseItemTran.linktoItemMasterId = Convert.ToInt32(sqlRdr["linktoItemMasterId"]);
                objPurchaseItemTran.Quantity = Convert.ToDouble(sqlRdr["Quantity"]);
                objPurchaseItemTran.linktoUnitMasterId = Convert.ToInt16(sqlRdr["linktoUnitMasterId"]);
                objPurchaseItemTran.Rate = Convert.ToDouble(sqlRdr["Rate"]);
                objPurchaseItemTran.Tax = Convert.ToDouble(sqlRdr["Tax"]);

                /// Extra
                objPurchaseItemTran.Purchase = Convert.ToString(sqlRdr["Purchase"]);
                objPurchaseItemTran.Item = Convert.ToString(sqlRdr["Item"]) + " (" + Convert.ToString(sqlRdr["ItemCode"]) + ")";
                objPurchaseItemTran.Unit = Convert.ToString(sqlRdr["Unit"]);
                objPurchaseItemTran.Discount = Convert.ToDouble(sqlRdr["Discount"]);
                objPurchaseItemTran.TotalAmount = Convert.ToDouble(sqlRdr["Quantity"]) * Convert.ToDouble(sqlRdr["Rate"]);


                lstPurchaseItemTran.Add(objPurchaseItemTran);
            }
            return lstPurchaseItemTran;
        }
        #endregion

        #region Insert
        public posRecordStatus InsertPurchaseItemTran(SqlTransaction sqlTran, SqlConnection sqlCon)
        {
            SqlCommand SqlCmd = null;
            try
            {
                SqlCmd = new SqlCommand("posPurchaseItemTran_Insert", sqlCon, sqlTran);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@PurchaseItemTranId", SqlDbType.Int).Direction = ParameterDirection.Output;
                SqlCmd.Parameters.Add("@linktoPurchaseMasterId", SqlDbType.Int).Value = this.linktoPurchaseMasterId;
                SqlCmd.Parameters.Add("@linktoItemMasterId", SqlDbType.Int).Value = this.linktoItemMasterId;
                SqlCmd.Parameters.Add("@Quantity", SqlDbType.Decimal).Value = this.Quantity;
                SqlCmd.Parameters.Add("@Discount", SqlDbType.Decimal).Value = this.Discount;
                SqlCmd.Parameters.Add("@linktoUnitMasterId", SqlDbType.SmallInt).Value = this.linktoUnitMasterId;
                SqlCmd.Parameters.Add("@Rate", SqlDbType.Money).Value = this.Rate;
                SqlCmd.Parameters.Add("@Tax", SqlDbType.Money).Value = this.Tax;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCmd.ExecuteNonQuery();

                this.PurchaseItemTranId = Convert.ToInt32(SqlCmd.Parameters["@PurchaseItemTranId"].Value);
                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
            }
        }
        #endregion

        #region Delete
        public posRecordStatus DeletePurchaseItemTran(SqlTransaction sqlTran, SqlConnection SqlCon)
        {
            SqlCommand SqlCmd = null;
            try
            {
                SqlCmd = new SqlCommand("posPurchaseItemTran_Delete", SqlCon, sqlTran);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@linktoPurchaseMasterId", SqlDbType.Int).Value = this.linktoPurchaseMasterId;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCmd.ExecuteNonQuery();

                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
            }
        }
        #endregion

        #region SelectAll
        public List<posPurchaseItemTranDAL> SelectAllPurchaseItemTran()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posPurchaseItemTran_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@linktoPurchaseMasterId", SqlDbType.Int).Value = this.linktoPurchaseMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<posPurchaseItemTranDAL> lstPurchaseItemTranDAL = SetListPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                return lstPurchaseItemTranDAL;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion
    }
}
