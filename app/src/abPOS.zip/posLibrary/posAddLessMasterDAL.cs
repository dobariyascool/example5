using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace posLibrary
{
    /// <summary>
    /// Class for posAddLessMaster
    /// </summary>
    public class posAddLessMasterDAL
    {
        #region Properties
        public short AddLessMasterId { get; set; }
        public string Name { get; set; }
        public short CalculatedOn { get; set; }
        public double Amount { get; set; }
        public bool IsPercentage { get; set; }
        public bool IsRounding { get; set; }
        public bool? IsSale { get; set; }
        public short linktoBusinessMasterId { get; set; }
        public bool IsEnabled { get; set; }
        public bool? IsForAllItems { get; set; }

        // Extra
        public string CalculatedOnText { get; set; }
        public string AmountWithType { get; set; }
        public string itemMasterIds { get; set; }
        public List<posAddLessItemTranDAL> lstAddLessItemTranDAL { get; set; }
        #endregion

        #region Class Methods
        private bool SetClassPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            if (sqlRdr.Read())
            {
                this.AddLessMasterId = Convert.ToInt16(sqlRdr["AddLessMasterId"]);
                this.Name = Convert.ToString(sqlRdr["Name"]);
                this.CalculatedOn = Convert.ToInt16(sqlRdr["CalculatedOn"]);
                this.Amount = Convert.ToDouble(sqlRdr["Amount"]);
                this.IsPercentage = Convert.ToBoolean(sqlRdr["IsPercentage"]);
                this.IsRounding = Convert.ToBoolean(sqlRdr["IsRounding"]);
                if (sqlRdr["IsSale"] != DBNull.Value)
                {
                    this.IsSale = Convert.ToBoolean(sqlRdr["IsSale"]);
                }
                this.linktoBusinessMasterId = Convert.ToInt16(sqlRdr["linktoBusinessMasterId"]);
                this.IsEnabled = Convert.ToBoolean(sqlRdr["IsEnabled"]);
                if (sqlRdr["IsForAllItems"] != DBNull.Value)
                {
                    this.IsForAllItems = Convert.ToBoolean(sqlRdr["IsForAllItems"]);
                }
                return true;
            }
            return false;
        }

        private List<posAddLessMasterDAL> SetListPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            List<posAddLessMasterDAL> lstAddLessMaster = new List<posAddLessMasterDAL>();
            posAddLessMasterDAL objAddLessMaster = null;
            while (sqlRdr.Read())
            {
                objAddLessMaster = new posAddLessMasterDAL();
                objAddLessMaster.AddLessMasterId = Convert.ToInt16(sqlRdr["AddLessMasterId"]);
                objAddLessMaster.Name = Convert.ToString(sqlRdr["Name"]);
                objAddLessMaster.CalculatedOn = Convert.ToInt16(sqlRdr["CalculatedOn"]);
                objAddLessMaster.Amount = Convert.ToDouble(sqlRdr["Amount"]);
                objAddLessMaster.IsPercentage = Convert.ToBoolean(sqlRdr["IsPercentage"]);
                objAddLessMaster.IsRounding = Convert.ToBoolean(sqlRdr["IsRounding"]);
                if (sqlRdr["IsSale"] != DBNull.Value)
                {
                    objAddLessMaster.IsSale = Convert.ToBoolean(sqlRdr["IsSale"]);
                }
                objAddLessMaster.linktoBusinessMasterId = Convert.ToInt16(sqlRdr["linktoBusinessMasterId"]);
                objAddLessMaster.IsEnabled = Convert.ToBoolean(sqlRdr["IsEnabled"]);
                if (sqlRdr["IsForAllItems"] != DBNull.Value)
                {
                    objAddLessMaster.IsForAllItems = Convert.ToBoolean(sqlRdr["IsForAllItems"]);
                }
                // Extra
                objAddLessMaster.CalculatedOnText = Convert.ToString(sqlRdr["CalculatedOnText"]);
                if (objAddLessMaster.IsPercentage)
                {
                    objAddLessMaster.AmountWithType = objAddLessMaster.Amount + " %";
                }
                else
                {
                    objAddLessMaster.AmountWithType = objAddLessMaster.Amount + " Rs.";
                }

                lstAddLessMaster.Add(objAddLessMaster);
            }
            return lstAddLessMaster;
        }
        #endregion

        #region Insert
        public posRecordStatus InsertAddLessMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlTransaction sqlTran = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCon.Open();
                sqlTran = SqlCon.BeginTransaction();
                SqlCmd = new SqlCommand("posAddLessMaster_Insert", SqlCon, sqlTran);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@AddLessMasterId", SqlDbType.SmallInt).Direction = ParameterDirection.Output;
                SqlCmd.Parameters.Add("@Name", SqlDbType.VarChar).Value = this.Name;
                SqlCmd.Parameters.Add("@CalculatedOn", SqlDbType.SmallInt).Value = this.CalculatedOn;
                SqlCmd.Parameters.Add("@Amount", SqlDbType.Money).Value = this.Amount;
                SqlCmd.Parameters.Add("@IsPercentage", SqlDbType.Bit).Value = this.IsPercentage;
                SqlCmd.Parameters.Add("@IsRounding", SqlDbType.Bit).Value = this.IsRounding;
                SqlCmd.Parameters.Add("@IsSale", SqlDbType.Bit).Value = this.IsSale;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCmd.Parameters.Add("@IsForAllItems", SqlDbType.Bit).Value = this.IsForAllItems;
                SqlCmd.Parameters.Add("@IsEnabled", SqlDbType.Bit).Value = this.IsEnabled;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                //  SqlCon.Open();
                SqlCmd.ExecuteNonQuery();

                this.AddLessMasterId = Convert.ToInt16(SqlCmd.Parameters["@AddLessMasterId"].Value);
                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;

                if (rs != posRecordStatus.Success)
                {
                    sqlTran.Rollback();
                    SqlCon.Close();
                    return rs;
                }
                else
                {
                    if (Convert.ToBoolean(!IsForAllItems))
                    {
                        posAddLessItemTranDAL objAddLessItemTranDAL = new posAddLessItemTranDAL();
                        objAddLessItemTranDAL.linktoAddLessMasterId = this.AddLessMasterId;
                        rs = objAddLessItemTranDAL.InsertAllAddLessItemTran(this.itemMasterIds, SqlCon, sqlTran);
                        if (rs != posRecordStatus.Success)
                        {
                            sqlTran.Rollback();
                            SqlCon.Close();
                            return rs;
                        }
                    }
                }
                sqlTran.Commit();
                SqlCon.Close();
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
                posObjectFactoryDAL.DisposeTransaction(sqlTran);
            }
        }
        #endregion

        #region Update
        public posRecordStatus UpdateAddLessMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlTransaction sqlTran = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCon.Open();
                sqlTran = SqlCon.BeginTransaction();
                SqlCmd = new SqlCommand("posAddLessMaster_Update", SqlCon, sqlTran);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@AddLessMasterId", SqlDbType.SmallInt).Value = this.AddLessMasterId;
                SqlCmd.Parameters.Add("@Name", SqlDbType.VarChar).Value = this.Name;
                SqlCmd.Parameters.Add("@CalculatedOn", SqlDbType.SmallInt).Value = this.CalculatedOn;
                SqlCmd.Parameters.Add("@Amount", SqlDbType.Money).Value = this.Amount;
                SqlCmd.Parameters.Add("@IsPercentage", SqlDbType.Bit).Value = this.IsPercentage;
                SqlCmd.Parameters.Add("@IsRounding", SqlDbType.Bit).Value = this.IsRounding;
                SqlCmd.Parameters.Add("@IsSale", SqlDbType.Bit).Value = this.IsSale;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCmd.Parameters.Add("@IsForAllItems", SqlDbType.Bit).Value = this.IsForAllItems;
                SqlCmd.Parameters.Add("@IsEnabled", SqlDbType.Bit).Value = this.IsEnabled;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCmd.ExecuteNonQuery();

                this.AddLessMasterId = Convert.ToInt16(SqlCmd.Parameters["@AddLessMasterId"].Value);
                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;

                if (rs != posRecordStatus.Success)
                {
                    sqlTran.Rollback();
                    SqlCon.Close();
                    return rs;
                }
                else
                {
                    if (Convert.ToBoolean(IsForAllItems))
                    {
                        posAddLessItemTranDAL objAddLessItemTranDAL = new posAddLessItemTranDAL();
                        objAddLessItemTranDAL.linktoAddLessMasterId = this.AddLessMasterId;
                        rs = objAddLessItemTranDAL.DeleteAddLessItemTran(SqlCon, sqlTran);
                        if (rs != posRecordStatus.Success)
                        {
                            sqlTran.Rollback();
                            SqlCon.Close();
                            return rs;
                        }
                    }
                    else
                    {
                        posAddLessItemTranDAL objAddLessItemTranDAL = new posAddLessItemTranDAL();
                        objAddLessItemTranDAL.linktoAddLessMasterId = this.AddLessMasterId;
                        rs = objAddLessItemTranDAL.InsertAllAddLessItemTran(this.itemMasterIds, SqlCon, sqlTran);
                        if (rs != posRecordStatus.Success)
                        {
                            sqlTran.Rollback();
                            SqlCon.Close();
                            return rs;
                        }
                    }
                }
                sqlTran.Commit();
                SqlCon.Close();
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
                posObjectFactoryDAL.DisposeTransaction(sqlTran);
            }
        }
        #endregion

        #region DeleteAll
        public static posRecordStatus DeleteAllAddLessMaster(string addLessMasterIds)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posAddLessMaster_DeleteAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@AddLessMasterIds", SqlDbType.VarChar).Value = addLessMasterIds;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region Select
        public bool SelectAddLessMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posAddLessMaster_Select", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@AddLessMasterId", SqlDbType.SmallInt).Value = this.AddLessMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                bool IsSelected = SetClassPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                return IsSelected;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return false;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region SelectAll
        public List<posAddLessMasterDAL> SelectAllAddLessMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posAddLessMaster_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@IsSale", SqlDbType.Bit).Value = this.IsSale;
                SqlCmd.Parameters.Add("@IsEnabled", SqlDbType.Bit).Value = this.IsEnabled;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<posAddLessMasterDAL> lstAddLessMasterDAL = SetListPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                return lstAddLessMasterDAL;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion
    }
}
