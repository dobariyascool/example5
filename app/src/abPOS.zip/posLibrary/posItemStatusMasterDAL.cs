using System;
using System.Data;
using System.Data.SqlClient;
using System.Collections.Generic;

namespace posLibrary
{
    /// <summary>
    /// Class for posItemStatusMaster
    /// </summary>
    public class posItemStatusMasterDAL
    {
        #region Properties
        public short ItemStatusMasterId { get; set; }
        public string StatusName { get; set; }
        public string StatusColor { get; set; }
        public bool IsEnabled { get; set; }
        #endregion

        #region Class Methods
        private List<posItemStatusMasterDAL> SetListPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            List<posItemStatusMasterDAL> lstItemStatusMaster = new List<posItemStatusMasterDAL>();
            posItemStatusMasterDAL objItemStatusMaster = null;
            while (sqlRdr.Read())
            {
                objItemStatusMaster = new posItemStatusMasterDAL();
                objItemStatusMaster.ItemStatusMasterId = Convert.ToInt16(sqlRdr["ItemStatusMasterId"]);
                objItemStatusMaster.StatusName = Convert.ToString(sqlRdr["StatusName"]);
                objItemStatusMaster.StatusColor = Convert.ToString(sqlRdr["StatusColor"]);
                objItemStatusMaster.IsEnabled = Convert.ToBoolean(sqlRdr["IsEnabled"]);
                lstItemStatusMaster.Add(objItemStatusMaster);
            }
            return lstItemStatusMaster;
        }
        #endregion

        #region SelectAll    

        public static List<posItemStatusMasterDAL> SelectAllItemStatusMasterStatusName()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posItemStatusMasterStatusName_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<posItemStatusMasterDAL> lstItemStatusMasterDAL = new List<posItemStatusMasterDAL>();
                posItemStatusMasterDAL objItemStatusMasterDAL = null;
                while (SqlRdr.Read())
                {
                    objItemStatusMasterDAL = new posItemStatusMasterDAL();
                    objItemStatusMasterDAL.ItemStatusMasterId = Convert.ToInt16(SqlRdr["ItemStatusMasterId"]);
                    objItemStatusMasterDAL.StatusName = Convert.ToString(SqlRdr["StatusName"]);
                    lstItemStatusMasterDAL.Add(objItemStatusMasterDAL);
                }
                SqlRdr.Close();
                SqlCon.Close();

                return lstItemStatusMasterDAL;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion
    }
}
