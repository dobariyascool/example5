using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace posLibrary
{
	/// <summary>
	/// Class for posBusinessInfoQuestionMaster
	/// </summary>
	public class posBusinessInfoQuestionMasterDAL
	{
		#region Properties
		public int BusinessInfoQuestionMasterId { get; set; }
		public short linktoBusinessTypeMasterId { get; set; }
		public string Question { get; set; }
		public short QuestionType { get; set; }
		public int? SortOrder { get; set; }
		public bool IsEnabled { get; set; }

		/// Extra
		public string BusinessType { get; set; }
        public string Answer { get; set; }
		#endregion

		#region Class Methods
		private List<posBusinessInfoQuestionMasterDAL> SetListPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
		{
			List<posBusinessInfoQuestionMasterDAL> lstBusinessInfoQuestionMaster = new List<posBusinessInfoQuestionMasterDAL>();
			posBusinessInfoQuestionMasterDAL objBusinessInfoQuestionMaster = null;
			while (sqlRdr.Read())
			{
				objBusinessInfoQuestionMaster = new posBusinessInfoQuestionMasterDAL();
				objBusinessInfoQuestionMaster.BusinessInfoQuestionMasterId = Convert.ToInt32(sqlRdr["BusinessInfoQuestionMasterId"]);
				objBusinessInfoQuestionMaster.linktoBusinessTypeMasterId = Convert.ToInt16(sqlRdr["linktoBusinessTypeMasterId"]);
				objBusinessInfoQuestionMaster.Question = Convert.ToString(sqlRdr["Question"]);
				objBusinessInfoQuestionMaster.QuestionType = Convert.ToInt16(sqlRdr["QuestionType"]);
				if (sqlRdr["SortOrder"] != DBNull.Value)
				{
					objBusinessInfoQuestionMaster.SortOrder = Convert.ToInt32(sqlRdr["SortOrder"]);
				}
				objBusinessInfoQuestionMaster.IsEnabled = Convert.ToBoolean(sqlRdr["IsEnabled"]);

				/// Extra
				objBusinessInfoQuestionMaster.BusinessType = Convert.ToString(sqlRdr["BusinessType"]);
                if (sqlRdr["Answer"] != DBNull.Value)
                {
                    objBusinessInfoQuestionMaster.Answer = Convert.ToString(sqlRdr["Answer"]);
                }
				lstBusinessInfoQuestionMaster.Add(objBusinessInfoQuestionMaster);
			}
			return lstBusinessInfoQuestionMaster;
		}
		#endregion

		#region SelectAll
        public List<posBusinessInfoQuestionMasterDAL> SelectAllBusinessInfoQuestionMaster(short linktoBusinessMasterId)
		{
			SqlConnection SqlCon = null;
			SqlCommand SqlCmd = null;
			SqlDataReader SqlRdr = null;
			try
			{
				SqlCon = posObjectFactoryDAL.CreateConnection();
				SqlCmd = new SqlCommand("posBusinessInfoQuestionMaster_SelectAll", SqlCon);
				SqlCmd.CommandType = CommandType.StoredProcedure;

				SqlCmd.Parameters.Add("@IsEnabled", SqlDbType.Bit).Value = this.IsEnabled;
               SqlCmd.Parameters.Add("@linktoBusinessTypeMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessTypeMasterId;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = linktoBusinessMasterId;

				SqlCon.Open();
				SqlRdr = SqlCmd.ExecuteReader();
				List<posBusinessInfoQuestionMasterDAL> lstBusinessInfoQuestionMasterDAL = SetListPropertiesFromSqlDataReader(SqlRdr);
				SqlRdr.Close();
				SqlCon.Close();

				return lstBusinessInfoQuestionMasterDAL;
			}
			catch (Exception ex)
			{
				posGlobalsDAL.SaveError(ex);
				return null;
			}
			finally
			{
				posObjectFactoryDAL.DisposeDataReader(SqlRdr);
				posObjectFactoryDAL.DisposeCommand(SqlCmd);
				posObjectFactoryDAL.DisposeConnection(SqlCon);
			}
		}
		#endregion
	}
}
