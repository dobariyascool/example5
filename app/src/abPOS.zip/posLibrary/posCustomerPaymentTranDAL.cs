using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace posLibrary
{
    /// <summary>
    /// Class for posCustomerPaymentTran
    /// </summary>
    public class posCustomerPaymentTranDAL
    {
        #region Properties
        public int CustomerPaymentTranId { get; set; }
        public int linktoCustomerMasterId { get; set; }
        public int? linktoCustomerInvoiceMasterId { get; set; }
        public short linktoPaymentTypeMasterId { get; set; }
        public DateTime PaymentDate { get; set; }
        public string ReceiptNo { get; set; }
        public double TotalAmount { get; set; }
        public string Remark { get; set; }
        public bool IsDeleted { get; set; }
        public DateTime CreateDateTime { get; set; }
        public short linktoUserMasterIdCreatedBy { get; set; }
        public DateTime? UpdateDateTime { get; set; }
        public short? linktoUserMasterIdUpdatedBy { get; set; }

        /// Extra
        public string Customer { get; set; }
        public string CustomerInvoice { get; set; }
        public string PaymentType { get; set; }
        #endregion

        #region Class Methods
        private bool SetClassPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            if (sqlRdr.Read())
            {
                this.CustomerPaymentTranId = Convert.ToInt32(sqlRdr["CustomerPaymentTranId"]);
                this.linktoCustomerMasterId = Convert.ToInt32(sqlRdr["linktoCustomerMasterId"]);
                if (sqlRdr["linktoCustomerInvoiceMasterId"] != DBNull.Value)
                {
                    this.linktoCustomerInvoiceMasterId = Convert.ToInt32(sqlRdr["linktoCustomerInvoiceMasterId"]);
                }
                this.linktoPaymentTypeMasterId = Convert.ToInt16(sqlRdr["linktoPaymentTypeMasterId"]);
                this.PaymentDate = Convert.ToDateTime(sqlRdr["PaymentDate"]);
                this.ReceiptNo = Convert.ToString(sqlRdr["ReceiptNo"]);
                this.TotalAmount = Convert.ToDouble(sqlRdr["TotalAmount"]);
                this.Remark = Convert.ToString(sqlRdr["Remark"]);
                this.IsDeleted = Convert.ToBoolean(sqlRdr["IsDeleted"]);
                this.CreateDateTime = Convert.ToDateTime(sqlRdr["CreateDateTime"]);
                this.linktoUserMasterIdCreatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdCreatedBy"]);
                if (sqlRdr["UpdateDateTime"] != DBNull.Value)
                {
                    this.UpdateDateTime = Convert.ToDateTime(sqlRdr["UpdateDateTime"]);
                }
                if (sqlRdr["linktoUserMasterIdUpdatedBy"] != DBNull.Value)
                {
                    this.linktoUserMasterIdUpdatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdUpdatedBy"]);
                }

                /// Extra
                this.Customer = Convert.ToString(sqlRdr["Customer"]);
                this.CustomerInvoice = Convert.ToString(sqlRdr["CustomerInvoice"]);
                this.PaymentType = Convert.ToString(sqlRdr["PaymentType"]);
                return true;
            }
            return false;
        }

        private List<posCustomerPaymentTranDAL> SetListPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            List<posCustomerPaymentTranDAL> lstCustomerPaymentTran = new List<posCustomerPaymentTranDAL>();
            posCustomerPaymentTranDAL objCustomerPaymentTran = null;
            while (sqlRdr.Read())
            {
                objCustomerPaymentTran = new posCustomerPaymentTranDAL();
                objCustomerPaymentTran.CustomerPaymentTranId = Convert.ToInt32(sqlRdr["CustomerPaymentTranId"]);
                objCustomerPaymentTran.linktoCustomerMasterId = Convert.ToInt32(sqlRdr["linktoCustomerMasterId"]);
                if (sqlRdr["linktoCustomerInvoiceMasterId"] != DBNull.Value)
                {
                    objCustomerPaymentTran.linktoCustomerInvoiceMasterId = Convert.ToInt32(sqlRdr["linktoCustomerInvoiceMasterId"]);
                }
                objCustomerPaymentTran.linktoPaymentTypeMasterId = Convert.ToInt16(sqlRdr["linktoPaymentTypeMasterId"]);
                objCustomerPaymentTran.PaymentDate = Convert.ToDateTime(sqlRdr["PaymentDate"]);
                objCustomerPaymentTran.ReceiptNo = Convert.ToString(sqlRdr["ReceiptNo"]);
                objCustomerPaymentTran.TotalAmount = Convert.ToDouble(sqlRdr["TotalAmount"]);
                objCustomerPaymentTran.Remark = Convert.ToString(sqlRdr["Remark"]);
                objCustomerPaymentTran.IsDeleted = Convert.ToBoolean(sqlRdr["IsDeleted"]);
                objCustomerPaymentTran.CreateDateTime = Convert.ToDateTime(sqlRdr["CreateDateTime"]);
                objCustomerPaymentTran.linktoUserMasterIdCreatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdCreatedBy"]);
                if (sqlRdr["UpdateDateTime"] != DBNull.Value)
                {
                    objCustomerPaymentTran.UpdateDateTime = Convert.ToDateTime(sqlRdr["UpdateDateTime"]);
                }
                if (sqlRdr["linktoUserMasterIdUpdatedBy"] != DBNull.Value)
                {
                    objCustomerPaymentTran.linktoUserMasterIdUpdatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdUpdatedBy"]);
                }

                /// Extra
                objCustomerPaymentTran.Customer = Convert.ToString(sqlRdr["Customer"]);
                objCustomerPaymentTran.CustomerInvoice = Convert.ToString(sqlRdr["CustomerInvoice"]);
                objCustomerPaymentTran.PaymentType = Convert.ToString(sqlRdr["PaymentType"]);
                lstCustomerPaymentTran.Add(objCustomerPaymentTran);
            }
            return lstCustomerPaymentTran;
        }
        #endregion

        #region Insert
        public posRecordStatus InsertCustomerPaymentTran()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posCustomerPaymentTran_Insert", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@CustomerPaymentTranId", SqlDbType.Int).Direction = ParameterDirection.Output;
                SqlCmd.Parameters.Add("@linktoCustomerMasterId", SqlDbType.Int).Value = this.linktoCustomerMasterId;
                SqlCmd.Parameters.Add("@linktoCustomerInvoiceMasterId", SqlDbType.Int).Value = this.linktoCustomerInvoiceMasterId;
                SqlCmd.Parameters.Add("@linktoPaymentTypeMasterId", SqlDbType.SmallInt).Value = this.linktoPaymentTypeMasterId;
                SqlCmd.Parameters.Add("@PaymentDate", SqlDbType.DateTime).Value = this.PaymentDate;
                SqlCmd.Parameters.Add("@ReceiptNo", SqlDbType.VarChar).Value = this.ReceiptNo;
                SqlCmd.Parameters.Add("@TotalAmount", SqlDbType.Money).Value = this.TotalAmount;
                SqlCmd.Parameters.Add("@Remark", SqlDbType.VarChar).Value = this.Remark;
                SqlCmd.Parameters.Add("@IsDeleted", SqlDbType.Bit).Value = this.IsDeleted;
                SqlCmd.Parameters.Add("@CreateDateTime", SqlDbType.DateTime).Value = this.CreateDateTime;
                SqlCmd.Parameters.Add("@linktoUserMasterIdCreatedBy", SqlDbType.SmallInt).Value = this.linktoUserMasterIdCreatedBy;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                this.CustomerPaymentTranId = Convert.ToInt32(SqlCmd.Parameters["@CustomerPaymentTranId"].Value);
                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region Update
        public posRecordStatus UpdateCustomerPaymentTran()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posCustomerPaymentTran_Update", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@CustomerPaymentTranId", SqlDbType.Int).Value = this.CustomerPaymentTranId;
                SqlCmd.Parameters.Add("@linktoCustomerMasterId", SqlDbType.Int).Value = this.linktoCustomerMasterId;
                SqlCmd.Parameters.Add("@linktoCustomerInvoiceMasterId", SqlDbType.Int).Value = this.linktoCustomerInvoiceMasterId;
                SqlCmd.Parameters.Add("@linktoPaymentTypeMasterId", SqlDbType.SmallInt).Value = this.linktoPaymentTypeMasterId;
                SqlCmd.Parameters.Add("@PaymentDate", SqlDbType.DateTime).Value = this.PaymentDate;
                SqlCmd.Parameters.Add("@ReceiptNo", SqlDbType.VarChar).Value = this.ReceiptNo;
                SqlCmd.Parameters.Add("@TotalAmount", SqlDbType.Money).Value = this.TotalAmount;
                SqlCmd.Parameters.Add("@Remark", SqlDbType.VarChar).Value = this.Remark;
                SqlCmd.Parameters.Add("@IsDeleted", SqlDbType.Bit).Value = this.IsDeleted;
                SqlCmd.Parameters.Add("@UpdateDateTime", SqlDbType.DateTime).Value = this.UpdateDateTime;
                SqlCmd.Parameters.Add("@linktoUserMasterIdUpdatedBy", SqlDbType.SmallInt).Value = this.linktoUserMasterIdUpdatedBy;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region DeleteAll
        public posRecordStatus DeleteAllCustomerPaymentTran(string customerPaymentTranIds)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posCustomerPaymentTran_DeleteAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@CustomerPaymentTranIds", SqlDbType.VarChar).Value = customerPaymentTranIds;
                SqlCmd.Parameters.Add("@UpdateDateTime", SqlDbType.DateTime).Value = this.UpdateDateTime;
                SqlCmd.Parameters.Add("@linktoUserMasterIdUpdatedBy", SqlDbType.SmallInt).Value = this.linktoUserMasterIdUpdatedBy;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region Select
        public bool SelectCustomerPaymentTran()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posCustomerPaymentTran_Select", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@CustomerPaymentTranId", SqlDbType.Int).Value = this.CustomerPaymentTranId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                bool IsSelected = SetClassPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                return IsSelected;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return false;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region SelectAll
        public List<posCustomerPaymentTranDAL> SelectAllCustomerPaymentTran(DateTime FromDate, DateTime ToDate)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posCustomerPaymentTran_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@FromDate", SqlDbType.DateTime).Value = FromDate;
                SqlCmd.Parameters.Add("@ToDate", SqlDbType.DateTime).Value = ToDate;
                SqlCmd.Parameters.Add("@linktoCustomerMasterId", SqlDbType.Int).Value = this.linktoCustomerMasterId;
                SqlCmd.Parameters.Add("@linktoCustomerInvoiceMasterId", SqlDbType.Int).Value = this.linktoCustomerInvoiceMasterId;
                SqlCmd.Parameters.Add("@ReceiptNo", SqlDbType.VarChar).Value = this.ReceiptNo;



                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<posCustomerPaymentTranDAL> lstCustomerPaymentTranDAL = SetListPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                return lstCustomerPaymentTranDAL;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion
    }
}
