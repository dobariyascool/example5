using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace posLibrary
{
    /// <summary>
    /// Class for posUserCounterTran
    /// </summary>
    public class posUserCounterTranDAL
    {
        #region Properties
        public int UserCounterTranId { get; set; }
        public short linktoUserMasterId { get; set; }
        public short linktoCounterMasterId { get; set; }

        /// Extra
        public string User { get; set; }
        public string CounterName { get; set; }
        public bool IsSelected { get; set; }
        #endregion

        #region Class Methods
        private List<posUserCounterTranDAL> SetListPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            List<posUserCounterTranDAL> lstUserCounterTran = new List<posUserCounterTranDAL>();
            posUserCounterTranDAL objUserCounterTran = null;
            while (sqlRdr.Read())
            {
                objUserCounterTran = new posUserCounterTranDAL();
                if (sqlRdr["UserCounterTranId"] != DBNull.Value)
                {
                    objUserCounterTran.UserCounterTranId = Convert.ToInt32(sqlRdr["UserCounterTranId"]);
                    objUserCounterTran.IsSelected = true;
                }
                else
                {
                    objUserCounterTran.IsSelected = false;
                }
                if (sqlRdr["linktoUserMasterId"] != DBNull.Value)
                {
                    objUserCounterTran.linktoUserMasterId = Convert.ToInt16(sqlRdr["linktoUserMasterId"]);
                }
                objUserCounterTran.linktoCounterMasterId = Convert.ToInt16(sqlRdr["CounterMasterId"]);

                /// Extra
                objUserCounterTran.CounterName = Convert.ToString(sqlRdr["CounterName"]);
                lstUserCounterTran.Add(objUserCounterTran);
            }
            return lstUserCounterTran;
        }
        #endregion

        #region Insert
        public static posRecordStatus InsertUserCounterTran(short linktoUserMasterId, string linktoCounterMasterIds, SqlConnection SqlCon, SqlTransaction SqlTran)
        {
            SqlCommand SqlCmd = null;
            posRecordStatus rs = posRecordStatus.Error;
            try
            {
                SqlCmd = new SqlCommand("posUserCounterTran_Insert", SqlCon, SqlTran);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                string[] CounterMasterIds = linktoCounterMasterIds.Split(',');

                for (int i = 0; i < CounterMasterIds.Length; i++)
                {
                    SqlCmd.Parameters.Clear();
                    SqlCmd.Parameters.Add("@UserCounterTranId", SqlDbType.Int).Direction = ParameterDirection.Output;
                    SqlCmd.Parameters.Add("@linktoUserMasterId", SqlDbType.SmallInt).Value = linktoUserMasterId;
                    SqlCmd.Parameters.Add("@linktoCounterMasterId", SqlDbType.SmallInt).Value = CounterMasterIds[i];
                    SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                    SqlCmd.ExecuteNonQuery();

                    rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;

                    if (rs == posRecordStatus.Error)
                    {
                        return rs;
                    }
                }
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
            }
        }
        #endregion

        #region Delete
        public static posRecordStatus DeleteUserCounterTran(short linktoUserMasterId, SqlConnection SqlCon, SqlTransaction SqlTran)
        {
            SqlCommand SqlCmd = null;
            try
            {
                SqlCmd = new SqlCommand("posUserCounterTran_Delete", SqlCon, SqlTran);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@linktoUserMasterId", SqlDbType.SmallInt).Value = linktoUserMasterId;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCmd.ExecuteNonQuery();

                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
            }
        }
        #endregion

        #region SelectAll

        public List<posUserCounterTranDAL> SelectAllUserCounterTran(short linktoBusinessMasterId)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posUserCounterTran_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;
                SqlCmd.Parameters.Add("@linktoUserMasterId", SqlDbType.SmallInt).Value = this.linktoUserMasterId;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = linktoBusinessMasterId;
                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<posUserCounterTranDAL> lstUserCounterTranDAL = SetListPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                return lstUserCounterTranDAL;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public List<posUserCounterTranDAL> SelectAllUserCounterTranUserWise()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posUserCounterTranUserWise_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;
                SqlCmd.Parameters.Add("@linktoUserMasterId", SqlDbType.SmallInt).Value = this.linktoUserMasterId;
                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<posUserCounterTranDAL> lstUserCounterTranDAL = new List<posUserCounterTranDAL>();
                posUserCounterTranDAL objUserCounterTranDAL = null;
                while (SqlRdr.Read())
                {
                    objUserCounterTranDAL = new posUserCounterTranDAL();

                    objUserCounterTranDAL.linktoCounterMasterId = Convert.ToInt16(SqlRdr["linktoCounterMasterId"]);
                    objUserCounterTranDAL.CounterName = Convert.ToString(SqlRdr["CounterName"]);

                    lstUserCounterTranDAL.Add(objUserCounterTranDAL);

                }
                SqlRdr.Close();
                SqlCon.Close();

                return lstUserCounterTranDAL;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        #endregion
    }
}
