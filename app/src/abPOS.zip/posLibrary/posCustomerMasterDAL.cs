using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace posLibrary
{
    /// <summary>
    /// Class for posCustomerMaster
    /// </summary>
    public class posCustomerMasterDAL
    {
        #region Properties
        public int CustomerMasterId { get; set; }
        public short? CustomerType { get; set; }
        public string ShortName { get; set; }
        public string CustomerName { get; set; }
        public string Description { get; set; }
        public string ContactPersonName { get; set; }
        public string Designation { get; set; }
        public string Address { get; set; }
        public DateTime? Birthdate { get; set; }
        public DateTime? AnniversaryDate { get; set; }
        public int? linktoCityMasterId { get; set; }
        public int? linktoAreaMasterId { get; set; }
        public string ZipCode { get; set; }
        public string Phone1 { get; set; }
        public bool IsPhone1DND { get; set; }
        public string Phone2 { get; set; }
        public bool? IsPhone2DND { get; set; }
        public string Email1 { get; set; }
        public string Email2 { get; set; }
        public string Fax { get; set; }
        public string ImageName { get; set; }
        public bool? IsFavourite { get; set; }
        public bool? IsCredit { get; set; }
        public double OpeningBalance { get; set; }
        public short CreditDays { get; set; }
        public double CreditBalance { get; set; }
        public double CreditLimit { get; set; }
        public short linktoBusinessMasterId { get; set; }
        public DateTime CreateDateTime { get; set; }
        public short linktoUserMasterIdCreatedBy { get; set; }
        public DateTime? UpdateDateTime { get; set; }
        public short? linktoUserMasterIdUpdatedBy { get; set; }
        public bool IsEnabled { get; set; }
        public bool IsDeleted { get; set; }
        public bool IsSelected { get; set; }
        public int? linktoDiscountMasterId { get; set; }
        public string OfferCode { get; set; }

        public string MembershipCardNumber { get; set; }
        public DateTime? MembershipCardExpiryDate { get; set; }
        public bool? IsMembershipCardUsedFirstTime { get; set; }
        public short? linktoMembershipTypeMasterId { get; set; }
        public short? TotalPoints { get; set; }
        public short? TotalAmount { get; set; }
        public bool IsCardOfPoint { get; set; }
        public short linktoSourceMasterId { get; set; }
        public DateTime? LastLoginDateTime { get; set; }
        public short linkSourceMasterId { get; set; }
        public string Gender { get; set; }
        public string Password { get; set; }
        public string Remark { get; set; }

        // Image Property
        public string xs_ImagePhysicalName { get; set; }
        public string sm_ImagePhysicalName { get; set; }
        public string md_ImagePhysicalName { get; set; }
        public string lg_ImagePhysicalName { get; set; }
        public string xl_ImagePhysicalName { get; set; }

        /// Extra
        public string City { get; set; }
        public string Area { get; set; }
        public string CustomerTypeName { get; set; }
        public string CustomerDetail { get; set; }
        public int linktoBookingMasterId { get; set; }
        public string DiscountTitle { get; set; }
        public string BirthDateString { get; set; }
        public string AnniversaryDateString { get; set; }
        #endregion

        #region Class Methods
        private bool SetClassPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            if (sqlRdr.Read())
            {
                this.CustomerMasterId = Convert.ToInt32(sqlRdr["CustomerMasterId"]);
                this.CustomerType = Convert.ToInt16(sqlRdr["CustomerType"]);
                this.ShortName = Convert.ToString(sqlRdr["ShortName"]);
                this.CustomerName = Convert.ToString(sqlRdr["CustomerName"]);
                this.Description = Convert.ToString(sqlRdr["Description"]);
                this.ContactPersonName = Convert.ToString(sqlRdr["ContactPersonName"]);
                this.Designation = Convert.ToString(sqlRdr["Designation"]);
                this.Address = Convert.ToString(sqlRdr["Address"]);
                if (sqlRdr["Birthdate"] != DBNull.Value)
                {
                    this.Birthdate = Convert.ToDateTime(sqlRdr["Birthdate"]);
                }
                if (sqlRdr["AnniversaryDate"] != DBNull.Value)
                {
                    this.AnniversaryDate = Convert.ToDateTime(sqlRdr["AnniversaryDate"]);
                }
                this.Phone1 = Convert.ToString(sqlRdr["Phone1"]);
                this.IsPhone1DND = Convert.ToBoolean(sqlRdr["IsPhone1DND"]);
                this.Phone2 = Convert.ToString(sqlRdr["Phone2"]);
                if (sqlRdr["IsPhone2DND"] != DBNull.Value)
                {
                    this.IsPhone2DND = Convert.ToBoolean(sqlRdr["IsPhone2DND"]);
                }
                this.Email1 = Convert.ToString(sqlRdr["Email1"]);
                this.Email2 = Convert.ToString(sqlRdr["Email2"]);
                this.Fax = Convert.ToString(sqlRdr["Fax"]);
                this.IsFavourite = Convert.ToBoolean(sqlRdr["IsFavourite"]);
                if (sqlRdr["IsCredit"] != DBNull.Value)
                {
                    this.IsCredit = Convert.ToBoolean(sqlRdr["IsCredit"]);
                }
                this.OpeningBalance = Convert.ToDouble(sqlRdr["OpeningBalance"]);
                this.CreditDays = Convert.ToInt16(sqlRdr["CreditDays"]);
                this.CreditBalance = Convert.ToDouble(sqlRdr["CreditBalance"]);
                this.CreditLimit = Convert.ToDouble(sqlRdr["CreditLimit"]);
                this.linktoBusinessMasterId = Convert.ToInt16(sqlRdr["linktoBusinessMasterId"]);
                this.CreateDateTime = Convert.ToDateTime(sqlRdr["CreateDateTime"]);
                this.linktoUserMasterIdCreatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdCreatedBy"]);
                if (sqlRdr["UpdateDateTime"] != DBNull.Value)
                {
                    this.UpdateDateTime = Convert.ToDateTime(sqlRdr["UpdateDateTime"]);
                }
                if (sqlRdr["linktoUserMasterIdUpdatedBy"] != DBNull.Value)
                {
                    this.linktoUserMasterIdUpdatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdUpdatedBy"]);
                }
                this.IsEnabled = Convert.ToBoolean(sqlRdr["IsEnabled"]);
                this.IsDeleted = Convert.ToBoolean(sqlRdr["IsDeleted"]);

                if (sqlRdr["MembershipCardNumber"] != DBNull.Value)
                {
                    this.MembershipCardNumber = Convert.ToString(sqlRdr["MembershipCardNumber"]);
                }
                if (sqlRdr["linktoMembershipTypeMasterId"] != DBNull.Value)
                {
                    this.linktoMembershipTypeMasterId = Convert.ToInt16(sqlRdr["linktoMembershipTypeMasterId"]);
                }
                if (sqlRdr["MembershipCardExpiryDate"] != DBNull.Value)
                {
                    this.MembershipCardExpiryDate = Convert.ToDateTime(sqlRdr["MembershipCardExpiryDate"]);
                }
                if (sqlRdr["TotalPoints"] != DBNull.Value)
                {
                    this.TotalPoints = Convert.ToInt16(sqlRdr["TotalPoints"]);
                }
                if (sqlRdr["TotalAmount"] != DBNull.Value)
                {
                    this.TotalAmount = Convert.ToInt16(sqlRdr["TotalAmount"]);
                }
                this.Password = Convert.ToString(sqlRdr["Password"]);
                this.Gender = Convert.ToString(sqlRdr["Gender"]);
                if (sqlRdr["ImageName"] != DBNull.Value)
                {
                    this.ImageName = Convert.ToString(sqlRdr["ImageName"]);

                    this.xs_ImagePhysicalName = "xs_" + Convert.ToString(sqlRdr["ImageName"]);
                    this.sm_ImagePhysicalName = "sm_" + Convert.ToString(sqlRdr["ImageName"]);
                    this.md_ImagePhysicalName = "md_" + Convert.ToString(sqlRdr["ImageName"]);
                    this.lg_ImagePhysicalName = "lg_" + Convert.ToString(sqlRdr["ImageName"]);
                    this.xl_ImagePhysicalName = "xl_" + Convert.ToString(sqlRdr["ImageName"]);
                }
                return true;
            }
            return false;
        }

        private List<posCustomerMasterDAL> SetListPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            List<posCustomerMasterDAL> lstCustomerMaster = new List<posCustomerMasterDAL>();
            posCustomerMasterDAL objCustomerMaster = null;
            while (sqlRdr.Read())
            {
                objCustomerMaster = new posCustomerMasterDAL();
                objCustomerMaster.CustomerMasterId = Convert.ToInt32(sqlRdr["CustomerMasterId"]);
                objCustomerMaster.CustomerType = Convert.ToInt16(sqlRdr["CustomerType"]);
                objCustomerMaster.ShortName = Convert.ToString(sqlRdr["ShortName"]);
                objCustomerMaster.CustomerName = Convert.ToString(sqlRdr["CustomerName"]);
                objCustomerMaster.Description = Convert.ToString(sqlRdr["Description"]);
                objCustomerMaster.ContactPersonName = Convert.ToString(sqlRdr["ContactPersonName"]);
                objCustomerMaster.Designation = Convert.ToString(sqlRdr["Designation"]);
                if (sqlRdr["Birthdate"] != DBNull.Value)
                {
                    objCustomerMaster.Birthdate = Convert.ToDateTime(sqlRdr["Birthdate"]);
                }
                if (sqlRdr["AnniversaryDate"] != DBNull.Value)
                {
                    objCustomerMaster.AnniversaryDate = Convert.ToDateTime(sqlRdr["AnniversaryDate"]);
                }
                objCustomerMaster.Phone1 = Convert.ToString(sqlRdr["Phone1"]);
                objCustomerMaster.IsPhone1DND = Convert.ToBoolean(sqlRdr["IsPhone1DND"]);
                objCustomerMaster.Phone2 = Convert.ToString(sqlRdr["Phone2"]);
                if (sqlRdr["IsPhone2DND"] != DBNull.Value)
                {
                    objCustomerMaster.IsPhone2DND = Convert.ToBoolean(sqlRdr["IsPhone2DND"]);
                }
                objCustomerMaster.Email1 = Convert.ToString(sqlRdr["Email1"]);
                objCustomerMaster.Email2 = Convert.ToString(sqlRdr["Email2"]);
                objCustomerMaster.Fax = Convert.ToString(sqlRdr["Fax"]);
                objCustomerMaster.ImageName = Convert.ToString(sqlRdr["ImageName"]);
                objCustomerMaster.IsFavourite = Convert.ToBoolean(sqlRdr["IsFavourite"]);
                if (sqlRdr["IsCredit"] != DBNull.Value)
                {
                    objCustomerMaster.IsCredit = Convert.ToBoolean(sqlRdr["IsCredit"]);
                }
                objCustomerMaster.OpeningBalance = Convert.ToDouble(sqlRdr["OpeningBalance"]);
                objCustomerMaster.CreditDays = Convert.ToInt16(sqlRdr["CreditDays"]);
                objCustomerMaster.CreditBalance = Convert.ToDouble(sqlRdr["CreditBalance"]);
                objCustomerMaster.CreditLimit = Convert.ToDouble(sqlRdr["CreditLimit"]);
                objCustomerMaster.linktoBusinessMasterId = Convert.ToInt16(sqlRdr["linktoBusinessMasterId"]);
                objCustomerMaster.CreateDateTime = Convert.ToDateTime(sqlRdr["CreateDateTime"]);
                objCustomerMaster.linktoUserMasterIdCreatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdCreatedBy"]);
                objCustomerMaster.Password = Convert.ToString(sqlRdr["Password"]);
                objCustomerMaster.Gender = Convert.ToString(sqlRdr["Gender"]);
                if (sqlRdr["UpdateDateTime"] != DBNull.Value)
                {
                    objCustomerMaster.UpdateDateTime = Convert.ToDateTime(sqlRdr["UpdateDateTime"]);
                }
                if (sqlRdr["linktoUserMasterIdUpdatedBy"] != DBNull.Value)
                {
                    objCustomerMaster.linktoUserMasterIdUpdatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdUpdatedBy"]);
                }
                objCustomerMaster.IsEnabled = Convert.ToBoolean(sqlRdr["IsEnabled"]);
                objCustomerMaster.IsDeleted = Convert.ToBoolean(sqlRdr["IsDeleted"]);

                lstCustomerMaster.Add(objCustomerMaster);
            }
            return lstCustomerMaster;
        }
        #endregion

        #region Insert
        public posRecordStatus InsertCustomerMaster(posCustomerAddressTranDAL objCustomerAddressTranDAL)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlTransaction sqlTran = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCon.Open();
                sqlTran = SqlCon.BeginTransaction();

                SqlCmd = new SqlCommand("posCustomerMaster_Insert", SqlCon, sqlTran);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@CustomerMasterId", SqlDbType.SmallInt).Direction = ParameterDirection.Output;
                SqlCmd.Parameters.Add("@CustomerType", SqlDbType.SmallInt).Value = this.CustomerType;
                SqlCmd.Parameters.Add("@ShortName", SqlDbType.VarChar).Value = this.ShortName;
                SqlCmd.Parameters.Add("@CustomerName", SqlDbType.VarChar).Value = this.CustomerName;
                SqlCmd.Parameters.Add("@Description", SqlDbType.VarChar).Value = this.Description;
                SqlCmd.Parameters.Add("@ContactPersonName", SqlDbType.VarChar).Value = this.ContactPersonName;
                SqlCmd.Parameters.Add("@Designation", SqlDbType.VarChar).Value = this.Designation;
                SqlCmd.Parameters.Add("@Birthdate", SqlDbType.DateTime).Value = this.Birthdate;
                SqlCmd.Parameters.Add("@AnniversaryDate", SqlDbType.DateTime).Value = this.AnniversaryDate;
                SqlCmd.Parameters.Add("@Phone1", SqlDbType.VarChar).Value = this.Phone1;
                SqlCmd.Parameters.Add("@IsPhone1DND", SqlDbType.Bit).Value = this.IsPhone1DND;
                SqlCmd.Parameters.Add("@Phone2", SqlDbType.VarChar).Value = this.Phone2;
                SqlCmd.Parameters.Add("@IsPhone2DND", SqlDbType.Bit).Value = this.IsPhone2DND;
                SqlCmd.Parameters.Add("@Email1", SqlDbType.VarChar).Value = this.Email1;
                SqlCmd.Parameters.Add("@Email2", SqlDbType.VarChar).Value = this.Email2;
                SqlCmd.Parameters.Add("@Fax", SqlDbType.VarChar).Value = this.Fax;
                SqlCmd.Parameters.Add("@ImageName", SqlDbType.VarChar).Value = this.ImageName;
                SqlCmd.Parameters.Add("@IsFavourite", SqlDbType.Bit).Value = this.IsFavourite;
                SqlCmd.Parameters.Add("@IsCredit", SqlDbType.Bit).Value = this.IsCredit;
                SqlCmd.Parameters.Add("@OpeningBalance", SqlDbType.Money).Value = this.OpeningBalance;
                SqlCmd.Parameters.Add("@CreditDays", SqlDbType.SmallInt).Value = this.CreditDays;
                SqlCmd.Parameters.Add("@CreditBalance", SqlDbType.Money).Value = this.CreditBalance;
                SqlCmd.Parameters.Add("@CreditLimit", SqlDbType.Money).Value = this.CreditLimit;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCmd.Parameters.Add("@CreateDateTime", SqlDbType.DateTime).Value = this.CreateDateTime;
                SqlCmd.Parameters.Add("@linktoUserMasterIdCreatedBy", SqlDbType.SmallInt).Value = this.linktoUserMasterIdCreatedBy;
                SqlCmd.Parameters.Add("@TotalPoints", SqlDbType.SmallInt).Value = this.TotalPoints;
                SqlCmd.Parameters.Add("@TotalAmount", SqlDbType.SmallInt).Value = this.TotalAmount;
                SqlCmd.Parameters.Add("@IsEnabled", SqlDbType.Bit).Value = this.IsEnabled;
                SqlCmd.Parameters.Add("@IsDeleted", SqlDbType.Bit).Value = this.IsDeleted;
                SqlCmd.Parameters.Add("@linktoSourceMasterId", SqlDbType.SmallInt).Value = this.linktoSourceMasterId;
                SqlCmd.Parameters.Add("@Gender", SqlDbType.VarChar).Value = this.Gender;
                SqlCmd.Parameters.Add("@Password", SqlDbType.VarChar).Value = this.Password;
                SqlCmd.Parameters.Add("@LastLoginDateTime", SqlDbType.DateTime).Value = this.LastLoginDateTime;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCmd.ExecuteNonQuery();

                this.CustomerMasterId = Convert.ToInt32(SqlCmd.Parameters["@CustomerMasterId"].Value);
                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                if (rs != posRecordStatus.Success)
                {
                    sqlTran.Rollback();
                    SqlCon.Close();
                    return rs;
                }
                if (!string.IsNullOrEmpty(objCustomerAddressTranDAL.Address))
                {
                    objCustomerAddressTranDAL.linktoCustomerMasterId = this.CustomerMasterId;
                    rs = objCustomerAddressTranDAL.InsertCustomerAddressTran(SqlCon, sqlTran);
                    if (rs != posRecordStatus.Success)
                    {
                        sqlTran.Rollback();
                        SqlCon.Close();
                        return rs;
                    }
                }
                sqlTran.Commit();
                SqlCon.Close();
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
                posObjectFactoryDAL.DisposeTransaction(sqlTran);
            }
        }

        public posRecordStatus InsertCustomerMaster(List<posCustomerAddressTranDAL> lstCustomerAddressTranDAL)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlTransaction sqlTran = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCon.Open();
                sqlTran = SqlCon.BeginTransaction();
                SqlCmd = new SqlCommand("posCustomerMaster_Insert", SqlCon, sqlTran);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@CustomerMasterId", SqlDbType.SmallInt).Direction = ParameterDirection.Output;
                SqlCmd.Parameters.Add("@CustomerType", SqlDbType.SmallInt).Value = this.CustomerType;
                SqlCmd.Parameters.Add("@ShortName", SqlDbType.VarChar).Value = this.ShortName;
                SqlCmd.Parameters.Add("@CustomerName", SqlDbType.VarChar).Value = this.CustomerName;
                SqlCmd.Parameters.Add("@Description", SqlDbType.VarChar).Value = this.Description;
                SqlCmd.Parameters.Add("@ContactPersonName", SqlDbType.VarChar).Value = this.ContactPersonName;
                SqlCmd.Parameters.Add("@Designation", SqlDbType.VarChar).Value = this.Designation;
                SqlCmd.Parameters.Add("@Birthdate", SqlDbType.DateTime).Value = this.Birthdate;
                SqlCmd.Parameters.Add("@Phone1", SqlDbType.VarChar).Value = this.Phone1;
                SqlCmd.Parameters.Add("@IsPhone1DND", SqlDbType.Bit).Value = this.IsPhone1DND;
                SqlCmd.Parameters.Add("@Phone2", SqlDbType.VarChar).Value = this.Phone2;
                SqlCmd.Parameters.Add("@IsPhone2DND", SqlDbType.Bit).Value = this.IsPhone2DND;
                SqlCmd.Parameters.Add("@Email1", SqlDbType.VarChar).Value = this.Email1;
                SqlCmd.Parameters.Add("@Email2", SqlDbType.VarChar).Value = this.Email2;
                SqlCmd.Parameters.Add("@Fax", SqlDbType.VarChar).Value = this.Fax;
                SqlCmd.Parameters.Add("@ImageName", SqlDbType.VarChar).Value = this.ImageName;
                SqlCmd.Parameters.Add("@IsFavourite", SqlDbType.Bit).Value = this.IsFavourite;
                SqlCmd.Parameters.Add("@IsCredit", SqlDbType.Bit).Value = this.IsCredit;
                SqlCmd.Parameters.Add("@OpeningBalance", SqlDbType.Money).Value = this.OpeningBalance;
                SqlCmd.Parameters.Add("@CreditDays", SqlDbType.SmallInt).Value = this.CreditDays;
                SqlCmd.Parameters.Add("@CreditBalance", SqlDbType.Money).Value = this.CreditBalance;
                SqlCmd.Parameters.Add("@CreditLimit", SqlDbType.Money).Value = this.CreditLimit;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCmd.Parameters.Add("@CreateDateTime", SqlDbType.DateTime).Value = this.CreateDateTime;
                SqlCmd.Parameters.Add("@linktoUserMasterIdCreatedBy", SqlDbType.SmallInt).Value = this.linktoUserMasterIdCreatedBy;

                SqlCmd.Parameters.Add("@linktoMembershipTypeMasterId", SqlDbType.SmallInt).Value = this.linktoMembershipTypeMasterId;
                SqlCmd.Parameters.Add("@TotalPoints", SqlDbType.SmallInt).Value = this.TotalPoints;
                SqlCmd.Parameters.Add("@TotalAmount", SqlDbType.SmallInt).Value = this.TotalAmount;
                SqlCmd.Parameters.Add("@MembershipCardExpiryDate", SqlDbType.DateTime).Value = this.MembershipCardExpiryDate;
                SqlCmd.Parameters.Add("@MembershipCardNumber", SqlDbType.VarChar).Value = this.MembershipCardNumber;
                SqlCmd.Parameters.Add("@linktoSourceMasterId", SqlDbType.SmallInt).Value = this.linktoSourceMasterId;
                SqlCmd.Parameters.Add("@Gender", SqlDbType.VarChar).Value = this.Gender;
                SqlCmd.Parameters.Add("@Password", SqlDbType.VarChar).Value = this.Password;
                SqlCmd.Parameters.Add("@LastLoginDateTime", SqlDbType.DateTime).Value = this.LastLoginDateTime;

                SqlCmd.Parameters.Add("@IsEnabled", SqlDbType.Bit).Value = this.IsEnabled;
                SqlCmd.Parameters.Add("@IsDeleted", SqlDbType.Bit).Value = this.IsDeleted;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCmd.ExecuteNonQuery();

                this.CustomerMasterId = Convert.ToInt32(SqlCmd.Parameters["@CustomerMasterId"].Value);
                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;

                if (rs != posRecordStatus.Success)
                {
                    sqlTran.Rollback();
                    SqlCon.Close();
                    return rs;
                }
                foreach (posCustomerAddressTranDAL objCustomerAddressTranDAL in lstCustomerAddressTranDAL)
                {
                    objCustomerAddressTranDAL.linktoCustomerMasterId = this.CustomerMasterId;
                    rs = objCustomerAddressTranDAL.InsertCustomerAddressTran(SqlCon, sqlTran);
                    if (rs != posRecordStatus.Success)
                    {
                        sqlTran.Rollback();
                        SqlCon.Close();
                        return rs;
                    }
                }
                sqlTran.Commit();
                SqlCon.Close();
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
                posObjectFactoryDAL.DisposeTransaction(sqlTran);
            }
        }

        public posRecordStatus InserCutomerMembership()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posCustomerMasterMembership_Update", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@CustomerMasterId", SqlDbType.SmallInt).Value = this.CustomerMasterId;
                SqlCmd.Parameters.Add("@linktoMembershipTypeMasterId", SqlDbType.SmallInt).Value = this.linktoMembershipTypeMasterId;
                SqlCmd.Parameters.Add("@TotalPoints", SqlDbType.SmallInt).Value = this.TotalPoints;
                SqlCmd.Parameters.Add("@MembershipCardExpiryDate", SqlDbType.DateTime).Value = this.MembershipCardExpiryDate;
                SqlCmd.Parameters.Add("@MembershipCardNumber", SqlDbType.VarChar).Value = this.MembershipCardNumber;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                SqlCon.Close();
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region Update
        public posRecordStatus UpdateCustomerMaster(List<posCustomerAddressTranDAL> lstCustomerAddressTranDAL)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlTransaction sqlTran = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCon.Open();
                sqlTran = SqlCon.BeginTransaction();
                SqlCmd = new SqlCommand("posCustomerMaster_Update", SqlCon, sqlTran);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@CustomerMasterId", SqlDbType.Int).Value = this.CustomerMasterId;
                SqlCmd.Parameters.Add("@CustomerType", SqlDbType.SmallInt).Value = this.CustomerType;
                SqlCmd.Parameters.Add("@ShortName", SqlDbType.VarChar).Value = this.ShortName;
                SqlCmd.Parameters.Add("@CustomerName", SqlDbType.VarChar).Value = this.CustomerName;
                SqlCmd.Parameters.Add("@Description", SqlDbType.VarChar).Value = this.Description;
                SqlCmd.Parameters.Add("@ContactPersonName", SqlDbType.VarChar).Value = this.ContactPersonName;
                SqlCmd.Parameters.Add("@Designation", SqlDbType.VarChar).Value = this.Designation;
                SqlCmd.Parameters.Add("@Birthdate", SqlDbType.DateTime).Value = this.Birthdate;
                SqlCmd.Parameters.Add("@AnniversaryDate", SqlDbType.DateTime).Value = this.AnniversaryDate;
                SqlCmd.Parameters.Add("@Phone1", SqlDbType.VarChar).Value = this.Phone1;
                SqlCmd.Parameters.Add("@IsPhone1DND", SqlDbType.Bit).Value = this.IsPhone1DND;
                SqlCmd.Parameters.Add("@Phone2", SqlDbType.VarChar).Value = this.Phone2;
                SqlCmd.Parameters.Add("@IsPhone2DND", SqlDbType.Bit).Value = this.IsPhone2DND;
                SqlCmd.Parameters.Add("@Email1", SqlDbType.VarChar).Value = this.Email1;
                SqlCmd.Parameters.Add("@Email2", SqlDbType.VarChar).Value = this.Email2;
                SqlCmd.Parameters.Add("@Fax", SqlDbType.VarChar).Value = this.Fax;
                SqlCmd.Parameters.Add("@ImageName", SqlDbType.VarChar).Value = this.ImageName;
                SqlCmd.Parameters.Add("@IsFavourite", SqlDbType.Bit).Value = this.IsFavourite;
                SqlCmd.Parameters.Add("@IsCredit", SqlDbType.Bit).Value = this.IsCredit;
                SqlCmd.Parameters.Add("@OpeningBalance", SqlDbType.Money).Value = this.OpeningBalance;
                SqlCmd.Parameters.Add("@CreditDays", SqlDbType.SmallInt).Value = this.CreditDays;
                SqlCmd.Parameters.Add("@CreditBalance", SqlDbType.Money).Value = this.CreditBalance;
                SqlCmd.Parameters.Add("@CreditLimit", SqlDbType.Money).Value = this.CreditLimit;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCmd.Parameters.Add("@UpdateDateTime", SqlDbType.DateTime).Value = this.UpdateDateTime;
                SqlCmd.Parameters.Add("@linktoUserMasterIdUpdatedBy", SqlDbType.SmallInt).Value = this.linktoUserMasterIdUpdatedBy;
                SqlCmd.Parameters.Add("@IsEnabled", SqlDbType.Bit).Value = this.IsEnabled;
                SqlCmd.Parameters.Add("@IsDeleted", SqlDbType.Bit).Value = this.IsDeleted;

                SqlCmd.Parameters.Add("@linktoMembershipTypeMasterId", SqlDbType.SmallInt).Value = this.linktoMembershipTypeMasterId;
                SqlCmd.Parameters.Add("@TotalPoints", SqlDbType.SmallInt).Value = this.TotalPoints;
                SqlCmd.Parameters.Add("@TotalAmount", SqlDbType.SmallInt).Value = this.TotalAmount;
                SqlCmd.Parameters.Add("@MembershipCardExpiryDate", SqlDbType.DateTime).Value = this.MembershipCardExpiryDate;
                SqlCmd.Parameters.Add("@MembershipCardNumber", SqlDbType.VarChar).Value = this.MembershipCardNumber;

                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCmd.ExecuteNonQuery();
                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                if (rs != posRecordStatus.Success)
                {
                    sqlTran.Rollback();
                    SqlCon.Close();
                    return rs;
                }

                foreach (posCustomerAddressTranDAL objCustomerAddressTranDAL in lstCustomerAddressTranDAL)
                {
                    objCustomerAddressTranDAL.linktoCustomerMasterId = this.CustomerMasterId;
                    if (objCustomerAddressTranDAL.CustomerAddressTranId > 0)
                    {
                        rs = objCustomerAddressTranDAL.UpdateCustomerAddressTran(SqlCon, sqlTran);
                    }
                    else
                    {
                        rs = objCustomerAddressTranDAL.InsertCustomerAddressTran(SqlCon, sqlTran);
                    }
                    if (rs != posRecordStatus.Success)
                    {
                        sqlTran.Rollback();
                        SqlCon.Close();
                        return rs;
                    }
                }
                sqlTran.Commit();
                SqlCon.Close();
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
                posObjectFactoryDAL.DisposeTransaction(sqlTran);
            }
        }

        public posRecordStatus UpdateCustomerMasterCreditBalance(SqlConnection SqlCon, SqlTransaction sqlTran)
        {
            SqlCommand SqlCmd = null;
            try
            {

                SqlCmd = new SqlCommand("posCustomerMasterCreditBalance_Update", SqlCon, sqlTran);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@UpdateDateTime", SqlDbType.DateTime).Value = this.UpdateDateTime;
                SqlCmd.Parameters.Add("@linktoUserMasterIdUpdatedBy", SqlDbType.SmallInt).Value = this.linktoUserMasterIdUpdatedBy;
                SqlCmd.Parameters.Add("@CustomerMasterId", SqlDbType.Int).Value = this.CustomerMasterId;
                SqlCmd.Parameters.Add("@CreditBalance", SqlDbType.Money).Value = this.CreditBalance;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCmd.ExecuteNonQuery();

                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
            }
        }

        public posRecordStatus UpdateCustomerMasterlinktoDiscountMasterId(string customerMasterIDs)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posCustomerMasterlinktoDiscountMasterId_Update", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@linktoDiscountMasterId", SqlDbType.Int).Value = this.linktoDiscountMasterId;
                SqlCmd.Parameters.Add("@CustomerMasterIDs", SqlDbType.VarChar).Value = customerMasterIDs;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public posRecordStatus UpdateCustomerMasterRemoveDiscount(string customerMasterIDs)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posCustomerMasterRemoveDiscount_Update", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@CustomerMasterIDs", SqlDbType.VarChar).Value = customerMasterIDs;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public posRecordStatus UpdateCustomerMasterPassword(string OldPassword)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posCustomerMasterPassword_Update", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@CustomerMasterId", SqlDbType.Int).Value = this.CustomerMasterId;
                SqlCmd.Parameters.Add("@Password", SqlDbType.VarChar).Value = this.Password;
                SqlCmd.Parameters.Add("@OldPassword", SqlDbType.VarChar).Value = OldPassword;
                SqlCmd.Parameters.Add("@UpdateDateTime", SqlDbType.DateTime).Value = this.UpdateDateTime;
                SqlCmd.Parameters.Add("@linktoUserMasterIdUpdatedBy", SqlDbType.SmallInt).Value = this.linktoUserMasterIdUpdatedBy;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public posRecordStatus UpdateCustomerMasterbyId()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posCustomerMasterById_Update", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@CustomerMasterId", SqlDbType.VarChar).Value = this.CustomerMasterId;
                SqlCmd.Parameters.Add("@CustomerName", SqlDbType.VarChar).Value = this.CustomerName;
                SqlCmd.Parameters.Add("@Birthdate", SqlDbType.DateTime).Value = this.Birthdate;
                SqlCmd.Parameters.Add("@Phone1", SqlDbType.VarChar).Value = this.Phone1;
                SqlCmd.Parameters.Add("@Gender", SqlDbType.VarChar).Value = this.Gender;
                SqlCmd.Parameters.Add("@UpdateDateTime", SqlDbType.DateTime).Value = this.UpdateDateTime;
                SqlCmd.Parameters.Add("@linktoUserMasterIdUpdatedBy", SqlDbType.SmallInt).Value = this.linktoUserMasterIdUpdatedBy;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region DeleteAll
        public static posRecordStatus DeleteAllCustomerMaster(string customerMasterIds, short linktoUserMasterIdUpdatedBy, DateTime UpdateDateTime)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posCustomerMaster_DeleteAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@CustomerMasterIds", SqlDbType.VarChar).Value = customerMasterIds;
                SqlCmd.Parameters.Add("@UpdateDateTime", SqlDbType.DateTime).Value = UpdateDateTime;
                SqlCmd.Parameters.Add("@linktoUserMasterIdUpdatedBy", SqlDbType.SmallInt).Value = linktoUserMasterIdUpdatedBy;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region Select
        public bool SelectCustomerMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posCustomerMaster_Select", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                if (this.CustomerMasterId > 0)
                {
                    SqlCmd.Parameters.Add("@CustomerMasterId", SqlDbType.Int).Value = this.CustomerMasterId;
                }
                SqlCmd.Parameters.Add("@Email1", SqlDbType.VarChar).Value = this.Email1;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                bool IsSelected = SetClassPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                return IsSelected;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return false;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public posCustomerMasterDAL SelectCustomerMasterCheckCardNumber()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            posCustomerMasterDAL objCustomerMasterDAL = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posCustomerMasterChekMembershipCardNumber_Select", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@MembershipCardNumber", SqlDbType.VarChar).Value = this.MembershipCardNumber;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCmd.Parameters.Add("@MembershipTypeMasterId", SqlDbType.SmallInt).Value = this.linktoMembershipTypeMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();

                objCustomerMasterDAL = new posCustomerMasterDAL();
                while (SqlRdr.Read())
                {
                    if (SqlRdr["CustomerMasterId"] == DBNull.Value)
                    {
                        objCustomerMasterDAL.CustomerMasterId = 0;
                        objCustomerMasterDAL.BirthDateString = Convert.ToString(SqlRdr["CardValidDate"]);
                        if (SqlRdr["TotalPointORAmount"] != DBNull.Value)
                        {
                            objCustomerMasterDAL.TotalAmount = Convert.ToInt16(SqlRdr["TotalPointORAmount"]);
                        }
                        objCustomerMasterDAL.IsCardOfPoint = Convert.ToBoolean(SqlRdr["IsCardOfPoint"]);

                        objCustomerMasterDAL.MembershipCardNumber = (string)SqlCmd.Parameters["@MembershipCardNumber"].Value;
                    }
                    else
                    {
                        objCustomerMasterDAL.CustomerMasterId = Convert.ToInt16(SqlRdr["CustomerMasterId"]);
                    }
                }
                SqlRdr.Close();
                SqlCon.Close();
                return objCustomerMasterDAL;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return objCustomerMasterDAL;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region SelectAll
        public List<posCustomerMasterDAL> SelectAllCustomerMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posCustomerMaster_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;
                if (this.CustomerType > 0)
                {
                    SqlCmd.Parameters.Add("@CustomerType", SqlDbType.SmallInt).Value = this.CustomerType;
                }
                SqlCmd.Parameters.Add("@CustomerName", SqlDbType.VarChar).Value = this.CustomerName;
                SqlCmd.Parameters.Add("@Phone1", SqlDbType.VarChar).Value = this.Phone1;
                SqlCmd.Parameters.Add("@IsFavourite", SqlDbType.Bit).Value = this.IsFavourite;
                SqlCmd.Parameters.Add("@IsCredit", SqlDbType.Bit).Value = this.IsCredit;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCmd.Parameters.Add("@IsEnabled", SqlDbType.Bit).Value = this.IsEnabled;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<posCustomerMasterDAL> lstCustomerMasterDAL = SetListPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                return lstCustomerMasterDAL;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public List<posCustomerMasterDAL> SelectAllCustomerMasterMembershipTypeWise()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posCustomerMasterMembershipTypeWise_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;
                if (this.linktoMembershipTypeMasterId > 0)
                {
                    SqlCmd.Parameters.Add("@linktoMembershipTypeMasterId", SqlDbType.SmallInt).Value = this.linktoMembershipTypeMasterId;
                }
                SqlCmd.Parameters.Add("@CustomerName", SqlDbType.VarChar).Value = this.CustomerName;
                SqlCmd.Parameters.Add("@Phone1", SqlDbType.VarChar).Value = this.Phone1;
                SqlCmd.Parameters.Add("@IsFavourite", SqlDbType.Bit).Value = this.IsFavourite;
                SqlCmd.Parameters.Add("@IsCredit", SqlDbType.Bit).Value = this.IsCredit;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCmd.Parameters.Add("@IsEnabled", SqlDbType.Bit).Value = this.IsEnabled;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<posCustomerMasterDAL> lstCustomerMasterDAL = SetListPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                return lstCustomerMasterDAL;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public static List<posCustomerMasterDAL> SelectAllCustomerMasterCustomerNameByCustomerType(short linktoBusinessMasterId, short CustomerType)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posCustomerMasterCustomerNameByCustomerTypeWise_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = linktoBusinessMasterId;
                SqlCmd.Parameters.Add("@CustomerType", SqlDbType.SmallInt).Value = CustomerType;
                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<posCustomerMasterDAL> lstCustomerMasterDAL = new List<posCustomerMasterDAL>();
                posCustomerMasterDAL objCustomerMasterDAL = null;
                while (SqlRdr.Read())
                {
                    objCustomerMasterDAL = new posCustomerMasterDAL();
                    objCustomerMasterDAL.CustomerMasterId = Convert.ToInt32(SqlRdr["CustomerMasterId"]);
                    objCustomerMasterDAL.CustomerName = Convert.ToString(SqlRdr["CustomerName"]);
                    lstCustomerMasterDAL.Add(objCustomerMasterDAL);
                }
                SqlRdr.Close();
                SqlCon.Close();

                return lstCustomerMasterDAL;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public static List<posCustomerMasterDAL> SelectAllCustomerMasterCustomerName(short customerType, short linktoBusinessMasterId)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posCustomerMasterCustomerNameByCustomerTypeWise_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@CustomerType", SqlDbType.SmallInt).Value = customerType;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = linktoBusinessMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<posCustomerMasterDAL> lstCustomerMasterDAL = new List<posCustomerMasterDAL>();
                posCustomerMasterDAL objCustomerMasterDAL = null;
                while (SqlRdr.Read())
                {
                    objCustomerMasterDAL = new posCustomerMasterDAL();
                    objCustomerMasterDAL.CustomerMasterId = Convert.ToInt32(SqlRdr["CustomerMasterId"]);
                    objCustomerMasterDAL.CustomerName = Convert.ToString(SqlRdr["CustomerName"]);
                    lstCustomerMasterDAL.Add(objCustomerMasterDAL);
                }
                SqlRdr.Close();
                SqlCon.Close();

                return lstCustomerMasterDAL;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public List<posCustomerMasterDAL> SelectAllCustomerMasterForKOT()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader sqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posCustomerMasterByNameShortNameAndMobile_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@CustomerType", SqlDbType.SmallInt).Value = this.CustomerType;
                SqlCmd.Parameters.Add("@CustomerName", SqlDbType.VarChar).Value = this.CustomerName;
                SqlCmd.Parameters.Add("@IsCredit", SqlDbType.Bit).Value = this.IsCredit;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;

                SqlCon.Open();
                sqlRdr = SqlCmd.ExecuteReader();
                List<posCustomerMasterDAL> lstCustomerMaster = new List<posCustomerMasterDAL>();
                posCustomerMasterDAL objCustomerMaster = null;
                while (sqlRdr.Read())
                {
                    objCustomerMaster = new posCustomerMasterDAL();
                    objCustomerMaster.CustomerMasterId = Convert.ToInt32(sqlRdr["CustomerMasterId"]);

                    objCustomerMaster.CustomerType = Convert.ToInt16(sqlRdr["CustomerType"]);
                    objCustomerMaster.CustomerTypeName = ((posCustomerType)objCustomerMaster.CustomerType).ToString();
                    //if (posCustomerType.Customer.GetHashCode() == objCustomerMaster.CustomerType)
                    //{
                    //    objCustomerMaster.CustomerTypeName = posCustomerType.Customer.ToString();
                    //}
                    //else
                    //{
                    //    objCustomerMaster.CustomerTypeName = posCustomerType.Registered_User.ToString().Replace("_", " ");
                    //}
                    objCustomerMaster.CreditBalance = Convert.ToDouble(sqlRdr["CreditBalance"]);
                    objCustomerMaster.Address = Convert.ToString(sqlRdr["Address"]);
                    objCustomerMaster.ShortName = Convert.ToString(sqlRdr["ShortName"]);
                    objCustomerMaster.CustomerName = Convert.ToString(sqlRdr["CustomerName"]);
                    objCustomerMaster.Phone1 = Convert.ToString(sqlRdr["Phone1"]);
                    objCustomerMaster.Email1 = Convert.ToString(sqlRdr["Email1"]);
                    if (sqlRdr["linktoMembershipTypeMasterId"] != DBNull.Value)
                    {
                        objCustomerMaster.linktoMembershipTypeMasterId = Convert.ToInt16(sqlRdr["linktoMembershipTypeMasterId"]);
                    }
                    if (sqlRdr["linktoDiscountMasterId"] != DBNull.Value)
                    {
                        objCustomerMaster.linktoDiscountMasterId = Convert.ToInt32(sqlRdr["linktoDiscountMasterId"]);
                    }
                    if (sqlRdr["DiscountTitle"] != DBNull.Value)
                    {
                        objCustomerMaster.DiscountTitle = Convert.ToString(sqlRdr["DiscountTitle"]);
                    }
                    objCustomerMaster.CustomerDetail = Convert.ToString(sqlRdr["CustomerMasterId"]) + "_" + Convert.ToDouble(sqlRdr["CreditBalance"]);
                    lstCustomerMaster.Add(objCustomerMaster);
                }

                sqlRdr.Close();
                SqlCon.Close();

                return lstCustomerMaster;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(sqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public List<posCustomerMasterDAL> SelectAllCustomerMasterByBookingMasterId()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posCustomerMasterByBookingMasterId_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@linktoBookingMasterId", SqlDbType.Int).Value = this.linktoBookingMasterId;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<posCustomerMasterDAL> lstCustomerMaster = new List<posCustomerMasterDAL>();
                posCustomerMasterDAL objCustomerMaster = null;
                while (SqlRdr.Read())
                {
                    objCustomerMaster = new posCustomerMasterDAL();
                    objCustomerMaster.CustomerMasterId = Convert.ToInt32(SqlRdr["CustomerMasterId"]);
                    objCustomerMaster.CreditBalance = Convert.ToDouble(SqlRdr["CreditBalance"]);
                    objCustomerMaster.CustomerName = Convert.ToString(SqlRdr["CustomerName"]);
                    lstCustomerMaster.Add(objCustomerMaster);
                }

                SqlRdr.Close();
                SqlCon.Close();

                return lstCustomerMaster;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public List<posCustomerMasterDAL> SelectAllCustomerMasterDiscountAssignment()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posCustomerMasterDiscountAssignment_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<posCustomerMasterDAL> lstCustomerDiscountDAL = new List<posCustomerMasterDAL>();
                posCustomerMasterDAL objCustomerMasterDAL = null;
                while (SqlRdr.Read())
                {
                    objCustomerMasterDAL = new posCustomerMasterDAL();
                    if (SqlRdr["linktoDiscountMasterId"] != DBNull.Value)
                    {
                        objCustomerMasterDAL.linktoDiscountMasterId = Convert.ToInt32(SqlRdr["linktoDiscountMasterId"]);
                    }
                    if (SqlRdr["DiscountTitle"] != DBNull.Value)
                    {
                        objCustomerMasterDAL.DiscountTitle = Convert.ToString(SqlRdr["DiscountTitle"]);
                    }
                    objCustomerMasterDAL.CustomerMasterId = Convert.ToInt32(SqlRdr["CustomerMasterId"]);
                    objCustomerMasterDAL.CustomerName = Convert.ToString(SqlRdr["CustomerName"]);
                    if (Convert.ToInt32(SqlRdr["CustomerType"]) == posCustomerType.Creditor.GetHashCode())
                    {
                        objCustomerMasterDAL.CustomerTypeName = posCustomerType.Creditor.ToString().Replace("_", " ");
                    }
                    else if (Convert.ToInt32(SqlRdr["CustomerType"]) == posCustomerType.Customer.GetHashCode())
                    {
                        objCustomerMasterDAL.CustomerTypeName = posCustomerType.Customer.ToString().Replace("_", " ");
                    }
                    else if (Convert.ToInt32(SqlRdr["CustomerType"]) == posCustomerType.Registered_User.GetHashCode())
                    {
                        objCustomerMasterDAL.CustomerTypeName = posCustomerType.Registered_User.ToString().Replace("_", " ");
                    }

                    objCustomerMasterDAL.Phone1 = Convert.ToString(SqlRdr["Phone1"]);
                    objCustomerMasterDAL.Email1 = Convert.ToString(SqlRdr["Email1"]);

                    lstCustomerDiscountDAL.Add(objCustomerMasterDAL);
                }
                SqlRdr.Close();
                SqlCon.Close();

                return lstCustomerDiscountDAL;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public List<posCustomerMasterDAL> SelectAllCustomerMasterForReport()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader sqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posCustomerMasterReport_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                if (this.linktoCityMasterId > 0)
                {
                    SqlCmd.Parameters.Add("@linktoCityMasterId", SqlDbType.Int).Value = this.linktoCityMasterId;
                }
                if (this.linktoAreaMasterId > 0)
                {
                    SqlCmd.Parameters.Add("@linktoAreaMasterId", SqlDbType.Int).Value = this.linktoAreaMasterId;
                }
                SqlCmd.Parameters.Add("@IsFavourite", SqlDbType.Bit).Value = this.IsFavourite;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;

                SqlCon.Open();
                sqlRdr = SqlCmd.ExecuteReader();
                List<posCustomerMasterDAL> lstCustomerMaster = new List<posCustomerMasterDAL>();
                posCustomerMasterDAL objCustomerMaster = null;
                while (sqlRdr.Read())
                {
                    objCustomerMaster = new posCustomerMasterDAL();

                    objCustomerMaster.CustomerName = Convert.ToString(sqlRdr["CustomerName"]);
                    if (sqlRdr["Birthdate"] != DBNull.Value)
                    {
                        objCustomerMaster.BirthDateString = Convert.ToDateTime(sqlRdr["Birthdate"]).ToString(posGlobalsDAL.DateFormat);

                    }
                    if (sqlRdr["AnniversaryDate"] != DBNull.Value)
                    {
                        objCustomerMaster.AnniversaryDateString = Convert.ToDateTime(sqlRdr["AnniversaryDate"]).ToString(posGlobalsDAL.DateFormat);
                    }
                    objCustomerMaster.Phone1 = Convert.ToString(sqlRdr["Phone1"]);
                    //   objCustomerMaster.IsFavourite = Convert.ToBoolean(sqlRdr["IsFavourite"]);
                    if (sqlRdr["CityName"] != DBNull.Value && sqlRdr["AreaName"] != DBNull.Value)
                    {
                        objCustomerMaster.CustomerDetail = Convert.ToString(sqlRdr["AreaName"]) + "," + Convert.ToString(sqlRdr["CityName"]);
                    }
                    else
                    {
                        if (sqlRdr["CityName"] == DBNull.Value)
                        {
                            objCustomerMaster.CustomerDetail = Convert.ToString(sqlRdr["AreaName"]);
                        }
                        else
                        {
                            objCustomerMaster.CustomerDetail = Convert.ToString(sqlRdr["CityName"]);
                        }
                    }
                    lstCustomerMaster.Add(objCustomerMaster);
                }

                sqlRdr.Close();
                SqlCon.Close();

                return lstCustomerMaster;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(sqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public List<posCustomerMasterDAL> SelectAllCustomerRegisteredUser(short linktoOfferMasterId = 0)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader sqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posCustomerMasterRegisteredUser_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@linktoOfferMasterId", SqlDbType.SmallInt).Value = linktoOfferMasterId;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCmd.Parameters.Add("@CustomerType", SqlDbType.SmallInt).Value = this.CustomerType;

                SqlCon.Open();
                sqlRdr = SqlCmd.ExecuteReader();
                List<posCustomerMasterDAL> lstCustomerMasterDAL = new List<posCustomerMasterDAL>();
                posCustomerMasterDAL objCustomerMasterDAL = null;
                while (sqlRdr.Read())
                {
                    objCustomerMasterDAL = new posCustomerMasterDAL();
                    objCustomerMasterDAL.CustomerMasterId = Convert.ToInt32(sqlRdr["CustomerMasterId"]);
                    objCustomerMasterDAL.CustomerName = Convert.ToString(sqlRdr["CustomerName"]);
                    objCustomerMasterDAL.Email1 = Convert.ToString(sqlRdr["Email1"]);
                    objCustomerMasterDAL.Phone1 = Convert.ToString(sqlRdr["Phone1"]);
                    if (sqlRdr["OfferCodesTranId"] != DBNull.Value)
                    {
                        objCustomerMasterDAL.IsSelected = true;
                    }
                    if (sqlRdr["OfferCode"] != DBNull.Value)
                    {
                        objCustomerMasterDAL.OfferCode = Convert.ToString(sqlRdr["OfferCode"]);
                    }
                    lstCustomerMasterDAL.Add(objCustomerMasterDAL);
                }

                sqlRdr.Close();
                SqlCon.Close();
                return lstCustomerMasterDAL;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(sqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public List<posCustomerMasterDAL> SelectAllCustomerMasterBySalesMasterId(long linktoSalesMasterId)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posCustomerMasterBySalesMasterId_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@linktoSalesMasterId", SqlDbType.Int).Value = linktoSalesMasterId;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<posCustomerMasterDAL> lstCustomerMaster = new List<posCustomerMasterDAL>();
                posCustomerMasterDAL objCustomerMaster = null;
                while (SqlRdr.Read())
                {
                    objCustomerMaster = new posCustomerMasterDAL();
                    objCustomerMaster.CustomerMasterId = Convert.ToInt32(SqlRdr["CustomerMasterId"]);
                    objCustomerMaster.CreditBalance = Convert.ToDouble(SqlRdr["CreditBalance"]);
                    objCustomerMaster.CustomerName = Convert.ToString(SqlRdr["CustomerName"]);
                    lstCustomerMaster.Add(objCustomerMaster);
                }

                SqlRdr.Close();
                SqlCon.Close();

                return lstCustomerMaster;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion
    }
}
