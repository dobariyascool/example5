using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace posLibrary
{
	/// <summary>
	/// Class for posBookingTableTran
	/// </summary>
	public class posBookingTableTranDAL
	{
		#region Properties
		public int BookingTableTranId { get; set; }
		public int linktoBookingMasterId { get; set; }
		public short linktoTableMasterId { get; set; }

        //Extra
        public string TableName { get; set; }       
        public short linktoCounterMasterId { get; set; }
        public bool IsSelected { get; set; }
        public double? DailyBookingRate { get; set; }
        public double? HourlyBookingRate { get; set; }
        public short linktoOrderTypeMasterId { get; set; }
		#endregion

		#region Class Methods
		private List<posBookingTableTranDAL> SetListPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
		{
			List<posBookingTableTranDAL> lstBookingTableTran = new List<posBookingTableTranDAL>();
			posBookingTableTranDAL objBookingTableTran = null;
			while (sqlRdr.Read())
			{
				objBookingTableTran = new posBookingTableTranDAL();
                if (sqlRdr["BookingTableTranId"] != DBNull.Value)
                {
                    objBookingTableTran.BookingTableTranId = Convert.ToInt32(sqlRdr["BookingTableTranId"]);
                    objBookingTableTran.IsSelected = true;
                }
                else
                {
                    objBookingTableTran.IsSelected = false;
                }
				objBookingTableTran.linktoTableMasterId = Convert.ToInt16(sqlRdr["TableMasterId"]);

                //Extra
                objBookingTableTran.TableName = Convert.ToString(sqlRdr["TableName"]);                
                if (sqlRdr["HourlyBookingRate"] != DBNull.Value)
                {
                    objBookingTableTran.HourlyBookingRate = Convert.ToDouble(sqlRdr["HourlyBookingRate"]);
                }
                if (sqlRdr["DailyBookingRate"] != DBNull.Value)
                {
                    objBookingTableTran.DailyBookingRate = Convert.ToDouble(sqlRdr["DailyBookingRate"]);
                }
                
                //if (sqlRdr[""] != DBNull.Value)
                //{
                    
                //}
                //if (sqlRdr[""] != DBNull.Value)
                //{
                //}
				lstBookingTableTran.Add(objBookingTableTran);
			}
			return lstBookingTableTran;
		}
		#endregion

		#region Insert
        public posRecordStatus InsertAllBookingTableTran(string linktoTableMasterIds, SqlConnection SqlCon,SqlTransaction SqlTran)
		{			
			SqlCommand SqlCmd = null;
			try
			{				
				SqlCmd = new SqlCommand("posBookingTableTran_InsertAll", SqlCon,SqlTran);
				SqlCmd.CommandType = CommandType.StoredProcedure;

				SqlCmd.Parameters.Add("@linktoBookingMasterId", SqlDbType.Int).Value = this.linktoBookingMasterId;
				SqlCmd.Parameters.Add("@linktoTableMasterIds", SqlDbType.VarChar).Value = linktoTableMasterIds;
				SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

				SqlCmd.ExecuteNonQuery();
		
				posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
				return rs;
			}
			catch (Exception ex)
			{
				posGlobalsDAL.SaveError(ex);
				return posRecordStatus.Error;
			}
			finally
			{
				posObjectFactoryDAL.DisposeCommand(SqlCmd);			
			}
		}
		#endregion

		#region SelectAll
        public List<posBookingTableTranDAL> SelectAllBookingTableTran(short linktoBusinessMasterId,SqlConnection sqlCon = null)
		{
			SqlConnection SqlCon = null;
			SqlCommand SqlCmd = null;
			SqlDataReader SqlRdr = null;
			try
			{
				if (sqlCon == null)
				{
					SqlCon = posObjectFactoryDAL.CreateConnection();
					SqlCmd = new SqlCommand("posBookingTableTran_SelectAll", SqlCon);
				}
				else
				{
					SqlCmd = new SqlCommand("posBookingTableTran_SelectAll", sqlCon);
				}
				SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@linktoBookingMasterId", SqlDbType.Int).Value = this.linktoBookingMasterId;
                SqlCmd.Parameters.Add("@linktoCounterMasterId", SqlDbType.SmallInt).Value = this.linktoCounterMasterId;
                SqlCmd.Parameters.Add("@linktoOrderTypeMasterId", SqlDbType.SmallInt).Value = this.linktoOrderTypeMasterId;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = linktoBusinessMasterId;

				if (sqlCon == null)
				{
					SqlCon.Open();
				}
				SqlRdr = SqlCmd.ExecuteReader();
				List<posBookingTableTranDAL> lstBookingTableTranDAL = SetListPropertiesFromSqlDataReader(SqlRdr);
				SqlRdr.Close();
				if (sqlCon == null)
				{
					SqlCon.Close();
				}

				return lstBookingTableTranDAL;
			}
			catch (Exception ex)
			{
				posGlobalsDAL.SaveError(ex);
				return null;
			}
			finally
			{
				posObjectFactoryDAL.DisposeDataReader(SqlRdr);
				posObjectFactoryDAL.DisposeCommand(SqlCmd);
				if (sqlCon == null)
				{
					posObjectFactoryDAL.DisposeConnection(SqlCon);
				}
			}
		}
		#endregion
	}
}
