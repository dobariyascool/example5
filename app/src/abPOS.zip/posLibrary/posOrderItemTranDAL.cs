using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;

namespace posLibrary
{
    /// <summary>
    /// Class for posOrderItemTran
    /// </summary>
    public class posOrderItemTranDAL
    {
        #region Properties
        public long OrderItemTranId { get; set; }
        public long linktoOrderMasterId { get; set; }
        public int linktoItemMasterId { get; set; }
        public short Quantity { get; set; }
        public double Rate { get; set; }
        public short ItemPoint { get; set; }
        public short DeductedPoint { get; set; }
        public string ItemRemark { get; set; }
        public short? linktoOrderStatusMasterId { get; set; }
        public DateTime? UpdateDateTime { get; set; }
        public short? linktoUserMasterIdUpdatedBy { get; set; }

        /// Extra
        public string OrderNumber { get; set; }
        public string ItemName { get; set; }
        public string ItemCode { get; set; }
        public short ItemType { get; set; }
        public string OrderStatus { get; set; }
        public string PrinterName { get; set; }
        public short PageSize { get; set; }
        public short NumberOfCopy { get; set; }
        public string OrderItemTranIds { get; set; }
        public string ModifierRates { get; set; }
        public short RateIndex { get; set; }

        #endregion

        #region Class Methods
        private List<posOrderItemTranDAL> SetListPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            List<posOrderItemTranDAL> lstOrderItemTran = new List<posOrderItemTranDAL>();
            posOrderItemTranDAL objOrderItemTran = null;
            while (sqlRdr.Read())
            {
                objOrderItemTran = new posOrderItemTranDAL();
                objOrderItemTran.OrderItemTranId = Convert.ToInt64(sqlRdr["OrderItemTranId"]);
                objOrderItemTran.linktoOrderMasterId = Convert.ToInt64(sqlRdr["linktoOrderMasterId"]);
                objOrderItemTran.linktoItemMasterId = Convert.ToInt32(sqlRdr["linktoItemMasterId"]);
                objOrderItemTran.Quantity = Convert.ToInt16(sqlRdr["Quantity"]);
                objOrderItemTran.Rate = Convert.ToDouble(sqlRdr["Rate"]);
                objOrderItemTran.ItemPoint = Convert.ToInt16(sqlRdr["ItemPoint"]);
                objOrderItemTran.DeductedPoint = Convert.ToInt16(sqlRdr["DeductedPoint"]);
                objOrderItemTran.ItemRemark = Convert.ToString(sqlRdr["ItemRemark"]);
                if (sqlRdr["linktoOrderStatusMasterId"] != DBNull.Value)
                {
                    objOrderItemTran.linktoOrderStatusMasterId = Convert.ToInt16(sqlRdr["linktoOrderStatusMasterId"]);
                }
                if (sqlRdr["UpdateDateTime"] != DBNull.Value)
                {
                    objOrderItemTran.UpdateDateTime = Convert.ToDateTime(sqlRdr["UpdateDateTime"]);
                }
                if (sqlRdr["linktoUserMasterIdUpdatedBy"] != DBNull.Value)
                {
                    objOrderItemTran.linktoUserMasterIdUpdatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdUpdatedBy"]);
                }

                /// Extra
                objOrderItemTran.OrderNumber = Convert.ToString(sqlRdr["OrderNumber"]);
                objOrderItemTran.ItemName = Convert.ToString(sqlRdr["Item"]);
                objOrderItemTran.OrderStatus = Convert.ToString(sqlRdr["OrderStatus"]);
                lstOrderItemTran.Add(objOrderItemTran);
            }
            return lstOrderItemTran;
        }
        #endregion

        #region Insert
        public static posRecordStatus InsertOrderItemTran(List<posOrderItemDAL> lstOrderItemTranDAL, List<posOrderItemDAL> lstOrderItemModifierTranDAL, long linktoOrderMasterId, short? RateIndex, short? linktoOrderStatusMasterId, SqlConnection SqlCon, SqlTransaction SqlTran)
        {
            SqlCommand SqlCmd = null;
            posRecordStatus rs = posRecordStatus.Error;
            //double discountItemRate = 0;

            try
            {
                SqlCmd = new SqlCommand("posOrderItemTran_Insert", SqlCon, SqlTran);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                if (lstOrderItemTranDAL != null || lstOrderItemTranDAL.Count > 0)
                {
                    foreach (posOrderItemDAL objItemMasterDAL in lstOrderItemTranDAL)
                    {
                        SqlCmd.Parameters.Clear();
                        SqlCmd.Parameters.Add("@OrderItemTranId", SqlDbType.Int).Direction = ParameterDirection.Output;
                        SqlCmd.Parameters.Add("@linktoOrderMasterId", SqlDbType.BigInt).Value = linktoOrderMasterId;
                        SqlCmd.Parameters.Add("@linktoItemMasterId", SqlDbType.Int).Value = objItemMasterDAL.ItemMasterId;
                        SqlCmd.Parameters.Add("@Quantity", SqlDbType.SmallInt).Value = objItemMasterDAL.Quantity;
                        SqlCmd.Parameters.Add("@Rate", SqlDbType.Money).Value = objItemMasterDAL.SaleRate;
                        //if (RateIndex == null || RateIndex == 0)
                        //{
                        //    SqlCmd.Parameters.Add("@Rate", SqlDbType.Money).Value = objItemMasterDAL.MRP;
                        //    double.TryParse(objItemMasterDAL.MRP.ToString(), out discountItemRate);
                        //}
                        //else
                        //{
                        //    switch (RateIndex)
                        //    {
                        //        case 1:
                        //            SqlCmd.Parameters.Add("@Rate", SqlDbType.Money).Value = objItemMasterDAL.Rate1;
                        //            discountItemRate = objItemMasterDAL.Rate1;
                        //            break;
                        //        case 2:
                        //            SqlCmd.Parameters.Add("@Rate", SqlDbType.Money).Value = objItemMasterDAL.Rate2;
                        //            discountItemRate = objItemMasterDAL.Rate2;
                        //            break;
                        //        case 3:
                        //            SqlCmd.Parameters.Add("@Rate", SqlDbType.Money).Value = objItemMasterDAL.Rate3;
                        //            discountItemRate = objItemMasterDAL.Rate3;
                        //            break;
                        //        case 4:
                        //            SqlCmd.Parameters.Add("@Rate", SqlDbType.Money).Value = objItemMasterDAL.Rate4;
                        //            discountItemRate = objItemMasterDAL.Rate4;
                        //            break;
                        //        case 5:
                        //            SqlCmd.Parameters.Add("@Rate", SqlDbType.Money).Value = objItemMasterDAL.Rate5;
                        //            discountItemRate = objItemMasterDAL.Rate5;
                        //            break;
                        //    }
                        //}

                        if (objItemMasterDAL.IsDiscountPercentage)
                        {
                            //discountItemRate = (discountItemRate * objItemMasterDAL.Discount) / 100;
                            SqlCmd.Parameters.Add("@DiscountPercentage", SqlDbType.Money).Value = objItemMasterDAL.DiscountPercentage;
                            //SqlCmd.Parameters.Add("@DiscountPercentage", SqlDbType.Money).Value = discountItemRate;
                            SqlCmd.Parameters.Add("@DiscountAmount", SqlDbType.Money).Value = (objItemMasterDAL.SaleRate * objItemMasterDAL.DiscountPercentage) / 100;
                        }
                        else
                        {
                            SqlCmd.Parameters.Add("@DiscountPercentage", SqlDbType.Money).Value = 0;
                            SqlCmd.Parameters.Add("@DiscountAmount", SqlDbType.Money).Value = objItemMasterDAL.DiscountPercentage;
                        }
                        SqlCmd.Parameters.Add("@IsRateTaxInclusive", SqlDbType.Bit).Value = objItemMasterDAL.IsRateTaxInclusive;
                        //SqlCmd.Parameters.Add("@Tax1", SqlDbType.Money).Value = objItemMasterDAL.TaxAmt1;
                        //SqlCmd.Parameters.Add("@Tax2", SqlDbType.Money).Value = objItemMasterDAL.TaxAmt2;
                        //SqlCmd.Parameters.Add("@Tax3", SqlDbType.Money).Value = objItemMasterDAL.TaxAmt3;
                        //SqlCmd.Parameters.Add("@Tax4", SqlDbType.Money).Value = objItemMasterDAL.TaxAmt4;
                        //SqlCmd.Parameters.Add("@Tax5", SqlDbType.Money).Value = objItemMasterDAL.TaxAmt5;
                        //SqlCmd.Parameters.Add("@AddLessAmount", SqlDbType.Money).Value = objItemMasterDAL.AddLessAmount;
                        SqlCmd.Parameters.Add("@ItemPoint", SqlDbType.SmallInt).Value = 0;
                        SqlCmd.Parameters.Add("@DeductedPoint", SqlDbType.SmallInt).Value = 0;
                        string Remark = string.Empty;
                        if (!string.IsNullOrEmpty(objItemMasterDAL.ItemOptions))
                        {
                            Remark += objItemMasterDAL.ItemOptions;
                        }
                        if (!string.IsNullOrEmpty(objItemMasterDAL.Remark))
                        {
                            if (!string.IsNullOrEmpty(Remark))
                            {
                                Remark += ", ";
                            }
                            Remark += objItemMasterDAL.Remark;
                        }
                        SqlCmd.Parameters.Add("@ItemRemark", SqlDbType.VarChar).Value = Remark;
                        SqlCmd.Parameters.Add("@linktoOrderStatusMasterId", SqlDbType.SmallInt).Value = linktoOrderStatusMasterId;
                        SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;
                        SqlCmd.ExecuteNonQuery();

                        rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                        int OrderItemTranId = Convert.ToInt32(SqlCmd.Parameters["@OrderItemTranId"].Value);
                        if (rs != posRecordStatus.Success)
                        {
                            return rs;
                        }

                        List<posOrderItemDAL> lstOrderItemModifierTranDAL2 = new List<posOrderItemDAL>();
                        lstOrderItemModifierTranDAL2 = lstOrderItemModifierTranDAL.Where(i => i.ItemMasterId == objItemMasterDAL.ItemMasterId && i.OrderId == objItemMasterDAL.OrderId).ToList();
                        if (lstOrderItemModifierTranDAL2.Count > 0)
                        {
                            rs = posOrderItemModifierTranDAL.DeleteOrderItemModifierTran(OrderItemTranId, SqlCon, SqlTran);
                            if (rs != posRecordStatus.Success)
                            {
                                return rs;
                            }

                            rs = posOrderItemModifierTranDAL.InsertOrderItemModifierTran(lstOrderItemModifierTranDAL2, OrderItemTranId, SqlCon, SqlTran);
                            if (rs != posRecordStatus.Success)
                            {
                                return rs;
                            }
                        }
                    }
                }
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
            }
        }
        #endregion

        #region Update
        public posRecordStatus UpdateOrderItemTranAndOrderMasterOrderStatus()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posOrderItemTranAndOrderMasterOrderStatus_Update", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;


                SqlCmd.Parameters.Add("@linktoOrderMasterId", SqlDbType.BigInt).Value = this.linktoOrderMasterId;
                SqlCmd.Parameters.Add("@linktoOrderStatusMasterId", SqlDbType.SmallInt).Value = this.linktoOrderStatusMasterId;
                SqlCmd.Parameters.Add("@UpdateDateTime", SqlDbType.DateTime).Value = this.UpdateDateTime;
                SqlCmd.Parameters.Add("@linktoUserMasterIdUpdatedBy", SqlDbType.SmallInt).Value = this.linktoUserMasterIdUpdatedBy;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public posRecordStatus UpdateOrderItemTranOrderStatus()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posOrderItemTranbyOrderStatus_Update", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;


                SqlCmd.Parameters.Add("@OrderItemTranIds", SqlDbType.VarChar).Value = this.OrderItemTranIds;
                SqlCmd.Parameters.Add("@linktoOrderStatusMasterId", SqlDbType.SmallInt).Value = this.linktoOrderStatusMasterId;
                SqlCmd.Parameters.Add("@UpdateDateTime", SqlDbType.DateTime).Value = this.UpdateDateTime;
                SqlCmd.Parameters.Add("@linktoUserMasterIdUpdatedBy", SqlDbType.SmallInt).Value = this.linktoUserMasterIdUpdatedBy;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region Delete
        public static posRecordStatus DeleteOrderItemTran(long linktoOrderMasterId, SqlConnection SqlCon, SqlTransaction SqlTran)
        {
            SqlCommand SqlCmd = null;
            try
            {
                SqlCmd = new SqlCommand("posOrderItemTran_Delete", SqlCon, SqlTran);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@linktoOrderMasterId", SqlDbType.BigInt).Value = linktoOrderMasterId;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCmd.ExecuteNonQuery();

                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
            }
        }
        #endregion

        #region SelectAll
        public List<posOrderItemTranDAL> SelectAllOrderItemTran()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posOrderItemTran_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                if (this.linktoOrderMasterId > 0)
                {
                    SqlCmd.Parameters.Add("@linktoOrderMasterId", SqlDbType.SmallInt).Value = this.linktoOrderMasterId;
                }

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<posOrderItemTranDAL> lstOrderItemTranDAL = SetListPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                return lstOrderItemTranDAL;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public List<posOrderItemTranDAL> SelectAllOrderItemKOTBlock()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posOrderItemTranKOTBlock_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();

                List<posOrderItemTranDAL> lstOrderItemTran = new List<posOrderItemTranDAL>();
                posOrderItemTranDAL objOrderItemTran = null;
                while (SqlRdr.Read())
                {
                    objOrderItemTran = new posOrderItemTranDAL();
                    objOrderItemTran.OrderItemTranId = Convert.ToInt64(SqlRdr["OrderItemTranId"]);
                    objOrderItemTran.linktoOrderMasterId = Convert.ToInt64(SqlRdr["linktoOrderMasterId"]);
                    objOrderItemTran.linktoItemMasterId = Convert.ToInt32(SqlRdr["linktoItemMasterId"]);
                    objOrderItemTran.Quantity = Convert.ToInt16(SqlRdr["Quantity"]);
                    objOrderItemTran.ItemRemark = Convert.ToString(SqlRdr["ItemRemark"]);
                    if (SqlRdr["linktoOrderStatusMasterId"] != DBNull.Value)
                    {
                        objOrderItemTran.linktoOrderStatusMasterId = Convert.ToInt16(SqlRdr["linktoOrderStatusMasterId"]);
                    }
                    /// Extra
                    objOrderItemTran.OrderNumber = Convert.ToString(SqlRdr["OrderNumber"]);
                    objOrderItemTran.ItemName = Convert.ToString(SqlRdr["Item"]);
                    objOrderItemTran.OrderStatus = Convert.ToString(SqlRdr["OrderStatus"]);
                    //objOrderItemTran.WaiterName = Convert.ToString(SqlRdr["WaiterName"]);
                    //objOrderItemTran.TableName = Convert.ToString(SqlRdr["TableName"]);

                    lstOrderItemTran.Add(objOrderItemTran);
                }

                SqlCon.Close();

                return lstOrderItemTran;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public List<posOrderItemTranDAL> SelectAllOrderMasterOrderItemTranReport(DateTime fromDate, DateTime toDate, short counterMasterId)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posOrderMasterOrderItemTranReport_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;
                SqlCmd.Parameters.Add("@CounterMasterId", SqlDbType.SmallInt).Value = counterMasterId;
                SqlCmd.Parameters.Add("@FromDate", SqlDbType.DateTime).Value = fromDate;
                SqlCmd.Parameters.Add("@ToDate", SqlDbType.DateTime).Value = toDate;
                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();

                List<posOrderItemTranDAL> lstOrderItemTran = new List<posOrderItemTranDAL>();
                posOrderItemTranDAL objOrderItemTran = null;
                while (SqlRdr.Read())
                {
                    objOrderItemTran = new posOrderItemTranDAL();
                    objOrderItemTran.linktoItemMasterId = Convert.ToInt32(SqlRdr["ItemMasterId"]);
                    objOrderItemTran.ItemName = Convert.ToString(SqlRdr["ItemName"]);
                    objOrderItemTran.ItemCode = Convert.ToString(SqlRdr["ItemCode"]);
                    objOrderItemTran.Quantity = Convert.ToInt16(SqlRdr["Quantity"]);
                    objOrderItemTran.Rate = Convert.ToDouble(SqlRdr["Amount"]);

                    lstOrderItemTran.Add(objOrderItemTran);
                }

                SqlCon.Close();

                return lstOrderItemTran;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public List<posOrderItemTranDAL> SelectAllOrderItemTranByOrderMasterId(string orderMasterIds)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posOrderItemTranByOrderMasterId_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;


                SqlCmd.Parameters.Add("@OrderMasterIds", SqlDbType.VarChar).Value = orderMasterIds;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();

                List<posOrderItemTranDAL> lstOrderItemTran = new List<posOrderItemTranDAL>();
                posOrderItemTranDAL objOrderItemTran = null;
                while (SqlRdr.Read())
                {
                    objOrderItemTran = new posOrderItemTranDAL();
                    objOrderItemTran.OrderNumber = Convert.ToString(SqlRdr["OrderNumber"]);
                    objOrderItemTran.ItemName = Convert.ToString(SqlRdr["ItemName"]);
                    objOrderItemTran.Quantity = Convert.ToInt16(SqlRdr["Quantity"]);
                    if (SqlRdr["RateIndex"] != DBNull.Value)
                    {
                        objOrderItemTran.RateIndex = Convert.ToInt16(SqlRdr["RateIndex"]);
                    }
                    objOrderItemTran.Rate = Convert.ToDouble(SqlRdr["Rate"]);
                    objOrderItemTran.linktoItemMasterId = Convert.ToInt16(SqlRdr["linktoItemMasterId"]);
                    objOrderItemTran.linktoOrderMasterId = Convert.ToInt64(SqlRdr["linktoOrderMasterId"]);
                    if (SqlRdr["linktoOrderStatusMasterId"] != DBNull.Value)
                    {
                        objOrderItemTran.linktoOrderStatusMasterId = Convert.ToInt16(SqlRdr["linktoOrderStatusMasterId"]);
                    }
                    objOrderItemTran.OrderItemTranIds = Convert.ToString(SqlRdr["OrderItemTranIds"]);
                    objOrderItemTran.ModifierRates = Convert.ToString(SqlRdr["ModifierRates"]);
                    lstOrderItemTran.Add(objOrderItemTran);
                }
                SqlRdr.Close();
                SqlCon.Close();

                return lstOrderItemTran;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public List<posOrderItemTranDAL> SelectAllOrderItemTranKOTPrintByOrderMasterIdReport()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posOrderItemTranKOTPrint_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@linktoOrderMasterId", SqlDbType.SmallInt).Value = this.linktoOrderMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();

                List<posOrderItemTranDAL> lstOrderItemTran = new List<posOrderItemTranDAL>();
                posOrderItemTranDAL objOrderItemTran = null;
                while (SqlRdr.Read())
                {
                    objOrderItemTran = new posOrderItemTranDAL();

                    objOrderItemTran.ItemName = Convert.ToString(SqlRdr["ItemName"]);
                    objOrderItemTran.Quantity = Convert.ToInt16(SqlRdr["Quantity"]);
                    objOrderItemTran.linktoItemMasterId = Convert.ToInt16(SqlRdr["linktoItemMasterId"]);
                    objOrderItemTran.PrinterName = Convert.ToString(SqlRdr["PrinterName"]);
                    objOrderItemTran.PageSize = Convert.ToInt16(SqlRdr["PageSize"]);
                    objOrderItemTran.NumberOfCopy = Convert.ToInt16(SqlRdr["NumberOfCopy"]);
                    objOrderItemTran.ItemType = Convert.ToInt16(SqlRdr["ItemType"]);

                    lstOrderItemTran.Add(objOrderItemTran);
                }
                SqlRdr.Close();
                SqlCon.Close();

                return lstOrderItemTran;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        //public List<posOrderItemTranDAL> SelectAllOrderMasterKOTPrintHeaderByOrderMasterIdReport()
        //{
        //    SqlConnection SqlCon = null;
        //    SqlCommand SqlCmd = null;
        //    SqlDataReader SqlRdr = null;
        //    try
        //    {
        //        SqlCon = posObjectFactoryDAL.CreateConnection();
        //        SqlCmd = new SqlCommand("posOrderMasterKOTPrintHeader_SelectAll", SqlCon);
        //        SqlCmd.CommandType = CommandType.StoredProcedure;


        //        SqlCmd.Parameters.Add("@linktoOrderMasterId", SqlDbType.SmallInt).Value = this.linktoOrderMasterId;

        //        SqlCon.Open();
        //        SqlRdr = SqlCmd.ExecuteReader();

        //        List<posOrderItemTranDAL> lstOrderItemTran = new List<posOrderItemTranDAL>();
        //        posOrderItemTranDAL objOrderItemTran = null;
        //        while (SqlRdr.Read())
        //        {
        //            objOrderItemTran = new posOrderItemTranDAL();
        //            objOrderItemTran.OrderNumber = Convert.ToString(SqlRdr["OrderNumber"]);
        //            objOrderItemTran.TableName = Convert.ToString(SqlRdr["TableName"]);
        //            objOrderItemTran.OrderType = Convert.ToString(SqlRdr["OrderType"]);
        //            objOrderItemTran.WaiterName = Convert.ToString(SqlRdr["WaiterName"]);
        //            objOrderItemTran.OrderDateTime = Convert.ToDateTime(SqlRdr["OrderDateTime"]).ToShortDateString() + " " + Convert.ToDateTime(SqlRdr["OrderDateTime"]).ToShortTimeString();
        //            lstOrderItemTran.Add(objOrderItemTran);
        //        }
        //        SqlRdr.Close();
        //        SqlCon.Close();

        //        return lstOrderItemTran;
        //    }
        //    catch (Exception ex)
        //    {
        //        posGlobalsDAL.SaveError(ex);
        //        return null;
        //    }
        //    finally
        //    {
        //        posObjectFactoryDAL.DisposeDataReader(SqlRdr);
        //        posObjectFactoryDAL.DisposeCommand(SqlCmd);
        //        posObjectFactoryDAL.DisposeConnection(SqlCon);
        //    }
        //}
        #endregion
    }
}
