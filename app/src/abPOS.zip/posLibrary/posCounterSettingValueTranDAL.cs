using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace posLibrary
{
    /// <summary>
    /// Class for posCounterSettingValueTran
    /// </summary>
    public class posCounterSettingValueTranDAL
    {
        #region Properties
        public short CounterSettingValueTranId { get; set; }
        public short linktoCounterMasterId { get; set; }
        public short linktoCounterSettingMasterId { get; set; }
        public string Value { get; set; }

        /// Extra
        public string Counter { get; set; }
        public DateTime DayEndDateTime { get; set; }
        #endregion

        #region Insert
        public static posRecordStatus InsertCounterSettingValueTran(short counterMasterId, List<posCounterSettingValueTranDAL> lstCounterSettingValueTran, SqlConnection sqlCon, SqlTransaction sqlTran)
        {
            SqlCommand SqlCmd = null;
            try
            {
                posRecordStatus rs = posRecordStatus.RecordNotFound;
                foreach (posCounterSettingValueTranDAL obj in lstCounterSettingValueTran)
                {

                    SqlCmd = new SqlCommand("posCounterSettingValueTran_Insert", sqlCon, sqlTran);
                    SqlCmd.CommandType = CommandType.StoredProcedure;

                    SqlCmd.Parameters.Add("@CounterSettingValueTranId", SqlDbType.SmallInt).Direction = ParameterDirection.Output;
                    SqlCmd.Parameters.Add("@linktoCounterMasterId", SqlDbType.SmallInt).Value = counterMasterId;
                    SqlCmd.Parameters.Add("@linktoCounterSettingMasterId", SqlDbType.SmallInt).Value = obj.linktoCounterSettingMasterId;
                    SqlCmd.Parameters.Add("@Value", SqlDbType.VarChar).Value = obj.Value;
                    SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                    SqlCmd.ExecuteNonQuery();

                    obj.CounterSettingValueTranId = Convert.ToInt16(SqlCmd.Parameters["@CounterSettingValueTranId"].Value);
                    rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                    if (rs != posRecordStatus.Success)
                    {
                        return rs;
                    }
                }
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
            }
        }
        #endregion

        #region Delete
        public posRecordStatus DeleteCounterSettingValueTran(SqlConnection sqlCon, SqlTransaction sqlTran)
        {
            SqlCommand SqlCmd = null;
            try
            {
                SqlCmd = new SqlCommand("posCounterSettingValueTran_Delete", sqlCon, sqlTran);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@linktoCounterMasterId", SqlDbType.SmallInt).Value = this.linktoCounterMasterId;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCmd.ExecuteNonQuery();

                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
            }
        }
        #endregion

        #region SelectAll
        public List<posCounterSettingValueTranDAL> SelectAllCounterSettingValueTranByCounterMasterId()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posCounterSettingValueTranCounterWise_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@linktoCounterMasterId", SqlDbType.SmallInt).Value = this.linktoCounterMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<posCounterSettingValueTranDAL> lstCounterSettingValueTranDAL = new List<posCounterSettingValueTranDAL>();
                posCounterSettingValueTranDAL objCounterSettingValueTran = null;
                while (SqlRdr.Read())
                {
                    objCounterSettingValueTran = new posCounterSettingValueTranDAL();
                    if (SqlRdr["CounterSettingValueTranId"] != DBNull.Value)
                    {
                        objCounterSettingValueTran.CounterSettingValueTranId = Convert.ToInt16(SqlRdr["CounterSettingValueTranId"]);
                    }
                    if (SqlRdr["linktoCounterMasterId"] != DBNull.Value)
                    {
                        objCounterSettingValueTran.linktoCounterMasterId = Convert.ToInt16(SqlRdr["linktoCounterMasterId"]);
                    }
                    objCounterSettingValueTran.linktoCounterSettingMasterId = Convert.ToInt16(SqlRdr["CounterSettingMasterId"]);
                    objCounterSettingValueTran.Value = Convert.ToString(SqlRdr["Value"]);

                    lstCounterSettingValueTranDAL.Add(objCounterSettingValueTran);

                }
                SqlRdr.Close();
                SqlCon.Close();

                return lstCounterSettingValueTranDAL;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public List<posCounterSettingValueTranDAL> SelectAllCounterSettingValueTranDayEndCounter()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posCounterSettingValueTranDayEndCounter_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@linktoCounterSettingMasterId", SqlDbType.SmallInt).Value = this.linktoCounterSettingMasterId;
                SqlCmd.Parameters.Add("@CurrentDate", SqlDbType.DateTime).Value = posGlobalsDAL.GetCurrentDateTime();
                SqlCmd.Parameters.Add("@linktoUserMasterId", SqlDbType.SmallInt).Value = posGlobalsDAL.UserInfo.UserMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<posCounterSettingValueTranDAL> lstCounterSettingValueTranDAL = new List<posCounterSettingValueTranDAL>();
                posCounterSettingValueTranDAL objCounterSettingValueTran = null;
                while (SqlRdr.Read())
                {
                    objCounterSettingValueTran = new posCounterSettingValueTranDAL();

                    if (SqlRdr["CounterMasterId"] != DBNull.Value)
                    {
                        objCounterSettingValueTran.linktoCounterMasterId = Convert.ToInt16(SqlRdr["CounterMasterId"]);
                    }
                    objCounterSettingValueTran.Counter = Convert.ToString(SqlRdr["CounterName"]);
                    if (SqlRdr["DayEndDateTime"] != DBNull.Value)
                    {
                        objCounterSettingValueTran.DayEndDateTime = Convert.ToDateTime(Convert.ToDateTime(SqlRdr["DayEndDateTime"]).ToShortDateString());
                    }

                    lstCounterSettingValueTranDAL.Add(objCounterSettingValueTran);

                }
                SqlRdr.Close();
                SqlCon.Close();

                return lstCounterSettingValueTranDAL;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion
    }
}
