using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace posLibrary
{
    /// <summary>
    /// Class for posDiscountMaster
    /// </summary>
    public class posDiscountMasterDAL
    {
        #region Properties
        public int DiscountMasterId { get; set; }
        public short linktoBusinessMasterId { get; set; }
        public string DiscountTitle { get; set; }
        public DateTime CreateDateTime { get; set; }
        public int linktoUserMasterIdCreatedBy { get; set; }
        public DateTime? UpdateDateTime { get; set; }
        public int? linktoUserMasterIdUpdatedBy { get; set; }
        #endregion

        #region Class Methods
        private bool SetClassPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            if (sqlRdr.Read())
            {
                this.DiscountMasterId = Convert.ToInt32(sqlRdr["DiscountMasterId"]);
                this.linktoBusinessMasterId = Convert.ToInt16(sqlRdr["linktoBusinessMasterId"]);
                this.DiscountTitle = Convert.ToString(sqlRdr["DiscountTitle"]);

                return true;
            }
            return false;
        }

        private List<posDiscountMasterDAL> SetListPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            List<posDiscountMasterDAL> lstDiscountMaster = new List<posDiscountMasterDAL>();
            posDiscountMasterDAL objDiscountMaster = null;
            while (sqlRdr.Read())
            {
                objDiscountMaster = new posDiscountMasterDAL();
                objDiscountMaster.DiscountMasterId = Convert.ToInt32(sqlRdr["DiscountMasterId"]);
                objDiscountMaster.DiscountTitle = Convert.ToString(sqlRdr["DiscountTitle"]);

                lstDiscountMaster.Add(objDiscountMaster);
            }
            return lstDiscountMaster;
        }
        #endregion

        #region Insert
        public posRecordStatus InsertDiscountMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posDiscountMaster_Insert", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@DiscountMasterId", SqlDbType.Int).Direction = ParameterDirection.Output;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCmd.Parameters.Add("@DiscountTitle", SqlDbType.VarChar).Value = this.DiscountTitle;
                SqlCmd.Parameters.Add("@CreateDateTime", SqlDbType.DateTime).Value = this.CreateDateTime;
                SqlCmd.Parameters.Add("@linktoUserMasterIdCreatedBy", SqlDbType.Int).Value = this.linktoUserMasterIdCreatedBy;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                this.DiscountMasterId = Convert.ToInt32(SqlCmd.Parameters["@DiscountMasterId"].Value);
                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region Update
        public posRecordStatus UpdateDiscountMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posDiscountMaster_Update", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@DiscountMasterId", SqlDbType.Int).Value = this.DiscountMasterId;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCmd.Parameters.Add("@DiscountTitle", SqlDbType.VarChar).Value = this.DiscountTitle;
                SqlCmd.Parameters.Add("@UpdateDateTime", SqlDbType.DateTime).Value = this.UpdateDateTime;
                SqlCmd.Parameters.Add("@linktoUserMasterIdUpdatedBy", SqlDbType.Int).Value = this.linktoUserMasterIdUpdatedBy;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region DeleteAll
        public posRecordStatus DeleteAllDiscountMaster(string discountMasterIds)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posDiscountMaster_DeleteAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@DiscountMasterIds", SqlDbType.VarChar).Value = discountMasterIds;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region Select
        public bool SelectDiscountMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posDiscountMaster_Select", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@DiscountMasterId", SqlDbType.Int).Value = this.DiscountMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                bool IsSelected = SetClassPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                return IsSelected;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return false;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region SelectAll
        public List<posDiscountMasterDAL> SelectAllDiscountMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posDiscountMaster_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<posDiscountMasterDAL> lstDiscountMasterDAL = SetListPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                return lstDiscountMasterDAL;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public static List<posDiscountMasterDAL> SelectAllDiscountMasterDiscountTitle(short linktoBusinessMasterId)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posDiscountMasterDiscountTitle_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = linktoBusinessMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<posDiscountMasterDAL> lstDiscountMasterDAL = new List<posDiscountMasterDAL>();
                posDiscountMasterDAL objDiscountMasterDAL = null;
                while (SqlRdr.Read())
                {
                    objDiscountMasterDAL = new posDiscountMasterDAL();
                    objDiscountMasterDAL.DiscountMasterId = Convert.ToInt32(SqlRdr["DiscountMasterId"]);
                    objDiscountMasterDAL.DiscountTitle = Convert.ToString(SqlRdr["DiscountTitle"]);
                    lstDiscountMasterDAL.Add(objDiscountMasterDAL);
                }
                SqlRdr.Close();
                SqlCon.Close();

                return lstDiscountMasterDAL;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion
    }
}
