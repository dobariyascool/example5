using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace posLibrary
{
    /// <summary>
    /// Class for posItemStockTran
    /// </summary>
    public class posItemStockTranDAL
    {
        #region Properties
        public int ItemStockTranId { get; set; }
        public int linktoItemMasterId { get; set; }
        public short linktoUnitMasterId { get; set; }
        public short linktoDepartmentMasterId { get; set; }
        public bool IsMaintainStock { get; set; }
        public double OpeningStock { get; set; }
        public double InHand { get; set; }
        public double MinimumStock { get; set; }
        public double MaximumStock { get; set; }
        public DateTime CreateDateTime { get; set; }
        public short linktoUserMasterIdCreatedBy { get; set; }
        public DateTime? UpdatedDateTime { get; set; }
        public short? linktoUserMasterIdUpdatedBy { get; set; }

        /// Extra
        public string Item { get; set; }
        public string Unit { get; set; }
        public string Department { get; set; }
        public string Category { get; set; }
        public string Reorder { get; set; }
        public string CategoryMasterIDs { get; set; }
        #endregion

        #region Class Methods
        private List<posItemStockTranDAL> SetListPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            List<posItemStockTranDAL> lstItemStockTran = new List<posItemStockTranDAL>();
            posItemStockTranDAL objItemStockTran = null;
            while (sqlRdr.Read())
            {
                objItemStockTran = new posItemStockTranDAL();
                objItemStockTran.ItemStockTranId = Convert.ToInt32(sqlRdr["ItemStockTranId"]);
                objItemStockTran.linktoItemMasterId = Convert.ToInt32(sqlRdr["linktoItemMasterId"]);
                objItemStockTran.linktoUnitMasterId = Convert.ToInt16(sqlRdr["linktoUnitMasterId"]);
                objItemStockTran.linktoDepartmentMasterId = Convert.ToInt16(sqlRdr["linktoDepartmentMasterId"]);
                objItemStockTran.IsMaintainStock = Convert.ToBoolean(sqlRdr["IsMaintainStock"]);
                objItemStockTran.OpeningStock = Convert.ToDouble(sqlRdr["OpeningStock"]);
                objItemStockTran.InHand = Convert.ToDouble(sqlRdr["InHand"]);
                objItemStockTran.MinimumStock = Convert.ToDouble(sqlRdr["MinimumStock"]);
                objItemStockTran.MaximumStock = Convert.ToDouble(sqlRdr["MaximumStock"]);
                objItemStockTran.CreateDateTime = Convert.ToDateTime(sqlRdr["CreateDateTime"]);
                objItemStockTran.linktoUserMasterIdCreatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdCreatedBy"]);
                if (sqlRdr["UpdatedDateTime"] != DBNull.Value)
                {
                    objItemStockTran.UpdatedDateTime = Convert.ToDateTime(sqlRdr["UpdatedDateTime"]);
                }
                if (sqlRdr["linktoUserMasterIdUpdatedBy"] != DBNull.Value)
                {
                    objItemStockTran.linktoUserMasterIdUpdatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdUpdatedBy"]);
                }

                /// Extra
                objItemStockTran.Item = Convert.ToString(sqlRdr["Item"]);
                objItemStockTran.Unit = Convert.ToString(sqlRdr["Unit"]);
                objItemStockTran.Department = Convert.ToString(sqlRdr["Department"]);
                lstItemStockTran.Add(objItemStockTran);
            }
            return lstItemStockTran;
        }
        #endregion

        #region Insert
        public static posRecordStatus InsertItemStockTran(posItemStockTranDAL objItemStockTran, int itemMasterId, SqlConnection sqlCon, SqlTransaction sqlTran)
        {
            SqlCommand SqlCmd = null;
            try
            {
                SqlCmd = new SqlCommand("posItemStockTran_Insert", sqlCon, sqlTran);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@ItemStockTranId", SqlDbType.Int).Direction = ParameterDirection.Output;
                SqlCmd.Parameters.Add("@linktoItemMasterId", SqlDbType.Int).Value = itemMasterId;
                SqlCmd.Parameters.Add("@linktoUnitMasterId", SqlDbType.SmallInt).Value = objItemStockTran.linktoUnitMasterId;
                SqlCmd.Parameters.Add("@linktoDepartmentMasterId", SqlDbType.SmallInt).Value = objItemStockTran.linktoDepartmentMasterId;
                SqlCmd.Parameters.Add("@IsMaintainStock", SqlDbType.Bit).Value = objItemStockTran.IsMaintainStock;
                SqlCmd.Parameters.Add("@OpeningStock", SqlDbType.Decimal).Value = objItemStockTran.OpeningStock;
                SqlCmd.Parameters.Add("@InHand", SqlDbType.Decimal).Value = objItemStockTran.InHand;
                SqlCmd.Parameters.Add("@MinimumStock", SqlDbType.Decimal).Value = objItemStockTran.MinimumStock;
                SqlCmd.Parameters.Add("@MaximumStock", SqlDbType.Decimal).Value = objItemStockTran.MaximumStock;
                SqlCmd.Parameters.Add("@linktoUserMasterIdCreatedBy", SqlDbType.Int).Value = posGlobalsDAL.UserInfo.BusinessMasterId;
                SqlCmd.Parameters.Add("@CreateDateTime", SqlDbType.DateTime).Value = posGlobalsDAL.GetCurrentDateTime();
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCmd.ExecuteNonQuery();

                objItemStockTran.ItemStockTranId = Convert.ToInt32(SqlCmd.Parameters["@ItemStockTranId"].Value);

                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;

            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
            }
        }
        #endregion

        #region Delete
        public static posRecordStatus DeleteItemStockTran(int itemMasterId, SqlConnection SqlCon, SqlTransaction sqlTran)
        {
            SqlCommand SqlCmd = null;
            try
            {
                SqlCmd = new SqlCommand("posItemStockTran_Delete", SqlCon, sqlTran);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@linktoItemMasterId", SqlDbType.Int).Value = itemMasterId;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCmd.ExecuteNonQuery();

                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
            }
        }
        #endregion

        #region SelectAll
        public List<posItemStockTranDAL> SelectAllItemStockTran()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posItemStockTran_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;
                SqlCmd.Parameters.Add("@linktoItemMasterId", SqlDbType.Int).Value = this.linktoItemMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<posItemStockTranDAL> lstItemStockTranDAL = SetListPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                return lstItemStockTranDAL;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public List<posItemStockTranDAL> SelectAllItemStockTranCategoryWiseReport(int linktoBusinessMasterId)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posItemStockTranCategoryWiseReport_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@CategoryMasterIDs", SqlDbType.VarChar).Value = this.CategoryMasterIDs;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.Int).Value = linktoBusinessMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<posItemStockTranDAL> lstItemStockTranDAL = new List<posItemStockTranDAL>();
                posItemStockTranDAL objItemStockTranDAL = null;
                while (SqlRdr.Read())
                {
                    objItemStockTranDAL = new posItemStockTranDAL();
                    objItemStockTranDAL.InHand = Convert.ToInt64(SqlRdr["InHand"]);
                    objItemStockTranDAL.MinimumStock = Convert.ToDouble(SqlRdr["MinimumStock"]);
                    objItemStockTranDAL.MaximumStock = Convert.ToDouble(SqlRdr["MaximumStock"]);
                    /// Extra
                    objItemStockTranDAL.Item = Convert.ToString(SqlRdr["ItemName"]);
                    objItemStockTranDAL.Category = Convert.ToString(SqlRdr["CategoryName"]);
                    objItemStockTranDAL.Reorder = Convert.ToString(SqlRdr["Reorder"]);
                    objItemStockTranDAL.Unit = Convert.ToString(SqlRdr["Unit"]);
                    lstItemStockTranDAL.Add(objItemStockTranDAL);
                }

                return lstItemStockTranDAL;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion
    }
}
