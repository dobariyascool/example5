using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace posLibrary
{
	/// <summary>
	/// Class for posPaymentTypeCateogryMaster
	/// </summary>
	public class posPaymentTypeCateogryMasterDAL
	{
		#region Properties
		public short PaymentTypeCategoryMasterId { get; set; }
		public string PaymentTypeCategory { get; set; }
		#endregion

        #region SelectAll
        public static List<posPaymentTypeCateogryMasterDAL> SelectAllPaymentTypeCateogryMasterPaymentTypeCategory()
		{
			SqlConnection SqlCon = null;
			SqlCommand SqlCmd = null;
			SqlDataReader SqlRdr = null;
			try
			{
				SqlCon = posObjectFactoryDAL.CreateConnection();
				SqlCmd = new SqlCommand("posPaymentTypeCateogryMasterPaymentTypeCategory_SelectAll", SqlCon);
				SqlCmd.CommandType = CommandType.StoredProcedure;

				SqlCon.Open();
				SqlRdr = SqlCmd.ExecuteReader();
				List<posPaymentTypeCateogryMasterDAL> lstPaymentTypeCateogryMasterDAL = new List<posPaymentTypeCateogryMasterDAL>();
				posPaymentTypeCateogryMasterDAL objPaymentTypeCateogryMasterDAL = null;
				while (SqlRdr.Read())
				{
					objPaymentTypeCateogryMasterDAL = new posPaymentTypeCateogryMasterDAL();
					objPaymentTypeCateogryMasterDAL.PaymentTypeCategoryMasterId = Convert.ToInt16(SqlRdr["PaymentTypeCategoryMasterId"]);
					objPaymentTypeCateogryMasterDAL.PaymentTypeCategory = Convert.ToString(SqlRdr["PaymentTypeCategory"]);
					lstPaymentTypeCateogryMasterDAL.Add(objPaymentTypeCateogryMasterDAL);
				}
				SqlRdr.Close();
				SqlCon.Close();

				return lstPaymentTypeCateogryMasterDAL;
			}
			catch (Exception ex)
			{
				posGlobalsDAL.SaveError(ex);
				return null;
			}
			finally
			{
				posObjectFactoryDAL.DisposeDataReader(SqlRdr);
				posObjectFactoryDAL.DisposeCommand(SqlCmd);
				posObjectFactoryDAL.DisposeConnection(SqlCon);
			}
        }
        #endregion
    }
}
