using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace posLibrary
{
    /// <summary>
    /// Class for posBankBookMaster
    /// </summary>
    public class posBankBookMasterDAL
    {
        #region Properties
        public int BankBookMasterId { get; set; }
        public short linktoBusinessMasterId { get; set; }
        public int linktoAccountMasterIdBank { get; set; }
        public string BankBookNumber { get; set; }
        public DateTime BankBookDate { get; set; }
        public string VoucherNumber { get; set; }
        public bool? IsPaid { get; set; }
        public int linktoAccountMasterId { get; set; }
        public double Amount { get; set; }
        public string ChequeNumber { get; set; }
        public int? linktoBankMasterId { get; set; }
        public string Remark { get; set; }
        public DateTime CreateDateTime { get; set; }
        public short linktoUserMasterIdCreatedBy { get; set; }
        public DateTime? UpdateDateTime { get; set; }
        public short? linktoUserMasterIdUpdatedBy { get; set; }

        /// Extra
        public string AccountBank { get; set; }
        public string Account { get; set; }
        public string Bank { get; set; }
        public int linktoAccountCategoryMasterId { get; set; }
        public int linktoAccountCategoryMasterId2 { get; set; }

        #endregion

        #region Class Methods
        private bool SetClassPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            if (sqlRdr.Read())
            {
                this.BankBookMasterId = Convert.ToInt32(sqlRdr["BankBookMasterId"]);
                this.linktoBusinessMasterId = Convert.ToInt16(sqlRdr["linktoBusinessMasterId"]);
                this.linktoAccountMasterIdBank = Convert.ToInt32(sqlRdr["linktoAccountMasterIdBank"]);
                this.BankBookNumber = Convert.ToString(sqlRdr["BankBookNumber"]);
                this.BankBookDate = Convert.ToDateTime(sqlRdr["BankBookDate"]);
                this.VoucherNumber = Convert.ToString(sqlRdr["VoucherNumber"]);
                if (sqlRdr["IsPaid"] != DBNull.Value)
                {
                    this.IsPaid = Convert.ToBoolean(sqlRdr["IsPaid"]);
                }
                this.linktoAccountMasterId = Convert.ToInt32(sqlRdr["linktoAccountMasterId"]);
                this.Amount = Convert.ToDouble(sqlRdr["Amount"]);
                this.ChequeNumber = Convert.ToString(sqlRdr["ChequeNumber"]);
                if (sqlRdr["linktoBankMasterId"] != DBNull.Value)
                {
                    this.linktoBankMasterId = Convert.ToInt32(sqlRdr["linktoBankMasterId"]);
                }
                this.Remark = Convert.ToString(sqlRdr["Remark"]);
                this.CreateDateTime = Convert.ToDateTime(sqlRdr["CreateDateTime"]);
                this.linktoUserMasterIdCreatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdCreatedBy"]);
                if (sqlRdr["UpdateDateTime"] != DBNull.Value)
                {
                    this.UpdateDateTime = Convert.ToDateTime(sqlRdr["UpdateDateTime"]);
                }
                if (sqlRdr["linktoUserMasterIdUpdatedBy"] != DBNull.Value)
                {
                    this.linktoUserMasterIdUpdatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdUpdatedBy"]);
                }

                /// Extra
                this.AccountBank = Convert.ToString(sqlRdr["AccountBank"]);
                this.Account = Convert.ToString(sqlRdr["Account"]);
                this.Bank = Convert.ToString(sqlRdr["Bank"]);
                this.linktoAccountCategoryMasterId = Convert.ToInt32(sqlRdr["linktoAccountCategoryMasterId"]);
                if (sqlRdr["linktoAccountCategoryMasterId2"] != DBNull.Value)
                {
                    this.linktoAccountCategoryMasterId2 = Convert.ToInt32(sqlRdr["linktoAccountCategoryMasterId2"]);
                }
                return true;
            }
            return false;
        }

        private List<posBankBookMasterDAL> SetListPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            List<posBankBookMasterDAL> lstBankBookMaster = new List<posBankBookMasterDAL>();
            posBankBookMasterDAL objBankBookMaster = null;
            while (sqlRdr.Read())
            {
                objBankBookMaster = new posBankBookMasterDAL();
                objBankBookMaster.BankBookMasterId = Convert.ToInt32(sqlRdr["BankBookMasterId"]);
                objBankBookMaster.linktoBusinessMasterId = Convert.ToInt16(sqlRdr["linktoBusinessMasterId"]);
                objBankBookMaster.linktoAccountMasterIdBank = Convert.ToInt32(sqlRdr["linktoAccountMasterIdBank"]);
                objBankBookMaster.BankBookNumber = Convert.ToString(sqlRdr["BankBookNumber"]);
                objBankBookMaster.BankBookDate = Convert.ToDateTime(sqlRdr["BankBookDate"]);
                objBankBookMaster.VoucherNumber = Convert.ToString(sqlRdr["VoucherNumber"]);
                if (sqlRdr["IsPaid"] != DBNull.Value)
                {
                    objBankBookMaster.IsPaid = Convert.ToBoolean(sqlRdr["IsPaid"]);
                }
                objBankBookMaster.linktoAccountMasterId = Convert.ToInt32(sqlRdr["linktoAccountMasterId"]);
                objBankBookMaster.Amount = Convert.ToDouble(sqlRdr["Amount"]);
                objBankBookMaster.ChequeNumber = Convert.ToString(sqlRdr["ChequeNumber"]);
                if (sqlRdr["linktoBankMasterId"] != DBNull.Value)
                {
                    objBankBookMaster.linktoBankMasterId = Convert.ToInt32(sqlRdr["linktoBankMasterId"]);
                }
                objBankBookMaster.Remark = Convert.ToString(sqlRdr["Remark"]);
                objBankBookMaster.CreateDateTime = Convert.ToDateTime(sqlRdr["CreateDateTime"]);
                objBankBookMaster.linktoUserMasterIdCreatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdCreatedBy"]);
                if (sqlRdr["UpdateDateTime"] != DBNull.Value)
                {
                    objBankBookMaster.UpdateDateTime = Convert.ToDateTime(sqlRdr["UpdateDateTime"]);
                }
                if (sqlRdr["linktoUserMasterIdUpdatedBy"] != DBNull.Value)
                {
                    objBankBookMaster.linktoUserMasterIdUpdatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdUpdatedBy"]);
                }

                /// Extra
                objBankBookMaster.AccountBank = Convert.ToString(sqlRdr["AccountBank"]);
                objBankBookMaster.Account = Convert.ToString(sqlRdr["Account"]);
                objBankBookMaster.Bank = Convert.ToString(sqlRdr["Bank"]);
                lstBankBookMaster.Add(objBankBookMaster);
            }
            return lstBankBookMaster;
        }
        #endregion

        #region Insert
        public posRecordStatus InsertBankBookMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posBankBookMaster_Insert", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@BankBookMasterId", SqlDbType.Int).Direction = ParameterDirection.Output;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCmd.Parameters.Add("@linktoAccountMasterIdBank", SqlDbType.Int).Value = this.linktoAccountMasterIdBank;
                SqlCmd.Parameters.Add("@BankBookNumber", SqlDbType.VarChar).Value = this.BankBookNumber;
                SqlCmd.Parameters.Add("@BankBookDate", SqlDbType.Date).Value = this.BankBookDate;
                SqlCmd.Parameters.Add("@VoucherNumber", SqlDbType.VarChar).Value = this.VoucherNumber;
                SqlCmd.Parameters.Add("@IsPaid", SqlDbType.Bit).Value = this.IsPaid;
                SqlCmd.Parameters.Add("@linktoAccountMasterId", SqlDbType.Int).Value = this.linktoAccountMasterId;
                SqlCmd.Parameters.Add("@Amount", SqlDbType.Money).Value = this.Amount;
                SqlCmd.Parameters.Add("@ChequeNumber", SqlDbType.VarChar).Value = this.ChequeNumber;
                SqlCmd.Parameters.Add("@linktoBankMasterId", SqlDbType.Int).Value = this.linktoBankMasterId;
                SqlCmd.Parameters.Add("@Remark", SqlDbType.VarChar).Value = this.Remark;
                SqlCmd.Parameters.Add("@CreateDateTime", SqlDbType.DateTime).Value = this.CreateDateTime;
                SqlCmd.Parameters.Add("@linktoUserMasterIdCreatedBy", SqlDbType.SmallInt).Value = this.linktoUserMasterIdCreatedBy;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                this.BankBookMasterId = Convert.ToInt32(SqlCmd.Parameters["@BankBookMasterId"].Value);
                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region Update
        public posRecordStatus UpdateBankBookMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posBankBookMaster_Update", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@BankBookMasterId", SqlDbType.Int).Value = this.BankBookMasterId;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCmd.Parameters.Add("@linktoAccountMasterIdBank", SqlDbType.Int).Value = this.linktoAccountMasterIdBank;
                SqlCmd.Parameters.Add("@BankBookNumber", SqlDbType.VarChar).Value = this.BankBookNumber;
                SqlCmd.Parameters.Add("@BankBookDate", SqlDbType.Date).Value = this.BankBookDate;
                SqlCmd.Parameters.Add("@VoucherNumber", SqlDbType.VarChar).Value = this.VoucherNumber;
                SqlCmd.Parameters.Add("@IsPaid", SqlDbType.Bit).Value = this.IsPaid;
                SqlCmd.Parameters.Add("@linktoAccountMasterId", SqlDbType.Int).Value = this.linktoAccountMasterId;
                SqlCmd.Parameters.Add("@Amount", SqlDbType.Money).Value = this.Amount;
                SqlCmd.Parameters.Add("@ChequeNumber", SqlDbType.VarChar).Value = this.ChequeNumber;
                SqlCmd.Parameters.Add("@linktoBankMasterId", SqlDbType.Int).Value = this.linktoBankMasterId;
                SqlCmd.Parameters.Add("@Remark", SqlDbType.VarChar).Value = this.Remark;
                SqlCmd.Parameters.Add("@UpdateDateTime", SqlDbType.DateTime).Value = this.UpdateDateTime;
                SqlCmd.Parameters.Add("@linktoUserMasterIdUpdatedBy", SqlDbType.SmallInt).Value = this.linktoUserMasterIdUpdatedBy;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region DeleteAll
        public posRecordStatus DeleteAllBankBookMaster(string BankMasterIds)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posBankMaster_DeleteAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@BankMasterIds", SqlDbType.VarChar).Value = BankMasterIds;
                SqlCmd.Parameters.Add("@UpdateDateTime", SqlDbType.DateTime).Value = this.UpdateDateTime;
                SqlCmd.Parameters.Add("@linktoUserMasterIdUpdatedBy", SqlDbType.SmallInt).Value = this.linktoUserMasterIdUpdatedBy;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

        
                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region Select
        public bool SelectBankBookMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posBankBookMaster_Select", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@BankBookMasterId", SqlDbType.Int).Value = this.BankBookMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                bool IsSelected = SetClassPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                return IsSelected;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return false;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public String SelectBankBookMasterBankNumber()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posBankBookMasterBankBookNumber_Select", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                if (SqlRdr.Read())
                {
                    if (SqlRdr["RecieptNumber"] != DBNull.Value)
                    {
                        this.BankBookNumber = Convert.ToString(SqlRdr["RecieptNumber"]);
                    }
                    else
                    {
                        this.BankBookNumber = "1";
                    }
                }
                SqlRdr.Close();
                SqlCon.Close();

                return this.BankBookNumber;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region SelectAll
        public List<posBankBookMasterDAL> SelectAllBankBookMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posBankBookMaster_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                if (this.linktoAccountMasterIdBank > 0)
                {
                    SqlCmd.Parameters.Add("@linktoAccountMasterIdBank", SqlDbType.Int).Value = this.linktoAccountMasterIdBank;
                }
                if (this.BankBookDate != new DateTime())
                {
                    SqlCmd.Parameters.Add("@BankBookDate", SqlDbType.Date).Value = this.BankBookDate;
                }
                SqlCmd.Parameters.Add("@VoucherNumber", SqlDbType.VarChar).Value = this.VoucherNumber;
                SqlCmd.Parameters.Add("@IsPaid", SqlDbType.Bit).Value = this.IsPaid;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<posBankBookMasterDAL> lstBankBookMasterDAL = SetListPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                return lstBankBookMasterDAL;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion
    }
}
