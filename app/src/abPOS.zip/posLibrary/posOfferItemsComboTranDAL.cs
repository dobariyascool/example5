using System;
using System.Data;
using System.Data.SqlClient;
using System.Collections.Generic;

namespace posLibrary
{
    /// <summary>
    /// Class for posOfferItemsComboTran
    /// </summary>
    public class posOfferItemsComboTranDAL
    {
        #region Properties
        public int OfferItemsComboTranId { get; set; }
        public int linktoOfferMasterId { get; set; }
        public int linktoItemMasterId { get; set; }
        public int linktoItemMasterIdCombo { get; set; }
        public double Discount { get; set; }
        public bool IsDiscountPercentage { get; set; }
        public List<posOfferItemsComboTranDAL> lstOfferItemsComboTranDAL { get; set; }

        /// Extra
        public string Offer { get; set; }
        public string Item { get; set; }
        public string ItemCombo { get; set; }
        public string DiscountWithType { get; set; }

        #endregion

        #region Class Methods
        private bool SetClassPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            if (sqlRdr.Read())
            {
                this.OfferItemsComboTranId = Convert.ToInt32(sqlRdr["OfferItemsComboTranId"]);
                this.linktoOfferMasterId = Convert.ToInt32(sqlRdr["linktoOfferMasterId"]);
                this.linktoItemMasterId = Convert.ToInt32(sqlRdr["linktoItemMasterId"]);
                this.linktoItemMasterIdCombo = Convert.ToInt32(sqlRdr["linktoItemMasterIdCombo"]);
                this.Discount = Convert.ToDouble(sqlRdr["Discount"]);
                this.IsDiscountPercentage = Convert.ToBoolean(sqlRdr["IsDiscountPercentage"]);

                /// Extra
                this.Offer = Convert.ToString(sqlRdr["Offer"]);
                this.Item = Convert.ToString(sqlRdr["Item"]);
                this.ItemCombo = Convert.ToString(sqlRdr["ItemCombo"]);
                return true;
            }
            return false;
        }

        private List<posOfferItemsComboTranDAL> SetListPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            List<posOfferItemsComboTranDAL> lstOfferItemsComboTran = new List<posOfferItemsComboTranDAL>();
            posOfferItemsComboTranDAL objOfferItemsComboTran = null;
            while (sqlRdr.Read())
            {
                objOfferItemsComboTran = new posOfferItemsComboTranDAL();
                objOfferItemsComboTran.OfferItemsComboTranId = Convert.ToInt32(sqlRdr["OfferItemsComboTranId"]);
                objOfferItemsComboTran.linktoOfferMasterId = Convert.ToInt32(sqlRdr["linktoOfferMasterId"]);
                objOfferItemsComboTran.linktoItemMasterId = Convert.ToInt32(sqlRdr["linktoItemMasterId"]);
                objOfferItemsComboTran.linktoItemMasterIdCombo = Convert.ToInt32(sqlRdr["linktoItemMasterIdCombo"]);
                objOfferItemsComboTran.Discount = Convert.ToDouble(sqlRdr["Discount"]);
                objOfferItemsComboTran.IsDiscountPercentage = Convert.ToBoolean(sqlRdr["IsDiscountPercentage"]);
                if (objOfferItemsComboTran.IsDiscountPercentage)
                {
                    objOfferItemsComboTran.DiscountWithType = objOfferItemsComboTran.Discount + "%";
                }
                else
                {
                    objOfferItemsComboTran.DiscountWithType = objOfferItemsComboTran.Discount + "Rs.";
                }

                /// Extra
                objOfferItemsComboTran.Offer = Convert.ToString(sqlRdr["Offer"]);
                objOfferItemsComboTran.Item = Convert.ToString(sqlRdr["Item"]);
                objOfferItemsComboTran.ItemCombo = Convert.ToString(sqlRdr["ItemCombo"]);
                lstOfferItemsComboTran.Add(objOfferItemsComboTran);
            }
            return lstOfferItemsComboTran;
        }
        #endregion

        #region Insert
        public posRecordStatus InsertOfferItemsComboTran(SqlConnection SqlCon, SqlTransaction SqlTran)
        {
            //  SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                //SqlCon = posObjectFactoryDAL.CreateConnection();
                // SqlCon.Open();
                foreach (posOfferItemsComboTranDAL objOfferItemsComboTranDAL in this.lstOfferItemsComboTranDAL)
                {
                    SqlCmd = new SqlCommand("posOfferItemsComboTran_Insert", SqlCon, SqlTran);
                    SqlCmd.CommandType = CommandType.StoredProcedure;

                    SqlCmd.Parameters.Add("@OfferItemsComboTranId", SqlDbType.Int).Direction = ParameterDirection.Output;
                    SqlCmd.Parameters.Add("@linktoOfferMasterId", SqlDbType.Int).Value = this.linktoOfferMasterId;
                    SqlCmd.Parameters.Add("@linktoItemMasterId", SqlDbType.Int).Value = objOfferItemsComboTranDAL.linktoItemMasterId;
                    SqlCmd.Parameters.Add("@linktoItemMasterIdCombo", SqlDbType.Int).Value = objOfferItemsComboTranDAL.linktoItemMasterIdCombo;
                    SqlCmd.Parameters.Add("@Discount", SqlDbType.Money).Value = objOfferItemsComboTranDAL.Discount;
                    SqlCmd.Parameters.Add("@IsDiscountPercentage", SqlDbType.Bit).Value = objOfferItemsComboTranDAL.IsDiscountPercentage;
                    SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                    SqlCmd.ExecuteNonQuery();
                }
                //  SqlCon.Close();

                this.OfferItemsComboTranId = Convert.ToInt32(SqlCmd.Parameters["@OfferItemsComboTranId"].Value);
                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                // posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region Update
        public posRecordStatus UpdateOfferItemsComboTran()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posOfferItemsComboTran_Update", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@OfferItemsComboTranId", SqlDbType.Int).Value = this.OfferItemsComboTranId;
                SqlCmd.Parameters.Add("@linktoOfferMasterId", SqlDbType.Int).Value = this.linktoOfferMasterId;
                SqlCmd.Parameters.Add("@linktoItemMasterId", SqlDbType.Int).Value = this.linktoItemMasterId;
                SqlCmd.Parameters.Add("@linktoItemMasterIdCombo", SqlDbType.Int).Value = this.linktoItemMasterIdCombo;
                SqlCmd.Parameters.Add("@Discount", SqlDbType.Money).Value = this.Discount;
                SqlCmd.Parameters.Add("@IsDiscountPercentage", SqlDbType.Bit).Value = this.IsDiscountPercentage;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region Delete
        public posRecordStatus DeleteOfferItemsComboTran()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posOfferItemsComboTran_Delete", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@linktoOfferMasterId", SqlDbType.Int).Value = this.linktoOfferMasterId;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        public posRecordStatus DeleteOfferItemsComboTran(SqlConnection SqlCon, SqlTransaction SqlTran)
        {
            //  SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                // SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posOfferItemsComboTran_Delete", SqlCon, SqlTran);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@linktoOfferMasterId", SqlDbType.Int).Value = this.linktoOfferMasterId;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                //  SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                // SqlCon.Close();

                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                // posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region DeleteAll

        public posRecordStatus DeleteAllOfferItemsComboTran(string offerItemsComboTranIds)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posOfferItemsComboTran_DeleteAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@OfferItemsComboTranIds", SqlDbType.VarChar).Value = offerItemsComboTranIds;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region Select
        public bool SelectOfferItemsComboTran()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posOfferItemsComboTran_Select", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@OfferItemsComboTranId", SqlDbType.Int).Value = this.OfferItemsComboTranId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                bool IsSelected = SetClassPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                return IsSelected;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return false;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region SelectAll

        public List<posOfferItemsComboTranDAL> SelectAllOfferItemsComboTran()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posOfferItemsComboTran_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@linktoOfferMasterId", SqlDbType.Int).Value = this.linktoOfferMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<posOfferItemsComboTranDAL> lstOfferItemsComboTranDAL = SetListPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                return lstOfferItemsComboTranDAL;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion
    }
}
