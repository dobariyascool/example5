using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace posLibrary
{
    /// <summary>
    /// Class for posOptionValueTran
    /// </summary>
    public class posOptionValueTranDAL
    {
        #region Properties
        public int OptionValueTranId { get; set; }
        public short linktoOptionMasterId { get; set; }
        public string OptionValue { get; set; }
        public bool IsDeleted { get; set; }
        public short linktoBusinessMasterId { get; set; }
        /// Extra
        public string OptionName { get; set; }
        #endregion

        #region Class Methods
        private List<posOptionValueTranDAL> SetListPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            List<posOptionValueTranDAL> lstOptionValueTran = new List<posOptionValueTranDAL>();
            posOptionValueTranDAL objOptionValueTran = null;
            while (sqlRdr.Read())
            {
                objOptionValueTran = new posOptionValueTranDAL();
                objOptionValueTran.OptionValueTranId = Convert.ToInt32(sqlRdr["OptionValueTranId"]);
                objOptionValueTran.linktoOptionMasterId = Convert.ToInt16(sqlRdr["linktoOptionMasterId"]);
                objOptionValueTran.OptionValue = Convert.ToString(sqlRdr["OptionValue"]);
                objOptionValueTran.IsDeleted = Convert.ToBoolean(sqlRdr["IsDeleted"]);

                /// Extra
                objOptionValueTran.OptionName = Convert.ToString(sqlRdr["OptionName"]);
                lstOptionValueTran.Add(objOptionValueTran);
            }
            return lstOptionValueTran;
        }
        #endregion

        #region Insert
        public posRecordStatus InsertOptionValueTran()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posOptionValueTran_Insert", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@OptionValueTranId", SqlDbType.Int).Direction = ParameterDirection.Output;
                SqlCmd.Parameters.Add("@linktoOptionMasterId", SqlDbType.SmallInt).Value = this.linktoOptionMasterId;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCmd.Parameters.Add("@OptionValue", SqlDbType.VarChar).Value = this.OptionValue;
                SqlCmd.Parameters.Add("@IsDeleted", SqlDbType.Bit).Value = this.IsDeleted;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                this.OptionValueTranId = Convert.ToInt32(SqlCmd.Parameters["@OptionValueTranId"].Value);
                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region Delete
        public posRecordStatus DeleteOptionValueTran()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posOptionValueTran_Delete", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@OptionValueTranId", SqlDbType.Int).Value = this.OptionValueTranId;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region SelectAll
        public List<posOptionValueTranDAL> SelectAllOptionValueTran()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posOptionValueTran_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@linktoOptionMasterId", SqlDbType.SmallInt).Value = this.linktoOptionMasterId;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<posOptionValueTranDAL> lstOptionValueTranDAL = SetListPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                return lstOptionValueTranDAL;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public List<posOptionValueTranDAL> SelectAllOptionValueTranByItemMasterId(int linktoItemMasterId)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posOptionValueTranByItemMasterId_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;
                SqlCmd.Parameters.Add("@linktoItemMasterId", SqlDbType.Int).Value = linktoItemMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<posOptionValueTranDAL> lstOptionValueTranDAL = SetListPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                return lstOptionValueTranDAL;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion
    }
}
