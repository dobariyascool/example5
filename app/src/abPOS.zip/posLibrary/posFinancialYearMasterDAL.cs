using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace posLibrary
{
    /// <summary>
    /// Class for posFinancialYearMaster
    /// </summary>
    public class posFinancialYearMasterDAL
    {
        #region Properties
        public short FinancialYearMasterId { get; set; }
        public short linktoBusinessMasterId { get; set; }
        public DateTime FromDate { get; set; }
        public DateTime ToDate { get; set; }
        public bool IsDefault { get; set; }

        /// Extra
        public int FinancialYearFrom { get; set; }
        public int FinancialYearTo { get; set; }
        public string FinancialMonthFrom { get; set; }
        public string FinancialMonthTo { get; set; }
        #endregion

        #region Class Methods
        private bool SetClassPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            if (sqlRdr.Read())
            {
                this.FinancialYearMasterId = Convert.ToInt16(sqlRdr["FinancialYearMasterId"]);
                this.linktoBusinessMasterId = Convert.ToInt16(sqlRdr["linktoBusinessMasterId"]);
                this.FromDate = Convert.ToDateTime(sqlRdr["FromDate"]);
                this.ToDate = Convert.ToDateTime(sqlRdr["ToDate"]);
                this.IsDefault = Convert.ToBoolean(sqlRdr["IsDefault"]);

                return true;
            }
            return false;
        }

        private List<posFinancialYearMasterDAL> SetListPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            List<posFinancialYearMasterDAL> lstFinancialYearMaster = new List<posFinancialYearMasterDAL>();
            posFinancialYearMasterDAL objFinancialYearMaster = null;
            while (sqlRdr.Read())
            {
                objFinancialYearMaster = new posFinancialYearMasterDAL();
                objFinancialYearMaster.FinancialYearMasterId = Convert.ToInt16(sqlRdr["FinancialYearMasterId"]);
                objFinancialYearMaster.linktoBusinessMasterId = Convert.ToInt16(sqlRdr["linktoBusinessMasterId"]);
                objFinancialYearMaster.FromDate = Convert.ToDateTime(sqlRdr["FromDate"]);
                objFinancialYearMaster.ToDate = Convert.ToDateTime(sqlRdr["ToDate"]);
                objFinancialYearMaster.IsDefault = Convert.ToBoolean(sqlRdr["IsDefault"]);

                /// Extra
                objFinancialYearMaster.FinancialYearFrom = Convert.ToInt32(sqlRdr["FinancialFromYear"]);
                objFinancialYearMaster.FinancialYearTo = Convert.ToInt32(sqlRdr["FinancialToYear"]);
                objFinancialYearMaster.FinancialMonthFrom = Convert.ToString(sqlRdr["FinancialFromMonth"]) + " - " + Convert.ToString(sqlRdr["FinancialFromYear"]);
                objFinancialYearMaster.FinancialMonthTo = Convert.ToString(sqlRdr["FinancialToMonth"]) + " - " + Convert.ToString(sqlRdr["FinancialToYear"]);
                lstFinancialYearMaster.Add(objFinancialYearMaster);
            }
            return lstFinancialYearMaster;
        }
        #endregion

        #region Insert
        public posRecordStatus InsertFinancialYearMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posFinancialYearMaster_Insert", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@FinancialYearMasterId", SqlDbType.SmallInt).Direction = ParameterDirection.Output;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCmd.Parameters.Add("@FromDate", SqlDbType.Date).Value = this.FromDate;
                SqlCmd.Parameters.Add("@ToDate", SqlDbType.Date).Value = this.ToDate;
                SqlCmd.Parameters.Add("@IsDefault", SqlDbType.Bit).Value = this.IsDefault;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                this.FinancialYearMasterId = Convert.ToInt16(SqlCmd.Parameters["@FinancialYearMasterId"].Value);
                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public posRecordStatus InsertFinancialYearMaster(SqlConnection SqlCon, SqlTransaction SqlTran)
        {
            SqlCommand SqlCmd = null;
            try
            {
                SqlCmd = new SqlCommand("posFinancialYearMaster_Insert", SqlCon, SqlTran);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@FinancialYearMasterId", SqlDbType.SmallInt).Direction = ParameterDirection.Output;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCmd.Parameters.Add("@FromDate", SqlDbType.Date).Value = this.FromDate;
                SqlCmd.Parameters.Add("@ToDate", SqlDbType.Date).Value = this.ToDate;
                SqlCmd.Parameters.Add("@IsDefault", SqlDbType.Bit).Value = this.IsDefault;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCmd.ExecuteNonQuery();

                this.FinancialYearMasterId = Convert.ToInt16(SqlCmd.Parameters["@FinancialYearMasterId"].Value);
                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
            }
        }
        #endregion

        #region Update
        public posRecordStatus UpdateFinancialYearMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posFinancialYearMaster_Update", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@FinancialYearMasterId", SqlDbType.SmallInt).Value = this.FinancialYearMasterId;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCmd.Parameters.Add("@FromDate", SqlDbType.Date).Value = this.FromDate;
                SqlCmd.Parameters.Add("@ToDate", SqlDbType.Date).Value = this.ToDate;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region Select
        public bool SelectFinancialYearMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posFinancialYearMaster_Select", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                if (this.FinancialYearMasterId > 0)
                {
                    SqlCmd.Parameters.Add("@FinancialYearMasterId", SqlDbType.SmallInt).Value = this.FinancialYearMasterId;
                }
                else
                {
                    SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                    SqlCmd.Parameters.Add("@IsDefault", SqlDbType.Bit).Value = this.IsDefault;
                }
                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                bool IsSelected = SetClassPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                return IsSelected;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return false;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region SelectAll
        public List<posFinancialYearMasterDAL> SelectAllFinancialYearMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posFinancialYearMaster_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<posFinancialYearMasterDAL> lstFinancialYearMasterDAL = SetListPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                return lstFinancialYearMasterDAL;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion
    }
}
