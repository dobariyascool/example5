using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace posLibrary
{
    /// <summary>
    /// Class for posAreaMaster
    /// </summary>
    public class posAreaMasterDAL
    {
        #region Properties
        public int AreaMasterId { get; set; }
        public short linktoBusinessMasterId { get; set; }
        public string AreaName { get; set; }
        public string ZipCode { get; set; }
        public int linktoCityMasterId { get; set; }
        public bool IsEnabled { get; set; }
        public bool IsDeleted { get; set; }
        public DateTime CreateDateTime { get; set; }
        public short linktoUserMasterIdCreatedBy { get; set; }
        public DateTime? UpdateDateTime { get; set; }
        public short? linktoUserMasterIdUpdatedBy { get; set; }

        /// Extra
        public string CityName { get; set; }
        public short StateMasterId { get; set; }
        public short linktoCountryMasterId { get; set; }
        #endregion

        #region Class Methods
        private bool SetClassPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            if (sqlRdr.Read())
            {
                this.AreaMasterId = Convert.ToInt32(sqlRdr["AreaMasterId"]);
                this.AreaName = Convert.ToString(sqlRdr["AreaName"]);
                this.ZipCode = Convert.ToString(sqlRdr["ZipCode"]);
                this.linktoCityMasterId = Convert.ToInt32(sqlRdr["linktoCityMasterId"]);
                this.IsEnabled = Convert.ToBoolean(sqlRdr["IsEnabled"]);

                /// Extra
                this.CityName = Convert.ToString(sqlRdr["CityName"]);
                this.StateMasterId = Convert.ToInt16(sqlRdr["StateMasterId"]);
                this.linktoCountryMasterId = Convert.ToInt16(sqlRdr["linktoCountryMasterId"]);
                return true;
            }
            return false;
        }

        private List<posAreaMasterDAL> SetListPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            List<posAreaMasterDAL> lstAreaMaster = new List<posAreaMasterDAL>();
            posAreaMasterDAL objAreaMaster = null;
            while (sqlRdr.Read())
            {
                objAreaMaster = new posAreaMasterDAL();
                objAreaMaster.AreaMasterId = Convert.ToInt32(sqlRdr["AreaMasterId"]);
                objAreaMaster.AreaName = Convert.ToString(sqlRdr["AreaName"]);
                objAreaMaster.ZipCode = Convert.ToString(sqlRdr["ZipCode"]);
                objAreaMaster.linktoCityMasterId = Convert.ToInt32(sqlRdr["linktoCityMasterId"]);
                objAreaMaster.IsEnabled = Convert.ToBoolean(sqlRdr["IsEnabled"]);

                /// Extra
                objAreaMaster.CityName = Convert.ToString(sqlRdr["CityName"]);
                lstAreaMaster.Add(objAreaMaster);
            }
            return lstAreaMaster;
        }
        #endregion

        #region Insert
        public posRecordStatus InsertAreaMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posAreaMaster_Insert", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@AreaMasterId", SqlDbType.SmallInt).Direction = ParameterDirection.Output;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCmd.Parameters.Add("@AreaName", SqlDbType.VarChar).Value = this.AreaName;
                SqlCmd.Parameters.Add("@ZipCode", SqlDbType.VarChar).Value = this.ZipCode;
                SqlCmd.Parameters.Add("@linktoCityMasterId", SqlDbType.Int).Value = this.linktoCityMasterId;
                SqlCmd.Parameters.Add("@IsEnabled", SqlDbType.Bit).Value = this.IsEnabled;
                SqlCmd.Parameters.Add("@IsDeleted", SqlDbType.Bit).Value = this.IsDeleted;
                SqlCmd.Parameters.Add("@CreateDateTime", SqlDbType.DateTime).Value = this.CreateDateTime;
                SqlCmd.Parameters.Add("@linktoUserMasterIdCreatedBy", SqlDbType.SmallInt).Value = this.linktoUserMasterIdCreatedBy;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                this.AreaMasterId = Convert.ToInt32(SqlCmd.Parameters["@AreaMasterId"].Value);
                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region Update
        public posRecordStatus UpdateAreaMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posAreaMaster_Update", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@AreaMasterId", SqlDbType.Int).Value = this.AreaMasterId;
                 SqlCmd.Parameters.Add("@AreaName", SqlDbType.VarChar).Value = this.AreaName;
                SqlCmd.Parameters.Add("@ZipCode", SqlDbType.VarChar).Value = this.ZipCode;
                SqlCmd.Parameters.Add("@linktoCityMasterId", SqlDbType.Int).Value = this.linktoCityMasterId;
                SqlCmd.Parameters.Add("@IsEnabled", SqlDbType.Bit).Value = this.IsEnabled;
                SqlCmd.Parameters.Add("@IsDeleted", SqlDbType.Bit).Value = this.IsDeleted;
                SqlCmd.Parameters.Add("@UpdateDateTime", SqlDbType.DateTime).Value = this.UpdateDateTime;
                SqlCmd.Parameters.Add("@linktoUserMasterIdUpdatedBy", SqlDbType.SmallInt).Value = this.linktoUserMasterIdUpdatedBy;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region DeleteAll
        public posRecordStatus DeleteAllAreaMaster(string areaMasterIds)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posAreaMaster_DeleteAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@AreaMasterIds", SqlDbType.VarChar).Value = areaMasterIds;
                SqlCmd.Parameters.Add("@UpdateDateTime", SqlDbType.DateTime).Value = this.UpdateDateTime;
                SqlCmd.Parameters.Add("@linktoUserMasterIdUpdatedBy", SqlDbType.SmallInt).Value = this.linktoUserMasterIdUpdatedBy;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region Select
        public bool SelectAreaMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posAreaMaster_Select", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@AreaMasterId", SqlDbType.Int).Value = this.AreaMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                bool IsSelected = SetClassPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                return IsSelected;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return false;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region SelectAll
        public List<posAreaMasterDAL> SelectAllAreaMaster(short? linktoCountryMasterId = null, short? linktoStateMasterId = null)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posAreaMaster_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;
                SqlCmd.Parameters.Add("@IsEnabled", SqlDbType.Bit).Value = this.IsEnabled;
                if (linktoCountryMasterId > 0)
                {
                    SqlCmd.Parameters.Add("@linktoCountryMasterId", SqlDbType.SmallInt).Value = linktoCountryMasterId;
                }
                if (linktoStateMasterId > 0)
                {
                    SqlCmd.Parameters.Add("@linktoStateMasterId", SqlDbType.SmallInt).Value = linktoStateMasterId;
                }
                if (linktoCityMasterId > 0)
                {
                    SqlCmd.Parameters.Add("@linktoCityMasterId", SqlDbType.SmallInt).Value = linktoCityMasterId;
                }
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<posAreaMasterDAL> lstAreaMasterDAL = SetListPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                return lstAreaMasterDAL;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public static List<posAreaMasterDAL> SelectAllAreaMasterAreaNameByCity(int linktoCityMasterId)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posAreaMasterAreaName_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@linktoCityMasterId", SqlDbType.SmallInt).Value = linktoCityMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<posAreaMasterDAL> lstAreaMasterDAL = new List<posAreaMasterDAL>();
                posAreaMasterDAL objAreaMasterDAL = null;
                while (SqlRdr.Read())
                {
                    objAreaMasterDAL = new posAreaMasterDAL();
                    objAreaMasterDAL.AreaMasterId = Convert.ToInt32(SqlRdr["AreaMasterId"]);
                    objAreaMasterDAL.AreaName = Convert.ToString(SqlRdr["AreaName"]);
                    lstAreaMasterDAL.Add(objAreaMasterDAL);
                }
                SqlRdr.Close();
                SqlCon.Close();

                return lstAreaMasterDAL;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion
    }
}
