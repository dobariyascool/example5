using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace posLibrary
{
    /// <summary>
    /// Class for posJournalVoucherTran
    /// </summary>
    public class posJournalVoucherTranDAL
    {
        #region Properties
        public int JournalVoucherTranId { get; set; }
        public int? linktoJournalVoucherMasterId { get; set; }
        public int linktoAccountMasterId { get; set; }
        public double? Debit { get; set; }
        public double? Credit { get; set; }

        /// Extra
        public string Account { get; set; }
        public bool IsDeleted { get; set; }
        #endregion

        #region Class Methods
        private bool SetClassPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            if (sqlRdr.Read())
            {
                this.JournalVoucherTranId = Convert.ToInt32(sqlRdr["JournalVoucherTranId"]);
                this.linktoJournalVoucherMasterId = Convert.ToInt32(sqlRdr["linktoJournalVoucherMasterId"]);
                this.linktoAccountMasterId = Convert.ToInt32(sqlRdr["linktoAccountMasterId"]);
                if (sqlRdr["Debit"] != DBNull.Value)
                {
                    this.Debit = Convert.ToDouble(sqlRdr["Debit"]);
                }
                if (sqlRdr["Credit"] != DBNull.Value)
                {
                    this.Credit = Convert.ToDouble(sqlRdr["Credit"]);
                }

                /// Extra
                this.Account = Convert.ToString(sqlRdr["Account"]);

                return true;
            }
            return false;
        }

        private List<posJournalVoucherTranDAL> SetListPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            List<posJournalVoucherTranDAL> lstJournalVoucherTran = new List<posJournalVoucherTranDAL>();
            posJournalVoucherTranDAL objJournalVoucherTran = null;
            while (sqlRdr.Read())
            {
                objJournalVoucherTran = new posJournalVoucherTranDAL();
                objJournalVoucherTran.JournalVoucherTranId = Convert.ToInt32(sqlRdr["JournalVoucherTranId"]);
                objJournalVoucherTran.linktoJournalVoucherMasterId = Convert.ToInt32(sqlRdr["linktoJournalVoucherMasterId"]);
                objJournalVoucherTran.linktoAccountMasterId = Convert.ToInt32(sqlRdr["linktoAccountMasterId"]);
                if (sqlRdr["Debit"] != DBNull.Value)
                {
                    objJournalVoucherTran.Debit = Convert.ToDouble(sqlRdr["Debit"]);
                }
                if (sqlRdr["Credit"] != DBNull.Value)
                {
                    objJournalVoucherTran.Credit = Convert.ToDouble(sqlRdr["Credit"]);
                }

                /// Extra
                objJournalVoucherTran.Account = Convert.ToString(sqlRdr["Account"]);
                objJournalVoucherTran.IsDeleted = false;
                lstJournalVoucherTran.Add(objJournalVoucherTran);
            }
            return lstJournalVoucherTran;
        }
        #endregion

        #region Insert
        public posRecordStatus InsertJournalVoucherTran(SqlConnection SqlCon, SqlTransaction sqlTran)
        {
            SqlCommand SqlCmd = null;
            try
            {
                SqlCmd = new SqlCommand("posJournalVoucherTran_Insert", SqlCon, sqlTran);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@JournalVoucherTranId", SqlDbType.Int).Direction = ParameterDirection.Output;
                SqlCmd.Parameters.Add("@linktoJournalVoucherMasterId", SqlDbType.Int).Value = this.linktoJournalVoucherMasterId;
                SqlCmd.Parameters.Add("@linktoAccountMasterId", SqlDbType.Int).Value = this.linktoAccountMasterId;
                SqlCmd.Parameters.Add("@Debit", SqlDbType.Money).Value = this.Debit;
                SqlCmd.Parameters.Add("@Credit", SqlDbType.Money).Value = this.Credit;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCmd.ExecuteNonQuery();

                this.JournalVoucherTranId = Convert.ToInt32(SqlCmd.Parameters["@JournalVoucherTranId"].Value);
                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
            }
        }
        #endregion

        #region Delete
        public posRecordStatus DeleteJournalVoucherTranByJournalVoucherMasterId(SqlConnection SqlCon, SqlTransaction sqlTran)
        {
            SqlCommand SqlCmd = null;
            try
            {
                SqlCmd = new SqlCommand("posJournalVoucherTranByJournalVoucherMasterId_Delete", SqlCon, sqlTran);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@linktoJournalVoucherMasterId", SqlDbType.Int).Value = this.linktoJournalVoucherMasterId;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCmd.ExecuteNonQuery();

                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
            }
        }
        #endregion

        #region SelectAll
        public List<posJournalVoucherTranDAL> SelectAllJournalVoucherTran()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posJournalVoucherTran_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@linktoJournalVoucherMasterId", SqlDbType.Int).Value = this.linktoJournalVoucherMasterId;
                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<posJournalVoucherTranDAL> lstJournalVoucherTranDAL = SetListPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                return lstJournalVoucherTranDAL;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion
    }
}
