using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace posLibrary
{
    /// <summary>
    /// Class for posFeedbackAnswerMaster
    /// </summary>
    public class posFeedbackAnswerMasterDAL
    {
        #region Properties
        public int FeedbackAnswerMasterId { get; set; }
        public int linktoFeedbackQuestionMasterId { get; set; }
        public string Answer { get; set; }
        public bool IsDeleted { get; set; }

        /// Extra
        public string FeedbackQuestion { get; set; }
        #endregion

        #region Class Methods
        private bool SetClassPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            if (sqlRdr.Read())
            {
                this.FeedbackAnswerMasterId = Convert.ToInt32(sqlRdr["FeedbackAnswerMasterId"]);
                this.linktoFeedbackQuestionMasterId = Convert.ToInt32(sqlRdr["linktoFeedbackQuestionMasterId"]);
                this.Answer = Convert.ToString(sqlRdr["Answer"]);
                this.IsDeleted = Convert.ToBoolean(sqlRdr["IsDeleted"]);

                /// Extra
                this.FeedbackQuestion = Convert.ToString(sqlRdr["FeedbackQuestion"]);
                return true;
            }
            return false;
        }

        private List<posFeedbackAnswerMasterDAL> SetListPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            List<posFeedbackAnswerMasterDAL> lstFeedbackAnswerMaster = new List<posFeedbackAnswerMasterDAL>();
            posFeedbackAnswerMasterDAL objFeedbackAnswerMaster = null;
            while (sqlRdr.Read())
            {
                objFeedbackAnswerMaster = new posFeedbackAnswerMasterDAL();
                objFeedbackAnswerMaster.FeedbackAnswerMasterId = Convert.ToInt32(sqlRdr["FeedbackAnswerMasterId"]);
                objFeedbackAnswerMaster.linktoFeedbackQuestionMasterId = Convert.ToInt32(sqlRdr["linktoFeedbackQuestionMasterId"]);
                objFeedbackAnswerMaster.Answer = Convert.ToString(sqlRdr["Answer"]);
                objFeedbackAnswerMaster.IsDeleted = Convert.ToBoolean(sqlRdr["IsDeleted"]);

                /// Extra
                objFeedbackAnswerMaster.FeedbackQuestion = Convert.ToString(sqlRdr["FeedbackQuestion"]);
                lstFeedbackAnswerMaster.Add(objFeedbackAnswerMaster);
            }
            return lstFeedbackAnswerMaster;
        }
        #endregion

        #region Insert
        public posRecordStatus InsertFeedbackAnswerMaster(SqlConnection SqlCon, SqlTransaction sqlTran)
        {
            SqlCommand SqlCmd = null;
            try
            {
                SqlCmd = new SqlCommand("posFeedbackAnswerMaster_Insert", SqlCon, sqlTran);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@FeedbackAnswerMasterId", SqlDbType.Int).Direction = ParameterDirection.Output;
                SqlCmd.Parameters.Add("@linktoFeedbackQuestionMasterId", SqlDbType.Int).Value = this.linktoFeedbackQuestionMasterId;
                SqlCmd.Parameters.Add("@Answer", SqlDbType.VarChar).Value = this.Answer;
                SqlCmd.Parameters.Add("@IsDeleted", SqlDbType.Bit).Value = this.IsDeleted;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCmd.ExecuteNonQuery();

                this.FeedbackAnswerMasterId = Convert.ToInt32(SqlCmd.Parameters["@FeedbackAnswerMasterId"].Value);
                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
            }
        }
        #endregion

        #region Update
        public posRecordStatus UpdateFeedbackAnswerMaster(SqlConnection SqlCon, SqlTransaction sqlTran)
        {
            SqlCommand SqlCmd = null;
            try
            {
                SqlCmd = new SqlCommand("posFeedbackAnswerMaster_Update", SqlCon, sqlTran);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@FeedbackAnswerMasterId", SqlDbType.Int).Value = this.FeedbackAnswerMasterId;
                SqlCmd.Parameters.Add("@linktoFeedbackQuestionMasterId", SqlDbType.Int).Value = this.linktoFeedbackQuestionMasterId;
                SqlCmd.Parameters.Add("@Answer", SqlDbType.VarChar).Value = this.Answer;
                SqlCmd.Parameters.Add("@IsDeleted", SqlDbType.Bit).Value = this.IsDeleted;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCmd.ExecuteNonQuery();
                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
            }
        }
        #endregion  
            
        #region SelectAll
        public List<posFeedbackAnswerMasterDAL> SelectAllFeedbackAnswerMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posFeedbackAnswerMaster_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                if (this.linktoFeedbackQuestionMasterId > 0)
                {
                    SqlCmd.Parameters.Add("@linktoFeedbackQuestionMasterId", SqlDbType.Int).Value = this.linktoFeedbackQuestionMasterId;
                }
                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<posFeedbackAnswerMasterDAL> lstFeedbackAnswerMasterDAL = SetListPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                return lstFeedbackAnswerMasterDAL;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion
    }
}
