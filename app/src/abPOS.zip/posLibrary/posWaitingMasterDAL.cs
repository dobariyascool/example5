using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace posLibrary
{
    /// <summary>
    /// Class for posWaitingMaster
    /// </summary>
    public class posWaitingMasterDAL
    {
        #region Properties
        public long WaitingMasterId { get; set; }
        public string PersonName { get; set; }
        public string PersonMobile { get; set; }
        public short NoOfPersons { get; set; }
        public short linktoWaitingStatusMasterId { get; set; }
        public DateTime CreateDateTime { get; set; }
        public short linktoUserMasterIdCreatedBy { get; set; }
        public short linktoBusinessMasterId { get; set; }
        public short? linktoTableMasterId { get; set; }
        public DateTime? UpdateDateTime { get; set; }
        public short? linktoUserMasterIdUpdatedBy { get; set; }
        /// Extra
        public string WaitingStatus { get; set; }
        public string OrderBy { get; set; }

        #endregion

        #region Class Methods
        private List<posWaitingMasterDAL> SetListPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            List<posWaitingMasterDAL> lstWaitingMaster = new List<posWaitingMasterDAL>();
            posWaitingMasterDAL objWaitingMaster = null;
            while (sqlRdr.Read())
            {
                objWaitingMaster = new posWaitingMasterDAL();
                objWaitingMaster.WaitingMasterId = Convert.ToInt64(sqlRdr["WaitingMasterId"]);
                objWaitingMaster.PersonName = Convert.ToString(sqlRdr["PersonName"]);
                objWaitingMaster.PersonMobile = Convert.ToString(sqlRdr["PersonMobile"]);
                objWaitingMaster.NoOfPersons = Convert.ToInt16(sqlRdr["NoOfPersons"]);
                objWaitingMaster.linktoWaitingStatusMasterId = Convert.ToInt16(sqlRdr["linktoWaitingStatusMasterId"]);
                objWaitingMaster.CreateDateTime = Convert.ToDateTime(sqlRdr["CreateDateTime"]);
                objWaitingMaster.linktoUserMasterIdCreatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdCreatedBy"]);
                objWaitingMaster.linktoBusinessMasterId = Convert.ToInt16(sqlRdr["linktoBusinessMasterId"]);
                if (sqlRdr["linktoTableMasterId"] != DBNull.Value)
                {
                    objWaitingMaster.linktoTableMasterId = Convert.ToInt16(sqlRdr["linktoTableMasterId"]);
                }
                /// Extra
                objWaitingMaster.WaitingStatus = Convert.ToString(sqlRdr["WaitingStatus"]);
                lstWaitingMaster.Add(objWaitingMaster);
            }
            return lstWaitingMaster;
        }
        #endregion

        #region Insert
        public posRecordStatus InsertWaitingMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posWaitingMaster_Insert", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@WaitingMasterId", SqlDbType.BigInt).Direction = ParameterDirection.Output;
                SqlCmd.Parameters.Add("@PersonName", SqlDbType.VarChar).Value = this.PersonName;
                SqlCmd.Parameters.Add("@PersonMobile", SqlDbType.VarChar).Value = this.PersonMobile;
                SqlCmd.Parameters.Add("@NoOfPersons", SqlDbType.SmallInt).Value = this.NoOfPersons;
                SqlCmd.Parameters.Add("@linktoWaitingStatusMasterId", SqlDbType.SmallInt).Value = this.linktoWaitingStatusMasterId;
                SqlCmd.Parameters.Add("@CreateDateTime", SqlDbType.DateTime).Value = this.CreateDateTime;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCmd.Parameters.Add("@linktoUserMasterIdCreatedBy", SqlDbType.SmallInt).Value = this.linktoUserMasterIdCreatedBy;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                this.WaitingMasterId = Convert.ToInt64(SqlCmd.Parameters["@WaitingMasterId"].Value);
                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region Update
        public posRecordStatus UpdateWaitingMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posWaitingMaster_Update", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@WaitingMasterId", SqlDbType.BigInt).Value = this.WaitingMasterId;
                SqlCmd.Parameters.Add("@PersonName", SqlDbType.VarChar).Value = this.PersonName;
                SqlCmd.Parameters.Add("@PersonMobile", SqlDbType.VarChar).Value = this.PersonMobile;
                SqlCmd.Parameters.Add("@NoOfPersons", SqlDbType.SmallInt).Value = this.NoOfPersons;
                SqlCmd.Parameters.Add("@linktoWaitingStatusMasterId", SqlDbType.SmallInt).Value = this.linktoWaitingStatusMasterId;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public posRecordStatus UpdateWaitingStatus()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posWaitingMasterByWaitingMasterId_Update", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCmd.Parameters.Add("@WaitingMasterId", SqlDbType.SmallInt).Value = this.WaitingMasterId;
                SqlCmd.Parameters.Add("@UpdateDateTime", SqlDbType.DateTime).Value = this.UpdateDateTime;
                SqlCmd.Parameters.Add("@linktoUserMasterIdUpdatedBy", SqlDbType.SmallInt).Value = this.linktoUserMasterIdUpdatedBy;               
                SqlCmd.Parameters.Add("@linktoWaitingStatusMasterId", SqlDbType.SmallInt).Value = this.linktoWaitingStatusMasterId;
                if (this.linktoTableMasterId > 0)
                {
                    SqlCmd.Parameters.Add("@linktoTableMasterId", SqlDbType.SmallInt).Value = this.linktoTableMasterId;
                }

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public posRecordStatus UpdateWaitingMasterTable()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posWaitingMasterTable_Update", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@WaitingMasterId", SqlDbType.Int).Value = this.WaitingMasterId;
                SqlCmd.Parameters.Add("@linktoTableMasterId", SqlDbType.SmallInt).Value = this.linktoTableMasterId;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region SelectAll
        public List<posWaitingMasterDAL> SelectAllWaitingMasterByWaitingStatusId()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posWaitingMasterByWaitingStatusId_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@linktoWaitingStatusMasterId", SqlDbType.SmallInt).Value = linktoWaitingStatusMasterId;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = linktoBusinessMasterId;
                SqlCmd.Parameters.Add("@OrderBy", SqlDbType.VarChar).Value = OrderBy;
                SqlCmd.Parameters.Add("@FromDate", SqlDbType.DateTime).Value = CreateDateTime;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<posWaitingMasterDAL> lstUserMasterDAL = SetListPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                return lstUserMasterDAL;
            }
            catch (Exception ex)
            {

                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion
    }
}
