using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace posLibrary
{
    /// <summary>
    /// Class for posJournalVoucherMaster
    /// </summary>
    public class posJournalVoucherMasterDAL
    {
        #region Properties
        public int JournalVoucherMasterId { get; set; }
        public short linktoBusinessMasterId { get; set; }
        public DateTime VoucherDate { get; set; }
        public string VoucherNumber { get; set; }
        public string Remark { get; set; }
        public DateTime CreateDateTime { get; set; }
        public short linktoUserMasterIdCreatedBy { get; set; }
        public DateTime? UpdateDateTime { get; set; }
        public short? linktoUserMasterIdUpdatedBy { get; set; }

        /// Extra
        /// 
        public string AccountName { get; set; }
        public double? Debit { get; set; }
        public double? Credit { get; set; }
        #endregion

        #region Class Methods
        private bool SetClassPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            if (sqlRdr.Read())
            {
                this.JournalVoucherMasterId = Convert.ToInt32(sqlRdr["JournalVoucherMasterId"]);
                this.linktoBusinessMasterId = Convert.ToInt16(sqlRdr["linktoBusinessMasterId"]);
                this.VoucherDate = Convert.ToDateTime(sqlRdr["VoucherDate"]);
                this.VoucherNumber = Convert.ToString(sqlRdr["VoucherNumber"]);
                this.Remark = Convert.ToString(sqlRdr["Remark"]);
                this.CreateDateTime = Convert.ToDateTime(sqlRdr["CreateDateTime"]);
                this.linktoUserMasterIdCreatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdCreatedBy"]);
                if (sqlRdr["UpdateDateTime"] != DBNull.Value)
                {
                    this.UpdateDateTime = Convert.ToDateTime(sqlRdr["UpdateDateTime"]);
                }
                if (sqlRdr["linktoUserMasterIdUpdatedBy"] != DBNull.Value)
                {
                    this.linktoUserMasterIdUpdatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdUpdatedBy"]);
                }

                /// Extra
                return true;
            }
            return false;
        }

        private List<posJournalVoucherMasterDAL> SetListPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            List<posJournalVoucherMasterDAL> lstJournalVoucherMaster = new List<posJournalVoucherMasterDAL>();
            posJournalVoucherMasterDAL objJournalVoucherMaster = null;
            while (sqlRdr.Read())
            {
                objJournalVoucherMaster = new posJournalVoucherMasterDAL();
                objJournalVoucherMaster.JournalVoucherMasterId = Convert.ToInt32(sqlRdr["JournalVoucherMasterId"]);
                objJournalVoucherMaster.linktoBusinessMasterId = Convert.ToInt16(sqlRdr["linktoBusinessMasterId"]);
                objJournalVoucherMaster.VoucherDate = Convert.ToDateTime(sqlRdr["VoucherDate"]);
                objJournalVoucherMaster.VoucherNumber = Convert.ToString(sqlRdr["VoucherNumber"]);
                objJournalVoucherMaster.Remark = Convert.ToString(sqlRdr["Remark"]);
                objJournalVoucherMaster.CreateDateTime = Convert.ToDateTime(sqlRdr["CreateDateTime"]);
                objJournalVoucherMaster.linktoUserMasterIdCreatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdCreatedBy"]);
                if (sqlRdr["UpdateDateTime"] != DBNull.Value)
                {
                    objJournalVoucherMaster.UpdateDateTime = Convert.ToDateTime(sqlRdr["UpdateDateTime"]);
                }
                if (sqlRdr["linktoUserMasterIdUpdatedBy"] != DBNull.Value)
                {
                    objJournalVoucherMaster.linktoUserMasterIdUpdatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdUpdatedBy"]);
                }
                
                /// Extra

                objJournalVoucherMaster.AccountName = Convert.ToString(sqlRdr["AccountName"]);
                if (sqlRdr["Debit"] != DBNull.Value)
                {
                    objJournalVoucherMaster.Debit = Convert.ToDouble(sqlRdr["Debit"]);
                }
                if (sqlRdr["Credit"] != DBNull.Value)
                {
                    objJournalVoucherMaster.Credit = Convert.ToDouble(sqlRdr["Credit"]);
                }

                lstJournalVoucherMaster.Add(objJournalVoucherMaster);
            }
            return lstJournalVoucherMaster;
        }
        #endregion

        #region Insert
        public posRecordStatus InsertJournalVoucherMaster(List<posJournalVoucherTranDAL> lstJournalVoucherTranDAL)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlTransaction sqlTran = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCon.Open();
                sqlTran = SqlCon.BeginTransaction();

                SqlCmd = new SqlCommand("posJournalVoucherMaster_Insert", SqlCon, sqlTran);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@JournalVoucherMasterId", SqlDbType.Int).Direction = ParameterDirection.Output;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCmd.Parameters.Add("@VoucherDate", SqlDbType.Date).Value = this.VoucherDate;
                SqlCmd.Parameters.Add("@VoucherNumber", SqlDbType.VarChar).Value = this.VoucherNumber;
                SqlCmd.Parameters.Add("@Remark", SqlDbType.VarChar).Value = this.Remark;
                SqlCmd.Parameters.Add("@CreateDateTime", SqlDbType.DateTime).Value = this.CreateDateTime;
                SqlCmd.Parameters.Add("@linktoUserMasterIdCreatedBy", SqlDbType.SmallInt).Value = this.linktoUserMasterIdCreatedBy;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCmd.ExecuteNonQuery();

                this.JournalVoucherMasterId = Convert.ToInt32(SqlCmd.Parameters["@JournalVoucherMasterId"].Value);
                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                if (rs != posRecordStatus.Success)
                {
                    sqlTran.Rollback();
                    SqlCon.Close();
                    return rs;
                }
                foreach (posJournalVoucherTranDAL objJournalVoucherTranDAL in lstJournalVoucherTranDAL)
                {
                    objJournalVoucherTranDAL.linktoJournalVoucherMasterId = this.JournalVoucherMasterId;

                    rs = objJournalVoucherTranDAL.InsertJournalVoucherTran(SqlCon, sqlTran);
                    if (rs != posRecordStatus.Success)
                    {
                        sqlTran.Rollback();
                        SqlCon.Close();
                        return rs;
                    }
                }
                sqlTran.Commit();
                SqlCon.Close();
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
                posObjectFactoryDAL.DisposeTransaction(sqlTran);
            }
        }
        #endregion

        #region Update
        public posRecordStatus UpdateJournalVoucherMaster(List<posJournalVoucherTranDAL> lstJournalVoucherTranDAL)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlTransaction sqlTran = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCon.Open();
                sqlTran = SqlCon.BeginTransaction();
                SqlCmd = new SqlCommand("posJournalVoucherMaster_Update", SqlCon, sqlTran);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@JournalVoucherMasterId", SqlDbType.Int).Value = this.JournalVoucherMasterId;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCmd.Parameters.Add("@VoucherDate", SqlDbType.Date).Value = this.VoucherDate;
                SqlCmd.Parameters.Add("@VoucherNumber", SqlDbType.VarChar).Value = this.VoucherNumber;
                SqlCmd.Parameters.Add("@Remark", SqlDbType.VarChar).Value = this.Remark;
                SqlCmd.Parameters.Add("@UpdateDateTime", SqlDbType.DateTime).Value = this.UpdateDateTime;
                SqlCmd.Parameters.Add("@linktoUserMasterIdUpdatedBy", SqlDbType.SmallInt).Value = this.linktoUserMasterIdUpdatedBy;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCmd.ExecuteNonQuery();
                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                if (rs != posRecordStatus.Success)
                {
                    sqlTran.Rollback();
                    SqlCon.Close();
                    return rs;
                }

                posJournalVoucherTranDAL objJournalVoucherTran = new posJournalVoucherTranDAL();
                objJournalVoucherTran.linktoJournalVoucherMasterId = this.JournalVoucherMasterId;
                rs = objJournalVoucherTran.DeleteJournalVoucherTranByJournalVoucherMasterId(SqlCon, sqlTran);
                if (rs != posRecordStatus.Success)
                {
                    sqlTran.Rollback();
                    SqlCon.Close();
                    return rs;
                }

                foreach (posJournalVoucherTranDAL objJournalVoucherTranDAL in lstJournalVoucherTranDAL)
                {
                    objJournalVoucherTranDAL.linktoJournalVoucherMasterId = this.JournalVoucherMasterId;
                    rs = objJournalVoucherTranDAL.InsertJournalVoucherTran(SqlCon, sqlTran);
                    if (rs != posRecordStatus.Success)
                    {
                        sqlTran.Rollback();
                        SqlCon.Close();
                        return rs;
                    }
                }
                sqlTran.Commit();
                SqlCon.Close();
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
                posObjectFactoryDAL.DisposeTransaction(sqlTran);
            }
        }
        #endregion

        #region DeleteAll
        public posRecordStatus DeleteAllJournalVoucherMaster(string journalVoucherMasterIds)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posJournalVoucherMaster_DeleteAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@JournalVoucherMasterIds", SqlDbType.VarChar).Value = journalVoucherMasterIds;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region Select
        public bool SelectJournalVoucherMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posJournalVoucherMaster_Select", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@JournalVoucherMasterId", SqlDbType.Int).Value = this.JournalVoucherMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                bool IsSelected = SetClassPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                return IsSelected;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return false;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region SelectAll
        public List<posJournalVoucherMasterDAL> SelectAllJournalVoucherMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posJournalVoucherMaster_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                if (this.VoucherDate != new DateTime())
                {
                    SqlCmd.Parameters.Add("@VoucherDate", SqlDbType.Date).Value = this.VoucherDate;
                }
                SqlCmd.Parameters.Add("@VoucherNumber", SqlDbType.VarChar).Value = this.VoucherNumber;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<posJournalVoucherMasterDAL> lstJournalVoucherMasterDAL = SetListPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                return lstJournalVoucherMasterDAL;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion
    }
}
