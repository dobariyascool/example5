using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace posLibrary
{
    /// <summary>
    /// Class for posItemRateTran
    /// </summary>
    [Serializable]
    public class posItemRateTranDAL
    {
        #region Properties
        public int ItemRateTranId { get; set; }
        public int linktoItemMasterId { get; set; }
        public double PurchaseRate { get; set; }
        public double MRP { get; set; }
        public double SaleRate { get; set; }
        public double Rate1 { get; set; }
        public double Rate2 { get; set; }
        public double Rate3 { get; set; }
        public double Rate4 { get; set; }
        public double Rate5 { get; set; }
        public decimal Tax1 { get; set; }
        public decimal Tax2 { get; set; }
        public decimal Tax3 { get; set; }
        public decimal Tax4 { get; set; }
        public decimal Tax5 { get; set; }
        public bool IsRateTaxInclusive { get; set; }
        public DateTime RateCreateDateTime { get; set; }
        public short RatelinktoUserMasterIdCreatedBy { get; set; }
        public DateTime? RateUpdateDateTime { get; set; }
        public short? RatelinktoUserMasterIdUpdatedBy { get; set; }
        #endregion

        #region Class Methods
        private bool SetClassPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            if (sqlRdr.Read())
            {
                this.ItemRateTranId = Convert.ToInt32(sqlRdr["ItemRateTranId"]);
                this.linktoItemMasterId = Convert.ToInt32(sqlRdr["linktoItemMasterId"]);
                this.PurchaseRate = Convert.ToDouble(sqlRdr["PurchaseRate"]);
                this.MRP = Convert.ToDouble(sqlRdr["MRP"]);
                this.SaleRate = Convert.ToDouble(sqlRdr["SaleRate"]);
                this.Rate1 = Convert.ToDouble(sqlRdr["Rate1"]);
                this.Rate2 = Convert.ToDouble(sqlRdr["Rate2"]);
                this.Rate3 = Convert.ToDouble(sqlRdr["Rate3"]);
                this.Rate4 = Convert.ToDouble(sqlRdr["Rate4"]);
                this.Rate5 = Convert.ToDouble(sqlRdr["Rate5"]);
                this.Tax1 = Convert.ToDecimal(sqlRdr["Tax1"]);
                this.Tax2 = Convert.ToDecimal(sqlRdr["Tax2"]);
                this.Tax3 = Convert.ToDecimal(sqlRdr["Tax3"]);
                this.Tax4 = Convert.ToDecimal(sqlRdr["Tax4"]);
                this.Tax5 = Convert.ToDecimal(sqlRdr["Tax5"]);
                this.IsRateTaxInclusive = Convert.ToBoolean(sqlRdr["IsRateTaxInclusive"]);
                this.RateCreateDateTime = Convert.ToDateTime(sqlRdr["CreateDateTime"]);
                this.RatelinktoUserMasterIdCreatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdCreatedBy"]);
                if (sqlRdr["UpdateDateTime"] != DBNull.Value)
                {
                    this.RateUpdateDateTime = Convert.ToDateTime(sqlRdr["UpdateDateTime"]);
                }
                if (sqlRdr["linktoUserMasterIdUpdatedBy"] != DBNull.Value)
                {
                    this.RatelinktoUserMasterIdUpdatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdUpdatedBy"]);
                }
                return true;
            }
            return false;
        }
        #endregion

        #region Insert
        public static posRecordStatus InsertItemRateTran(posItemRateTranDAL objItemRateTran, int itemMasterId, SqlConnection sqlCon, SqlTransaction sqlTran)
        {
            SqlCommand SqlCmd = null;
            try
            {
                SqlCmd = new SqlCommand("posItemRateTran_Insert", sqlCon, sqlTran);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@ItemRateTranId", SqlDbType.Int).Direction = ParameterDirection.Output;
                SqlCmd.Parameters.Add("@linktoItemMasterId", SqlDbType.Int).Value = itemMasterId;
                SqlCmd.Parameters.Add("@PurchaseRate", SqlDbType.Money).Value = objItemRateTran.PurchaseRate;
                SqlCmd.Parameters.Add("@MRP", SqlDbType.Money).Value = objItemRateTran.MRP;
                SqlCmd.Parameters.Add("@SaleRate", SqlDbType.Money).Value = objItemRateTran.SaleRate;
                SqlCmd.Parameters.Add("@Rate1", SqlDbType.Money).Value = objItemRateTran.Rate1;
                SqlCmd.Parameters.Add("@Rate2", SqlDbType.Money).Value = objItemRateTran.Rate2;
                SqlCmd.Parameters.Add("@Rate3", SqlDbType.Money).Value = objItemRateTran.Rate3;
                SqlCmd.Parameters.Add("@Rate4", SqlDbType.Money).Value = objItemRateTran.Rate4;
                SqlCmd.Parameters.Add("@Rate5", SqlDbType.Money).Value = objItemRateTran.Rate5;
                SqlCmd.Parameters.Add("@Tax1", SqlDbType.Money).Value = objItemRateTran.Tax1;
                SqlCmd.Parameters.Add("@Tax2", SqlDbType.Money).Value = objItemRateTran.Tax2;
                SqlCmd.Parameters.Add("@Tax3", SqlDbType.Money).Value = objItemRateTran.Tax3;
                SqlCmd.Parameters.Add("@Tax4", SqlDbType.Money).Value = objItemRateTran.Tax4;
                SqlCmd.Parameters.Add("@Tax5", SqlDbType.Money).Value = objItemRateTran.Tax5;
                SqlCmd.Parameters.Add("@IsRateTaxInclusive", SqlDbType.Bit).Value = objItemRateTran.IsRateTaxInclusive;
                SqlCmd.Parameters.Add("@CreateDateTime", SqlDbType.DateTime).Value = objItemRateTran.RateCreateDateTime;
                SqlCmd.Parameters.Add("@linktoUserMasterIdCreatedBy", SqlDbType.SmallInt).Value = objItemRateTran.RatelinktoUserMasterIdCreatedBy;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCmd.ExecuteNonQuery();

                objItemRateTran.ItemRateTranId = Convert.ToInt32(SqlCmd.Parameters["@ItemRateTranId"].Value);
                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
            }
        }
        #endregion

        #region Update
        public static posRecordStatus UpdateItemRateTran(posItemRateTranDAL objItemRateTran, int itemMasterId, SqlConnection sqlCon, SqlTransaction sqlTran)
        {
            SqlCommand SqlCmd = null;
            try
            {
                SqlCmd = new SqlCommand("posItemRateTran_Update", sqlCon, sqlTran);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@linktoItemMasterId", SqlDbType.Int).Value = itemMasterId;
                SqlCmd.Parameters.Add("@PurchaseRate", SqlDbType.Money).Value = objItemRateTran.PurchaseRate;
                SqlCmd.Parameters.Add("@MRP", SqlDbType.Money).Value = objItemRateTran.MRP;
                SqlCmd.Parameters.Add("@SaleRate", SqlDbType.Money).Value = objItemRateTran.SaleRate;
                SqlCmd.Parameters.Add("@Rate1", SqlDbType.Money).Value = objItemRateTran.Rate1;
                SqlCmd.Parameters.Add("@Rate2", SqlDbType.Money).Value = objItemRateTran.Rate2;
                SqlCmd.Parameters.Add("@Rate3", SqlDbType.Money).Value = objItemRateTran.Rate3;
                SqlCmd.Parameters.Add("@Rate4", SqlDbType.Money).Value = objItemRateTran.Rate4;
                SqlCmd.Parameters.Add("@Rate5", SqlDbType.Money).Value = objItemRateTran.Rate5;
                SqlCmd.Parameters.Add("@Tax1", SqlDbType.Money).Value = objItemRateTran.Tax1;
                SqlCmd.Parameters.Add("@Tax2", SqlDbType.Money).Value = objItemRateTran.Tax2;
                SqlCmd.Parameters.Add("@Tax3", SqlDbType.Money).Value = objItemRateTran.Tax3;
                SqlCmd.Parameters.Add("@Tax4", SqlDbType.Money).Value = objItemRateTran.Tax4;
                SqlCmd.Parameters.Add("@Tax5", SqlDbType.Money).Value = objItemRateTran.Tax5;
                SqlCmd.Parameters.Add("@IsRateTaxInclusive", SqlDbType.Bit).Value = objItemRateTran.IsRateTaxInclusive;
                SqlCmd.Parameters.Add("@UpdateDateTime", SqlDbType.DateTime).Value = objItemRateTran.RateUpdateDateTime;
                SqlCmd.Parameters.Add("@linktoUserMasterIdUpdatedBy", SqlDbType.SmallInt).Value = objItemRateTran.RatelinktoUserMasterIdUpdatedBy;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCmd.ExecuteNonQuery();

                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
            }
        }

        public posRecordStatus UpdateItemRateTran(short businessMasterId, short option, SqlConnection sqlCon, SqlTransaction sqlTran)
        {
            SqlCommand SqlCmd = null;
            try
            {
                SqlCmd = new SqlCommand("posItemRateTranUpdatebyTaxSetting_Update", sqlCon, sqlTran);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@Tax1", SqlDbType.Decimal).Value = this.Tax1;
                SqlCmd.Parameters.Add("@Tax2", SqlDbType.Decimal).Value = this.Tax2;
                SqlCmd.Parameters.Add("@Tax3", SqlDbType.Decimal).Value = this.Tax3;
                SqlCmd.Parameters.Add("@Tax4", SqlDbType.Decimal).Value = this.Tax4;
                SqlCmd.Parameters.Add("@Tax5", SqlDbType.Decimal).Value = this.Tax5;
                SqlCmd.Parameters.Add("@Options", SqlDbType.SmallInt).Value = option;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = businessMasterId;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCmd.ExecuteNonQuery();

                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
            }
        }
        #endregion

        #region Select
        public bool SelectItemRateTran()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posItemRateTran_Select", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@linktoItemMasterId", SqlDbType.Int).Value = this.linktoItemMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                bool IsSelected = SetClassPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                return IsSelected;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return false;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        //public bool SelectItemRateTranWithTaxCalculations()
        //{
        //    SqlConnection SqlCon = null;
        //    SqlCommand SqlCmd = null;
        //    SqlDataReader SqlRdr = null;
        //    try
        //    {
        //        SqlCon = posObjectFactoryDAL.CreateConnection();
        //        SqlCmd = new SqlCommand("posItemRateTranWithTaxCalculation_Select", SqlCon);
        //        SqlCmd.CommandType = CommandType.StoredProcedure;

        //        SqlCmd.Parameters.Add("@linktoItemMasterId", SqlDbType.Int).Value = this.linktoItemMasterId;

        //        SqlCon.Open();
        //        SqlRdr = SqlCmd.ExecuteReader();
        //        bool IsSelected = false;
        //        if (SqlRdr.Read())
        //        {
        //            this.ItemRateTranId = Convert.ToInt32(SqlRdr["ItemRateTranId"]);
        //            this.linktoItemMasterId = Convert.ToInt32(SqlRdr["linktoItemMasterId"]);
        //            this.PurchaseRate = Convert.ToDouble(SqlRdr["PurchaseRate"]);
        //            this.MRP = Convert.ToDouble(SqlRdr["MRP"]);
        //            this.SaleRate = Convert.ToDouble(SqlRdr["SaleRate"]);
        //            this.Rate1 = Convert.ToDouble(SqlRdr["Rate1"]);
        //            this.Rate2 = Convert.ToDouble(SqlRdr["Rate2"]);
        //            this.Rate3 = Convert.ToDouble(SqlRdr["Rate3"]);
        //            this.Rate4 = Convert.ToDouble(SqlRdr["Rate4"]);
        //            this.Rate5 = Convert.ToDouble(SqlRdr["Rate5"]);
        //            this.Tax1 = Convert.ToDouble(SqlRdr["Tax1"]);
        //            this.Tax2 = Convert.ToDouble(SqlRdr["Tax2"]);
        //            this.Tax3 = Convert.ToDouble(SqlRdr["Tax3"]);
        //            this.Tax4 = Convert.ToDouble(SqlRdr["Tax4"]);
        //            this.Tax5 = Convert.ToDouble(SqlRdr["Tax5"]);
        //            this.IsRateTaxInclusive = Convert.ToBoolean(SqlRdr["IsRateTaxInclusive"]);
        //            this.RateCreateDateTime = Convert.ToDateTime(SqlRdr["CreateDateTime"]);
        //            this.RatelinktoUserMasterIdCreatedBy = Convert.ToInt16(SqlRdr["linktoUserMasterIdCreatedBy"]);
        //            if (SqlRdr["UpdateDateTime"] != DBNull.Value)
        //            {
        //                this.RateUpdateDateTime = Convert.ToDateTime(SqlRdr["UpdateDateTime"]);
        //            }
        //            if (SqlRdr["linktoUserMasterIdUpdatedBy"] != DBNull.Value)
        //            {
        //                this.RatelinktoUserMasterIdUpdatedBy = Convert.ToInt16(SqlRdr["linktoUserMasterIdUpdatedBy"]);
        //            }
        //            this.MRPWithTax = Convert.ToDouble(SqlRdr["MRPWithTax"]);
        //            this.Rate1WithTax = Convert.ToDouble(SqlRdr["Rate1WithTax"]);
        //            this.Rate2WithTax = Convert.ToDouble(SqlRdr["Rate2WithTax"]);
        //            this.Rate3WithTax = Convert.ToDouble(SqlRdr["Rate3WithTax"]);
        //            this.Rate4WithTax = Convert.ToDouble(SqlRdr["Rate4WithTax"]);
        //            this.Rate5WithTax = Convert.ToDouble(SqlRdr["Rate5WithTax"]);

        //            IsSelected = true;
        //        }
        //        SqlRdr.Close();
        //        SqlCon.Close();

        //        return IsSelected;
        //    }
        //    catch (Exception ex)
        //    {
        //        posGlobalsDAL.SaveError(ex);
        //        return false;
        //    }
        //    finally
        //    {
        //        posObjectFactoryDAL.DisposeDataReader(SqlRdr);
        //        posObjectFactoryDAL.DisposeCommand(SqlCmd);
        //        posObjectFactoryDAL.DisposeConnection(SqlCon);
        //    }
        //}
        #endregion
    }
}
