using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace posLibrary
{
    /// <summary>
    /// Class for posMiscExpenseCategoryMaster
    /// </summary>
    public class posMiscExpenseCategoryMasterDAL
    {
        #region Properties
        public short MiscExpenseCategoryMasterId { get; set; }
        public string CategoryName { get; set; }
        public string Description { get; set; }
        public bool IsEnabled { get; set; }
        public short linktoBusinessMasterId { get; set; }
        #endregion

        #region Class Methods
        private bool SetClassPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            if (sqlRdr.Read())
            {
                this.MiscExpenseCategoryMasterId = Convert.ToInt16(sqlRdr["MiscExpenseCategoryMasterId"]);
                this.CategoryName = Convert.ToString(sqlRdr["CategoryName"]);
                this.Description = Convert.ToString(sqlRdr["Description"]);
                this.IsEnabled = Convert.ToBoolean(sqlRdr["IsEnabled"]);
                return true;
            }
            return false;
        }

        private List<posMiscExpenseCategoryMasterDAL> SetListPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            List<posMiscExpenseCategoryMasterDAL> lstMiscExpenseCategoryMaster = new List<posMiscExpenseCategoryMasterDAL>();
            posMiscExpenseCategoryMasterDAL objMiscExpenseCategoryMaster = null;
            while (sqlRdr.Read())
            {
                objMiscExpenseCategoryMaster = new posMiscExpenseCategoryMasterDAL();
                objMiscExpenseCategoryMaster.MiscExpenseCategoryMasterId = Convert.ToInt16(sqlRdr["MiscExpenseCategoryMasterId"]);
                objMiscExpenseCategoryMaster.CategoryName = Convert.ToString(sqlRdr["CategoryName"]);
                objMiscExpenseCategoryMaster.Description = Convert.ToString(sqlRdr["Description"]);
                objMiscExpenseCategoryMaster.IsEnabled = Convert.ToBoolean(sqlRdr["IsEnabled"]);
                lstMiscExpenseCategoryMaster.Add(objMiscExpenseCategoryMaster);
            }
            return lstMiscExpenseCategoryMaster;
        }
        #endregion

        #region Insert
        public posRecordStatus InsertMiscExpenseCategoryMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posMiscExpenseCategoryMaster_Insert", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@MiscExpenseCategoryMasterId", SqlDbType.SmallInt).Direction = ParameterDirection.Output;
                SqlCmd.Parameters.Add("@CategoryName", SqlDbType.VarChar).Value = this.CategoryName;
                SqlCmd.Parameters.Add("@Description", SqlDbType.VarChar).Value = this.Description;
                SqlCmd.Parameters.Add("@IsEnabled", SqlDbType.Bit).Value = this.IsEnabled;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                this.MiscExpenseCategoryMasterId = Convert.ToInt16(SqlCmd.Parameters["@MiscExpenseCategoryMasterId"].Value);
                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region Update
        public posRecordStatus UpdateMiscExpenseCategoryMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posMiscExpenseCategoryMaster_Update", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@MiscExpenseCategoryMasterId", SqlDbType.SmallInt).Value = this.MiscExpenseCategoryMasterId;
                SqlCmd.Parameters.Add("@CategoryName", SqlDbType.VarChar).Value = this.CategoryName;
                SqlCmd.Parameters.Add("@Description", SqlDbType.VarChar).Value = this.Description;
                SqlCmd.Parameters.Add("@IsEnabled", SqlDbType.Bit).Value = this.IsEnabled;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region DeleteAll
        public static posRecordStatus DeleteAllMiscExpenseCategoryMaster(string miscExpenseCategoryMasterIds)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posMiscExpenseCategoryMaster_DeleteAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@MiscExpenseCategoryMasterIds", SqlDbType.VarChar).Value = miscExpenseCategoryMasterIds;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region Select
        public bool SelectMiscExpenseCategoryMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posMiscExpenseCategoryMaster_Select", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@MiscExpenseCategoryMasterId", SqlDbType.SmallInt).Value = this.MiscExpenseCategoryMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                bool IsSelected = SetClassPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                return IsSelected;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return false;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region SelectAll
        public List<posMiscExpenseCategoryMasterDAL> SelectAllMiscExpenseCategoryMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posMiscExpenseCategoryMaster_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@IsEnabled", SqlDbType.Bit).Value = this.IsEnabled;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<posMiscExpenseCategoryMasterDAL> lstMiscExpenseCategoryMasterDAL = SetListPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                return lstMiscExpenseCategoryMasterDAL;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public static List<posMiscExpenseCategoryMasterDAL> SelectAllMiscExpenseCategoryMasterCategoryName(short linktoBusinessMasterId)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posMiscExpenseCategoryMasterCategoryName_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = linktoBusinessMasterId;
                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<posMiscExpenseCategoryMasterDAL> lstMiscExpenseCategoryMasterDAL = new List<posMiscExpenseCategoryMasterDAL>();
                posMiscExpenseCategoryMasterDAL objMiscExpenseCategoryMasterDAL = null;
                while (SqlRdr.Read())
                {
                    objMiscExpenseCategoryMasterDAL = new posMiscExpenseCategoryMasterDAL();
                    objMiscExpenseCategoryMasterDAL.MiscExpenseCategoryMasterId = Convert.ToInt16(SqlRdr["MiscExpenseCategoryMasterId"]);
                    objMiscExpenseCategoryMasterDAL.CategoryName = Convert.ToString(SqlRdr["CategoryName"]);
                    lstMiscExpenseCategoryMasterDAL.Add(objMiscExpenseCategoryMasterDAL);
                }
                SqlRdr.Close();
                SqlCon.Close();

                return lstMiscExpenseCategoryMasterDAL;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion
    }
}
