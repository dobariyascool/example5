using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace posLibrary
{
	/// <summary>
	/// 
	/// </summary>
    public class posShortcutDAL
	{
		#region Properties
        public short ShortcutId { get; set; }
        public string ShortcutName { get; set; }
		public string ShortcutKey { get; set; }
		#endregion

		#region Class Methods
        //private List<posShortcutDAL> SetListPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        //{
        //    List<posShortcutDAL> lstShortcut = new List<posShortcutDAL>();
        //    posShortcutDAL objShortcut = null;
        //    while (sqlRdr.Read())
        //    {
        //        objShortcut = new posShortcutDAL();
        //        objShortcut.ShortcutId = Convert.ToInt16(sqlRdr["ShortcutId"]);
        //        objShortcut.ShortcutName = Convert.ToString(sqlRdr["ShortcutName"]);
        //        objShortcut.ShortcutKey = Convert.ToString(sqlRdr["ShortcutKey"]);
        //        lstShortcut.Add(objShortcut);
        //    }
        //    return lstShortcut;
        //}
		#endregion

		#region SelectAll
        public List<posShortcutDAL> SelectAllShortcut()
		{
			SqlConnection SqlCon = null;
			SqlCommand SqlCmd = null;
			SqlDataReader SqlRdr = null;
			try
			{
				SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posShortcut_SelectAll", SqlCon);
				SqlCmd.CommandType = CommandType.StoredProcedure;

				SqlCon.Open();
				SqlRdr = SqlCmd.ExecuteReader();

                List<posShortcutDAL> lstShortcut = new List<posShortcutDAL>();
                posShortcutDAL objShortcut = null;
                while (SqlRdr.Read())
                {
                    objShortcut = new posShortcutDAL();
                    objShortcut.ShortcutName = Convert.ToString(SqlRdr["ShortcutName"]);
                    objShortcut.ShortcutKey = Convert.ToString(SqlRdr["ShortcutKey"]);
                    lstShortcut.Add(objShortcut);
                }

				SqlRdr.Close();
				SqlCon.Close();

				return lstShortcut;
			}
			catch (Exception ex)
			{
				posGlobalsDAL.SaveError(ex);
				return null;
			}
			finally
			{
				posObjectFactoryDAL.DisposeDataReader(SqlRdr);
				posObjectFactoryDAL.DisposeCommand(SqlCmd);
				posObjectFactoryDAL.DisposeConnection(SqlCon);
			}
		}
		#endregion
	}
}
