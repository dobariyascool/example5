using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace posLibrary
{
	/// <summary>
	/// Class for posTableAmentitiesTran
	/// </summary>
	public class posTableAmentitiesTranDAL
	{
		#region Properties
		public int TableAmentitiesTranId { get; set; }
		public short linktoTableMasterId { get; set; }
		public short linktoAmentitiesMasterId { get; set; }

		/// Extra
		public string Table { get; set; }
		public string Amentities { get; set; }

		#endregion

		#region Class Methods
		private List<posTableAmentitiesTranDAL> SetListPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
		{
			List<posTableAmentitiesTranDAL> lstTableAmentitiesTran = new List<posTableAmentitiesTranDAL>();
			posTableAmentitiesTranDAL objTableAmentitiesTran = null;
			while (sqlRdr.Read())
			{
				objTableAmentitiesTran = new posTableAmentitiesTranDAL();
				objTableAmentitiesTran.TableAmentitiesTranId = Convert.ToInt32(sqlRdr["TableAmentitiesTranId"]);
				objTableAmentitiesTran.linktoTableMasterId = Convert.ToInt16(sqlRdr["linktoTableMasterId"]);
				objTableAmentitiesTran.linktoAmentitiesMasterId = Convert.ToInt16(sqlRdr["linktoAmentitiesMasterId"]);

				/// Extra
				objTableAmentitiesTran.Table = Convert.ToString(sqlRdr["Table"]);
				objTableAmentitiesTran.Amentities = Convert.ToString(sqlRdr["Amentities"]);
				lstTableAmentitiesTran.Add(objTableAmentitiesTran);
			}
			return lstTableAmentitiesTran;
		}
		#endregion

		#region Insert
		public static posRecordStatus InsertTableAmentitiesTran(string amentitiesIds,short tableMasterId )
		{
			SqlConnection SqlCon = null;
			SqlCommand SqlCmd = null;
			try
			{
				SqlCon = posObjectFactoryDAL.CreateConnection();
				SqlCmd = new SqlCommand("posTableAmentitiesTran_Insert", SqlCon);
				SqlCmd.CommandType = CommandType.StoredProcedure;
				
                SqlCmd.Parameters.Add("@AmentitiesIds", SqlDbType.VarChar).Value = amentitiesIds;
                SqlCmd.Parameters.Add("@linktoTableMasterId", SqlDbType.SmallInt).Value = tableMasterId;
				SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

				SqlCon.Open();
				SqlCmd.ExecuteNonQuery();
				SqlCon.Close();

				posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
				return rs;
			}
			catch (Exception ex)
			{
				posGlobalsDAL.SaveError(ex);
				return posRecordStatus.Error;
			}
			finally
			{
				posObjectFactoryDAL.DisposeCommand(SqlCmd);
				posObjectFactoryDAL.DisposeConnection(SqlCon);
			}
		}
		#endregion

		#region SelectAll
        public  List<posTableAmentitiesTranDAL> SelectAllTableAmentitiesTranByTableMasterId()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posTableAmentitiesTranBylinktoTableMasterId_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@linktoTableMasterId", SqlDbType.Int).Value = this.linktoTableMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();

                List<posTableAmentitiesTranDAL> lstTableAmentitiesTranDALL = new List<posTableAmentitiesTranDAL>();
                posTableAmentitiesTranDAL objTableAmentitiesTranDAL = null;
                while (SqlRdr.Read())
                {
                    objTableAmentitiesTranDAL = new posTableAmentitiesTranDAL();
                    objTableAmentitiesTranDAL.linktoTableMasterId = Convert.ToInt16(SqlRdr["linktoTableMasterId"]);
                    objTableAmentitiesTranDAL.linktoAmentitiesMasterId = Convert.ToInt16(SqlRdr["linktoAmentitiesMasterId"]);

                    lstTableAmentitiesTranDALL.Add(objTableAmentitiesTranDAL);
                }

                SqlRdr.Close();
                SqlCon.Close();

                return lstTableAmentitiesTranDALL;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
		#endregion
	}
}
