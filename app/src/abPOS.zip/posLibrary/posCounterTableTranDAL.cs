using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace posLibrary
{
    /// <summary>
    /// Class for posCounterTableTran
    /// </summary>
    public class posCounterTableTranDAL
    {
        #region Properties
        public int CounterTableTranId { get; set; }
        public short linktoCounterMasterId { get; set; }
        public short linktoTableMasterId { get; set; }

        /// Extra
        public string Table { get; set; }
        public Boolean IsSelected { get; set; }
        public int TableMasterID { get; set; }
        public string OrderType { get; set; }
        public string Counter { get; set; }
        #endregion

        #region Class Methods
        private List<posCounterTableTranDAL> SetListPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            List<posCounterTableTranDAL> lstCounterTableTran = new List<posCounterTableTranDAL>();
            posCounterTableTranDAL objCounterTableTran = null;
            while (sqlRdr.Read())
            {
                objCounterTableTran = new posCounterTableTranDAL();
                if (sqlRdr["CounterTableTranId"] != DBNull.Value)
                {
                    objCounterTableTran.CounterTableTranId = Convert.ToInt32(sqlRdr["CounterTableTranId"]);
                    objCounterTableTran.IsSelected = true;
                }
                else
                {
                    objCounterTableTran.IsSelected = false;
                }
                if (sqlRdr["linktoCounterMasterId"] != DBNull.Value)
                {
                    objCounterTableTran.linktoCounterMasterId = Convert.ToInt16(sqlRdr["linktoCounterMasterId"]);
                } if (sqlRdr["linktoTableMasterId"] != DBNull.Value)
                {
                    objCounterTableTran.linktoTableMasterId = Convert.ToInt16(sqlRdr["linktoTableMasterId"]);
                }
                /// Extra
                objCounterTableTran.Table = Convert.ToString(sqlRdr["TableName"]);
                objCounterTableTran.OrderType = Convert.ToString(sqlRdr["OrderType"]);
                objCounterTableTran.TableMasterID = Convert.ToInt32(sqlRdr["TableMasterId"]);
                lstCounterTableTran.Add(objCounterTableTran);
            }
            return lstCounterTableTran;
        }
        #endregion

        #region Insert
        public static posRecordStatus InsertCounterTableTran(string TableMasterIds, int linktoCounterMasterId)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posCounterTableTran_Insert", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@TableMasterIds", SqlDbType.VarChar).Value = TableMasterIds;
                SqlCmd.Parameters.Add("@CounterMasterID", SqlDbType.SmallInt).Value = linktoCounterMasterId;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public posRecordStatus InsertCounterTableTran(List<posCounterTableTranDAL> lstCounterTableTranDAL, short linktoBusinessMasterId, SqlConnection SqlCon, SqlTransaction SqlTran)
        {
            SqlCommand SqlCmd = null;
            try
            {
                posRecordStatus rs = posRecordStatus.Error;

                SqlCmd = new SqlCommand("posCounterTableTranConfiguration_Insert", SqlCon, SqlTran);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                foreach (posCounterTableTranDAL objCounterTableTran in lstCounterTableTranDAL)
                {
                    SqlCmd.Parameters.Clear();
                    SqlCmd.Parameters.Add("@TableName", SqlDbType.VarChar).Value = objCounterTableTran.Table;
                    SqlCmd.Parameters.Add("@CounterName", SqlDbType.VarChar).Value = objCounterTableTran.Counter;
                    SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = linktoBusinessMasterId;
                    SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                    SqlCmd.ExecuteNonQuery();

                    rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                    if (rs != posRecordStatus.Success)
                    {
                        return rs;
                    }
                }
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
            }
        }
        #endregion

        #region SelectAll
        public List<posCounterTableTranDAL> SelectAllCounterTableTran(short linktoBusinessMasterId)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posCounterTableTran_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@CounterMasterID", SqlDbType.VarChar).Value = linktoCounterMasterId;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = linktoBusinessMasterId;
                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<posCounterTableTranDAL> lstCounterTableTranDAL = SetListPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                return lstCounterTableTranDAL;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion
    }
}
