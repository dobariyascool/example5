using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace posLibrary
{
    /// <summary>
    /// Class for posUnitMaster
    /// </summary>
    public class posUnitMasterDAL
    {
        #region Properties
        public short UnitMasterId { get; set; }
        public string ShortName { get; set; }
        public string UnitName { get; set; }
        public string Description { get; set; }
        public bool IsEnabled { get; set; }
        public bool IsDeleted { get; set; }
        public short linktoBusinessMasterId { get; set; }
        public short linktoUserMasterIdCreatedBy { get; set; }
        public DateTime CreateDateTime { get; set; }
        public short? linktoUserMasterIdUpdatedBy { get; set; }
        public DateTime? UpdateDateTime { get; set; }
        #endregion

        #region Class Methods
        private bool SetClassPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            if (sqlRdr.Read())
            {
                this.UnitMasterId = Convert.ToInt16(sqlRdr["UnitMasterId"]);
                this.ShortName = Convert.ToString(sqlRdr["ShortName"]);
                this.UnitName = Convert.ToString(sqlRdr["UnitName"]);
                this.Description = Convert.ToString(sqlRdr["Description"]);
                this.IsEnabled = Convert.ToBoolean(sqlRdr["IsEnabled"]);
                this.IsDeleted = Convert.ToBoolean(sqlRdr["IsDeleted"]);
                this.linktoBusinessMasterId = Convert.ToInt16(sqlRdr["linktoBusinessMasterId"]);
                this.linktoUserMasterIdCreatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdCreatedBy"]);
                this.CreateDateTime = Convert.ToDateTime(sqlRdr["CreateDateTime"]);
                if (sqlRdr["linktoUserMasterIdUpdatedBy"] != DBNull.Value)
                {
                    this.linktoUserMasterIdUpdatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdUpdatedBy"]);
                }
                if (sqlRdr["UpdateDateTime"] != DBNull.Value)
                {
                    this.UpdateDateTime = Convert.ToDateTime(sqlRdr["UpdateDateTime"]);
                }

                return true;
            }
            return false;
        }

        private List<posUnitMasterDAL> SetListPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            List<posUnitMasterDAL> lstUnitMaster = new List<posUnitMasterDAL>();
            posUnitMasterDAL objUnitMaster = null;
            while (sqlRdr.Read())
            {
                objUnitMaster = new posUnitMasterDAL();
                objUnitMaster.UnitMasterId = Convert.ToInt16(sqlRdr["UnitMasterId"]);
                objUnitMaster.ShortName = Convert.ToString(sqlRdr["ShortName"]);
                objUnitMaster.UnitName = Convert.ToString(sqlRdr["UnitName"]);
                objUnitMaster.Description = Convert.ToString(sqlRdr["Description"]);
                objUnitMaster.IsEnabled = Convert.ToBoolean(sqlRdr["IsEnabled"]);
                objUnitMaster.IsDeleted = Convert.ToBoolean(sqlRdr["IsDeleted"]);
                objUnitMaster.linktoBusinessMasterId = Convert.ToInt16(sqlRdr["linktoBusinessMasterId"]);
                objUnitMaster.linktoUserMasterIdCreatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdCreatedBy"]);
                objUnitMaster.CreateDateTime = Convert.ToDateTime(sqlRdr["CreateDateTime"]);
                if (sqlRdr["linktoUserMasterIdUpdatedBy"] != DBNull.Value)
                {
                    objUnitMaster.linktoUserMasterIdUpdatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdUpdatedBy"]);
                }
                if (sqlRdr["UpdateDateTime"] != DBNull.Value)
                {
                    objUnitMaster.UpdateDateTime = Convert.ToDateTime(sqlRdr["UpdateDateTime"]);
                }

                lstUnitMaster.Add(objUnitMaster);
            }
            return lstUnitMaster;
        }
        #endregion

        #region Insert
        public posRecordStatus InsertUnitMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posUnitMaster_Insert", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@UnitMasterId", SqlDbType.SmallInt).Direction = ParameterDirection.Output;
                SqlCmd.Parameters.Add("@ShortName", SqlDbType.VarChar).Value = this.ShortName;
                SqlCmd.Parameters.Add("@UnitName", SqlDbType.VarChar).Value = this.UnitName;
                SqlCmd.Parameters.Add("@Description", SqlDbType.VarChar).Value = this.Description;
                SqlCmd.Parameters.Add("@IsEnabled", SqlDbType.Bit).Value = this.IsEnabled;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCmd.Parameters.Add("@IsDeleted", SqlDbType.Bit).Value = this.IsDeleted;
                SqlCmd.Parameters.Add("@linktoUserMasterIdCreatedBy", SqlDbType.SmallInt).Value = this.linktoUserMasterIdCreatedBy;
                SqlCmd.Parameters.Add("@CreateDateTime", SqlDbType.DateTime).Value = this.CreateDateTime;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                this.UnitMasterId = Convert.ToInt16(SqlCmd.Parameters["@UnitMasterId"].Value);
                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public posRecordStatus InsertUnitMasterUnits(SqlConnection sqlCon, SqlTransaction sqlTran, List<posUnitMasterDAL> lstUnitMasterDAL)
        {
            SqlCommand SqlCmd = null;
            try
            {
                posRecordStatus rs = posRecordStatus.Error;
                SqlCmd = new SqlCommand("posUnitMaster_Insert", sqlCon, sqlTran);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                foreach (posUnitMasterDAL objUnitMasterDAL in lstUnitMasterDAL)
                {
                    SqlCmd.Parameters.Clear();
                    SqlCmd.Parameters.Add("@UnitMasterId", SqlDbType.SmallInt).Direction = ParameterDirection.Output;
                    SqlCmd.Parameters.Add("@ShortName", SqlDbType.VarChar).Value = objUnitMasterDAL.ShortName;
                    SqlCmd.Parameters.Add("@UnitName", SqlDbType.VarChar).Value = objUnitMasterDAL.UnitName;
                    SqlCmd.Parameters.Add("@Description", SqlDbType.VarChar).Value = objUnitMasterDAL.Description;
                    SqlCmd.Parameters.Add("@IsEnabled", SqlDbType.Bit).Value = objUnitMasterDAL.IsEnabled;
                    SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                    SqlCmd.Parameters.Add("@IsDeleted", SqlDbType.Bit).Value = objUnitMasterDAL.IsDeleted;
                    SqlCmd.Parameters.Add("@linktoUserMasterIdCreatedBy", SqlDbType.SmallInt).Value = this.linktoUserMasterIdCreatedBy;
                    SqlCmd.Parameters.Add("@CreateDateTime", SqlDbType.DateTime).Value = objUnitMasterDAL.CreateDateTime;

                    SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;
                    SqlCmd.ExecuteNonQuery();

                    this.UnitMasterId = Convert.ToInt16(SqlCmd.Parameters["@UnitMasterId"].Value);

                    rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                    if (rs != posRecordStatus.Success)
                    {
                        return rs;
                    }
                }
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
            }
        }
        #endregion

        #region Update
        public posRecordStatus UpdateUnitMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posUnitMaster_Update", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@UnitMasterId", SqlDbType.SmallInt).Value = this.UnitMasterId;
                SqlCmd.Parameters.Add("@ShortName", SqlDbType.VarChar).Value = this.ShortName;
                SqlCmd.Parameters.Add("@UnitName", SqlDbType.VarChar).Value = this.UnitName;
                SqlCmd.Parameters.Add("@Description", SqlDbType.VarChar).Value = this.Description;
                SqlCmd.Parameters.Add("@IsEnabled", SqlDbType.Bit).Value = this.IsEnabled;
                SqlCmd.Parameters.Add("@IsDeleted", SqlDbType.Bit).Value = this.IsDeleted;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCmd.Parameters.Add("@linktoUserMasterIdUpdatedBy", SqlDbType.SmallInt).Value = this.linktoUserMasterIdUpdatedBy;
                SqlCmd.Parameters.Add("@UpdateDateTime", SqlDbType.DateTime).Value = this.UpdateDateTime;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region DeleteAll
        public static posRecordStatus DeleteAllUnitMaster(string unitMasterIds)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posUnitMaster_DeleteAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@UnitMasterIds", SqlDbType.VarChar).Value = unitMasterIds;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region Select
        public bool SelectUnitMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posUnitMaster_Select", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@UnitMasterId", SqlDbType.SmallInt).Value = this.UnitMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                bool IsSelected = SetClassPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                return IsSelected;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return false;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region SelectAll
        public List<posUnitMasterDAL> SelectAllUnitMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posUnitMaster_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@IsEnabled", SqlDbType.Bit).Value = this.IsEnabled;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<posUnitMasterDAL> lstUnitMasterDAL = SetListPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                return lstUnitMasterDAL;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public static List<posUnitMasterDAL> SelectAllUnitMasterUnitName(short linktoBusinessMasterId)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posUnitMasterUnitName_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = linktoBusinessMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<posUnitMasterDAL> lstUnitMasterDAL = new List<posUnitMasterDAL>();
                posUnitMasterDAL objUnitMasterDAL = null;
                while (SqlRdr.Read())
                {
                    objUnitMasterDAL = new posUnitMasterDAL();
                    objUnitMasterDAL.UnitMasterId = Convert.ToInt16(SqlRdr["UnitMasterId"]);
                    objUnitMasterDAL.UnitName = Convert.ToString(SqlRdr["UnitName"]);
                    lstUnitMasterDAL.Add(objUnitMasterDAL);
                }
                SqlRdr.Close();
                SqlCon.Close();

                return lstUnitMasterDAL;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion
    }
}
