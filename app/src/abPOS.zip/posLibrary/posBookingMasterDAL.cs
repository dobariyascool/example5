using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace posLibrary
{
    /// <summary>
    /// Class for posBookingMaster
    /// </summary>
    public class posBookingMasterDAL
    {
        #region Properties
        public int BookingMasterId { get; set; }
        public DateTime FromDate { get; set; }
        public DateTime ToDate { get; set; }
        public TimeSpan? FromTime { get; set; }
        public TimeSpan? ToTime { get; set; }        
        public int linktoCustomerMasterId { get; set; }
        public short NoOfAdults { get; set; }
        public short NoOfChildren { get; set; }
        public double TotalAmount { get; set; }
        public short DiscountPercentage { get; set; }
        public double DiscountAmount { get; set; }
        public double ExtraAmount { get; set; }
        public double NetAmount { get; set; }
        public double PaidAmount { get; set; }
        public double BalanceAmount { get; set; }
        public string Remark { get; set; }
        public DateTime CreateDateTime { get; set; }
        public short linktoUserMasterIdCreatedBy { get; set; }
        public DateTime? UpdateDateTime { get; set; }
        public short? linktoUserMasterIdUpdatedBy { get; set; }
        public short linktoBusinessMasterId { get; set; }
        public bool IsDeleted { get; set; }
        public bool IsHourly { get; set; }

        /// Extra
        public string Table { get; set; }

        public List<posBookingPaymentTranDAL> lstBookingPaymentTran { get; set; }
        public string Customer { get; set; }
        public List<posCustomerMasterDAL> lstCustomerMasterDAL { get; set; }
        public string linktoTableMasterIds { get; set; }
        public short linktoTableMasterId { get; set; }

        #region  Booking Master Hourly Properties

        public short linktoSectionMasterId { get; set; }

        public string T0 { get; set; }
        public string T1 { get; set; }
        public string T2 { get; set; }
        public string T3 { get; set; }
        public string T4 { get; set; }
        public string T5 { get; set; }
        public string T6 { get; set; }
        public string T7 { get; set; }
        public string T8 { get; set; }
        public string T9 { get; set; }
        public string T10 { get; set; }
        public string T11 { get; set; }
        public string T12 { get; set; }
        public string T13 { get; set; }
        public string T14 { get; set; }
        public string T15 { get; set; }
        public string T16 { get; set; }
        public string T17 { get; set; }
        public string T18 { get; set; }
        public string T19 { get; set; }
        public string T20 { get; set; }
        public string T21 { get; set; }
        public string T22 { get; set; }
        public string T23 { get; set; }

        #endregion

        #endregion

        #region Class Methods
        private bool SetClassPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            if (sqlRdr.Read())
            {
                this.BookingMasterId = Convert.ToInt32(sqlRdr["BookingMasterId"]);
                this.FromDate = Convert.ToDateTime(sqlRdr["FromDate"]);
                this.ToDate = Convert.ToDateTime(sqlRdr["ToDate"]);
                if (sqlRdr["FromTime"] != DBNull.Value)
                {
                    this.FromTime = TimeSpan.Parse(sqlRdr["FromTime"].ToString());
                }
                if (sqlRdr["ToTime"] != DBNull.Value)
                {
                    this.ToTime = TimeSpan.Parse(sqlRdr["ToTime"].ToString());
                }
                //this.linktoTableMasterId = Convert.ToInt16(sqlRdr["linktoTableMasterId"]);
                this.linktoCustomerMasterId = Convert.ToInt32(sqlRdr["linktoCustomerMasterId"]);
                this.NoOfAdults = Convert.ToInt16(sqlRdr["NoOfAdults"]);
                this.NoOfChildren = Convert.ToInt16(sqlRdr["NoOfChildren"]);
                this.TotalAmount = Convert.ToDouble(sqlRdr["TotalAmount"]);
                this.DiscountPercentage = Convert.ToInt16(sqlRdr["DiscountPercentage"]);
                this.DiscountAmount = Convert.ToDouble(sqlRdr["DiscountAmount"]);
                this.ExtraAmount = Convert.ToDouble(sqlRdr["ExtraAmount"]);
                this.NetAmount = Convert.ToDouble(sqlRdr["NetAmount"]);
                this.PaidAmount = Convert.ToDouble(sqlRdr["PaidAmount"]);
                this.BalanceAmount = Convert.ToDouble(sqlRdr["BalanceAmount"]);
                this.Remark = Convert.ToString(sqlRdr["Remark"]);
                this.CreateDateTime = Convert.ToDateTime(sqlRdr["CreateDateTime"]);
                this.linktoUserMasterIdCreatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdCreatedBy"]);
                if (sqlRdr["UpdateDateTime"] != DBNull.Value)
                {
                    this.UpdateDateTime = Convert.ToDateTime(sqlRdr["UpdateDateTime"]);
                }
                if (sqlRdr["linktoUserMasterIdUpdatedBy"] != DBNull.Value)
                {
                    this.linktoUserMasterIdUpdatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdUpdatedBy"]);
                }
                this.linktoBusinessMasterId = Convert.ToInt16(sqlRdr["linktoBusinessMasterId"]);
                this.IsDeleted = Convert.ToBoolean(sqlRdr["IsDeleted"]);
                this.IsHourly = Convert.ToBoolean(sqlRdr["IsHourly"]);

                /// Extra
                //this.Table = Convert.ToString(sqlRdr["TableName"]);
                //this.linktoSectionMasterId = Convert.ToInt16(sqlRdr["linktoSectionMasterId"]);
                this.Customer = Convert.ToString(sqlRdr["Customer"]);
                return true;
            }
            return false;
        }

        private List<posBookingMasterDAL> SetListPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            List<posBookingMasterDAL> lstBookingMaster = new List<posBookingMasterDAL>();
            posBookingMasterDAL objBookingMaster = null;
            while (sqlRdr.Read())
            {
                objBookingMaster = new posBookingMasterDAL();
                objBookingMaster.BookingMasterId = Convert.ToInt32(sqlRdr["BookingMasterId"]);
                objBookingMaster.FromDate = Convert.ToDateTime(sqlRdr["FromDate"]);
                objBookingMaster.ToDate = Convert.ToDateTime(sqlRdr["ToDate"]);
                if (sqlRdr["FromTime"] != DBNull.Value)
                {
                    objBookingMaster.FromTime = TimeSpan.Parse(sqlRdr["FromTime"].ToString());
                }
                if (sqlRdr["ToTime"] != DBNull.Value)
                {
                    objBookingMaster.ToTime = TimeSpan.Parse(sqlRdr["ToTime"].ToString());
                }
                //objBookingMaster.linktoTableMasterId = Convert.ToInt16(sqlRdr["linktoTableMasterId"]);
                objBookingMaster.linktoCustomerMasterId = Convert.ToInt32(sqlRdr["linktoCustomerMasterId"]);
                objBookingMaster.NoOfAdults = Convert.ToInt16(sqlRdr["NoOfAdults"]);
                objBookingMaster.NoOfChildren = Convert.ToInt16(sqlRdr["NoOfChildren"]);
                objBookingMaster.TotalAmount = Convert.ToDouble(sqlRdr["TotalAmount"]);
                objBookingMaster.DiscountPercentage = Convert.ToInt16(sqlRdr["DiscountPercentage"]);
                objBookingMaster.DiscountAmount = Convert.ToDouble(sqlRdr["DiscountAmount"]);
                objBookingMaster.ExtraAmount = Convert.ToDouble(sqlRdr["ExtraAmount"]);
                objBookingMaster.NetAmount = Convert.ToDouble(sqlRdr["NetAmount"]);
                objBookingMaster.PaidAmount = Convert.ToDouble(sqlRdr["PaidAmount"]);
                objBookingMaster.BalanceAmount = Convert.ToDouble(sqlRdr["BalanceAmount"]);
                objBookingMaster.Remark = Convert.ToString(sqlRdr["Remark"]);
                objBookingMaster.CreateDateTime = Convert.ToDateTime(sqlRdr["CreateDateTime"]);
                objBookingMaster.linktoUserMasterIdCreatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdCreatedBy"]);
                if (sqlRdr["UpdateDateTime"] != DBNull.Value)
                {
                    objBookingMaster.UpdateDateTime = Convert.ToDateTime(sqlRdr["UpdateDateTime"]);
                }
                if (sqlRdr["linktoUserMasterIdUpdatedBy"] != DBNull.Value)
                {
                    objBookingMaster.linktoUserMasterIdUpdatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdUpdatedBy"]);
                }
                objBookingMaster.linktoBusinessMasterId = Convert.ToInt16(sqlRdr["linktoBusinessMasterId"]);
                objBookingMaster.IsDeleted = Convert.ToBoolean(sqlRdr["IsDeleted"]);
                objBookingMaster.IsHourly = Convert.ToBoolean(sqlRdr["IsHourly"]);



                /// Extra
                objBookingMaster.Table = Convert.ToString(sqlRdr["TableNames"]);
                objBookingMaster.Customer = Convert.ToString(sqlRdr["Customer"]);
                lstBookingMaster.Add(objBookingMaster);
            }
            return lstBookingMaster;
        }
        #endregion

        #region Insert
        public posRecordStatus InsertBookingMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlTransaction sqlTran = null;
            posCustomerMasterDAL objCustomerMasterDAL = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCon.Open();
                sqlTran = SqlCon.BeginTransaction();

                SqlCmd = new SqlCommand("posBookingMaster_Insert", SqlCon, sqlTran);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@BookingMasterId", SqlDbType.Int).Direction = ParameterDirection.Output;
                SqlCmd.Parameters.Add("@FromDate", SqlDbType.Date).Value = this.FromDate;
                SqlCmd.Parameters.Add("@ToDate", SqlDbType.Date).Value = this.ToDate;
                SqlCmd.Parameters.Add("@FromTime", SqlDbType.Time).Value = this.FromTime;
                SqlCmd.Parameters.Add("@ToTime", SqlDbType.Time).Value = this.ToTime;                
                SqlCmd.Parameters.Add("@linktoCustomerMasterId", SqlDbType.Int).Value = this.linktoCustomerMasterId;
                SqlCmd.Parameters.Add("@NoOfAdults", SqlDbType.SmallInt).Value = this.NoOfAdults;
                SqlCmd.Parameters.Add("@NoOfChildren", SqlDbType.SmallInt).Value = this.NoOfChildren;
                SqlCmd.Parameters.Add("@TotalAmount", SqlDbType.Money).Value = this.TotalAmount;
                SqlCmd.Parameters.Add("@DiscountPercentage", SqlDbType.SmallInt).Value = this.DiscountPercentage;
                SqlCmd.Parameters.Add("@DiscountAmount", SqlDbType.Money).Value = this.DiscountAmount;
                SqlCmd.Parameters.Add("@ExtraAmount", SqlDbType.Money).Value = this.ExtraAmount;
                SqlCmd.Parameters.Add("@NetAmount", SqlDbType.Money).Value = this.NetAmount;
                SqlCmd.Parameters.Add("@PaidAmount", SqlDbType.Money).Value = this.PaidAmount;
                SqlCmd.Parameters.Add("@BalanceAmount", SqlDbType.Money).Value = this.BalanceAmount;
                SqlCmd.Parameters.Add("@Remark", SqlDbType.VarChar).Value = this.Remark;
                SqlCmd.Parameters.Add("@CreateDateTime", SqlDbType.DateTime).Value = this.CreateDateTime;
                SqlCmd.Parameters.Add("@linktoUserMasterIdCreatedBy", SqlDbType.SmallInt).Value = this.linktoUserMasterIdCreatedBy;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCmd.Parameters.Add("@IsDeleted", SqlDbType.Bit).Value = this.IsDeleted;
                SqlCmd.Parameters.Add("@IsHourly", SqlDbType.Bit).Value = this.IsHourly;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCmd.ExecuteNonQuery();

                this.BookingMasterId = Convert.ToInt32(SqlCmd.Parameters["@BookingMasterId"].Value);
                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                if (rs != posRecordStatus.Success)
                {
                    sqlTran.Rollback();
                    SqlCon.Close();
                    return rs;
                }
                
                if (this.lstBookingPaymentTran != null)
                {
                    foreach (posBookingPaymentTranDAL objBookingPaymentTranDAL in this.lstBookingPaymentTran)
                    {
                        objBookingPaymentTranDAL.linktoBookingMasterId = this.BookingMasterId;
                        objBookingPaymentTranDAL.linktoCustomerMasterId = objBookingPaymentTranDAL.linktoCustomerMasterId;
                        objBookingPaymentTranDAL.linktoPaymentTypeMasterId = objBookingPaymentTranDAL.linktoPaymentTypeMasterId;
                        objBookingPaymentTranDAL.Remark = objBookingPaymentTranDAL.Remark;
                        objBookingPaymentTranDAL.AmountPaid = objBookingPaymentTranDAL.AmountPaid;
                        objBookingPaymentTranDAL.IsDeleted = objBookingPaymentTranDAL.IsDeleted;
                        objBookingPaymentTranDAL.PaymentDateTime = objBookingPaymentTranDAL.PaymentDateTime;
                        objBookingPaymentTranDAL.CreateDateTime = objBookingPaymentTranDAL.CreateDateTime;
                        objBookingPaymentTranDAL.linktoUserMasterIdCreatedBy = objBookingPaymentTranDAL.linktoUserMasterIdCreatedBy;
                        rs = objBookingPaymentTranDAL.InsertBookingPaymentTran(SqlCon, sqlTran);

                        if (rs != posRecordStatus.Success)
                        {
                            sqlTran.Rollback();
                            SqlCon.Close();
                            return rs;
                        }
                    }
                }
                if (lstCustomerMasterDAL != null)
                {
                    foreach (posCustomerMasterDAL objCustomer in lstCustomerMasterDAL)
                    {

                        objCustomerMasterDAL = new posCustomerMasterDAL();
                        objCustomerMasterDAL.CustomerMasterId = Convert.ToInt32(objCustomer.CustomerMasterId);
                        objCustomerMasterDAL.CreditBalance = objCustomer.CreditBalance;
                        objCustomerMasterDAL.UpdateDateTime = posGlobalsDAL.GetCurrentDateTime();
                        //objCustomerMasterDAL.IsDeleted = objBookingPaymentTranDAL.IsDeleted;
                        objCustomerMasterDAL.linktoUserMasterIdUpdatedBy = posGlobalsDAL.UserInfo.UserMasterId;
                        rs = objCustomerMasterDAL.UpdateCustomerMasterCreditBalance(SqlCon, sqlTran);
                        if (rs != posRecordStatus.Success)
                        {
                            sqlTran.Rollback();
                            SqlCon.Close();
                            return rs;
                        }
                    }
                }

                posBookingTableTranDAL objBookingTableTranDAL = new posBookingTableTranDAL();
                objBookingTableTranDAL.linktoBookingMasterId = this.BookingMasterId;
                rs = objBookingTableTranDAL.InsertAllBookingTableTran(linktoTableMasterIds,SqlCon,sqlTran);
                if (rs != posRecordStatus.Success)
                {
                    sqlTran.Rollback();
                    SqlCon.Close();
                    return rs;
                }
                sqlTran.Commit();
                SqlCon.Close();
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
                objCustomerMasterDAL = null;
            }
        }
        #endregion

        #region Update
        public posRecordStatus UpdateBookingMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlTransaction sqlTran = null;
            posCustomerMasterDAL objCustomerMasterDAL = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCon.Open();
                sqlTran = SqlCon.BeginTransaction();
                SqlCmd = new SqlCommand("posBookingMaster_Update", SqlCon, sqlTran);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@BookingMasterId", SqlDbType.Int).Value = this.BookingMasterId;
                SqlCmd.Parameters.Add("@FromDate", SqlDbType.Date).Value = this.FromDate;
                SqlCmd.Parameters.Add("@ToDate", SqlDbType.Date).Value = this.ToDate;
                SqlCmd.Parameters.Add("@FromTime", SqlDbType.Time).Value = this.FromTime;
                SqlCmd.Parameters.Add("@ToTime", SqlDbType.Time).Value = this.ToTime;                
                SqlCmd.Parameters.Add("@linktoCustomerMasterId", SqlDbType.Int).Value = this.linktoCustomerMasterId;
                SqlCmd.Parameters.Add("@NoOfAdults", SqlDbType.SmallInt).Value = this.NoOfAdults;
                SqlCmd.Parameters.Add("@NoOfChildren", SqlDbType.SmallInt).Value = this.NoOfChildren;
                SqlCmd.Parameters.Add("@TotalAmount", SqlDbType.Money).Value = this.TotalAmount;
                SqlCmd.Parameters.Add("@DiscountPercentage", SqlDbType.SmallInt).Value = this.DiscountPercentage;
                SqlCmd.Parameters.Add("@DiscountAmount", SqlDbType.Money).Value = this.DiscountAmount;
                SqlCmd.Parameters.Add("@ExtraAmount", SqlDbType.Money).Value = this.ExtraAmount;
                SqlCmd.Parameters.Add("@NetAmount", SqlDbType.Money).Value = this.NetAmount;
                SqlCmd.Parameters.Add("@PaidAmount", SqlDbType.Money).Value = this.PaidAmount;
                SqlCmd.Parameters.Add("@BalanceAmount", SqlDbType.Money).Value = this.BalanceAmount;
                SqlCmd.Parameters.Add("@Remark", SqlDbType.VarChar).Value = this.Remark;
                SqlCmd.Parameters.Add("@UpdateDateTime", SqlDbType.DateTime).Value = this.UpdateDateTime;
                SqlCmd.Parameters.Add("@linktoUserMasterIdUpdatedBy", SqlDbType.SmallInt).Value = this.linktoUserMasterIdUpdatedBy;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCmd.Parameters.Add("@IsHourly", SqlDbType.Bit).Value = this.IsHourly;
                SqlCmd.Parameters.Add("@IsDeleted", SqlDbType.Bit).Value = this.IsDeleted;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                // SqlCon.Open();
                SqlCmd.ExecuteNonQuery();

                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                if (rs != posRecordStatus.Success)
                {
                    sqlTran.Rollback();
                    SqlCon.Close();
                    return rs;
                }
                
                if (this.lstBookingPaymentTran != null)
                {
                    foreach (posBookingPaymentTranDAL objBookingPaymentTranDAL in this.lstBookingPaymentTran)
                    {
                        objBookingPaymentTranDAL.BookingPaymentTranId = objBookingPaymentTranDAL.BookingPaymentTranId;
                        objBookingPaymentTranDAL.linktoBookingMasterId = this.BookingMasterId;
                        objBookingPaymentTranDAL.linktoCustomerMasterId = objBookingPaymentTranDAL.linktoCustomerMasterId;
                        objBookingPaymentTranDAL.linktoPaymentTypeMasterId = objBookingPaymentTranDAL.linktoPaymentTypeMasterId;
                        objBookingPaymentTranDAL.Remark = objBookingPaymentTranDAL.Remark;
                        objBookingPaymentTranDAL.AmountPaid = objBookingPaymentTranDAL.AmountPaid;
                        objBookingPaymentTranDAL.IsDeleted = objBookingPaymentTranDAL.IsDeleted;
                        objBookingPaymentTranDAL.PaymentDateTime = objBookingPaymentTranDAL.PaymentDateTime;

                        if (objBookingPaymentTranDAL.BookingPaymentTranId > 0)
                        {
                            objBookingPaymentTranDAL.UpdateDateTime = posGlobalsDAL.GetCurrentDateTime();
                            objBookingPaymentTranDAL.linktoUserMasterIdUpdatedBy = posGlobalsDAL.UserInfo.UserMasterId;
                            rs = objBookingPaymentTranDAL.UpdateBookingPaymentTran(SqlCon, sqlTran);

                            if (rs != posRecordStatus.Success)
                            {
                                sqlTran.Rollback();
                                SqlCon.Close();
                                return rs;
                            }
                        }
                        else
                        {
                            objBookingPaymentTranDAL.CreateDateTime = objBookingPaymentTranDAL.CreateDateTime;
                            objBookingPaymentTranDAL.linktoUserMasterIdCreatedBy = objBookingPaymentTranDAL.linktoUserMasterIdCreatedBy;
                            rs = objBookingPaymentTranDAL.InsertBookingPaymentTran(SqlCon, sqlTran);

                            if (rs != posRecordStatus.Success)
                            {
                                sqlTran.Rollback();
                                SqlCon.Close();
                                return rs;
                            }
                        }
                    }
                }
                if (lstCustomerMasterDAL != null)
                {
                    foreach (posCustomerMasterDAL objCustomer in lstCustomerMasterDAL)
                    {

                        objCustomerMasterDAL = new posCustomerMasterDAL();
                        objCustomerMasterDAL.CustomerMasterId = Convert.ToInt32(objCustomer.CustomerMasterId);
                        objCustomerMasterDAL.CreditBalance = objCustomer.CreditBalance;
                        objCustomerMasterDAL.UpdateDateTime = posGlobalsDAL.GetCurrentDateTime();
                        //objCustomerMasterDAL.IsDeleted = objBookingPaymentTranDAL.IsDeleted;
                        objCustomerMasterDAL.linktoUserMasterIdUpdatedBy = posGlobalsDAL.UserInfo.UserMasterId;
                        rs = objCustomerMasterDAL.UpdateCustomerMasterCreditBalance(SqlCon, sqlTran);
                        if (rs != posRecordStatus.Success)
                        {
                            sqlTran.Rollback();
                            SqlCon.Close();
                            return rs;
                        }
                    }
                }
                posBookingTableTranDAL objBookingTableTranDAL = new posBookingTableTranDAL();
                objBookingTableTranDAL.linktoBookingMasterId = this.BookingMasterId;
                rs = objBookingTableTranDAL.InsertAllBookingTableTran(linktoTableMasterIds, SqlCon, sqlTran);
                if (rs != posRecordStatus.Success)
                {
                    sqlTran.Rollback();
                    SqlCon.Close();
                    return rs;
                }
             
                sqlTran.Commit();
                SqlCon.Close();
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
                objCustomerMasterDAL = null;
            }
        }
    
        #endregion

       #region DeleteAll

        public posRecordStatus DeleteAllBookingMaster(string bookingMasterIds)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posBookingMaster_DeleteAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@BookingMasterIds", SqlDbType.VarChar).Value = bookingMasterIds;
                SqlCmd.Parameters.Add("@UpdateDateTime", SqlDbType.DateTime).Value = this.UpdateDateTime;
                SqlCmd.Parameters.Add("@linktoUserMasterIdUpdatedBy", SqlDbType.SmallInt).Value = this.linktoUserMasterIdUpdatedBy;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region Select
        public bool SelectBookingMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posBookingMaster_Select", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@BookingMasterId", SqlDbType.Int).Value = this.BookingMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                bool IsSelected = SetClassPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                return IsSelected;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return false;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }


        public bool SelectBookingMasterVerify()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posBookingMaster_Verify", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@linktoTableMasterIds", SqlDbType.VarChar).Value = this.linktoTableMasterIds;
                SqlCmd.Parameters.Add("@BookingMasterId", SqlDbType.SmallInt).Value = this.BookingMasterId;
                SqlCmd.Parameters.Add("@FromDate", SqlDbType.Date).Value = this.FromDate.Date;
                SqlCmd.Parameters.Add("@ToDate", SqlDbType.Date).Value = this.ToDate.Date;
                SqlCmd.Parameters.Add("@ISHourly", SqlDbType.Bit).Value = this.IsHourly;
                SqlCmd.Parameters.Add("@FromTime", SqlDbType.Time).Value = this.FromTime;
                SqlCmd.Parameters.Add("@ToTime", SqlDbType.Time).Value = this.ToTime;


                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                bool IsSelected = false;
                if (SqlRdr.Read())
                {
                    this.BookingMasterId = Convert.ToInt32(SqlRdr["BookingMasterId"]);
                    this.Table = Convert.ToString(SqlRdr["TableNames"]);
                    this.Customer = Convert.ToString(SqlRdr["CustomerName"]);
                    IsSelected = true;
                }
                SqlRdr.Close();
                SqlCon.Close();

                return IsSelected;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return false;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region SelectAll

        public List<posBookingMasterDAL> SelectAllBookingMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posBookingMaster_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                if (this.FromDate != new DateTime())
                {
                    SqlCmd.Parameters.Add("@FromDate", SqlDbType.Date).Value = this.FromDate;
                }
                if (this.ToDate != new DateTime())
                {
                    SqlCmd.Parameters.Add("@ToDate", SqlDbType.Date).Value = this.ToDate;
                }
                if (this.linktoCustomerMasterId > 0)
                {
                    SqlCmd.Parameters.Add("@linktoCustomerMasterId", SqlDbType.Int).Value = this.linktoCustomerMasterId;
                }
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<posBookingMasterDAL> lstBookingMasterDAL = SetListPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                return lstBookingMasterDAL;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region Booking Master Hourly
        private List<posBookingMasterDAL> SetListPropertiesFromSqlDataReaderHourly(SqlDataReader sqlRdr)
        {
            List<posBookingMasterDAL> lstBookingMaster = new List<posBookingMasterDAL>();
            posBookingMasterDAL objBookingMaster = null;

            while (sqlRdr.Read())
            {
                objBookingMaster = new posBookingMasterDAL();

                objBookingMaster.linktoTableMasterId = Convert.ToInt16(sqlRdr["TableMasterId"]);

                objBookingMaster.Table = Convert.ToString(sqlRdr["TableName"]);
                
                objBookingMaster.T0 = Convert.ToString(sqlRdr["T0"]);
                objBookingMaster.T1 = Convert.ToString(sqlRdr["T1"]);
                objBookingMaster.T2 = Convert.ToString(sqlRdr["T2"]);
                objBookingMaster.T3 = Convert.ToString(sqlRdr["T3"]);
                objBookingMaster.T4 = Convert.ToString(sqlRdr["T4"]);
                objBookingMaster.T5 = Convert.ToString(sqlRdr["T5"]);
                objBookingMaster.T6 = Convert.ToString(sqlRdr["T6"]);
                objBookingMaster.T7 = Convert.ToString(sqlRdr["T7"]);
                objBookingMaster.T8 = Convert.ToString(sqlRdr["T8"]);
                objBookingMaster.T9 = Convert.ToString(sqlRdr["T9"]);
                objBookingMaster.T10 = Convert.ToString(sqlRdr["T10"]);
                objBookingMaster.T11 = Convert.ToString(sqlRdr["T11"]);
                objBookingMaster.T12 = Convert.ToString(sqlRdr["T12"]);
                objBookingMaster.T13 = Convert.ToString(sqlRdr["T13"]);
                objBookingMaster.T14 = Convert.ToString(sqlRdr["T14"]);
                objBookingMaster.T15 = Convert.ToString(sqlRdr["T15"]);
                objBookingMaster.T16 = Convert.ToString(sqlRdr["T16"]);
                objBookingMaster.T17 = Convert.ToString(sqlRdr["T17"]);
                objBookingMaster.T18 = Convert.ToString(sqlRdr["T18"]);
                objBookingMaster.T19 = Convert.ToString(sqlRdr["T19"]);
                objBookingMaster.T20 = Convert.ToString(sqlRdr["T20"]);
                objBookingMaster.T21 = Convert.ToString(sqlRdr["T21"]);
                objBookingMaster.T22 = Convert.ToString(sqlRdr["T22"]);
                objBookingMaster.T23 = Convert.ToString(sqlRdr["T23"]);

                lstBookingMaster.Add(objBookingMaster);
            }
            return lstBookingMaster;
        }

        public List<posBookingMasterDAL> SelectAllBookingMasterOnHourly()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posBookingMasterHourlyChart_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                if (this.FromDate != new DateTime())
                {
                    SqlCmd.Parameters.Add("@FromDate", SqlDbType.Date).Value = this.FromDate;
                }
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<posBookingMasterDAL> lstBookingMasterDAL = SetListPropertiesFromSqlDataReaderHourly(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                return lstBookingMasterDAL;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public DataSet SelectAllBookingMasterOnDaily()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;

            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posBookingMasterDailyChart_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                if (this.FromDate != new DateTime())
                {

                    SqlCmd.Parameters.Add("@FromDate", SqlDbType.Date).Value = this.FromDate;
                }
                if (this.ToDate != new DateTime())
                {

                    SqlCmd.Parameters.Add("@ToDate", SqlDbType.Date).Value = this.ToDate;
                }
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCon.Open();
               
                SqlDataAdapter SqlDa = new SqlDataAdapter(SqlCmd);
                DataSet Ds = new DataSet();
                SqlDa.Fill(Ds);               
                SqlCon.Close();

                return Ds;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                //posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);

            }
        }
        #endregion
    }
}
