using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace posLibrary
{
	/// <summary>
	/// Class for labUserRightsGroupMaster
	/// </summary>
	public class posUserRightsGroupMasterDAL
	{
		#region Properties
		public short UserRightsGroupMasterId { get; set; }
		public string UserRightsGroup { get; set; }
		#endregion

		#region Class Methods
        private List<posUserRightsGroupMasterDAL> SetListPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
		{
            List<posUserRightsGroupMasterDAL> lstUserRightsGroupMaster = new List<posUserRightsGroupMasterDAL>();
			posUserRightsGroupMasterDAL objUserRightsGroupMaster = null;
			while (sqlRdr.Read())
			{
                objUserRightsGroupMaster = new posUserRightsGroupMasterDAL();
                objUserRightsGroupMaster.UserRightsGroupMasterId = Convert.ToInt16(sqlRdr["UserRightsGroupMasterId"]);
				objUserRightsGroupMaster.UserRightsGroup = Convert.ToString(sqlRdr["UserRightsGroup"]);

				lstUserRightsGroupMaster.Add(objUserRightsGroupMaster);
			}
			return lstUserRightsGroupMaster;
		}
		#endregion

		#region SelectAll
        public List<posUserRightsGroupMasterDAL> SelectAllUserRightsGroupMaster()
		{
			SqlConnection SqlCon = null;
			SqlCommand SqlCmd = null;
			SqlDataReader SqlRdr = null;
			try
			{
				SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posUserRightsGroupMaster_SelectAll", SqlCon);
				SqlCmd.CommandType = CommandType.StoredProcedure;

				SqlCon.Open();
				SqlRdr = SqlCmd.ExecuteReader();
				List<posUserRightsGroupMasterDAL> lstUserRightsGroupMasterDAL = SetListPropertiesFromSqlDataReader(SqlRdr);
				SqlRdr.Close();
				SqlCon.Close();

				return lstUserRightsGroupMasterDAL;
			}
			catch (Exception ex)
			{
                posGlobalsDAL.SaveError(ex);
				return null;
			}
			finally
			{
				posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
			}
		}
		#endregion
	}
}
