using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace posLibrary
{
	/// <summary>
	/// Class for posItemComboTran
	/// </summary>
	public class posItemComboTranDAL
	{
		#region Properties
		public int ItemComboTranId { get; set; }
		public int linktoItemMasterId { get; set; }
		public int linktoItemMasterIdCombo { get; set; }

		/// Extra
		public string Item { get; set; }
		public string ItemCombo { get; set; }
		#endregion

		#region Class Methods
		private List<posItemComboTranDAL> SetListPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
		{
			List<posItemComboTranDAL> lstItemComboTran = new List<posItemComboTranDAL>();
			posItemComboTranDAL objItemComboTran = null;
			while (sqlRdr.Read())
			{
				objItemComboTran = new posItemComboTranDAL();
				objItemComboTran.ItemComboTranId = Convert.ToInt32(sqlRdr["ItemComboTranId"]);
				objItemComboTran.linktoItemMasterId = Convert.ToInt32(sqlRdr["linktoItemMasterId"]);
				objItemComboTran.linktoItemMasterIdCombo = Convert.ToInt32(sqlRdr["linktoItemMasterIdCombo"]);

				/// Extra
				objItemComboTran.Item = Convert.ToString(sqlRdr["Item"]);
				objItemComboTran.ItemCombo = Convert.ToString(sqlRdr["ItemCombo"]);
				lstItemComboTran.Add(objItemComboTran);
			}
			return lstItemComboTran;
		}
		#endregion

		#region Insert
        public static posRecordStatus InsertItemComboTran(string ComboItemMasterIds, int itemMasterId, SqlConnection sqlCon, SqlTransaction sqlTran)
		{			
			SqlCommand SqlCmd = null;
			try
			{
                SqlCmd = new SqlCommand("posItemComboTran_Insert", sqlCon, sqlTran);
				SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@linktoItemMasterId", SqlDbType.Int).Value = itemMasterId;
                SqlCmd.Parameters.Add("@linktoItemMasterIdsCombo", SqlDbType.VarChar).Value = ComboItemMasterIds;
				SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;
                				
				SqlCmd.ExecuteNonQuery();
								
				posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
				return rs;
			}
			catch (Exception ex)
			{
				posGlobalsDAL.SaveError(ex);
				return posRecordStatus.Error;
			}
			finally
			{
				posObjectFactoryDAL.DisposeCommand(SqlCmd);				
			}
		}
		#endregion

		#region SelectAll
		public List<posItemComboTranDAL> SelectAllItemComboTran()
		{
			SqlConnection SqlCon = null;
			SqlCommand SqlCmd = null;
			SqlDataReader SqlRdr = null;
			try
			{
				SqlCon = posObjectFactoryDAL.CreateConnection();
				SqlCmd = new SqlCommand("posItemComboTran_SelectAll", SqlCon);
				SqlCmd.CommandType = CommandType.StoredProcedure;
                SqlCmd.Parameters.Add("@linktoItemMasterId", SqlDbType.Int).Value = this.linktoItemMasterId;
				SqlCon.Open();
				SqlRdr = SqlCmd.ExecuteReader();
				List<posItemComboTranDAL> lstItemComboTranDAL = SetListPropertiesFromSqlDataReader(SqlRdr);
				SqlRdr.Close();
				SqlCon.Close();

				return lstItemComboTranDAL;
			}
			catch (Exception ex)
			{
				posGlobalsDAL.SaveError(ex);
				return null;
			}
			finally
			{
				posObjectFactoryDAL.DisposeDataReader(SqlRdr);
				posObjectFactoryDAL.DisposeCommand(SqlCmd);
				posObjectFactoryDAL.DisposeConnection(SqlCon);
			}
		}
		#endregion
	}
}
