using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace posLibrary
{
    /// <summary>
    /// Class for posMiscIncomeMaster
    /// </summary>
    public class posMiscIncomeMasterDAL
    {
        #region Properties
        public int MiscIncomeMasterId { get; set; }
        public short linktoMiscIncomeCategoryMasterId { get; set; }
        public string PaidBy { get; set; }
        public DateTime ReceiveDate { get; set; }
        public string ReceiptNo { get; set; }
        public short linktoPaymentTypeMasterId { get; set; }
        public short linktoCounterMasterId { get; set; }
        public double Amount { get; set; }
        public string Remark { get; set; }
        public DateTime CreateDateTime { get; set; }
        public short linktoUserMasterIdCreatedBy { get; set; }
        public DateTime? UpdateDateTime { get; set; }
        public short? linktoUserMasterIdUpdatedBy { get; set; }
        public short linktoBusinessMasterId { get; set; }
        /// Extra
        public string MiscIncomeCategory { get; set; }
        public string PaymentType { get; set; }
        public DateTime ReceivedDateTo { get; set; }//<---for data filtering operation
        #endregion

        #region Class Methods
        private bool SetClassPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            if (sqlRdr.Read())
            {
                this.MiscIncomeMasterId = Convert.ToInt32(sqlRdr["MiscIncomeMasterId"]);
                this.linktoMiscIncomeCategoryMasterId = Convert.ToInt16(sqlRdr["linktoMiscIncomeCategoryMasterId"]);
                this.PaidBy = Convert.ToString(sqlRdr["PaidBy"]);
                this.ReceiveDate = Convert.ToDateTime(sqlRdr["ReceiveDate"]);
                this.ReceiptNo = Convert.ToString(sqlRdr["ReceiptNo"]);
                this.linktoPaymentTypeMasterId = Convert.ToInt16(sqlRdr["linktoPaymentTypeMasterId"]);
                this.linktoCounterMasterId = Convert.ToInt16(sqlRdr["linktoCounterMasterId"]);
                this.Amount = Convert.ToDouble(sqlRdr["Amount"]);
                this.Remark = Convert.ToString(sqlRdr["Remark"]);
                this.CreateDateTime = Convert.ToDateTime(sqlRdr["CreateDateTime"]);
                this.linktoUserMasterIdCreatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdCreatedBy"]);
                if (sqlRdr["UpdateDateTime"] != DBNull.Value)
                {
                    this.UpdateDateTime = Convert.ToDateTime(sqlRdr["UpdateDateTime"]);
                }
                if (sqlRdr["linktoUserMasterIdUpdatedBy"] != DBNull.Value)
                {
                    this.linktoUserMasterIdUpdatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdUpdatedBy"]);
                }

                /// Extra
                this.MiscIncomeCategory = Convert.ToString(sqlRdr["MiscIncomeCategory"]);
                this.PaymentType = Convert.ToString(sqlRdr["PaymentType"]);
                return true;
            }
            return false;
        }

        private List<posMiscIncomeMasterDAL> SetListPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            List<posMiscIncomeMasterDAL> lstMiscIncomeMaster = new List<posMiscIncomeMasterDAL>();
            posMiscIncomeMasterDAL objMiscIncomeMaster = null;
            while (sqlRdr.Read())
            {
                objMiscIncomeMaster = new posMiscIncomeMasterDAL();
                objMiscIncomeMaster.MiscIncomeMasterId = Convert.ToInt32(sqlRdr["MiscIncomeMasterId"]);
                objMiscIncomeMaster.linktoMiscIncomeCategoryMasterId = Convert.ToInt16(sqlRdr["linktoMiscIncomeCategoryMasterId"]);
                objMiscIncomeMaster.PaidBy = Convert.ToString(sqlRdr["PaidBy"]);
                objMiscIncomeMaster.ReceiveDate = Convert.ToDateTime(sqlRdr["ReceiveDate"]);
                objMiscIncomeMaster.ReceiptNo = Convert.ToString(sqlRdr["ReceiptNo"]);
                objMiscIncomeMaster.linktoPaymentTypeMasterId = Convert.ToInt16(sqlRdr["linktoPaymentTypeMasterId"]);
                objMiscIncomeMaster.linktoCounterMasterId = Convert.ToInt16(sqlRdr["linktoCounterMasterId"]);
                objMiscIncomeMaster.Amount = Convert.ToDouble(sqlRdr["Amount"]);
                objMiscIncomeMaster.Remark = Convert.ToString(sqlRdr["Remark"]);
                objMiscIncomeMaster.CreateDateTime = Convert.ToDateTime(sqlRdr["CreateDateTime"]);
                objMiscIncomeMaster.linktoUserMasterIdCreatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdCreatedBy"]);
                if (sqlRdr["UpdateDateTime"] != DBNull.Value)
                {
                    objMiscIncomeMaster.UpdateDateTime = Convert.ToDateTime(sqlRdr["UpdateDateTime"]);
                }
                if (sqlRdr["linktoUserMasterIdUpdatedBy"] != DBNull.Value)
                {
                    objMiscIncomeMaster.linktoUserMasterIdUpdatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdUpdatedBy"]);
                }

                /// Extra
                objMiscIncomeMaster.MiscIncomeCategory = Convert.ToString(sqlRdr["MiscIncomeCategory"]);
                objMiscIncomeMaster.PaymentType = Convert.ToString(sqlRdr["PaymentType"]);
                lstMiscIncomeMaster.Add(objMiscIncomeMaster);
            }
            return lstMiscIncomeMaster;
        }
        #endregion

        #region Insert
        public posRecordStatus InsertMiscIncomeMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posMiscIncomeMaster_Insert", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@MiscIncomeMasterId", SqlDbType.Int).Direction = ParameterDirection.Output;
                SqlCmd.Parameters.Add("@linktoMiscIncomeCategoryMasterId", SqlDbType.SmallInt).Value = this.linktoMiscIncomeCategoryMasterId;
                SqlCmd.Parameters.Add("@PaidBy", SqlDbType.VarChar).Value = this.PaidBy;
                SqlCmd.Parameters.Add("@ReceiveDate", SqlDbType.Date).Value = this.ReceiveDate;
                SqlCmd.Parameters.Add("@ReceiptNo", SqlDbType.VarChar).Value = this.ReceiptNo;
                SqlCmd.Parameters.Add("@linktoPaymentTypeMasterId", SqlDbType.SmallInt).Value = this.linktoPaymentTypeMasterId;
                SqlCmd.Parameters.Add("@linktoCounterMasterId", SqlDbType.SmallInt).Value = this.linktoCounterMasterId;
                SqlCmd.Parameters.Add("@Amount", SqlDbType.Money).Value = this.Amount;
                SqlCmd.Parameters.Add("@Remark", SqlDbType.VarChar).Value = this.Remark;
                SqlCmd.Parameters.Add("@CreateDateTime", SqlDbType.DateTime).Value = this.CreateDateTime;
                SqlCmd.Parameters.Add("@linktoUserMasterIdCreatedBy", SqlDbType.SmallInt).Value = this.linktoUserMasterIdCreatedBy;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;

                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                this.MiscIncomeMasterId = Convert.ToInt32(SqlCmd.Parameters["@MiscIncomeMasterId"].Value);
                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region Update
        public posRecordStatus UpdateMiscIncomeMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posMiscIncomeMaster_Update", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@MiscIncomeMasterId", SqlDbType.Int).Value = this.MiscIncomeMasterId;
                SqlCmd.Parameters.Add("@linktoMiscIncomeCategoryMasterId", SqlDbType.SmallInt).Value = this.linktoMiscIncomeCategoryMasterId;
                SqlCmd.Parameters.Add("@PaidBy", SqlDbType.VarChar).Value = this.PaidBy;
                SqlCmd.Parameters.Add("@ReceiveDate", SqlDbType.Date).Value = this.ReceiveDate;
                SqlCmd.Parameters.Add("@ReceiptNo", SqlDbType.VarChar).Value = this.ReceiptNo;
                SqlCmd.Parameters.Add("@linktoPaymentTypeMasterId", SqlDbType.SmallInt).Value = this.linktoPaymentTypeMasterId;
                SqlCmd.Parameters.Add("@linktoCounterMasterId", SqlDbType.SmallInt).Value = this.linktoCounterMasterId;
                SqlCmd.Parameters.Add("@Amount", SqlDbType.Money).Value = this.Amount;
                SqlCmd.Parameters.Add("@Remark", SqlDbType.VarChar).Value = this.Remark;
                SqlCmd.Parameters.Add("@UpdateDateTime", SqlDbType.DateTime).Value = this.UpdateDateTime;
                SqlCmd.Parameters.Add("@linktoUserMasterIdUpdatedBy", SqlDbType.SmallInt).Value = this.linktoUserMasterIdUpdatedBy;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region DeleteAll
        public static posRecordStatus DeleteAllMiscIncomeMaster(string miscIncomeMasterIds)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posMiscIncomeMaster_DeleteAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@MiscIncomeMasterIds", SqlDbType.VarChar).Value = miscIncomeMasterIds;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region Select
        public bool SelectMiscIncomeMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posMiscIncomeMaster_Select", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@MiscIncomeMasterId", SqlDbType.Int).Value = this.MiscIncomeMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                bool IsSelected = SetClassPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                return IsSelected;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return false;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region SelectAll
        public List<posMiscIncomeMasterDAL> SelectAllMiscIncomeMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posMiscIncomeMaster_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                if (this.linktoMiscIncomeCategoryMasterId > 0)
                {
                    SqlCmd.Parameters.Add("@linktoMiscIncomeCategoryMasterId", SqlDbType.SmallInt).Value = this.linktoMiscIncomeCategoryMasterId;
                }
                SqlCmd.Parameters.Add("@PaidBy", SqlDbType.VarChar).Value = this.PaidBy;
                if (this.ReceiveDate != new DateTime())
                {
                    SqlCmd.Parameters.Add("@ReceiveDate", SqlDbType.Date).Value = this.ReceiveDate;
                }
                if (this.ReceivedDateTo != new DateTime())
                {
                    SqlCmd.Parameters.Add("@ReceivedDateTo", SqlDbType.Date).Value = this.ReceivedDateTo;
                }
                SqlCmd.Parameters.Add("@ReceiptNo", SqlDbType.VarChar).Value = this.ReceiptNo;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<posMiscIncomeMasterDAL> lstMiscIncomeMasterDAL = SetListPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                return lstMiscIncomeMasterDAL;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion
    }
}
