using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace posLibrary
{
	/// <summary>
	/// Class for posDesignationMaster
	/// </summary>
	public class posDesignationMasterDAL
	{
		#region Properties
		public short DesignationMasterId { get; set; }
		public string ShortName { get; set; }
		public string DesignationName { get; set; }
		public string Description { get; set; }
        public short linktoBusinessMasterId { get; set; }
		public bool IsEnabled { get; set; }
		public bool IsDeleted { get; set; }
		public DateTime? UpdateDateTime { get; set; }
		public short? linktoUserMasterIdUpdatedBy { get; set; }
		#endregion

		#region Class Methods
		private bool SetClassPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
		{
			if (sqlRdr.Read())
			{
				this.DesignationMasterId = Convert.ToInt16(sqlRdr["DesignationMasterId"]);
				this.ShortName = Convert.ToString(sqlRdr["ShortName"]);
				this.DesignationName = Convert.ToString(sqlRdr["DesignationName"]);
				this.Description = Convert.ToString(sqlRdr["Description"]);
				this.IsEnabled = Convert.ToBoolean(sqlRdr["IsEnabled"]);
				this.IsDeleted = Convert.ToBoolean(sqlRdr["IsDeleted"]);
				if (sqlRdr["UpdateDateTime"] != DBNull.Value)
				{
					this.UpdateDateTime = Convert.ToDateTime(sqlRdr["UpdateDateTime"]);
				}
				if (sqlRdr["linktoUserMasterIdUpdatedBy"] != DBNull.Value)
				{
					this.linktoUserMasterIdUpdatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdUpdatedBy"]);
				}
				return true;
			}
			return false;
		}

		private List<posDesignationMasterDAL> SetListPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
		{
			List<posDesignationMasterDAL> lstDesignationMaster = new List<posDesignationMasterDAL>();
			posDesignationMasterDAL objDesignationMaster = null;
			while (sqlRdr.Read())
			{
				objDesignationMaster = new posDesignationMasterDAL();
				objDesignationMaster.DesignationMasterId = Convert.ToInt16(sqlRdr["DesignationMasterId"]);
				objDesignationMaster.ShortName = Convert.ToString(sqlRdr["ShortName"]);
				objDesignationMaster.DesignationName = Convert.ToString(sqlRdr["DesignationName"]);
				objDesignationMaster.Description = Convert.ToString(sqlRdr["Description"]);
				objDesignationMaster.IsEnabled = Convert.ToBoolean(sqlRdr["IsEnabled"]);
				objDesignationMaster.IsDeleted = Convert.ToBoolean(sqlRdr["IsDeleted"]);
				if (sqlRdr["UpdateDateTime"] != DBNull.Value)
				{
					objDesignationMaster.UpdateDateTime = Convert.ToDateTime(sqlRdr["UpdateDateTime"]);
				}
				if (sqlRdr["linktoUserMasterIdUpdatedBy"] != DBNull.Value)
				{
					objDesignationMaster.linktoUserMasterIdUpdatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdUpdatedBy"]);
				}
				lstDesignationMaster.Add(objDesignationMaster);
			}
			return lstDesignationMaster;
		}
		#endregion

		#region Insert
		public posRecordStatus InsertDesignationMaster()
		{
			SqlConnection SqlCon = null;
			SqlCommand SqlCmd = null;
			try
			{
				SqlCon = posObjectFactoryDAL.CreateConnection();
				SqlCmd = new SqlCommand("posDesignationMaster_Insert", SqlCon);
				SqlCmd.CommandType = CommandType.StoredProcedure;

				SqlCmd.Parameters.Add("@DesignationMasterId", SqlDbType.SmallInt).Direction = ParameterDirection.Output;
				SqlCmd.Parameters.Add("@ShortName", SqlDbType.VarChar).Value = this.ShortName;
				SqlCmd.Parameters.Add("@DesignationName", SqlDbType.VarChar).Value = this.DesignationName;
				SqlCmd.Parameters.Add("@Description", SqlDbType.VarChar).Value = this.Description;
				SqlCmd.Parameters.Add("@IsEnabled", SqlDbType.Bit).Value = this.IsEnabled;
				SqlCmd.Parameters.Add("@IsDeleted", SqlDbType.Bit).Value = this.IsDeleted;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
				SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

				SqlCon.Open();
				SqlCmd.ExecuteNonQuery();
				SqlCon.Close();

				this.DesignationMasterId = Convert.ToInt16(SqlCmd.Parameters["@DesignationMasterId"].Value);
				posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
				return rs;
			}
			catch (Exception ex)
			{
				posGlobalsDAL.SaveError(ex);
				return posRecordStatus.Error;
			}
			finally
			{
				posObjectFactoryDAL.DisposeCommand(SqlCmd);
				posObjectFactoryDAL.DisposeConnection(SqlCon);
			}
		}
		#endregion

		#region Update
		public posRecordStatus UpdateDesignationMaster()
		{
			SqlConnection SqlCon = null;
			SqlCommand SqlCmd = null;
			try
			{
				SqlCon = posObjectFactoryDAL.CreateConnection();
				SqlCmd = new SqlCommand("posDesignationMaster_Update", SqlCon);
				SqlCmd.CommandType = CommandType.StoredProcedure;

				SqlCmd.Parameters.Add("@DesignationMasterId", SqlDbType.SmallInt).Value = this.DesignationMasterId;
				SqlCmd.Parameters.Add("@ShortName", SqlDbType.VarChar).Value = this.ShortName;
				SqlCmd.Parameters.Add("@DesignationName", SqlDbType.VarChar).Value = this.DesignationName;
				SqlCmd.Parameters.Add("@Description", SqlDbType.VarChar).Value = this.Description;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
				SqlCmd.Parameters.Add("@IsEnabled", SqlDbType.Bit).Value = this.IsEnabled;
				SqlCmd.Parameters.Add("@IsDeleted", SqlDbType.Bit).Value = this.IsDeleted;
				SqlCmd.Parameters.Add("@UpdateDateTime", SqlDbType.DateTime).Value = this.UpdateDateTime;
				SqlCmd.Parameters.Add("@linktoUserMasterIdUpdatedBy", SqlDbType.SmallInt).Value = this.linktoUserMasterIdUpdatedBy;
				SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

				SqlCon.Open();
				SqlCmd.ExecuteNonQuery();
				SqlCon.Close();

				posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
				return rs;
			}
			catch (Exception ex)
			{
				posGlobalsDAL.SaveError(ex);
				return posRecordStatus.Error;
			}
			finally
			{
				posObjectFactoryDAL.DisposeCommand(SqlCmd);
				posObjectFactoryDAL.DisposeConnection(SqlCon);
			}
		}
		#endregion

		#region DeleteAll
        public static posRecordStatus DeleteAllDesignationMaster(string designationMasterIds, short linktoUserMasterIdUpdatedBy, DateTime UpdateDateTime)
		{
			SqlConnection SqlCon = null;
			SqlCommand SqlCmd = null;
			try
			{
				SqlCon = posObjectFactoryDAL.CreateConnection();
				SqlCmd = new SqlCommand("posDesignationMaster_DeleteAll", SqlCon);
				SqlCmd.CommandType = CommandType.StoredProcedure;

				SqlCmd.Parameters.Add("@DesignationMasterIds", SqlDbType.VarChar).Value = designationMasterIds;
                SqlCmd.Parameters.Add("@UpdateDateTime", SqlDbType.DateTime).Value = UpdateDateTime;
                SqlCmd.Parameters.Add("@linktoUserMasterIdUpdatedBy", SqlDbType.SmallInt).Value = linktoUserMasterIdUpdatedBy;
				SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

				SqlCon.Open();
				SqlCmd.ExecuteNonQuery();
				SqlCon.Close();

				posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
				return rs;
			}
			catch (Exception ex)
			{
				posGlobalsDAL.SaveError(ex);
				return posRecordStatus.Error;
			}
			finally
			{
				posObjectFactoryDAL.DisposeCommand(SqlCmd);
				posObjectFactoryDAL.DisposeConnection(SqlCon);
			}
		}
		#endregion

		#region Select
		public bool SelectDesignationMaster()
		{
			SqlConnection SqlCon = null;
			SqlCommand SqlCmd = null;
			SqlDataReader SqlRdr = null;
			try
			{
				SqlCon = posObjectFactoryDAL.CreateConnection();
				SqlCmd = new SqlCommand("posDesignationMaster_Select", SqlCon);
				SqlCmd.CommandType = CommandType.StoredProcedure;

				SqlCmd.Parameters.Add("@DesignationMasterId", SqlDbType.SmallInt).Value = this.DesignationMasterId;

				SqlCon.Open();
				SqlRdr = SqlCmd.ExecuteReader();
				bool IsSelected = SetClassPropertiesFromSqlDataReader(SqlRdr);
				SqlRdr.Close();
				SqlCon.Close();

				return IsSelected;
			}
			catch (Exception ex)
			{
				posGlobalsDAL.SaveError(ex);
				return false;
			}
			finally
			{
				posObjectFactoryDAL.DisposeDataReader(SqlRdr);
				posObjectFactoryDAL.DisposeCommand(SqlCmd);
				posObjectFactoryDAL.DisposeConnection(SqlCon);
			}
		}
		#endregion

		#region SelectAll
		public List<posDesignationMasterDAL> SelectAllDesignationMaster()
		{
			SqlConnection SqlCon = null;
			SqlCommand SqlCmd = null;
			SqlDataReader SqlRdr = null;
			try
			{
				SqlCon = posObjectFactoryDAL.CreateConnection();
				SqlCmd = new SqlCommand("posDesignationMaster_SelectAll", SqlCon);
				SqlCmd.CommandType = CommandType.StoredProcedure;

				SqlCmd.Parameters.Add("@IsEnabled", SqlDbType.Bit).Value = this.IsEnabled;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;

				SqlCon.Open();
				SqlRdr = SqlCmd.ExecuteReader();
				List<posDesignationMasterDAL> lstDesignationMasterDAL = SetListPropertiesFromSqlDataReader(SqlRdr);
				SqlRdr.Close();
				SqlCon.Close();

				return lstDesignationMasterDAL;
			}
			catch (Exception ex)
			{
				posGlobalsDAL.SaveError(ex);
				return null;
			}
			finally
			{
				posObjectFactoryDAL.DisposeDataReader(SqlRdr);
				posObjectFactoryDAL.DisposeCommand(SqlCmd);
				posObjectFactoryDAL.DisposeConnection(SqlCon);
			}
		}

		public static List<posDesignationMasterDAL> SelectAllDesignationMasterDesignationName(short linktoBusinessMasterId)
		{
			SqlConnection SqlCon = null;
			SqlCommand SqlCmd = null;
			SqlDataReader SqlRdr = null;
			try
			{
				SqlCon = posObjectFactoryDAL.CreateConnection();
				SqlCmd = new SqlCommand("posDesignationMasterDesignationName_SelectAll", SqlCon);
				SqlCmd.CommandType = CommandType.StoredProcedure;
                
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = linktoBusinessMasterId;
				
                SqlCon.Open();
				SqlRdr = SqlCmd.ExecuteReader();
				List<posDesignationMasterDAL> lstDesignationMasterDAL = new List<posDesignationMasterDAL>();
				posDesignationMasterDAL objDesignationMasterDAL = null;
				while (SqlRdr.Read())
				{
					objDesignationMasterDAL = new posDesignationMasterDAL();
					objDesignationMasterDAL.DesignationMasterId = Convert.ToInt16(SqlRdr["DesignationMasterId"]);
					objDesignationMasterDAL.DesignationName = Convert.ToString(SqlRdr["DesignationName"]);
					lstDesignationMasterDAL.Add(objDesignationMasterDAL);
				}
				SqlRdr.Close();
				SqlCon.Close();

				return lstDesignationMasterDAL;
			}
			catch (Exception ex)
			{
				posGlobalsDAL.SaveError(ex);
				return null;
			}
			finally
			{
				posObjectFactoryDAL.DisposeDataReader(SqlRdr);
				posObjectFactoryDAL.DisposeCommand(SqlCmd);
				posObjectFactoryDAL.DisposeConnection(SqlCon);
			}
		}
		#endregion
    }
}
