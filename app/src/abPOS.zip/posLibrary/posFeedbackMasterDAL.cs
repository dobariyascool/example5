﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace posLibrary
{
    /// <summary>
    /// Class for posFeedbackMaster
    /// </summary>
    public class posFeedbackMasterDAL
    {
        #region Properties
        public int FeedbackMasterId { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }
        public string Phone { get; set; }
        public string Feedback { get; set; }
        public DateTime FeedbackDateTime { get; set; }
        public short linktoFeedbackTypeMasterId { get; set; }
        public int? linktoCustomerMasterId { get; set; }
        public short linktoBusinessMasterId { get; set; }

        /// Extra
        public string FeedbackType { get; set; }
        public List<posFeedbackTranDAL> lstFeedbackTranDAL { get; set; }
        #endregion

        #region Class Methods
        private bool SetClassPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            if (sqlRdr.Read())
            {
                this.FeedbackMasterId = Convert.ToInt32(sqlRdr["FeedbackMasterId"]);
                this.Name = Convert.ToString(sqlRdr["Name"]);
                this.Email = Convert.ToString(sqlRdr["Email"]);
                this.Phone = Convert.ToString(sqlRdr["Phone"]);
                this.Feedback = Convert.ToString(sqlRdr["Feedback"]);
                this.FeedbackDateTime = Convert.ToDateTime(sqlRdr["FeedbackDateTime"]);
                this.linktoFeedbackTypeMasterId = Convert.ToInt16(sqlRdr["linktoFeedbackTypeMasterId"]);
                if (sqlRdr["linktoCustomerMasterId"] != DBNull.Value)
                {
                    this.linktoCustomerMasterId = Convert.ToInt32(sqlRdr["linktoCustomerMasterId"]);
                }
                this.linktoBusinessMasterId = Convert.ToInt16(sqlRdr["linktoBusinessMasterId"]);

                /// Extra
                this.FeedbackType = Convert.ToString(sqlRdr["FeedbackType"]);
                return true;
            }
            return false;
        }
        #endregion

        #region Insert
        public posRecordStatus InsertFeedbackMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlTransaction SqlTran = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCon.Open();
                SqlTran = SqlCon.BeginTransaction();
                SqlCmd = new SqlCommand("posFeedbackMaster_Insert", SqlCon, SqlTran);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@FeedbackMasterId", SqlDbType.Int).Direction = ParameterDirection.Output;
                SqlCmd.Parameters.Add("@Name", SqlDbType.VarChar).Value = this.Name;
                SqlCmd.Parameters.Add("@Email", SqlDbType.VarChar).Value = this.Email;
                SqlCmd.Parameters.Add("@Phone", SqlDbType.VarChar).Value = this.Phone;
                SqlCmd.Parameters.Add("@Feedback", SqlDbType.VarChar).Value = this.Feedback;
                SqlCmd.Parameters.Add("@FeedbackDateTime", SqlDbType.DateTime).Value = this.FeedbackDateTime;
                SqlCmd.Parameters.Add("@linktoFeedbackTypeMasterId", SqlDbType.SmallInt).Value = this.linktoFeedbackTypeMasterId;
                SqlCmd.Parameters.Add("@linktoCustomerMasterId", SqlDbType.Int).Value = this.linktoCustomerMasterId;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCmd.ExecuteNonQuery();

                this.FeedbackMasterId = Convert.ToInt32(SqlCmd.Parameters["@FeedbackMasterId"].Value);
                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                if (rs == posRecordStatus.Success)
                {
                    if (lstFeedbackTranDAL != null && lstFeedbackTranDAL.Count > 0)
                    {
                        if (posFeedbackTranDAL.InsertFeedbackTran(this.FeedbackMasterId, lstFeedbackTranDAL, SqlCon, SqlTran) == posRecordStatus.Error)
                        {
                            SqlTran.Rollback();
                            return posRecordStatus.Error;
                        }
                    }
                }
                else
                {
                    SqlTran.Rollback();
                    return posRecordStatus.Error;
                }
                SqlTran.Commit();
                SqlCon.Close();
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion
    }
}
