using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace posLibrary
{
	/// <summary>
	/// Class for posDiscountTran
	/// </summary>
	public class posDiscountTranDAL
	{
		#region Properties
		public int DiscountTranId { get; set; }
		public int linktoDiscountMasterId { get; set; }
		public int linktoItemMasterId { get; set; }
		public double Discount { get; set; }
		public bool IsPercentage { get; set; }

		/// Extra
		public string DiscountTitle { get; set; }
		public string ItemName { get; set; }        
        public string CategoryName { get; set; }
        public string DiscountAmount { get; set; }
        public bool IsSelected { get; set; }
        public List<posDiscountTranDAL> lstDiscountTran { get; set; }
		#endregion

		#region Class Methods
		private List<posDiscountTranDAL> SetListPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
		{
			List<posDiscountTranDAL> lstDiscountTran = new List<posDiscountTranDAL>();
			posDiscountTranDAL objDiscountTran = null;
			while (sqlRdr.Read())
			{
				objDiscountTran = new posDiscountTranDAL();
                if (sqlRdr["DiscountTranId"] != DBNull.Value)
                {
                    objDiscountTran.DiscountTranId = Convert.ToInt32(sqlRdr["DiscountTranId"]);
                    objDiscountTran.IsSelected = true;
                }
                else
                {
                    objDiscountTran.IsSelected = false;
                }
                objDiscountTran.linktoItemMasterId = Convert.ToInt32(sqlRdr["ItemMasterId"]);
                if (sqlRdr["Discount"] != DBNull.Value)
                {
                    objDiscountTran.Discount = Convert.ToDouble(sqlRdr["Discount"]);
                    if (Convert.ToBoolean(sqlRdr["IsPercentage"]))
                    {
                        objDiscountTran.DiscountAmount = objDiscountTran.Discount + " %";
                    }
                    else
                    {
                        objDiscountTran.DiscountAmount = objDiscountTran.Discount + " Rs.";
                    }                    
                }			

				/// Extra                
                objDiscountTran.ItemName = Convert.ToString(sqlRdr["ItemName"]) + " (" + Convert.ToString(sqlRdr["ItemCode"]) + ")";
                objDiscountTran.CategoryName = Convert.ToString(sqlRdr["CategoryName"]);
				lstDiscountTran.Add(objDiscountTran);
			}
			return lstDiscountTran;
		}
		#endregion

		#region Insert
		public posRecordStatus InsertDiscountTran()
		{
			SqlConnection SqlCon = null;
			SqlCommand SqlCmd = null;
            SqlTransaction SqlTran = null;            
			try
			{
				SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCon.Open();
                SqlTran = SqlCon.BeginTransaction();

                posRecordStatus rs = DeleteDiscountTran(this.linktoDiscountMasterId,SqlCon, SqlTran);

                if (rs == posRecordStatus.Error)
                {
                    SqlTran.Rollback();
                    SqlCon.Close();
                    return rs;
                }

                SqlCmd = new SqlCommand("posDiscountTran_Insert", SqlCon, SqlTran);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                foreach (posDiscountTranDAL objDiscountTranDAL in lstDiscountTran)
                {
                    SqlCmd.Parameters.Clear();
                    SqlCmd.Parameters.Add("@DiscountTranId", SqlDbType.Int).Direction = ParameterDirection.Output;
                    SqlCmd.Parameters.Add("@linktoDiscountMasterId", SqlDbType.Int).Value = objDiscountTranDAL.linktoDiscountMasterId;
                    SqlCmd.Parameters.Add("@linktoItemMasterId", SqlDbType.Int).Value = objDiscountTranDAL.linktoItemMasterId;
                    SqlCmd.Parameters.Add("@Discount", SqlDbType.Money).Value = objDiscountTranDAL.Discount;
                    SqlCmd.Parameters.Add("@IsPercentage", SqlDbType.Bit).Value = objDiscountTranDAL.IsPercentage;
                    SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                    SqlCmd.ExecuteNonQuery();

                    this.DiscountTranId = Convert.ToInt32(SqlCmd.Parameters["@DiscountTranId"].Value);
                    rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                    if (rs == posRecordStatus.Error)
                    {
                        SqlTran.Rollback();
                        SqlCon.Close();
                        return rs;
                    }
                }
                SqlTran.Commit();
                SqlCon.Close();
                return rs;
			}
			catch (Exception ex)
			{
				posGlobalsDAL.SaveError(ex);
				return posRecordStatus.Error;
			}
			finally
			{
				posObjectFactoryDAL.DisposeCommand(SqlCmd);
				posObjectFactoryDAL.DisposeConnection(SqlCon);
			}
		}
		#endregion

		#region Delete
		public static posRecordStatus DeleteDiscountTran(int linktoDiscountMasterId,SqlConnection SqlCon,SqlTransaction SqlTran)
		{			
			SqlCommand SqlCmd = null;
			try
			{				
				SqlCmd = new SqlCommand("posDiscountTran_Delete", SqlCon,SqlTran);
				SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@linktoDiscountMasterId", SqlDbType.Int).Value = linktoDiscountMasterId;
				SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

				SqlCmd.ExecuteNonQuery();

                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
				return rs;
			}
			catch (Exception ex)
			{
				posGlobalsDAL.SaveError(ex);
				return posRecordStatus.Error;
			}
			finally
			{
				posObjectFactoryDAL.DisposeCommand(SqlCmd);
			}
		}
		#endregion 

		#region SelectAll
        public List<posDiscountTranDAL> SelectAllDiscountTran(short linktoBusinessMasterId)
		{
			SqlConnection SqlCon = null;
			SqlCommand SqlCmd = null;
			SqlDataReader SqlRdr = null;
			try
			{
				SqlCon = posObjectFactoryDAL.CreateConnection();
				SqlCmd = new SqlCommand("posDiscountTran_SelectAll", SqlCon);
				SqlCmd.CommandType = CommandType.StoredProcedure;
                SqlCmd.Parameters.Add("@linktoDiscountMasterId", SqlDbType.Int).Value = this.linktoDiscountMasterId;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.Int).Value = linktoBusinessMasterId;
				SqlCon.Open();
				SqlRdr = SqlCmd.ExecuteReader();
				List<posDiscountTranDAL> lstDiscountTranDAL = SetListPropertiesFromSqlDataReader(SqlRdr);
				SqlRdr.Close();
				SqlCon.Close();

				return lstDiscountTranDAL;
			}
			catch (Exception ex)
			{
				posGlobalsDAL.SaveError(ex);
				return null;
			}
			finally
			{
				posObjectFactoryDAL.DisposeDataReader(SqlRdr);
				posObjectFactoryDAL.DisposeCommand(SqlCmd);
				posObjectFactoryDAL.DisposeConnection(SqlCon);
			}
		}
		#endregion
	}
}
