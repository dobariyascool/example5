using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace posLibrary
{
    /// <summary>
    /// Class for posSalesMaster
    /// </summary>
    public class posSalesMasterDAL
    {
        #region Properties
        public long SalesMasterId { get; set; }
        public string BillNumber { get; set; }
        public DateTime? BillDateTime { get; set; }
        public short linktoCounterMasterId { get; set; }
        public string linktoTableMasterIds { get; set; }
        public int? linktoWaiterMasterId { get; set; }
        public int? linktoCustomerMasterId { get; set; }
        public short linktoOrderTypeMasterId { get; set; }
        public short? linktoOrderStatusMasterId { get; set; }
        public double TotalAmount { get; set; }
        public double TotalTax { get; set; }
        public double DiscountPercentage { get; set; }
        public double DiscountAmount { get; set; }
        public double ExtraAmount { get; set; }
        public double TotalItemDiscount { get; set; }
        public double TotalItemTax { get; set; }
        public double NetAmount { get; set; }
        public double PaidAmount { get; set; }
        public double BalanceAmount { get; set; }
        public string Remark { get; set; }
        public bool IsComplimentary { get; set; }
        public short TotalItemPoint { get; set; }
        public short TotalDeductedPoint { get; set; }
        public short linktoBusinessMasterId { get; set; }
        public DateTime CreateDateTime { get; set; }
        public short linktoUserMasterIdCreatedBy { get; set; }
        public DateTime? UpdateDateTime { get; set; }
        public short? linktoUserMasterIdUpdatedBy { get; set; }
        public short? linktoWaiterMasterIdCaptain { get; set; }
        public double Rounding { get; set; }
        public bool IsDeleted { get; set; }
        public short? NoOfAdults { get; set; }
        public short? NoOfChildren { get; set; }
        public short? RateIndex { get; set; }
        public string OfferCode { get; set; }
        public short? linktoOfferMasterId { get; set; }

        /// Extra
        public string Counter { get; set; }
        public string Waiter { get; set; }
        public string Customer { get; set; }
        public string OrderType { get; set; }
        public string OrderStatus { get; set; }
        public string Business { get; set; }
        public string CaptainName { get; set; }
        public double DineInSale { get; set; }
        public double HomeDeliverySale { get; set; }
        public double TakeAwaySale { get; set; }
        public double TotalSale { get; set; }
        public string FirstBillNumber { get; set; }
        public string LastBillNumber { get; set; }
        public string UserName { get; set; }
        public string PaymentType { get; set; }
        public int Quantity { get; set; }
        public double Cash { get; set; }
        public double Bank { get; set; }
        public double Card { get; set; }
        public double Complemetory { get; set; }
        public double Others { get; set; }
        public short CustomerType { get; set; }
        public string OrderMasterIds { get; set; }
        public string TableName { get; set; }
        public DateTime ToBillDateTime { get; set; }
        public string BillDateTimeString { get; set; }
        public List<posItemMasterDAL> lstSaleItemTranDAL { get; set; }
        public List<posItemMasterDAL> lstSaleItemModifierTranDAL { get; set; }
        public List<posSalesTaxTranDAL> lstSalesTaxTran { get; set; }
        public List<posSalesPaymentTranDAL> lstSalesPaymentTran { get; set; }
        public List<posCustomerMasterDAL> lstCustomerMasterDAL { get; set; }
        public string Month { get; set; }
        public string Year { get; set; }
        public double DailySale { get; set; }
        public double MonthlySale { get; set; }
        public double Weeaklysale { get; set; }
        public string LeastSellingDayName { get; set; }
        public int CustomerInvoiceTranId { get; set; }
        public string OrderNumber { get; set; }
        public string RateName { get; set; }
        public short? linktoSourceMasterId { get; set; }
        #endregion

        #region Class Methods
        private bool SetClassPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            if (sqlRdr.Read())
            {
                this.SalesMasterId = Convert.ToInt64(sqlRdr["SalesMasterId"]);
                this.BillNumber = Convert.ToString(sqlRdr["BillNumber"]);
                if (sqlRdr["BillDateTime"] != DBNull.Value)
                {
                    this.BillDateTime = Convert.ToDateTime(sqlRdr["BillDateTime"]);
                }
                this.linktoCounterMasterId = Convert.ToInt16(sqlRdr["linktoCounterMasterId"]);
                this.linktoTableMasterIds = Convert.ToString(sqlRdr["linktoTableMasterIds"]);
                if (sqlRdr["linktoWaiterMasterId"] != DBNull.Value)
                {
                    this.linktoWaiterMasterId = Convert.ToInt32(sqlRdr["linktoWaiterMasterId"]);
                }
                if (sqlRdr["linktoCustomerMasterId"] != DBNull.Value)
                {
                    this.linktoCustomerMasterId = Convert.ToInt32(sqlRdr["linktoCustomerMasterId"]);
                }
                this.linktoOrderTypeMasterId = Convert.ToInt16(sqlRdr["linktoOrderTypeMasterId"]);
                if (sqlRdr["linktoOrderStatusMasterId"] != DBNull.Value)
                {
                    this.linktoOrderStatusMasterId = Convert.ToInt16(sqlRdr["linktoOrderStatusMasterId"]);
                }
                this.TotalAmount = Convert.ToDouble(sqlRdr["TotalAmount"]);
                this.TotalTax = Convert.ToDouble(sqlRdr["TotalTax"]);
                this.DiscountPercentage = Convert.ToDouble(sqlRdr["DiscountPercentage"]);
                this.DiscountAmount = Convert.ToDouble(sqlRdr["DiscountAmount"]);
                this.ExtraAmount = Convert.ToDouble(sqlRdr["ExtraAmount"]);
                this.TotalItemDiscount = Convert.ToDouble(sqlRdr["TotalItemDiscount"]);
                this.TotalItemTax = Convert.ToDouble(sqlRdr["TotalItemTax"]);
                this.NetAmount = Convert.ToDouble(sqlRdr["NetAmount"]);
                this.PaidAmount = Convert.ToDouble(sqlRdr["PaidAmount"]);
                this.BalanceAmount = Convert.ToDouble(sqlRdr["BalanceAmount"]);
                this.Remark = Convert.ToString(sqlRdr["Remark"]);
                this.IsComplimentary = Convert.ToBoolean(sqlRdr["IsComplimentary"]);
                this.TotalItemPoint = Convert.ToInt16(sqlRdr["TotalItemPoint"]);
                this.TotalDeductedPoint = Convert.ToInt16(sqlRdr["TotalDeductedPoint"]);
                this.linktoBusinessMasterId = Convert.ToInt16(sqlRdr["linktoBusinessMasterId"]);
                this.CreateDateTime = Convert.ToDateTime(sqlRdr["CreateDateTime"]);
                this.linktoUserMasterIdCreatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdCreatedBy"]);
                if (sqlRdr["UpdateDateTime"] != DBNull.Value)
                {
                    this.UpdateDateTime = Convert.ToDateTime(sqlRdr["UpdateDateTime"]);
                }
                if (sqlRdr["linktoUserMasterIdUpdatedBy"] != DBNull.Value)
                {
                    this.linktoUserMasterIdUpdatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdUpdatedBy"]);
                }
                if (sqlRdr["RateIndex"] != DBNull.Value)
                {
                    this.RateIndex = Convert.ToInt16(sqlRdr["RateIndex"]);
                }
                /// Extra
                this.Counter = Convert.ToString(sqlRdr["Counter"]);
                this.Waiter = Convert.ToString(sqlRdr["Waiter"]);
                this.Customer = Convert.ToString(sqlRdr["Customer"]);
                this.OrderType = Convert.ToString(sqlRdr["OrderType"]);
                //this.OrderStatus = Convert.ToString(sqlRdr["OrderStatus"]);
                this.CaptainName = Convert.ToString(sqlRdr["CaptainName"]);
                this.TableName = Convert.ToString(sqlRdr["TableName"]);
                this.RateName = Convert.ToString(sqlRdr["RateName"]);
                if (sqlRdr["OfferCode"] != DBNull.Value)
                {
                    this.OfferCode = Convert.ToString(sqlRdr["OfferCode"]);
                }
                if (sqlRdr["linktoOfferMasterId"] != DBNull.Value)
                {
                    this.linktoOfferMasterId = Convert.ToInt16(sqlRdr["linktoOfferMasterId"]);
                }
                return true;
            }
            return false;
        }

        private List<posSalesMasterDAL> SetListPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            List<posSalesMasterDAL> lstSalesMaster = new List<posSalesMasterDAL>();
            posSalesMasterDAL objSalesMaster = null;
            while (sqlRdr.Read())
            {
                objSalesMaster = new posSalesMasterDAL();
                objSalesMaster.SalesMasterId = Convert.ToInt64(sqlRdr["SalesMasterId"]);
                objSalesMaster.BillNumber = Convert.ToString(sqlRdr["BillNumber"]);
                if (sqlRdr["BillDateTime"] != DBNull.Value)
                {
                    objSalesMaster.BillDateTime = Convert.ToDateTime(sqlRdr["BillDateTime"]);
                }
                objSalesMaster.linktoCounterMasterId = Convert.ToInt16(sqlRdr["linktoCounterMasterId"]);
                objSalesMaster.linktoTableMasterIds = Convert.ToString(sqlRdr["linktoTableMasterIds"]);
                if (sqlRdr["linktoWaiterMasterId"] != DBNull.Value)
                {
                    objSalesMaster.linktoWaiterMasterId = Convert.ToInt32(sqlRdr["linktoWaiterMasterId"]);
                }
                if (sqlRdr["linktoCustomerMasterId"] != DBNull.Value)
                {
                    objSalesMaster.linktoCustomerMasterId = Convert.ToInt32(sqlRdr["linktoCustomerMasterId"]);
                }
                objSalesMaster.linktoOrderTypeMasterId = Convert.ToInt16(sqlRdr["linktoOrderTypeMasterId"]);
                if (sqlRdr["linktoOrderStatusMasterId"] != DBNull.Value)
                {
                    objSalesMaster.linktoOrderStatusMasterId = Convert.ToInt16(sqlRdr["linktoOrderStatusMasterId"]);
                }
                objSalesMaster.TotalAmount = Convert.ToDouble(sqlRdr["TotalAmount"]);
                objSalesMaster.TotalTax = Convert.ToDouble(sqlRdr["TotalTax"]);
                objSalesMaster.DiscountPercentage = Convert.ToDouble(sqlRdr["DiscountPercentage"]);
                objSalesMaster.DiscountAmount = Convert.ToDouble(sqlRdr["DiscountAmount"]);
                objSalesMaster.ExtraAmount = Convert.ToDouble(sqlRdr["ExtraAmount"]);
                objSalesMaster.TotalItemDiscount = Convert.ToDouble(sqlRdr["TotalItemDiscount"]);
                objSalesMaster.TotalItemTax = Convert.ToDouble(sqlRdr["TotalItemTax"]);
                objSalesMaster.NetAmount = Convert.ToDouble(sqlRdr["NetAmount"]);
                objSalesMaster.PaidAmount = Convert.ToDouble(sqlRdr["PaidAmount"]);
                objSalesMaster.BalanceAmount = Convert.ToDouble(sqlRdr["BalanceAmount"]);
                objSalesMaster.Remark = Convert.ToString(sqlRdr["Remark"]);
                objSalesMaster.IsComplimentary = Convert.ToBoolean(sqlRdr["IsComplimentary"]);
                objSalesMaster.TotalItemPoint = Convert.ToInt16(sqlRdr["TotalItemPoint"]);
                objSalesMaster.TotalDeductedPoint = Convert.ToInt16(sqlRdr["TotalDeductedPoint"]);
                objSalesMaster.linktoBusinessMasterId = Convert.ToInt16(sqlRdr["linktoBusinessMasterId"]);
                objSalesMaster.CreateDateTime = Convert.ToDateTime(sqlRdr["CreateDateTime"]);
                objSalesMaster.linktoUserMasterIdCreatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdCreatedBy"]);
                if (sqlRdr["UpdateDateTime"] != DBNull.Value)
                {
                    objSalesMaster.UpdateDateTime = Convert.ToDateTime(sqlRdr["UpdateDateTime"]);
                }
                if (sqlRdr["linktoUserMasterIdUpdatedBy"] != DBNull.Value)
                {
                    objSalesMaster.linktoUserMasterIdUpdatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdUpdatedBy"]);
                }

                /// Extra
                objSalesMaster.Counter = Convert.ToString(sqlRdr["Counter"]);
                objSalesMaster.Waiter = Convert.ToString(sqlRdr["Waiter"]);
                objSalesMaster.CaptainName = Convert.ToString(sqlRdr["Captain"]);
                objSalesMaster.Customer = Convert.ToString(sqlRdr["Customer"]);
                objSalesMaster.OrderType = Convert.ToString(sqlRdr["OrderType"]);
                objSalesMaster.OrderStatus = Convert.ToString(sqlRdr["OrderStatus"]);
                objSalesMaster.Business = Convert.ToString(sqlRdr["Business"]);
                if (sqlRdr["TableName"] != DBNull.Value)
                {
                    objSalesMaster.TableName = Convert.ToString(sqlRdr["TableName"]);
                }
                if (sqlRdr["CustomerInvoiceTranId"] != DBNull.Value)
                {
                    objSalesMaster.CustomerInvoiceTranId = Convert.ToInt16(sqlRdr["CustomerInvoiceTranId"]);
                }
                if (sqlRdr["OrderNumber"] != DBNull.Value)
                {
                    objSalesMaster.OrderNumber = Convert.ToString(sqlRdr["OrderNumber"]);
                }
                if (sqlRdr["OrderMasterIds"] != DBNull.Value)
                {
                    objSalesMaster.OrderMasterIds = Convert.ToString(sqlRdr["OrderMasterIds"]);
                }
                if (sqlRdr["OfferCode"] != DBNull.Value)
                {
                    objSalesMaster.OfferCode = Convert.ToString(sqlRdr["OfferCode"]);
                }
                if (sqlRdr["linktoOfferMasterId"] != DBNull.Value)
                {
                    objSalesMaster.linktoOfferMasterId = Convert.ToInt16(sqlRdr["linktoOfferMasterId"]);
                }
                //if (sqlRdr["linktoSourceMasterId"] != DBNull.Value)
                //{
                //    objSalesMaster.linktoSourceMasterId = Convert.ToInt16(sqlRdr["linktoSourceMasterId"]);
                //}
                lstSalesMaster.Add(objSalesMaster);
            }
            return lstSalesMaster;
        }
        #endregion

        #region Insert
        public posRecordStatus InsertSalesMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlTransaction SqlTran = null;
            posCustomerMasterDAL objCustomerMasterDAL = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCon.Open();
                SqlTran = SqlCon.BeginTransaction();
                SqlCmd = new SqlCommand("posSalesMaster_Insert", SqlCon, SqlTran);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@SalesMasterId", SqlDbType.BigInt).Direction = ParameterDirection.Output;
                SqlCmd.Parameters.Add("@BillNumber", SqlDbType.VarChar).Value = this.BillNumber;
                SqlCmd.Parameters.Add("@BillDateTime", SqlDbType.DateTime).Value = this.BillDateTime;
                SqlCmd.Parameters.Add("@linktoCounterMasterId", SqlDbType.SmallInt).Value = this.linktoCounterMasterId;
                SqlCmd.Parameters.Add("@linktoTableMasterIds", SqlDbType.VarChar).Value = this.linktoTableMasterIds;
                SqlCmd.Parameters.Add("@linktoWaiterMasterId", SqlDbType.Int).Value = this.linktoWaiterMasterId;
                SqlCmd.Parameters.Add("@linktoWaiterMasterIdCaptain", SqlDbType.Int).Value = this.linktoWaiterMasterIdCaptain;
                SqlCmd.Parameters.Add("@linktoCustomerMasterId", SqlDbType.Int).Value = this.linktoCustomerMasterId;
                SqlCmd.Parameters.Add("@linktoOrderTypeMasterId", SqlDbType.SmallInt).Value = this.linktoOrderTypeMasterId;
                SqlCmd.Parameters.Add("@linktoOrderStatusMasterId", SqlDbType.SmallInt).Value = this.linktoOrderStatusMasterId;
                SqlCmd.Parameters.Add("@NoOfAdults", SqlDbType.SmallInt).Value = this.NoOfAdults;
                SqlCmd.Parameters.Add("@NoOfChildren", SqlDbType.SmallInt).Value = this.NoOfChildren;
                SqlCmd.Parameters.Add("@RateIndex", SqlDbType.SmallInt).Value = this.RateIndex;
                SqlCmd.Parameters.Add("@TotalAmount", SqlDbType.Money).Value = this.TotalAmount;
                SqlCmd.Parameters.Add("@TotalTax", SqlDbType.Money).Value = this.TotalTax;
                SqlCmd.Parameters.Add("@DiscountPercentage", SqlDbType.Money).Value = this.DiscountPercentage;
                SqlCmd.Parameters.Add("@DiscountAmount", SqlDbType.Money).Value = this.DiscountAmount;
                SqlCmd.Parameters.Add("@ExtraAmount", SqlDbType.Money).Value = this.ExtraAmount;
                SqlCmd.Parameters.Add("@TotalItemDiscount", SqlDbType.Money).Value = this.TotalItemDiscount;
                SqlCmd.Parameters.Add("@TotalItemTax", SqlDbType.Money).Value = this.TotalItemTax;
                SqlCmd.Parameters.Add("@Rounding", SqlDbType.Money).Value = this.Rounding;
                SqlCmd.Parameters.Add("@NetAmount", SqlDbType.Money).Value = this.NetAmount;
                SqlCmd.Parameters.Add("@PaidAmount", SqlDbType.Money).Value = this.PaidAmount;
                SqlCmd.Parameters.Add("@BalanceAmount", SqlDbType.Money).Value = this.BalanceAmount;
                SqlCmd.Parameters.Add("@Remark", SqlDbType.VarChar).Value = this.Remark;
                SqlCmd.Parameters.Add("@IsComplimentary", SqlDbType.Bit).Value = this.IsComplimentary;
                SqlCmd.Parameters.Add("@TotalItemPoint", SqlDbType.SmallInt).Value = this.TotalItemPoint;
                SqlCmd.Parameters.Add("@TotalDeductedPoint", SqlDbType.SmallInt).Value = this.TotalDeductedPoint;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCmd.Parameters.Add("@IsDeleted", SqlDbType.Bit).Value = this.IsDeleted;
                SqlCmd.Parameters.Add("@CreateDateTime", SqlDbType.DateTime).Value = this.CreateDateTime;
                SqlCmd.Parameters.Add("@linktoUserMasterIdCreatedBy", SqlDbType.SmallInt).Value = this.linktoUserMasterIdCreatedBy;
                SqlCmd.Parameters.Add("@OfferCode", SqlDbType.VarChar).Value = this.OfferCode;
                SqlCmd.Parameters.Add("@OrderMasterIds", SqlDbType.VarChar).Value = this.OrderMasterIds;
                SqlCmd.Parameters.Add("@linktoOfferMasterId", SqlDbType.SmallInt).Value = this.linktoOfferMasterId;
                SqlCmd.Parameters.Add("@linktoSourceMasterId", SqlDbType.SmallInt).Value = this.linktoSourceMasterId;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCmd.ExecuteNonQuery();

                this.SalesMasterId = Convert.ToInt64(SqlCmd.Parameters["@SalesMasterId"].Value);
                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                if (rs == posRecordStatus.Success)
                {
                    if (posSalesItemTranDAL.InsertSalesItemTran(this.lstSaleItemTranDAL, this.lstSaleItemModifierTranDAL, this.SalesMasterId, this.linktoOrderStatusMasterId, this.CreateDateTime, this.linktoUserMasterIdCreatedBy, SqlCon, SqlTran) == posRecordStatus.Error)
                    {
                        SqlTran.Rollback();
                        SqlCon.Close();
                        return posRecordStatus.Error;
                    }
                    else
                    {
                        if (posSalesTaxTranDAL.DeleteSalesTaxTran(this.SalesMasterId, SqlCon, SqlTran) == posRecordStatus.Error)
                        {
                            SqlTran.Rollback();
                            SqlCon.Close();
                            return posRecordStatus.Error;
                        }
                        else
                        {
                            if (posSalesTaxTranDAL.InsertSalesTaxTran(this.lstSalesTaxTran, this.SalesMasterId, SqlCon, SqlTran) == posRecordStatus.Error)
                            {
                                SqlTran.Rollback();
                                SqlCon.Close();
                                return posRecordStatus.Error;
                            }
                            else
                            {
                                if (OrderMasterIds != string.Empty)
                                {
                                    if (posOrderMasterDAL.UpdateOrderMasterlinktoSalesMasterId(OrderMasterIds, this.SalesMasterId, this.CreateDateTime, this.linktoUserMasterIdCreatedBy, SqlCon, SqlTran) == posRecordStatus.Error)
                                    {
                                        SqlTran.Rollback();
                                        SqlCon.Close();
                                        return posRecordStatus.Error;
                                    }
                                }
                                else
                                {
                                    if (this.lstSalesPaymentTran != null)
                                    {
                                        foreach (posSalesPaymentTranDAL objSalesPaymentTranDAL in this.lstSalesPaymentTran)
                                        {
                                            objSalesPaymentTranDAL.linktoSalesMasterId = this.SalesMasterId;
                                            objSalesPaymentTranDAL.linktoCustomerMasterId = objSalesPaymentTranDAL.linktoCustomerMasterId;
                                            objSalesPaymentTranDAL.linktoPaymentTypeMasterId = objSalesPaymentTranDAL.linktoPaymentTypeMasterId;
                                            objSalesPaymentTranDAL.Remark = objSalesPaymentTranDAL.Remark;
                                            objSalesPaymentTranDAL.AmountPaid = objSalesPaymentTranDAL.AmountPaid;
                                            objSalesPaymentTranDAL.IsDeleted = objSalesPaymentTranDAL.IsDeleted;
                                            objSalesPaymentTranDAL.PaymentDateTime = objSalesPaymentTranDAL.PaymentDateTime;
                                            objSalesPaymentTranDAL.CreateDateTime = objSalesPaymentTranDAL.CreateDateTime;
                                            objSalesPaymentTranDAL.linktoUserMasterIdCreatedBy = objSalesPaymentTranDAL.linktoUserMasterIdCreatedBy;
                                            rs = objSalesPaymentTranDAL.InsertSalesPaymentTran(SqlCon, SqlTran);

                                            if (rs != posRecordStatus.Success)
                                            {
                                                SqlTran.Rollback();
                                                SqlCon.Close();
                                                return rs;
                                            }

                                            if (objSalesPaymentTranDAL.linktoCustomerMasterId > 0)
                                            {
                                                objCustomerMasterDAL = new posCustomerMasterDAL();
                                                objCustomerMasterDAL.CustomerMasterId = Convert.ToInt32(objSalesPaymentTranDAL.linktoCustomerMasterId);
                                                objCustomerMasterDAL.CreditBalance = objSalesPaymentTranDAL.AmountPaid;
                                                objCustomerMasterDAL.UpdateDateTime = posGlobalsDAL.GetCurrentDateTime();
                                                objCustomerMasterDAL.IsDeleted = objSalesPaymentTranDAL.IsDeleted;
                                                objCustomerMasterDAL.linktoUserMasterIdUpdatedBy = posGlobalsDAL.UserInfo.UserMasterId;
                                                rs = objCustomerMasterDAL.UpdateCustomerMasterCreditBalance(SqlCon, SqlTran);
                                                if (rs != posRecordStatus.Success)
                                                {
                                                    SqlTran.Rollback();
                                                    SqlCon.Close();
                                                    return rs;
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                else
                {
                    SqlTran.Rollback();
                    return posRecordStatus.Error;
                }
                SqlTran.Commit();
                SqlCon.Close();

                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public posRecordStatus InsertSalesMaster(List<posOrderItemDAL> lstSalesItem, List<posOrderItemDAL> lstItemModifier, List<posSalesTaxTranDAL> lstSalesTaxTranDAL)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlTransaction SqlTran = null;

            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCon.Open();
                SqlTran = SqlCon.BeginTransaction();
                SqlCmd = new SqlCommand("posSalesMaster_Insert", SqlCon, SqlTran);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@SalesMasterId", SqlDbType.BigInt).Direction = ParameterDirection.Output;
                SqlCmd.Parameters.Add("@BillNumber", SqlDbType.VarChar).Value = this.BillNumber;
                SqlCmd.Parameters.Add("@BillDateTime", SqlDbType.DateTime).Value = this.BillDateTime;
                SqlCmd.Parameters.Add("@linktoCounterMasterId", SqlDbType.SmallInt).Value = this.linktoCounterMasterId;
                SqlCmd.Parameters.Add("@linktoTableMasterIds", SqlDbType.VarChar).Value = this.linktoTableMasterIds;
                SqlCmd.Parameters.Add("@linktoWaiterMasterId", SqlDbType.Int).Value = this.linktoWaiterMasterId;
                SqlCmd.Parameters.Add("@linktoWaiterMasterIdCaptain", SqlDbType.Int).Value = this.linktoWaiterMasterIdCaptain;
                SqlCmd.Parameters.Add("@linktoCustomerMasterId", SqlDbType.Int).Value = this.linktoCustomerMasterId;
                SqlCmd.Parameters.Add("@linktoOrderTypeMasterId", SqlDbType.SmallInt).Value = this.linktoOrderTypeMasterId;
                SqlCmd.Parameters.Add("@linktoOrderStatusMasterId", SqlDbType.SmallInt).Value = this.linktoOrderStatusMasterId;
                SqlCmd.Parameters.Add("@NoOfAdults", SqlDbType.SmallInt).Value = this.NoOfAdults;
                SqlCmd.Parameters.Add("@NoOfChildren", SqlDbType.SmallInt).Value = this.NoOfChildren;
                SqlCmd.Parameters.Add("@RateIndex", SqlDbType.SmallInt).Value = this.RateIndex;
                SqlCmd.Parameters.Add("@TotalAmount", SqlDbType.Money).Value = this.TotalAmount;
                SqlCmd.Parameters.Add("@TotalTax", SqlDbType.Money).Value = this.TotalTax;
                SqlCmd.Parameters.Add("@DiscountPercentage", SqlDbType.Money).Value = this.DiscountPercentage;
                SqlCmd.Parameters.Add("@DiscountAmount", SqlDbType.Money).Value = this.DiscountAmount;
                SqlCmd.Parameters.Add("@ExtraAmount", SqlDbType.Money).Value = this.ExtraAmount;
                SqlCmd.Parameters.Add("@TotalItemDiscount", SqlDbType.Money).Value = this.TotalItemDiscount;
                SqlCmd.Parameters.Add("@TotalItemTax", SqlDbType.Money).Value = this.TotalItemTax;
                SqlCmd.Parameters.Add("@Rounding", SqlDbType.Money).Value = this.Rounding;
                SqlCmd.Parameters.Add("@NetAmount", SqlDbType.Money).Value = this.NetAmount;
                SqlCmd.Parameters.Add("@PaidAmount", SqlDbType.Money).Value = this.PaidAmount;
                SqlCmd.Parameters.Add("@BalanceAmount", SqlDbType.Money).Value = this.BalanceAmount;
                SqlCmd.Parameters.Add("@Remark", SqlDbType.VarChar).Value = this.Remark;
                SqlCmd.Parameters.Add("@IsComplimentary", SqlDbType.Bit).Value = this.IsComplimentary;
                SqlCmd.Parameters.Add("@TotalItemPoint", SqlDbType.SmallInt).Value = this.TotalItemPoint;
                SqlCmd.Parameters.Add("@TotalDeductedPoint", SqlDbType.SmallInt).Value = this.TotalDeductedPoint;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCmd.Parameters.Add("@IsDeleted", SqlDbType.Bit).Value = this.IsDeleted;
                SqlCmd.Parameters.Add("@CreateDateTime", SqlDbType.DateTime).Value = this.CreateDateTime;
                SqlCmd.Parameters.Add("@linktoUserMasterIdCreatedBy", SqlDbType.SmallInt).Value = this.linktoUserMasterIdCreatedBy;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCmd.ExecuteNonQuery();

                this.SalesMasterId = Convert.ToInt64(SqlCmd.Parameters["@SalesMasterId"].Value);
                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                if (rs != posRecordStatus.Success)
                {
                    SqlTran.Rollback();
                    SqlCon.Close();
                    return rs;
                }

                rs = posSalesItemTranDAL.InsertSalesItemTran(lstSalesItem, lstItemModifier, this.SalesMasterId, this.RateIndex, this.linktoOrderStatusMasterId, this.CreateDateTime, this.linktoUserMasterIdCreatedBy, SqlCon, SqlTran);
                if (rs != posRecordStatus.Success)
                {
                    SqlTran.Rollback();
                    SqlCon.Close();
                    return rs;
                }

                foreach (posSalesTaxTranDAL objSalesTaxTranDAL in lstSalesTaxTranDAL)
                {
                    objSalesTaxTranDAL.linktoSalesMasterId = this.SalesMasterId;
                    rs = objSalesTaxTranDAL.InsertSalesTaxTran(SqlCon, SqlTran, this.linktoBusinessMasterId);
                    if (rs != posRecordStatus.Success)
                    {
                        SqlTran.Rollback();
                        SqlCon.Close();
                        return rs;
                    }
                }

                rs = posOrderMasterDAL.UpdateOrderMasterlinktoSalesMasterId(OrderMasterIds, this.SalesMasterId, this.CreateDateTime, this.linktoUserMasterIdCreatedBy, SqlCon, SqlTran);
                if (rs != posRecordStatus.Success)
                {
                    SqlTran.Rollback();
                    SqlCon.Close();
                    return rs;
                }

                if (this.lstSalesPaymentTran != null)
                {
                    foreach (posSalesPaymentTranDAL objSalesPaymentTranDAL in this.lstSalesPaymentTran)
                    {
                        objSalesPaymentTranDAL.linktoSalesMasterId = this.SalesMasterId;
                        rs = objSalesPaymentTranDAL.InsertSalesPaymentTran(SqlCon, SqlTran);

                        if (rs != posRecordStatus.Success)
                        {
                            SqlTran.Rollback();
                            SqlCon.Close();
                            return rs;
                        }
                    }
                }
                if (lstCustomerMasterDAL != null)
                {
                    posCustomerMasterDAL objCustomerMasterDAL = null;
                    foreach (posCustomerMasterDAL objCustomer in lstCustomerMasterDAL)
                    {

                        objCustomerMasterDAL = new posCustomerMasterDAL();
                        objCustomerMasterDAL.CustomerMasterId = Convert.ToInt32(objCustomer.CustomerMasterId);
                        objCustomerMasterDAL.CreditBalance = objCustomer.CreditBalance;
                        objCustomerMasterDAL.UpdateDateTime = posGlobalsDAL.GetCurrentDateTime();
                        objCustomerMasterDAL.linktoUserMasterIdUpdatedBy = posGlobalsDAL.UserInfo.UserMasterId;
                        rs = objCustomerMasterDAL.UpdateCustomerMasterCreditBalance(SqlCon, SqlTran);
                        if (rs != posRecordStatus.Success)
                        {
                            SqlTran.Rollback();
                            SqlCon.Close();
                            return rs;
                        }
                    }
                }

                SqlTran.Commit();
                SqlCon.Close();

                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region Update
        public posRecordStatus UpdateSalesMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlTransaction SqlTran = null;
            posCustomerMasterDAL objCustomerMasterDAL = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCon.Open();
                SqlTran = SqlCon.BeginTransaction();
                SqlCmd = new SqlCommand("posSalesMaster_Update", SqlCon, SqlTran);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@SalesMasterId", SqlDbType.BigInt).Value = this.SalesMasterId;
                //SqlCmd.Parameters.Add("@BillNumber", SqlDbType.VarChar).Value = this.BillNumber;
                //SqlCmd.Parameters.Add("@BillDateTime", SqlDbType.DateTime).Value = this.BillDateTime;
                SqlCmd.Parameters.Add("@linktoCounterMasterId", SqlDbType.SmallInt).Value = this.linktoCounterMasterId;
                SqlCmd.Parameters.Add("@linktoTableMasterIds", SqlDbType.VarChar).Value = this.linktoTableMasterIds;
                SqlCmd.Parameters.Add("@linktoWaiterMasterId", SqlDbType.Int).Value = this.linktoWaiterMasterId;
                SqlCmd.Parameters.Add("@linktoWaiterMasterIdCaptain", SqlDbType.Int).Value = this.linktoWaiterMasterIdCaptain;
                SqlCmd.Parameters.Add("@linktoCustomerMasterId", SqlDbType.Int).Value = this.linktoCustomerMasterId;
                SqlCmd.Parameters.Add("@linktoOrderTypeMasterId", SqlDbType.SmallInt).Value = this.linktoOrderTypeMasterId;
                SqlCmd.Parameters.Add("@linktoOrderStatusMasterId", SqlDbType.SmallInt).Value = this.linktoOrderStatusMasterId;
                SqlCmd.Parameters.Add("@TotalAmount", SqlDbType.Money).Value = this.TotalAmount;
                SqlCmd.Parameters.Add("@TotalTax", SqlDbType.Money).Value = this.TotalTax;
                SqlCmd.Parameters.Add("@DiscountPercentage", SqlDbType.Money).Value = this.DiscountPercentage;
                SqlCmd.Parameters.Add("@DiscountAmount", SqlDbType.Money).Value = this.DiscountAmount;
                SqlCmd.Parameters.Add("@ExtraAmount", SqlDbType.Money).Value = this.ExtraAmount;
                SqlCmd.Parameters.Add("@TotalItemDiscount", SqlDbType.Money).Value = this.TotalItemDiscount;
                SqlCmd.Parameters.Add("@TotalItemTax", SqlDbType.Money).Value = this.TotalItemTax;
                SqlCmd.Parameters.Add("@NetAmount", SqlDbType.Money).Value = this.NetAmount;
                SqlCmd.Parameters.Add("@PaidAmount", SqlDbType.Money).Value = this.PaidAmount;
                SqlCmd.Parameters.Add("@BalanceAmount", SqlDbType.Money).Value = this.BalanceAmount;
                SqlCmd.Parameters.Add("@Remark", SqlDbType.VarChar).Value = this.Remark;
                SqlCmd.Parameters.Add("@IsComplimentary", SqlDbType.Bit).Value = this.IsComplimentary;
                SqlCmd.Parameters.Add("@TotalItemPoint", SqlDbType.SmallInt).Value = this.TotalItemPoint;
                SqlCmd.Parameters.Add("@TotalDeductedPoint", SqlDbType.SmallInt).Value = this.TotalDeductedPoint;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCmd.Parameters.Add("@UpdateDateTime", SqlDbType.DateTime).Value = this.UpdateDateTime;
                SqlCmd.Parameters.Add("@linktoUserMasterIdUpdatedBy", SqlDbType.SmallInt).Value = this.linktoUserMasterIdUpdatedBy;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCmd.ExecuteNonQuery();

                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                if (rs == posRecordStatus.Success)
                {
                    if (posSalesItemTranDAL.DeleteSalesItemTran(this.SalesMasterId, SqlCon, SqlTran) == posRecordStatus.Error)
                    {
                        SqlTran.Rollback();
                        return posRecordStatus.Error;
                    }
                    else
                    {
                        if (posSalesItemTranDAL.InsertSalesItemTran(this.lstSaleItemTranDAL, this.lstSaleItemModifierTranDAL, this.SalesMasterId, this.linktoOrderStatusMasterId, this.CreateDateTime, this.linktoUserMasterIdCreatedBy, SqlCon, SqlTran) == posRecordStatus.Error)
                        {
                            SqlTran.Rollback();
                            return posRecordStatus.Error;
                        }
                        else
                        {
                            if (posSalesTaxTranDAL.DeleteSalesTaxTran(this.SalesMasterId, SqlCon, SqlTran) == posRecordStatus.Error)
                            {
                                SqlTran.Rollback();
                                return posRecordStatus.Error;
                            }
                            else
                            {
                                if (posSalesTaxTranDAL.InsertSalesTaxTran(this.lstSalesTaxTran, this.SalesMasterId, SqlCon, SqlTran) == posRecordStatus.Error)
                                {
                                    SqlTran.Rollback();
                                    return posRecordStatus.Error;
                                }
                                else
                                {
                                    if (this.lstSalesPaymentTran != null)
                                    {
                                        foreach (posSalesPaymentTranDAL objSalesPaymentTranDAL in this.lstSalesPaymentTran)
                                        {
                                            objSalesPaymentTranDAL.SalesPaymentTranId = objSalesPaymentTranDAL.SalesPaymentTranId;
                                            objSalesPaymentTranDAL.linktoSalesMasterId = this.SalesMasterId;
                                            objSalesPaymentTranDAL.linktoCustomerMasterId = objSalesPaymentTranDAL.linktoCustomerMasterId;
                                            objSalesPaymentTranDAL.linktoPaymentTypeMasterId = objSalesPaymentTranDAL.linktoPaymentTypeMasterId;
                                            objSalesPaymentTranDAL.Remark = objSalesPaymentTranDAL.Remark;
                                            objSalesPaymentTranDAL.AmountPaid = objSalesPaymentTranDAL.AmountPaid;
                                            objSalesPaymentTranDAL.IsDeleted = objSalesPaymentTranDAL.IsDeleted;
                                            objSalesPaymentTranDAL.PaymentDateTime = objSalesPaymentTranDAL.PaymentDateTime;

                                            if (objSalesPaymentTranDAL.SalesPaymentTranId > 0)
                                            {
                                                objSalesPaymentTranDAL.UpdateDateTime = posGlobalsDAL.GetCurrentDateTime();
                                                objSalesPaymentTranDAL.linktoUserMasterIdUpdatedBy = posGlobalsDAL.UserInfo.UserMasterId;
                                                rs = objSalesPaymentTranDAL.UpdateSalesPaymentTran(SqlCon, SqlTran);
                                                if (rs != posRecordStatus.Success)
                                                {
                                                    SqlTran.Rollback();
                                                    SqlCon.Close();
                                                    return rs;
                                                }
                                            }
                                            else
                                            {
                                                objSalesPaymentTranDAL.CreateDateTime = objSalesPaymentTranDAL.CreateDateTime;
                                                objSalesPaymentTranDAL.linktoUserMasterIdCreatedBy = objSalesPaymentTranDAL.linktoUserMasterIdCreatedBy;
                                                rs = objSalesPaymentTranDAL.InsertSalesPaymentTran(SqlCon, SqlTran);
                                                if (rs != posRecordStatus.Success)
                                                {
                                                    SqlTran.Rollback();
                                                    SqlCon.Close();
                                                    return rs;
                                                }

                                                //if (objSalesPaymentTranDAL.linktoCustomerMasterId > 0)
                                                //{
                                                //    objCustomerMasterDAL = new posCustomerMasterDAL();
                                                //    objCustomerMasterDAL.CustomerMasterId = Convert.ToInt32(objSalesPaymentTranDAL.linktoCustomerMasterId);
                                                //    objCustomerMasterDAL.CreditBalance = objSalesPaymentTranDAL.AmountPaid;
                                                //    objCustomerMasterDAL.UpdateDateTime = posGlobalsDAL.GetCurrentDateTime();
                                                //    objCustomerMasterDAL.IsDeleted = objSalesPaymentTranDAL.IsDeleted;
                                                //    objCustomerMasterDAL.linktoUserMasterIdUpdatedBy = posGlobalsDAL.UserInfo.UserMasterId;
                                                //    rs = objCustomerMasterDAL.UpdateCustomerMasterCreditBalance(SqlCon, SqlTran);
                                                //    if (rs != posRecordStatus.Success)
                                                //    {
                                                //        SqlTran.Rollback();
                                                //        SqlCon.Close();
                                                //        return rs;
                                                //    }
                                                //} 
                                            }
                                            //if (rs != posRecordStatus.Success)
                                            //{
                                            //    SqlTran.Rollback();
                                            //    SqlCon.Close();
                                            //}


                                            if (objSalesPaymentTranDAL.linktoCustomerMasterId > 0)
                                            {
                                                objCustomerMasterDAL = new posCustomerMasterDAL();
                                                objCustomerMasterDAL.CustomerMasterId = Convert.ToInt32(objSalesPaymentTranDAL.linktoCustomerMasterId);
                                                objCustomerMasterDAL.CreditBalance = objSalesPaymentTranDAL.AmountPaid;
                                                objCustomerMasterDAL.UpdateDateTime = posGlobalsDAL.GetCurrentDateTime();
                                                objCustomerMasterDAL.IsDeleted = objSalesPaymentTranDAL.IsDeleted;
                                                objCustomerMasterDAL.linktoUserMasterIdUpdatedBy = posGlobalsDAL.UserInfo.UserMasterId;
                                                rs = objCustomerMasterDAL.UpdateCustomerMasterCreditBalance(SqlCon, SqlTran);
                                                if (rs != posRecordStatus.Success)
                                                {
                                                    SqlTran.Rollback();
                                                    SqlCon.Close();
                                                    return rs;
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                else
                {
                    SqlTran.Rollback();
                    return posRecordStatus.Error;
                }
                SqlTran.Commit();
                SqlCon.Close();

                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public posRecordStatus UpdateSalesMaster(List<posOrderItemDAL> lstOrderItem, List<posOrderItemDAL> lstItemModifier, List<posSalesTaxTranDAL> lstSalesTaxTranDAL)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlTransaction SqlTran = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCon.Open();
                SqlTran = SqlCon.BeginTransaction();
                SqlCmd = new SqlCommand("posSalesMaster_Update", SqlCon, SqlTran);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@SalesMasterId", SqlDbType.BigInt).Value = this.SalesMasterId;
                SqlCmd.Parameters.Add("@BillDateTime", SqlDbType.DateTime).Value = this.BillDateTime;
                SqlCmd.Parameters.Add("@linktoCounterMasterId", SqlDbType.SmallInt).Value = this.linktoCounterMasterId;
                SqlCmd.Parameters.Add("@linktoTableMasterIds", SqlDbType.VarChar).Value = this.linktoTableMasterIds;
                SqlCmd.Parameters.Add("@linktoCustomerMasterId", SqlDbType.Int).Value = this.linktoCustomerMasterId;
                SqlCmd.Parameters.Add("@linktoOrderTypeMasterId", SqlDbType.SmallInt).Value = this.linktoOrderTypeMasterId;
                SqlCmd.Parameters.Add("@linktoOrderStatusMasterId", SqlDbType.SmallInt).Value = this.linktoOrderStatusMasterId;
                SqlCmd.Parameters.Add("@linktoWaiterMasterId", SqlDbType.SmallInt).Value = this.linktoWaiterMasterId;
                SqlCmd.Parameters.Add("@linktoWaiterMasterIdCaptain", SqlDbType.SmallInt).Value = this.linktoWaiterMasterIdCaptain;
                SqlCmd.Parameters.Add("@TotalAmount", SqlDbType.Money).Value = this.TotalAmount;
                SqlCmd.Parameters.Add("@TotalTax", SqlDbType.Money).Value = this.TotalTax;
                SqlCmd.Parameters.Add("@NetAmount", SqlDbType.Money).Value = this.NetAmount;
                SqlCmd.Parameters.Add("@DiscountPercentage", SqlDbType.Money).Value = this.DiscountPercentage;
                SqlCmd.Parameters.Add("@DiscountAmount", SqlDbType.Money).Value = this.DiscountAmount;
                SqlCmd.Parameters.Add("@ExtraAmount", SqlDbType.Money).Value = this.ExtraAmount;
                SqlCmd.Parameters.Add("@TotalItemPoint", SqlDbType.SmallInt).Value = this.TotalItemPoint;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCmd.Parameters.Add("@TotalItemDiscount", SqlDbType.Money).Value = this.TotalItemDiscount;
                SqlCmd.Parameters.Add("@TotalItemTax", SqlDbType.Money).Value = this.TotalItemTax;
                SqlCmd.Parameters.Add("@Rounding", SqlDbType.Money).Value = this.Rounding;
                SqlCmd.Parameters.Add("@NoOfAdults", SqlDbType.SmallInt).Value = this.NoOfAdults;
                SqlCmd.Parameters.Add("@NoOfChildren", SqlDbType.SmallInt).Value = this.NoOfChildren;
                SqlCmd.Parameters.Add("@RateIndex", SqlDbType.SmallInt).Value = this.RateIndex;
                SqlCmd.Parameters.Add("@PaidAmount", SqlDbType.Money).Value = this.PaidAmount;
                SqlCmd.Parameters.Add("@BalanceAmount", SqlDbType.Money).Value = this.BalanceAmount;
                SqlCmd.Parameters.Add("@TotalDeductedPoint", SqlDbType.SmallInt).Value = this.TotalDeductedPoint;
                SqlCmd.Parameters.Add("@Remark", SqlDbType.VarChar).Value = this.Remark;
                SqlCmd.Parameters.Add("@UpdateDateTime", SqlDbType.DateTime).Value = this.UpdateDateTime;
                SqlCmd.Parameters.Add("@linktoUserMasterIdUpdatedBy", SqlDbType.SmallInt).Value = this.linktoUserMasterIdUpdatedBy;
                SqlCmd.Parameters.Add("@IsComplimentary", SqlDbType.Bit).Value = this.IsComplimentary;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCmd.ExecuteNonQuery();

                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                if (rs != posRecordStatus.Success)
                {
                    SqlTran.Rollback();
                    SqlCon.Close();
                    return rs;
                }

                rs = posSalesItemTranDAL.DeleteSalesItemTran(this.SalesMasterId, SqlCon, SqlTran);
                if (rs != posRecordStatus.Success)
                {
                    SqlTran.Rollback();
                    SqlCon.Close();
                    return rs;
                }

                rs = posSalesItemTranDAL.InsertSalesItemTran(lstOrderItem, lstItemModifier, this.SalesMasterId, this.RateIndex, this.linktoOrderStatusMasterId, Convert.ToDateTime(this.UpdateDateTime), Convert.ToInt16(this.linktoUserMasterIdUpdatedBy), SqlCon, SqlTran);
                if (rs != posRecordStatus.Success)
                {
                    SqlTran.Rollback();
                    SqlCon.Close();
                    return rs;
                }

                rs = posSalesTaxTranDAL.DeleteSalesTaxTran(this.SalesMasterId, SqlCon, SqlTran);
                if (rs != posRecordStatus.Success)
                {
                    SqlTran.Rollback();
                    SqlCon.Close();
                    return rs;
                }

                foreach (posSalesTaxTranDAL objSalesTaxTranDAL in lstSalesTaxTranDAL)
                {
                    objSalesTaxTranDAL.linktoSalesMasterId = this.SalesMasterId;
                    rs = objSalesTaxTranDAL.InsertSalesTaxTran(SqlCon, SqlTran, this.linktoBusinessMasterId);
                    if (rs != posRecordStatus.Success)
                    {
                        SqlTran.Rollback();
                        SqlCon.Close();
                        return rs;
                    }
                }

                if (this.lstSalesPaymentTran != null)
                {
                    foreach (posSalesPaymentTranDAL objSalesPaymentTranDAL in this.lstSalesPaymentTran)
                    {
                        objSalesPaymentTranDAL.linktoSalesMasterId = this.SalesMasterId;

                        if (objSalesPaymentTranDAL.SalesPaymentTranId > 0)
                        {
                            objSalesPaymentTranDAL.UpdateDateTime = this.UpdateDateTime;
                            objSalesPaymentTranDAL.linktoUserMasterIdUpdatedBy = this.linktoUserMasterIdUpdatedBy;
                            rs = objSalesPaymentTranDAL.UpdateSalesPaymentTran(SqlCon, SqlTran);
                        }
                        else
                        {
                            rs = objSalesPaymentTranDAL.InsertSalesPaymentTran(SqlCon, SqlTran);
                        }
                        if (rs != posRecordStatus.Success)
                        {
                            SqlTran.Rollback();
                            SqlCon.Close();
                            return rs;
                        }
                    }
                }
                if (lstCustomerMasterDAL != null)
                {
                    posCustomerMasterDAL objCustomerMasterDAL = null;
                    foreach (posCustomerMasterDAL objCustomer in lstCustomerMasterDAL)
                    {
                        objCustomerMasterDAL = new posCustomerMasterDAL();
                        objCustomerMasterDAL.CustomerMasterId = Convert.ToInt32(objCustomer.CustomerMasterId);
                        objCustomerMasterDAL.CreditBalance = objCustomer.CreditBalance;
                        objCustomerMasterDAL.UpdateDateTime = posGlobalsDAL.GetCurrentDateTime();
                        objCustomerMasterDAL.linktoUserMasterIdUpdatedBy = posGlobalsDAL.UserInfo.UserMasterId;
                        rs = objCustomerMasterDAL.UpdateCustomerMasterCreditBalance(SqlCon, SqlTran);
                        if (rs != posRecordStatus.Success)
                        {
                            SqlTran.Rollback();
                            SqlCon.Close();
                            return rs;
                        }
                    }
                }

                SqlTran.Commit();
                SqlCon.Close();
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public static posRecordStatus UpdateSalesMasterByHomeDeliveryOrders(string orderMasterIds, short linktoWaiterMasterId, SqlConnection SqlCon, SqlTransaction SqlTran)
        {
            SqlCommand SqlCmd = null;
            try
            {
                SqlCmd = new SqlCommand("posSalesMasterByHomeDeliveryOrders_Update", SqlCon, SqlTran);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@OrderMasterIds", SqlDbType.VarChar).Value = orderMasterIds;
                SqlCmd.Parameters.Add("@linktoOrderStatusMasterId", SqlDbType.SmallInt).Value = Convert.ToInt16(posOrderStatus.Dispached.GetHashCode());
                SqlCmd.Parameters.Add("@linktoWaiterMasterId", SqlDbType.SmallInt).Value = linktoWaiterMasterId;
                SqlCmd.Parameters.Add("@UpdateDateTime", SqlDbType.DateTime).Value = posGlobalsDAL.GetCurrentDateTime();
                SqlCmd.Parameters.Add("@linktoUserMasterIdUpdatedBy", SqlDbType.SmallInt).Value = posGlobalsDAL.UserInfo.UserMasterId;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCmd.ExecuteNonQuery();

                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
            }
        }
        #endregion

        #region Select
        public bool SelectSalesMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posSalesMaster_Select", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@SalesMasterId", SqlDbType.BigInt).Value = this.SalesMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                bool IsSelected = SetClassPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                return IsSelected;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return false;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public bool SelectSalesMasterBillNumberAutoIncrement()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            bool IsSelected = false;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posSalesMasterBillNumberAutoIncrement_Select", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                if (SqlRdr.Read())
                {
                    this.BillNumber = Convert.ToString(SqlRdr["BillNumber"]);
                    IsSelected = true;
                }
                SqlRdr.Close();
                SqlCon.Close();

                return IsSelected;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return false;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public bool SelectSalesMasterSaleDaylyWeeklyMonthly()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            bool IsSelected = false;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posSalesMasterSaleDailyWeeaklyMonthly_Select", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                if (SqlRdr.Read())
                {
                    if (SqlRdr["MonthlySale"] != DBNull.Value)
                    {
                        this.MonthlySale = Convert.ToDouble(SqlRdr["MonthlySale"]);
                    }
                    if (SqlRdr["WeeaklySale"] != DBNull.Value)
                    {
                        this.Weeaklysale = Convert.ToDouble(SqlRdr["WeeaklySale"]);
                    }
                    if (SqlRdr["DailySale"] != DBNull.Value)
                    {
                        this.DailySale = Convert.ToDouble(SqlRdr["DailySale"]);
                    }
                    IsSelected = true;
                }
                SqlRdr.Close();
                SqlCon.Close();

                return IsSelected;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return false;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public bool SelectSalesMasterLeastSellingDayOfLastWeek()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            bool IsSelected = false;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posSalesMasterLeastSellingDay_Select", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCmd.Parameters.Add("@CancelOrderStatus", SqlDbType.SmallInt).Value = this.linktoOrderStatusMasterId;
                SqlCmd.Parameters.Add("@CurrentDate", SqlDbType.DateTime).Value = posGlobalsDAL.GetCurrentDateTime();

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                if (SqlRdr.Read())
                {
                    this.BillDateTimeString = Convert.ToString(SqlRdr["OrderDate"]);
                    this.LeastSellingDayName = Convert.ToString(SqlRdr["theDayName"]);
                    this.NetAmount = Convert.ToDouble(SqlRdr["SellingAmt"]);
                    IsSelected = true;
                }
                SqlRdr.Close();
                SqlCon.Close();

                return IsSelected;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return false;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region SelectAll
        public List<posSalesMasterDAL> SelectAllSalesMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posSalesMaster_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@BillNumber", SqlDbType.VarChar).Value = this.BillNumber;
                SqlCmd.Parameters.Add("@linktoTableMasterIds", SqlDbType.VarChar).Value = this.linktoTableMasterIds;
                SqlCmd.Parameters.Add("@BillDateTime", SqlDbType.Date).Value = this.BillDateTime;
                SqlCmd.Parameters.Add("@ToBillDateTime", SqlDbType.Date).Value = this.ToBillDateTime;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<posSalesMasterDAL> lstSalesMasterDAL = SetListPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                return lstSalesMasterDAL;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public static List<posSalesMasterDAL> SelectAllSalesMasterBillNumber(short linktoBusinessMasterId)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posSalesMasterBillNumber_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = linktoBusinessMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<posSalesMasterDAL> lstSalesMasterDAL = new List<posSalesMasterDAL>();
                posSalesMasterDAL objSalesMasterDAL = null;
                while (SqlRdr.Read())
                {
                    objSalesMasterDAL = new posSalesMasterDAL();
                    objSalesMasterDAL.SalesMasterId = Convert.ToInt64(SqlRdr["SalesMasterId"]);
                    objSalesMasterDAL.BillNumber = Convert.ToString(SqlRdr["BillNumber"]);
                    lstSalesMasterDAL.Add(objSalesMasterDAL);
                }
                SqlRdr.Close();
                SqlCon.Close();

                return lstSalesMasterDAL;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public List<posSalesMasterDAL> SelectAllSalesMasterOrderWiseSaleReport(DateTime FromDate, DateTime ToDate,int linktoBusinessMasterId)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posSalesMasterOrderWiseSalesReport_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@FromDate", SqlDbType.DateTime).Value = FromDate;
                SqlCmd.Parameters.Add("@ToDate", SqlDbType.DateTime).Value = ToDate;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.Int).Value = linktoBusinessMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<posSalesMasterDAL> lstSalesMasterDAL = new List<posSalesMasterDAL>();
                posSalesMasterDAL objSalesMasterDAL = null;
                while (SqlRdr.Read())
                {
                    objSalesMasterDAL = new posSalesMasterDAL();
                    objSalesMasterDAL.BillDateTime = Convert.ToDateTime(SqlRdr["BillDate"]).Date;
                    if (SqlRdr["Take Away"] != DBNull.Value)
                    {
                        objSalesMasterDAL.TakeAwaySale = Convert.ToDouble(SqlRdr["Take Away"]);
                    }
                    else
                    {
                        objSalesMasterDAL.TakeAwaySale = 0.00;
                    }

                    if (SqlRdr["Dine In"] != DBNull.Value)
                    {
                        objSalesMasterDAL.DineInSale = Convert.ToDouble(SqlRdr["Dine In"].ToString());
                    }
                    else
                    {
                        objSalesMasterDAL.DineInSale = 0.00;
                    }

                    if (SqlRdr["Home Delivery"] != DBNull.Value)
                    {
                        objSalesMasterDAL.HomeDeliverySale = Convert.ToDouble(SqlRdr["Home Delivery"]);
                    }
                    else
                    {
                        objSalesMasterDAL.HomeDeliverySale = 0.00;
                    }

                    if (SqlRdr["TotalSale"] != DBNull.Value)
                    {
                        objSalesMasterDAL.TotalSale = Convert.ToDouble(SqlRdr["TotalSale"]);
                    }
                    else
                    {
                        objSalesMasterDAL.TotalSale = 0.00;
                    }

                    lstSalesMasterDAL.Add(objSalesMasterDAL);
                }
                SqlRdr.Close();
                SqlCon.Close();

                return lstSalesMasterDAL;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public List<posSalesMasterDAL> SelectAllSalesMasteUserPaymentTypeWiseSaleReport(DateTime FromDate, DateTime ToDate)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posSaleMasterUserPaymentTypeWiseReport_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@FromDate", SqlDbType.DateTime).Value = FromDate;
                SqlCmd.Parameters.Add("@ToDate", SqlDbType.DateTime).Value = ToDate;
                SqlCmd.Parameters.Add("@linktoUserMasterIdCreatedBy", SqlDbType.Int).Value = this.linktoUserMasterIdCreatedBy;
                SqlCmd.Parameters.Add("@linktoCounterMasterId", SqlDbType.Int).Value = this.linktoCounterMasterId;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.Int).Value = this.linktoBusinessMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<posSalesMasterDAL> lstSalesMasterDAL = new List<posSalesMasterDAL>();
                posSalesMasterDAL objSalesMasterDAL = null;
                while (SqlRdr.Read())
                {
                    objSalesMasterDAL = new posSalesMasterDAL();
                    objSalesMasterDAL.UserName = Convert.ToString(SqlRdr["Username"]);
                    objSalesMasterDAL.BillDateTimeString = Convert.ToDateTime(SqlRdr["BillDateTime"]).ToShortDateString();
                    objSalesMasterDAL.PaymentType = Convert.ToString(SqlRdr["PaymentType"]);
                    objSalesMasterDAL.PaidAmount = Convert.ToDouble(SqlRdr["AmountPaid"]);
                    objSalesMasterDAL.TotalAmount = Convert.ToDouble(SqlRdr["TotalAmount"]);
                    objSalesMasterDAL.DiscountAmount = Convert.ToDouble(SqlRdr["DiscountAmount"]);
                    objSalesMasterDAL.TotalTax = Convert.ToDouble(SqlRdr["TotalTax"]);
                    objSalesMasterDAL.NetAmount = Convert.ToDouble(SqlRdr["NetAmount"]);
                    lstSalesMasterDAL.Add(objSalesMasterDAL);
                }
                SqlRdr.Close();
                SqlCon.Close();

                return lstSalesMasterDAL;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public List<posSalesMasterDAL> SelectAllSalesMasteSalesCollectionReport(DateTime FromDate, DateTime ToDate)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posSalesMasterSalesCollectionReport_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@linktoOrderTypeMasterId", SqlDbType.SmallInt).Value = this.linktoOrderTypeMasterId;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.Int).Value = this.linktoBusinessMasterId;
                SqlCmd.Parameters.Add("@FromDate", SqlDbType.DateTime).Value = FromDate;
                SqlCmd.Parameters.Add("@ToDate", SqlDbType.DateTime).Value = ToDate;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<posSalesMasterDAL> lstSalesMasterDAL = new List<posSalesMasterDAL>();
                posSalesMasterDAL objSalesMasterDAL = null;
                while (SqlRdr.Read())
                {
                    objSalesMasterDAL = new posSalesMasterDAL();
                    objSalesMasterDAL.BillDateTimeString = Convert.ToString(SqlRdr["BillDate"]);
                    objSalesMasterDAL.TotalAmount = Convert.ToDouble(SqlRdr["TotalAmount"]);
                    objSalesMasterDAL.DiscountAmount = Convert.ToDouble(SqlRdr["DiscountAmount"]);
                    objSalesMasterDAL.DiscountPercentage = Convert.ToDouble(SqlRdr["DiscountPercentage"]);
                    objSalesMasterDAL.NetAmount = Convert.ToDouble(SqlRdr["NetAmount"]);
                    objSalesMasterDAL.PaymentType = Convert.ToString(SqlRdr["PaymentType"]);

                    lstSalesMasterDAL.Add(objSalesMasterDAL);
                }
                SqlRdr.Close();
                SqlCon.Close();

                return lstSalesMasterDAL;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public List<posSalesMasterDAL> SelectAllSalesMasterByTableReport(DateTime FromDate, DateTime ToDate)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader sqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posSalesMasterTableWiseSummaryReport_SelectALL", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCmd.Parameters.Add("@linktoCounterMasterId", SqlDbType.SmallInt).Value = this.linktoCounterMasterId;
                SqlCmd.Parameters.Add("@FromDate", SqlDbType.DateTime).Value = FromDate;
                SqlCmd.Parameters.Add("@ToDate", SqlDbType.DateTime).Value = ToDate;

                SqlCon.Open();
                sqlRdr = SqlCmd.ExecuteReader();
                List<posSalesMasterDAL> lstSalesMasterDAL = new List<posSalesMasterDAL>();
                posSalesMasterDAL objSalesMasterDAL = null;
                while (sqlRdr.Read())
                {
                    objSalesMasterDAL = new posSalesMasterDAL();
                    objSalesMasterDAL.TableName = Convert.ToString(sqlRdr["TableName"]);
                    objSalesMasterDAL.TotalAmount = Convert.ToDouble(sqlRdr["TotalAmount"]);
                    objSalesMasterDAL.DiscountAmount = Convert.ToDouble(sqlRdr["DiscountAmount"]);
                    objSalesMasterDAL.TotalTax = Convert.ToDouble(sqlRdr["TotalTax"]);
                    objSalesMasterDAL.NetAmount = Convert.ToDouble(sqlRdr["NetAmount"]);
                    objSalesMasterDAL.Quantity = Convert.ToInt32(sqlRdr["Quantity"]);

                    lstSalesMasterDAL.Add(objSalesMasterDAL);
                }
                return lstSalesMasterDAL;

            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(sqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public DataTable SelectAllSalesMasterByTimeIntervalWiseCategorySaleReport(short TimeInterval, short? CategoryMasterId, bool AmtQty, DateTime FromDate, DateTime ToDate, int linktoBusinessMasterId)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataAdapter sqlAdp = null;
            DataTable dtTimeIntervalWiseCategorySale = new DataTable();
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posSaleMasterTimeIntervalWiseCatergorySale_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                if (CategoryMasterId > 0)
                {
                    SqlCmd.Parameters.Add("@CategoryMasterId", SqlDbType.SmallInt).Value = CategoryMasterId;
                }
                SqlCmd.Parameters.Add("@AmountQuantity", SqlDbType.Bit).Value = AmtQty;
                SqlCmd.Parameters.Add("@FromBillDate", SqlDbType.DateTime).Value = FromDate;
                SqlCmd.Parameters.Add("@ToBillDate", SqlDbType.DateTime).Value = ToDate;
                SqlCmd.Parameters.Add("@TimeInterval", SqlDbType.SmallInt).Value = TimeInterval;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.Int).Value = linktoBusinessMasterId;

                SqlCon.Open();
                sqlAdp = new SqlDataAdapter(SqlCmd);
                sqlAdp.Fill(dtTimeIntervalWiseCategorySale);
                SqlCon.Close();

                return dtTimeIntervalWiseCategorySale;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                // posObjectFactoryDAL.DisposeDataReader(sqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public DataTable SelectAllSalesMasterByCounterWiseTimeWiseSaleReport(short linktoCounterMasterId, short TimeInterval, DateTime FromDate, DateTime ToDate, int linktoBusinessMasterId)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataAdapter sqlAdp = null;
            DataTable dtTimeIntervalWiseCategorySale = new DataTable();
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posSaleMasterCounterWiseTimeWiseSaleReport_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                if (linktoCounterMasterId > 0)
                {
                    SqlCmd.Parameters.Add("@linktoCounterMasterId", SqlDbType.SmallInt).Value = linktoCounterMasterId;
                }
                SqlCmd.Parameters.Add("@FromBillDate", SqlDbType.DateTime).Value = FromDate;
                SqlCmd.Parameters.Add("@ToBillDate", SqlDbType.DateTime).Value = ToDate;
                SqlCmd.Parameters.Add("@TimeInterval", SqlDbType.SmallInt).Value = TimeInterval;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.Int).Value = linktoBusinessMasterId;

                SqlCon.Open();
                // SqlCmd.ExecuteNonQuery();
                sqlAdp = new SqlDataAdapter(SqlCmd);
                sqlAdp.Fill(dtTimeIntervalWiseCategorySale);
                SqlCon.Close();

                return dtTimeIntervalWiseCategorySale;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                // posObjectFactoryDAL.DisposeDataReader(sqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public DataTable SelectAllSalesMasterByTimeIntervalWiseItemSaleReport(short TimeInterval, short? CategoryMasterId, bool AmtQty, DateTime FromDate, DateTime ToDate, int linktoBusinessMasterId)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataAdapter sqlAdp = null;
            DataTable dtItemSale = new DataTable();
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posSaleMasterTimeIntervalWiseItemSale_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                if (CategoryMasterId > 0)
                {
                    SqlCmd.Parameters.Add("@CategoryMasterId", SqlDbType.SmallInt).Value = CategoryMasterId;
                }
                SqlCmd.Parameters.Add("@AmountQuantity", SqlDbType.Bit).Value = AmtQty;
                SqlCmd.Parameters.Add("@FromBillDate", SqlDbType.DateTime).Value = FromDate;
                SqlCmd.Parameters.Add("@ToBillDate", SqlDbType.DateTime).Value = ToDate;
                SqlCmd.Parameters.Add("@TimeInterval", SqlDbType.SmallInt).Value = TimeInterval;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.Int).Value = linktoBusinessMasterId;

                SqlCon.Open();
                sqlAdp = new SqlDataAdapter(SqlCmd);
                sqlAdp.Fill(dtItemSale);
                SqlCon.Close();

                return dtItemSale;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public List<posSalesMasterDAL> SelectAllSalesMasteCustomerWiseSale(short customerType, short linktoBusinessMasterId, DateTime FromDate, DateTime ToDate)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader sqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posSalesMasterCustomerWiseSaleReport_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@FromBillDate", SqlDbType.DateTime).Value = FromDate;
                SqlCmd.Parameters.Add("@ToBillDate", SqlDbType.DateTime).Value = ToDate;
                SqlCmd.Parameters.Add("@CustomerType", SqlDbType.SmallInt).Value = customerType;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = linktoBusinessMasterId;
                if (this.linktoCustomerMasterId > 0)
                {
                    SqlCmd.Parameters.Add("@linktoCustomerMasterId", SqlDbType.SmallInt).Value = this.linktoCustomerMasterId;
                }


                SqlCon.Open();
                sqlRdr = SqlCmd.ExecuteReader();
                List<posSalesMasterDAL> lstSaleserMaster = new List<posSalesMasterDAL>();
                posSalesMasterDAL objSalesMaster = null;
                while (sqlRdr.Read())
                {
                    objSalesMaster = new posSalesMasterDAL();
                    objSalesMaster.CustomerType = Convert.ToInt16(sqlRdr["CustomerType"]);
                    objSalesMaster.Customer = Convert.ToString(sqlRdr["CustomerName"]);
                    objSalesMaster.BillDateTimeString = Convert.ToString(sqlRdr["BillDate"]);
                    objSalesMaster.TotalTax = Convert.ToDouble(sqlRdr["Tax"]);
                    objSalesMaster.TotalAmount = Convert.ToDouble(sqlRdr["TotalAmount"]);
                    objSalesMaster.DiscountAmount = Convert.ToDouble(sqlRdr["DiscountAmount"]);
                    objSalesMaster.NetAmount = Convert.ToDouble(sqlRdr["NetAmount"]);
                    lstSaleserMaster.Add(objSalesMaster);
                }

                sqlRdr.Close();
                SqlCon.Close();

                return lstSaleserMaster;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(sqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public List<posSalesMasterDAL> SelectAllSalesMasteSalesUserDateWiseReport(DateTime FromDate, int linktoBusinessMasterId, DateTime ToDate)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posSalesMasterSalesUserDateCounetrWiseReport_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@linktoCounterMasterId", SqlDbType.SmallInt).Value = this.linktoCounterMasterId;
                SqlCmd.Parameters.Add("@linktoUserMasterIdCreatedBy", SqlDbType.SmallInt).Value = this.linktoUserMasterIdCreatedBy;
                SqlCmd.Parameters.Add("@FromDate", SqlDbType.DateTime).Value = FromDate;
                SqlCmd.Parameters.Add("@ToDate", SqlDbType.DateTime).Value = ToDate;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.Int).Value = linktoBusinessMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<posSalesMasterDAL> lstSalesMasterDAL = new List<posSalesMasterDAL>();
                posSalesMasterDAL objSalesMasterDAL = null;
                while (SqlRdr.Read())
                {
                    objSalesMasterDAL = new posSalesMasterDAL();
                    objSalesMasterDAL.BillDateTimeString = Convert.ToString(SqlRdr["BillDate"]);
                    objSalesMasterDAL.TotalTax = Convert.ToDouble(SqlRdr["Tax"]);
                    objSalesMasterDAL.TotalAmount = Convert.ToDouble(SqlRdr["GrossAmount"]);
                    objSalesMasterDAL.DiscountAmount = Convert.ToDouble(SqlRdr["DiscountAmount"]);
                    objSalesMasterDAL.Rounding = Convert.ToDouble(SqlRdr["Rounding"]);
                    objSalesMasterDAL.Cash = Convert.ToDouble(SqlRdr["Cash"]);
                    objSalesMasterDAL.Bank = Convert.ToDouble(SqlRdr["Bank"]);
                    objSalesMasterDAL.Card = Convert.ToDouble(SqlRdr["Card"]);
                    objSalesMasterDAL.Complemetory = Convert.ToDouble(SqlRdr["Complemetory"]);
                    objSalesMasterDAL.Others = Convert.ToDouble(SqlRdr["Others"]);
                    objSalesMasterDAL.UserName = Convert.ToString(SqlRdr["UserName"]);
                    objSalesMasterDAL.NetAmount = Convert.ToDouble(SqlRdr["NetAmount"]);
                    lstSalesMasterDAL.Add(objSalesMasterDAL);
                }
                SqlRdr.Close();
                SqlCon.Close();

                return lstSalesMasterDAL;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public List<posSalesMasterDAL> SelectAllSalesMasterSalesBillwiseReport(DateTime FromDate, DateTime ToDate)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posSalesMasterSalesBillwiseReport_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@linktoCounterMasterId", SqlDbType.SmallInt).Value = this.linktoCounterMasterId;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;

                SqlCmd.Parameters.Add("@FromBillNumber", SqlDbType.VarChar).Value = this.FirstBillNumber;
                SqlCmd.Parameters.Add("@ToBillNumber", SqlDbType.VarChar).Value = this.LastBillNumber;

                SqlCmd.Parameters.Add("@FromDate", SqlDbType.DateTime).Value = FromDate;
                SqlCmd.Parameters.Add("@ToDate", SqlDbType.DateTime).Value = ToDate;


                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<posSalesMasterDAL> lstSalesMasterDAL = new List<posSalesMasterDAL>();
                posSalesMasterDAL objSalesMasterDAL = null;
                while (SqlRdr.Read())
                {
                    objSalesMasterDAL = new posSalesMasterDAL();
                    objSalesMasterDAL.Counter = Convert.ToString(SqlRdr["CounterName"]);
                    objSalesMasterDAL.BillNumber = Convert.ToString(SqlRdr["BillNumber"]);
                    objSalesMasterDAL.TotalTax = Convert.ToDouble(SqlRdr["Tax"]);
                    objSalesMasterDAL.TotalAmount = Convert.ToDouble(SqlRdr["GrossAmount"]);
                    objSalesMasterDAL.DiscountAmount = Convert.ToDouble(SqlRdr["DiscountAmount"]);
                    objSalesMasterDAL.Rounding = Convert.ToDouble(SqlRdr["Rounding"]);
                    objSalesMasterDAL.Cash = Convert.ToDouble(SqlRdr["Cash"]);
                    objSalesMasterDAL.Bank = Convert.ToDouble(SqlRdr["Bank"]);
                    objSalesMasterDAL.Card = Convert.ToDouble(SqlRdr["Card"]);
                    objSalesMasterDAL.Complemetory = Convert.ToDouble(SqlRdr["Complemetory"]);
                    objSalesMasterDAL.Others = Convert.ToDouble(SqlRdr["Others"]);
                    objSalesMasterDAL.NetAmount = Convert.ToDouble(SqlRdr["NetAmount"]);
                    lstSalesMasterDAL.Add(objSalesMasterDAL);
                }
                SqlRdr.Close();
                SqlCon.Close();

                return lstSalesMasterDAL;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public List<posSalesMasterDAL> SelectAllSalesMasterOrderTypeWiseChart(DateTime FromDate, DateTime ToDate)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posSalesMasterOrderTypeWiseChart_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@FromDate", SqlDbType.DateTime).Value = FromDate;
                SqlCmd.Parameters.Add("@ToDate", SqlDbType.DateTime).Value = ToDate;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<posSalesMasterDAL> lstSalesMasterDAL = new List<posSalesMasterDAL>();
                posSalesMasterDAL objSalesMasterDAL = null;
                while (SqlRdr.Read())
                {
                    objSalesMasterDAL = new posSalesMasterDAL();
                    objSalesMasterDAL.OrderType = Convert.ToString(SqlRdr["OrderType"]);
                    objSalesMasterDAL.NetAmount = Convert.ToDouble(SqlRdr["NetAmount"]);
                    objSalesMasterDAL.TotalAmount = Convert.ToDouble(SqlRdr["SalesInPercentage"]);
                    lstSalesMasterDAL.Add(objSalesMasterDAL);
                }
                SqlRdr.Close();
                SqlCon.Close();

                return lstSalesMasterDAL;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public List<posSalesMasterDAL> SelectAllSalesMasterYearlyRevenueChart(string year)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posSalesMasterYearlyRevenue_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@Year", SqlDbType.VarChar).Value = year;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<posSalesMasterDAL> lstSalesMasterDAL = new List<posSalesMasterDAL>();
                posSalesMasterDAL objSalesMasterDAL = null;
                while (SqlRdr.Read())
                {
                    objSalesMasterDAL = new posSalesMasterDAL();
                    objSalesMasterDAL.Month = Convert.ToString(SqlRdr["months"]);
                    objSalesMasterDAL.NetAmount = Convert.ToDouble(SqlRdr["Revenue"]);
                    objSalesMasterDAL.Year = Convert.ToString(SqlRdr["years"]);
                    lstSalesMasterDAL.Add(objSalesMasterDAL);
                }
                SqlRdr.Close();
                SqlCon.Close();

                return lstSalesMasterDAL;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public List<posSalesMasterDAL> SelectAllSalesPaymentTranCreditorPayment()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posSalesPaymentTranCreditorPayment_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;
                SqlCmd.Parameters.Add("@linktoCustomerMasterId", SqlDbType.Int).Value = this.linktoCustomerMasterId;
                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<posSalesMasterDAL> lstSalesMaster = new List<posSalesMasterDAL>();
                posSalesMasterDAL objSalesMaster = null;
                while (SqlRdr.Read())
                {
                    objSalesMaster = new posSalesMasterDAL();
                    objSalesMaster.SalesMasterId = Convert.ToInt64(SqlRdr["SalesMasterId"]);
                    objSalesMaster.linktoCustomerMasterId = Convert.ToInt32(SqlRdr["CustomerMasterId"]);
                    objSalesMaster.TotalAmount = Convert.ToDouble(SqlRdr["Amount"]);
                    objSalesMaster.Customer = Convert.ToString(SqlRdr["CustomerName"]);
                    objSalesMaster.BillNumber = Convert.ToString(SqlRdr["BillNumber"]);
                    objSalesMaster.TableName = Convert.ToString(SqlRdr["TableName"]);
                    objSalesMaster.TotalSale = Convert.ToDouble(SqlRdr["TotalAmount"]);
                    lstSalesMaster.Add(objSalesMaster);
                }
                SqlRdr.Close();
                SqlCon.Close();
                return lstSalesMaster;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion
    }
}
