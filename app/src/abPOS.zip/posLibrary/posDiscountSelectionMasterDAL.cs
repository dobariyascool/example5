using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace posLibrary
{
    /// <summary>
    /// Class for posDiscountSelectionMaster
    /// </summary>
    public class posDiscountSelectionMasterDAL
    {
        #region Properties
        public short DiscountSelectionMasterId { get; set; }
        public double Discount { get; set; }
        public bool IsPercentage { get; set; }
        public string DiscountTitle { get; set; }
        public short linktoBusinessMasterId { get; set; }

        /// Extra
        public string Business { get; set; }
        public string DiscountRate { get; set; }
        #endregion

        #region Class Methods
        private List<posDiscountSelectionMasterDAL> SetListPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            List<posDiscountSelectionMasterDAL> lstDiscountSelectionMaster = new List<posDiscountSelectionMasterDAL>();
            posDiscountSelectionMasterDAL objDiscountSelectionMaster = null;
            while (sqlRdr.Read())
            {
                objDiscountSelectionMaster = new posDiscountSelectionMasterDAL();
                objDiscountSelectionMaster.DiscountSelectionMasterId = Convert.ToInt16(sqlRdr["DiscountSelectionMasterId"]);
                objDiscountSelectionMaster.IsPercentage = Convert.ToBoolean(sqlRdr["IsPercentage"]);
                objDiscountSelectionMaster.Discount = Convert.ToDouble(sqlRdr["Discount"]);
                objDiscountSelectionMaster.DiscountTitle = Convert.ToString(sqlRdr["DiscountTitle"]);
                objDiscountSelectionMaster.linktoBusinessMasterId = Convert.ToInt16(sqlRdr["linktoBusinessMasterId"]);

                /// Extra
                objDiscountSelectionMaster.Business = Convert.ToString(sqlRdr["Business"]);
                if (objDiscountSelectionMaster.IsPercentage)
                {
                    objDiscountSelectionMaster.DiscountRate = objDiscountSelectionMaster.Discount + " %";
                }
                else
                {
                    objDiscountSelectionMaster.DiscountRate = objDiscountSelectionMaster.Discount + " Rs.";
                }

                lstDiscountSelectionMaster.Add(objDiscountSelectionMaster);
            }
            return lstDiscountSelectionMaster;
        }
        #endregion

        #region Insert
        public posRecordStatus InsertDiscountSelectionMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posDiscountSelectionMaster_Insert", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@DiscountSelectionMasterId", SqlDbType.SmallInt).Direction = ParameterDirection.Output;
                SqlCmd.Parameters.Add("@Discount", SqlDbType.Decimal).Value = this.Discount;
                SqlCmd.Parameters.Add("@IsPercentage", SqlDbType.Bit).Value = this.IsPercentage;
                SqlCmd.Parameters.Add("@DiscountTitle", SqlDbType.VarChar).Value = this.DiscountTitle;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                this.DiscountSelectionMasterId = Convert.ToInt16(SqlCmd.Parameters["@DiscountSelectionMasterId"].Value);
                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region Delete
        public posRecordStatus DeleteDiscountSelectionMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posDiscountSelectionMaster_Delete", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@DiscountSelectionMasterId", SqlDbType.SmallInt).Value = this.DiscountSelectionMasterId;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region SelectAll
        public List<posDiscountSelectionMasterDAL> SelectAllDiscountSelectionMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posDiscountSelectionMaster_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                if (this.linktoBusinessMasterId > 0)
                {
                    SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                }

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<posDiscountSelectionMasterDAL> lstDiscountSelectionMasterDAL = SetListPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                return lstDiscountSelectionMasterDAL;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion
    }
}
