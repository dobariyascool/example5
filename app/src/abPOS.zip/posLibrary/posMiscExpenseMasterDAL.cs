using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace posLibrary
{
    /// <summary>
    /// Class for posMiscExpenseMaster
    /// </summary>
    public class posMiscExpenseMasterDAL
    {
        #region Properties
        public int MiscExpenseMasterId { get; set; }
        public short linktoMiscExpenseCategoryMasterId { get; set; }
        public string PaidTo { get; set; }
        public DateTime PaidDate { get; set; }
        public string InvoiceNo { get; set; }
        public short linktoPaymentTypeMasterId { get; set; }
        public short linktoCounterMasterId { get; set; }
        public double Amount { get; set; }
        public string Remark { get; set; }
        public DateTime CreateDateTime { get; set; }
        public short linktoUserMasterIdCreatedBy { get; set; }
        public DateTime? UpdateDateTime { get; set; }
        public short? linktoUserMasterIdUpdatedBy { get; set; }
        public short linktoBusinessMasterId { get; set; }

        /// Extra
        public string MiscExpenseCategory { get; set; }
        public string PaymentType { get; set; }
        public DateTime PaidDateTo { get; set; }//<---for data filtering operation
        #endregion

        #region Class Methods
        private bool SetClassPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            if (sqlRdr.Read())
            {
                this.MiscExpenseMasterId = Convert.ToInt32(sqlRdr["MiscExpenseMasterId"]);
                this.linktoMiscExpenseCategoryMasterId = Convert.ToInt16(sqlRdr["linktoMiscExpenseCategoryMasterId"]);
                this.PaidTo = Convert.ToString(sqlRdr["PaidTo"]);
                this.PaidDate = Convert.ToDateTime(sqlRdr["PaidDate"]);
                this.InvoiceNo = Convert.ToString(sqlRdr["InvoiceNo"]);
                this.linktoPaymentTypeMasterId = Convert.ToInt16(sqlRdr["linktoPaymentTypeMasterId"]);
                this.linktoCounterMasterId = Convert.ToInt16(sqlRdr["linktoCounterMasterId"]);
                this.Amount = Convert.ToDouble(sqlRdr["Amount"]);
                this.Remark = Convert.ToString(sqlRdr["Remark"]);
                this.CreateDateTime = Convert.ToDateTime(sqlRdr["CreateDateTime"]);
                this.linktoUserMasterIdCreatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdCreatedBy"]);
                if (sqlRdr["UpdateDateTime"] != DBNull.Value)
                {
                    this.UpdateDateTime = Convert.ToDateTime(sqlRdr["UpdateDateTime"]);
                }
                if (sqlRdr["linktoUserMasterIdUpdatedBy"] != DBNull.Value)
                {
                    this.linktoUserMasterIdUpdatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdUpdatedBy"]);
                }

                /// Extra
                this.MiscExpenseCategory = Convert.ToString(sqlRdr["MiscExpenseCategory"]);
                this.PaymentType = Convert.ToString(sqlRdr["PaymentType"]);
                return true;
            }
            return false;
        }

        private List<posMiscExpenseMasterDAL> SetListPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            List<posMiscExpenseMasterDAL> lstMiscExpenseMaster = new List<posMiscExpenseMasterDAL>();
            posMiscExpenseMasterDAL objMiscExpenseMaster = null;
            while (sqlRdr.Read())
            {
                objMiscExpenseMaster = new posMiscExpenseMasterDAL();
                objMiscExpenseMaster.MiscExpenseMasterId = Convert.ToInt32(sqlRdr["MiscExpenseMasterId"]);
                objMiscExpenseMaster.linktoMiscExpenseCategoryMasterId = Convert.ToInt16(sqlRdr["linktoMiscExpenseCategoryMasterId"]);
                objMiscExpenseMaster.PaidTo = Convert.ToString(sqlRdr["PaidTo"]);
                objMiscExpenseMaster.PaidDate = Convert.ToDateTime(sqlRdr["PaidDate"]);
                objMiscExpenseMaster.InvoiceNo = Convert.ToString(sqlRdr["InvoiceNo"]);
                objMiscExpenseMaster.linktoPaymentTypeMasterId = Convert.ToInt16(sqlRdr["linktoPaymentTypeMasterId"]);
                objMiscExpenseMaster.linktoCounterMasterId = Convert.ToInt16(sqlRdr["linktoCounterMasterId"]);
                objMiscExpenseMaster.Amount = Convert.ToDouble(sqlRdr["Amount"]);
                objMiscExpenseMaster.Remark = Convert.ToString(sqlRdr["Remark"]);
                objMiscExpenseMaster.CreateDateTime = Convert.ToDateTime(sqlRdr["CreateDateTime"]);
                objMiscExpenseMaster.linktoUserMasterIdCreatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdCreatedBy"]);
                if (sqlRdr["UpdateDateTime"] != DBNull.Value)
                {
                    objMiscExpenseMaster.UpdateDateTime = Convert.ToDateTime(sqlRdr["UpdateDateTime"]);
                }
                if (sqlRdr["linktoUserMasterIdUpdatedBy"] != DBNull.Value)
                {
                    objMiscExpenseMaster.linktoUserMasterIdUpdatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdUpdatedBy"]);
                }

                /// Extra
                objMiscExpenseMaster.MiscExpenseCategory = Convert.ToString(sqlRdr["MiscExpenseCategory"]);
                objMiscExpenseMaster.PaymentType = Convert.ToString(sqlRdr["PaymentType"]);
                lstMiscExpenseMaster.Add(objMiscExpenseMaster);
            }
            return lstMiscExpenseMaster;
        }
        #endregion

        #region Insert
        public posRecordStatus InsertMiscExpenseMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posMiscExpenseMaster_Insert", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@MiscExpenseMasterId", SqlDbType.Int).Direction = ParameterDirection.Output;
                SqlCmd.Parameters.Add("@linktoMiscExpenseCategoryMasterId", SqlDbType.SmallInt).Value = this.linktoMiscExpenseCategoryMasterId;
                SqlCmd.Parameters.Add("@PaidTo", SqlDbType.VarChar).Value = this.PaidTo;
                SqlCmd.Parameters.Add("@PaidDate", SqlDbType.Date).Value = this.PaidDate;
                SqlCmd.Parameters.Add("@InvoiceNo", SqlDbType.VarChar).Value = this.InvoiceNo;
                SqlCmd.Parameters.Add("@linktoPaymentTypeMasterId", SqlDbType.SmallInt).Value = this.linktoPaymentTypeMasterId;
                SqlCmd.Parameters.Add("@linktoCounterMasterId", SqlDbType.SmallInt).Value = this.linktoCounterMasterId;
                SqlCmd.Parameters.Add("@Amount", SqlDbType.Money).Value = this.Amount;
                SqlCmd.Parameters.Add("@Remark", SqlDbType.VarChar).Value = this.Remark;
                SqlCmd.Parameters.Add("@CreateDateTime", SqlDbType.DateTime).Value = this.CreateDateTime;
                SqlCmd.Parameters.Add("@linktoUserMasterIdCreatedBy", SqlDbType.SmallInt).Value = this.linktoUserMasterIdCreatedBy;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                this.MiscExpenseMasterId = Convert.ToInt32(SqlCmd.Parameters["@MiscExpenseMasterId"].Value);
                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region Update
        public posRecordStatus UpdateMiscExpenseMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posMiscExpenseMaster_Update", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@MiscExpenseMasterId", SqlDbType.Int).Value = this.MiscExpenseMasterId;
                SqlCmd.Parameters.Add("@linktoMiscExpenseCategoryMasterId", SqlDbType.SmallInt).Value = this.linktoMiscExpenseCategoryMasterId;
                SqlCmd.Parameters.Add("@PaidTo", SqlDbType.VarChar).Value = this.PaidTo;
                SqlCmd.Parameters.Add("@PaidDate", SqlDbType.Date).Value = this.PaidDate;
                SqlCmd.Parameters.Add("@InvoiceNo", SqlDbType.VarChar).Value = this.InvoiceNo;
                SqlCmd.Parameters.Add("@linktoPaymentTypeMasterId", SqlDbType.SmallInt).Value = this.linktoPaymentTypeMasterId;
                SqlCmd.Parameters.Add("@linktoCounterMasterId", SqlDbType.SmallInt).Value = this.linktoCounterMasterId;
                SqlCmd.Parameters.Add("@Amount", SqlDbType.Money).Value = this.Amount;
                SqlCmd.Parameters.Add("@Remark", SqlDbType.VarChar).Value = this.Remark;
                SqlCmd.Parameters.Add("@UpdateDateTime", SqlDbType.DateTime).Value = this.UpdateDateTime;
                SqlCmd.Parameters.Add("@linktoUserMasterIdUpdatedBy", SqlDbType.SmallInt).Value = this.linktoUserMasterIdUpdatedBy;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region DeleteAll
        public static posRecordStatus DeleteAllMiscExpenseMaster(string miscExpenseMasterIds)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posMiscExpenseMaster_DeleteAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@MiscExpenseMasterIds", SqlDbType.VarChar).Value = miscExpenseMasterIds;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region Select
        public bool SelectMiscExpenseMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posMiscExpenseMaster_Select", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@MiscExpenseMasterId", SqlDbType.Int).Value = this.MiscExpenseMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                bool IsSelected = SetClassPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                return IsSelected;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return false;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region SelectAll
        public List<posMiscExpenseMasterDAL> SelectAllMiscExpenseMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posMiscExpenseMaster_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                if (this.linktoMiscExpenseCategoryMasterId > 0)
                {
                    SqlCmd.Parameters.Add("@linktoMiscExpenseCategoryMasterId", SqlDbType.SmallInt).Value = this.linktoMiscExpenseCategoryMasterId;
                }
                SqlCmd.Parameters.Add("@PaidTo", SqlDbType.VarChar).Value = this.PaidTo;
                if (this.PaidDate != new DateTime())
                {
                    SqlCmd.Parameters.Add("@PaidDate", SqlDbType.Date).Value = this.PaidDate;
                }
                if (this.PaidDateTo != new DateTime())
                {
                    SqlCmd.Parameters.Add("@PaidDateTo", SqlDbType.Date).Value = this.PaidDateTo;
                }
                SqlCmd.Parameters.Add("@InvoiceNo", SqlDbType.VarChar).Value = this.InvoiceNo;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<posMiscExpenseMasterDAL> lstMiscExpenseMasterDAL = SetListPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                return lstMiscExpenseMasterDAL;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion
    }
}
