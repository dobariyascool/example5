using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace posLibrary
{
    /// <summary>
    /// Class for posCounterItemTran
    /// </summary>
    public class posCounterItemTranDAL
    {
        #region Properties
        public int CounterItemTranId { get; set; }
        public short linktoCounterMasterId { get; set; }
        public int linktoItemMasterId { get; set; }

        /// Extra
        public string ItemNameWithCode { get; set; }
        public bool IsSelected { get; set; }
        public string CategoryName { get; set; }
        public int ItemMasterId { get; set; }
        public short? linktoOfferMasterId { get; set; }
        public short ItemType { get; set; }
        public string linktoCounterMasterIds { get; set; }
        #endregion

        #region Class Methods
        private List<posCounterItemTranDAL> SetListPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            List<posCounterItemTranDAL> lstCounterItemTran = new List<posCounterItemTranDAL>();
            posCounterItemTranDAL objCounterItemTran = null;
            while (sqlRdr.Read())
            {
                objCounterItemTran = new posCounterItemTranDAL();
                if (sqlRdr["CounterItemTranId"] != DBNull.Value)
                {
                    objCounterItemTran.CounterItemTranId = Convert.ToInt32(sqlRdr["CounterItemTranId"]);
                }
                if (sqlRdr["linktoCounterMasterId"] != DBNull.Value)
                {
                    objCounterItemTran.linktoCounterMasterId = Convert.ToInt16(sqlRdr["linktoCounterMasterId"]);
                }
                if (sqlRdr["linktoItemMasterId"] != DBNull.Value)
                {
                    objCounterItemTran.linktoItemMasterId = Convert.ToInt32(sqlRdr["linktoItemMasterId"]);
                    objCounterItemTran.IsSelected = true;
                }

                /// Extra
                objCounterItemTran.ItemMasterId = Convert.ToInt16(sqlRdr["ItemMasterId"]);
                objCounterItemTran.ItemNameWithCode = Convert.ToString(sqlRdr["ItemName"]) + " (" + Convert.ToString(sqlRdr["ItemCode"]) + ")";
                if (sqlRdr["Category"] != DBNull.Value)
                {
                    objCounterItemTran.CategoryName = Convert.ToString(sqlRdr["Category"]);
                }
                if (sqlRdr["ItemType"] != DBNull.Value)
                {
                    objCounterItemTran.ItemType = Convert.ToInt16(sqlRdr["ItemType"]);
                }
                // objCounterItemTran.CategoryName = "";
                lstCounterItemTran.Add(objCounterItemTran);
            }
            return lstCounterItemTran;
        }
        #endregion

        #region InsertAll
        public static posRecordStatus InsertAllCounterItemTran(int linktoCounterMasterId, string linkToItemMasterIds)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posCounterItemTran_InsertAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@linktoCounterMasterId", SqlDbType.SmallInt).Value = linktoCounterMasterId;
                if (linkToItemMasterIds != null)
                {
                    SqlCmd.Parameters.Add("@linktoItemMasterIds", SqlDbType.VarChar).Value = linkToItemMasterIds;
                }
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public static posRecordStatus InsertCounterItemTran(int linktoCounterMasterId, int linkToItemMasterId, SqlConnection sqlCon, SqlTransaction sqlTran)
        {
            SqlCommand SqlCmd = null;
            try
            {
                SqlCmd = new SqlCommand("posCounterItemTran_Insert", sqlCon, sqlTran);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@linktoCounterMasterId", SqlDbType.SmallInt).Value = linktoCounterMasterId;

                SqlCmd.Parameters.Add("@linktoItemMasterId", SqlDbType.Int).Value = linkToItemMasterId;

                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCmd.ExecuteNonQuery();

                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
            }
        }
        #endregion

        #region SelectAll
        public List<posCounterItemTranDAL> SelectAllCounterItemTran(short linktobusinessMasterId)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posCounterItemTran_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@linktoCounterMasterId", SqlDbType.SmallInt).Value = linktoCounterMasterId;
                SqlCmd.Parameters.Add("@linktobusinessMasterId", SqlDbType.SmallInt).Value = linktobusinessMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<posCounterItemTranDAL> lstCounterItemTranDAL = SetListPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                return lstCounterItemTranDAL;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public List<posCounterItemTranDAL> SelectAllCounterItemTranWithOfferItemsByCounter(short linktoBusinessMasterId)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader sqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posCounterItemTranWithOfferItemsTranByCounter_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@linktoOfferMasterId", SqlDbType.SmallInt).Value = this.linktoOfferMasterId;
                SqlCmd.Parameters.Add("@linktoCounterMasterIds", SqlDbType.VarChar).Value = this.linktoCounterMasterIds;
                SqlCmd.Parameters.Add("@OfferItemType", SqlDbType.SmallInt).Value = this.ItemType;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = linktoBusinessMasterId;
                SqlCon.Open();
                sqlRdr = SqlCmd.ExecuteReader();
                List<posCounterItemTranDAL> lstCounterItemTran = new List<posCounterItemTranDAL>();
                posCounterItemTranDAL objCounterItemTran = null;
                while (sqlRdr.Read())
                {
                    objCounterItemTran = new posCounterItemTranDAL();
                    objCounterItemTran.ItemMasterId = Convert.ToInt16(sqlRdr["ItemMasterId"]);
                    objCounterItemTran.ItemNameWithCode = Convert.ToString(sqlRdr["ItemName"]) + " (" + Convert.ToString(sqlRdr["ItemCode"]) + ")";

                    if (sqlRdr["CategoryName"] != DBNull.Value)
                    {
                        objCounterItemTran.CategoryName = Convert.ToString(sqlRdr["CategoryName"]);
                    }
                    if (sqlRdr["OfferItemsTranId"] != DBNull.Value)
                    {
                        objCounterItemTran.IsSelected = true;
                    }
                    if (sqlRdr["linktoOfferMasterId"] != DBNull.Value)
                    {
                        objCounterItemTran.linktoOfferMasterId = Convert.ToInt16(sqlRdr["linktoOfferMasterId"]);
                    }
                    if (sqlRdr["linktoCounterMasterIds"] != DBNull.Value)
                    {
                        objCounterItemTran.linktoCounterMasterIds = Convert.ToString(sqlRdr["linktoCounterMasterIds"]);
                    }
                    lstCounterItemTran.Add(objCounterItemTran);
                }

                sqlRdr.Close();
                SqlCon.Close();
                return lstCounterItemTran;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(sqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion
    }
}
