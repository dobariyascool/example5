using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace posLibrary
{
    /// <summary>
    /// Class for posEmployeeMaster
    /// </summary>
    public class posEmployeeMasterDAL
    {
        #region Properties
        public short EmployeeMasterId { get; set; }
        public string EmployeeCode { get; set; }
        public string EmployeeName { get; set; }
        public string ImageName { get; set; }
        public DateTime BirthDate { get; set; }
        public string Gender { get; set; }
        public string Address { get; set; }
        public short linktoCountryMasterId { get; set; }
        public short linktoStateMasterId { get; set; }
        public int linktoCityMasterId { get; set; }
        public string ZipCode { get; set; }
        public string Phone1 { get; set; }
        public string Phone2 { get; set; }
        public string Email { get; set; }
        public double? Salary { get; set; }
        public DateTime? JoinDate { get; set; }
        public DateTime? LeaveDate { get; set; }
        public string BloodGroup { get; set; }
        public short? linktoDesignationMasterId { get; set; }
        public short? linktoDepartmentMasterId { get; set; }
        public string ReferenceBy { get; set; }
        public string Remark { get; set; }
        public bool IsEnabled { get; set; }
        public bool IsDeleted { get; set; }
        public short linktoBusinessMasterId { get; set; }
        public DateTime CreateDateTime { get; set; }
        public short linktoUserMasterIdCreatedBy { get; set; }
        public DateTime? UpdateDateTime { get; set; }
        public short? linktoUserMasterIdUpdatedBy { get; set; }

        // Image Property
        public string xs_ImagePhysicalName { get; set; }
        public string sm_ImagePhysicalName { get; set; }
        public string md_ImagePhysicalName { get; set; }
        public string lg_ImagePhysicalName { get; set; }
        public string xl_ImagePhysicalName { get; set; }

        /// Extra
        public string Designation { get; set; }
        public string Department { get; set; }
        public string City { get; set; }
        #endregion

        #region Class Methods
        private bool SetClassPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            if (sqlRdr.Read())
            {
                this.EmployeeMasterId = Convert.ToInt16(sqlRdr["EmployeeMasterId"]);
                this.EmployeeCode = Convert.ToString(sqlRdr["EmployeeCode"]);
                this.EmployeeName = Convert.ToString(sqlRdr["EmployeeName"]);
                this.BirthDate = Convert.ToDateTime(sqlRdr["BirthDate"]);
                this.Gender = Convert.ToString(sqlRdr["Gender"]);
                this.Address = Convert.ToString(sqlRdr["Address"]);
                this.linktoCountryMasterId = Convert.ToInt16(sqlRdr["linktoCountryMasterId"]);
                this.linktoStateMasterId = Convert.ToInt16(sqlRdr["linktoStateMasterId"]);
                this.linktoCityMasterId = Convert.ToInt32(sqlRdr["linktoCityMasterId"]);
                this.ZipCode = Convert.ToString(sqlRdr["ZipCode"]);
                this.Phone1 = Convert.ToString(sqlRdr["Phone1"]);
                this.Phone2 = Convert.ToString(sqlRdr["Phone2"]);
                this.Email = Convert.ToString(sqlRdr["Email"]);
                if (sqlRdr["Salary"] != DBNull.Value)
                {
                    this.Salary = Convert.ToDouble(sqlRdr["Salary"]);
                }
                if (sqlRdr["JoinDate"] != DBNull.Value)
                {
                    this.JoinDate = Convert.ToDateTime(sqlRdr["JoinDate"]);
                }
                if (sqlRdr["LeaveDate"] != DBNull.Value)
                {
                    this.LeaveDate = Convert.ToDateTime(sqlRdr["LeaveDate"]);
                }
                this.BloodGroup = Convert.ToString(sqlRdr["BloodGroup"]);
                this.linktoDesignationMasterId = Convert.ToInt16(sqlRdr["linktoDesignationMasterId"]);
                this.linktoDepartmentMasterId = Convert.ToInt16(sqlRdr["linktoDepartmentMasterId"]);
                this.ReferenceBy = Convert.ToString(sqlRdr["ReferenceBy"]);
                this.Remark = Convert.ToString(sqlRdr["Remark"]);
                this.IsEnabled = Convert.ToBoolean(sqlRdr["IsEnabled"]);
                this.IsDeleted = Convert.ToBoolean(sqlRdr["IsDeleted"]);
                this.linktoBusinessMasterId = Convert.ToInt16(sqlRdr["linktoBusinessMasterId"]);
                this.CreateDateTime = Convert.ToDateTime(sqlRdr["CreateDateTime"]);
                this.linktoUserMasterIdCreatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdCreatedBy"]);
                if (sqlRdr["UpdateDateTime"] != DBNull.Value)
                {
                    this.UpdateDateTime = Convert.ToDateTime(sqlRdr["UpdateDateTime"]);
                }
                if (sqlRdr["linktoUserMasterIdUpdatedBy"] != DBNull.Value)
                {
                    this.linktoUserMasterIdUpdatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdUpdatedBy"]);
                }
                if (sqlRdr["ImageName"] != DBNull.Value)
                {
                    this.ImageName = Convert.ToString(sqlRdr["ImageName"]);

                    this.xs_ImagePhysicalName = "xs_" + Convert.ToString(sqlRdr["ImageName"]);
                    this.sm_ImagePhysicalName = "sm_" + Convert.ToString(sqlRdr["ImageName"]);
                    this.md_ImagePhysicalName = "md_" + Convert.ToString(sqlRdr["ImageName"]);
                    this.lg_ImagePhysicalName = "lg_" + Convert.ToString(sqlRdr["ImageName"]);
                    this.xl_ImagePhysicalName = "xl_" + Convert.ToString(sqlRdr["ImageName"]);
                }
                /// Extra
                this.Designation = Convert.ToString(sqlRdr["Designation"]);
                this.Department = Convert.ToString(sqlRdr["Department"]);
                return true;
            }
            return false;
        }

        private List<posEmployeeMasterDAL> SetListPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            List<posEmployeeMasterDAL> lstEmployeeMaster = new List<posEmployeeMasterDAL>();
            posEmployeeMasterDAL objEmployeeMaster = null;
            while (sqlRdr.Read())
            {
                objEmployeeMaster = new posEmployeeMasterDAL();
                objEmployeeMaster.EmployeeMasterId = Convert.ToInt16(sqlRdr["EmployeeMasterId"]);
                objEmployeeMaster.EmployeeCode = Convert.ToString(sqlRdr["EmployeeCode"]);
                objEmployeeMaster.EmployeeName = Convert.ToString(sqlRdr["EmployeeName"]);
                objEmployeeMaster.ImageName = Convert.ToString(sqlRdr["ImageName"]);
                objEmployeeMaster.BirthDate = Convert.ToDateTime(sqlRdr["BirthDate"]);
                objEmployeeMaster.Gender = Convert.ToString(sqlRdr["Gender"]);
                objEmployeeMaster.Address = Convert.ToString(sqlRdr["Address"]);
                objEmployeeMaster.linktoCountryMasterId = Convert.ToInt16(sqlRdr["linktoCountryMasterId"]);
                objEmployeeMaster.linktoStateMasterId = Convert.ToInt16(sqlRdr["linktoStateMasterId"]);
                objEmployeeMaster.linktoCityMasterId = Convert.ToInt32(sqlRdr["linktoCityMasterId"]);
                objEmployeeMaster.ZipCode = Convert.ToString(sqlRdr["ZipCode"]);
                objEmployeeMaster.Phone1 = Convert.ToString(sqlRdr["Phone1"]);
                objEmployeeMaster.Phone2 = Convert.ToString(sqlRdr["Phone2"]);
                objEmployeeMaster.Email = Convert.ToString(sqlRdr["Email"]);
                if (sqlRdr["Salary"] != DBNull.Value)
                {
                    objEmployeeMaster.Salary = Convert.ToDouble(sqlRdr["Salary"]);
                }
                if (sqlRdr["JoinDate"] != DBNull.Value)
                {
                    objEmployeeMaster.JoinDate = Convert.ToDateTime(sqlRdr["JoinDate"]);
                }
                if (sqlRdr["LeaveDate"] != DBNull.Value)
                {
                    objEmployeeMaster.LeaveDate = Convert.ToDateTime(sqlRdr["LeaveDate"]);
                }
                objEmployeeMaster.BloodGroup = Convert.ToString(sqlRdr["BloodGroup"]);
                objEmployeeMaster.linktoDesignationMasterId = Convert.ToInt16(sqlRdr["linktoDesignationMasterId"]);
                objEmployeeMaster.linktoDepartmentMasterId = Convert.ToInt16(sqlRdr["linktoDepartmentMasterId"]);
                objEmployeeMaster.ReferenceBy = Convert.ToString(sqlRdr["ReferenceBy"]);
                objEmployeeMaster.Remark = Convert.ToString(sqlRdr["Remark"]);
                objEmployeeMaster.IsEnabled = Convert.ToBoolean(sqlRdr["IsEnabled"]);
                objEmployeeMaster.IsDeleted = Convert.ToBoolean(sqlRdr["IsDeleted"]);
                objEmployeeMaster.linktoBusinessMasterId = Convert.ToInt16(sqlRdr["linktoBusinessMasterId"]);
                objEmployeeMaster.CreateDateTime = Convert.ToDateTime(sqlRdr["CreateDateTime"]);
                objEmployeeMaster.linktoUserMasterIdCreatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdCreatedBy"]);
                if (sqlRdr["UpdateDateTime"] != DBNull.Value)
                {
                    objEmployeeMaster.UpdateDateTime = Convert.ToDateTime(sqlRdr["UpdateDateTime"]);
                }
                if (sqlRdr["linktoUserMasterIdUpdatedBy"] != DBNull.Value)
                {
                    objEmployeeMaster.linktoUserMasterIdUpdatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdUpdatedBy"]);
                }

                /// Extra
                objEmployeeMaster.Designation = Convert.ToString(sqlRdr["Designation"]);
                objEmployeeMaster.Department = Convert.ToString(sqlRdr["Department"]);
                objEmployeeMaster.City = Convert.ToString(sqlRdr["City"]);

                lstEmployeeMaster.Add(objEmployeeMaster);
            }
            return lstEmployeeMaster;
        }
        #endregion

        #region Insert
        public posRecordStatus InsertEmployeeMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posEmployeeMaster_Insert", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@EmployeeMasterId", SqlDbType.SmallInt).Direction = ParameterDirection.Output;
                SqlCmd.Parameters.Add("@EmployeeCode", SqlDbType.VarChar).Value = this.EmployeeCode;
                SqlCmd.Parameters.Add("@EmployeeName", SqlDbType.VarChar).Value = this.EmployeeName;
                SqlCmd.Parameters.Add("@ImageName", SqlDbType.VarChar).Value = this.ImageName;
                SqlCmd.Parameters.Add("@BirthDate", SqlDbType.Date).Value = this.BirthDate;
                SqlCmd.Parameters.Add("@Gender", SqlDbType.VarChar).Value = this.Gender;
                SqlCmd.Parameters.Add("@Address", SqlDbType.VarChar).Value = this.Address;
                SqlCmd.Parameters.Add("@linktoCountryMasterId", SqlDbType.SmallInt).Value = this.linktoCountryMasterId;
                SqlCmd.Parameters.Add("@linktoStateMasterId", SqlDbType.SmallInt).Value = this.linktoStateMasterId;
                SqlCmd.Parameters.Add("@linktoCityMasterId", SqlDbType.Int).Value = this.linktoCityMasterId;
                SqlCmd.Parameters.Add("@ZipCode", SqlDbType.VarChar).Value = this.ZipCode;
                SqlCmd.Parameters.Add("@Phone1", SqlDbType.VarChar).Value = this.Phone1;
                SqlCmd.Parameters.Add("@Phone2", SqlDbType.VarChar).Value = this.Phone2;
                SqlCmd.Parameters.Add("@Email", SqlDbType.VarChar).Value = this.Email;
                SqlCmd.Parameters.Add("@Salary", SqlDbType.Money).Value = this.Salary;
                SqlCmd.Parameters.Add("@JoinDate", SqlDbType.Date).Value = this.JoinDate;
                SqlCmd.Parameters.Add("@LeaveDate", SqlDbType.Date).Value = this.LeaveDate;
                SqlCmd.Parameters.Add("@BloodGroup", SqlDbType.VarChar).Value = this.BloodGroup;
                SqlCmd.Parameters.Add("@linktoDesignationMasterId", SqlDbType.SmallInt).Value = this.linktoDesignationMasterId;
                SqlCmd.Parameters.Add("@linktoDepartmentMasterId", SqlDbType.SmallInt).Value = this.linktoDepartmentMasterId;
                SqlCmd.Parameters.Add("@ReferenceBy", SqlDbType.VarChar).Value = this.ReferenceBy;
                SqlCmd.Parameters.Add("@Remark", SqlDbType.VarChar).Value = this.Remark;
                SqlCmd.Parameters.Add("@IsEnabled", SqlDbType.Bit).Value = this.IsEnabled;
                SqlCmd.Parameters.Add("@IsDeleted", SqlDbType.Bit).Value = this.IsDeleted;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCmd.Parameters.Add("@CreateDateTime", SqlDbType.DateTime).Value = this.CreateDateTime;
                SqlCmd.Parameters.Add("@linktoUserMasterIdCreatedBy", SqlDbType.SmallInt).Value = this.linktoUserMasterIdCreatedBy;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                this.EmployeeMasterId = Convert.ToInt16(SqlCmd.Parameters["@EmployeeMasterId"].Value);
                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region Update
        public posRecordStatus UpdateEmployeeMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posEmployeeMaster_Update", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@EmployeeMasterId", SqlDbType.SmallInt).Value = this.EmployeeMasterId;
                SqlCmd.Parameters.Add("@EmployeeCode", SqlDbType.VarChar).Value = this.EmployeeCode;
                SqlCmd.Parameters.Add("@EmployeeName", SqlDbType.VarChar).Value = this.EmployeeName;
                SqlCmd.Parameters.Add("@ImageName", SqlDbType.VarChar).Value = this.ImageName;
                SqlCmd.Parameters.Add("@BirthDate", SqlDbType.Date).Value = this.BirthDate;
                SqlCmd.Parameters.Add("@Gender", SqlDbType.VarChar).Value = this.Gender;
                SqlCmd.Parameters.Add("@Address", SqlDbType.VarChar).Value = this.Address;
                SqlCmd.Parameters.Add("@linktoCountryMasterId", SqlDbType.SmallInt).Value = this.linktoCountryMasterId;
                SqlCmd.Parameters.Add("@linktoStateMasterId", SqlDbType.SmallInt).Value = this.linktoStateMasterId;
                SqlCmd.Parameters.Add("@linktoCityMasterId", SqlDbType.Int).Value = this.linktoCityMasterId;
                SqlCmd.Parameters.Add("@ZipCode", SqlDbType.VarChar).Value = this.ZipCode;
                SqlCmd.Parameters.Add("@Phone1", SqlDbType.VarChar).Value = this.Phone1;
                SqlCmd.Parameters.Add("@Phone2", SqlDbType.VarChar).Value = this.Phone2;
                SqlCmd.Parameters.Add("@Email", SqlDbType.VarChar).Value = this.Email;
                SqlCmd.Parameters.Add("@Salary", SqlDbType.Money).Value = this.Salary;
                SqlCmd.Parameters.Add("@JoinDate", SqlDbType.Date).Value = this.JoinDate;
                SqlCmd.Parameters.Add("@LeaveDate", SqlDbType.Date).Value = this.LeaveDate;
                SqlCmd.Parameters.Add("@BloodGroup", SqlDbType.VarChar).Value = this.BloodGroup;
                SqlCmd.Parameters.Add("@linktoDesignationMasterId", SqlDbType.SmallInt).Value = this.linktoDesignationMasterId;
                SqlCmd.Parameters.Add("@linktoDepartmentMasterId", SqlDbType.SmallInt).Value = this.linktoDepartmentMasterId;
                SqlCmd.Parameters.Add("@ReferenceBy", SqlDbType.VarChar).Value = this.ReferenceBy;
                SqlCmd.Parameters.Add("@Remark", SqlDbType.VarChar).Value = this.Remark;
                SqlCmd.Parameters.Add("@IsEnabled", SqlDbType.Bit).Value = this.IsEnabled;
                SqlCmd.Parameters.Add("@IsDeleted", SqlDbType.Bit).Value = this.IsDeleted;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCmd.Parameters.Add("@UpdateDateTime", SqlDbType.DateTime).Value = this.UpdateDateTime;
                SqlCmd.Parameters.Add("@linktoUserMasterIdUpdatedBy", SqlDbType.SmallInt).Value = this.linktoUserMasterIdUpdatedBy;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region DeleteAll
        public posRecordStatus DeleteAllEmployeeMaster(string employeeMasterIds)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posEmployeeMaster_DeleteAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@EmployeeMasterIds", SqlDbType.VarChar).Value = employeeMasterIds;
                SqlCmd.Parameters.Add("@UpdateDateTime", SqlDbType.DateTime).Value = this.UpdateDateTime;
                SqlCmd.Parameters.Add("@linktoUserMasterIdUpdatedBy", SqlDbType.SmallInt).Value = this.linktoUserMasterIdUpdatedBy;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region Select
        public bool SelectEmployeeMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posEmployeeMaster_Select", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@EmployeeMasterId", SqlDbType.SmallInt).Value = this.EmployeeMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                bool IsSelected = SetClassPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                return IsSelected;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return false;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region SelectAll
        public List<posEmployeeMasterDAL> SelectAllEmployeeMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posEmployeeMaster_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@EmployeeName", SqlDbType.VarChar).Value = this.EmployeeName;
                if (this.linktoDesignationMasterId > 0)
                {
                    SqlCmd.Parameters.Add("@linktoDesignationMasterId", SqlDbType.SmallInt).Value = this.linktoDesignationMasterId;
                }
                if (this.linktoDepartmentMasterId > 0)
                {
                    SqlCmd.Parameters.Add("@linktoDepartmentMasterId", SqlDbType.SmallInt).Value = this.linktoDepartmentMasterId;
                }
                SqlCmd.Parameters.Add("@IsEnabled", SqlDbType.Bit).Value = this.IsEnabled;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<posEmployeeMasterDAL> lstEmployeeMasterDAL = SetListPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                return lstEmployeeMasterDAL;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion
    }
}
