using System;
using System.Data;
using System.Data.SqlClient;
using System.Collections.Generic;

namespace posLibrary
{
	/// <summary>
	/// Class for posItemTypeMaster
	/// </summary>
	public class posItemTypeMasterDAL
	{
		#region Properties
		public short ItemTypeMasterId { get; set; }
		public string ItemType { get; set; }
		public short linktoBusinessTypeMasterId { get; set; }
		#endregion

		#region Class Methods
		private List<posItemTypeMasterDAL> SetListPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
		{
			List<posItemTypeMasterDAL> lstItemTypeMaster = new List<posItemTypeMasterDAL>();
			posItemTypeMasterDAL objItemTypeMaster = null;
			while (sqlRdr.Read())
			{
				objItemTypeMaster = new posItemTypeMasterDAL();
				objItemTypeMaster.ItemTypeMasterId = Convert.ToInt16(sqlRdr["ItemTypeMasterId"]);
				objItemTypeMaster.ItemType = Convert.ToString(sqlRdr["ItemType"]);
				objItemTypeMaster.linktoBusinessTypeMasterId = Convert.ToInt16(sqlRdr["linktoBusinessTypeMasterId"]);
				lstItemTypeMaster.Add(objItemTypeMaster);
			}
			return lstItemTypeMaster;
		}
		#endregion

		#region SelectAll

		public List<posItemTypeMasterDAL> SelectAllItemTypeMaster()
		{
			SqlConnection SqlCon = null;
			SqlCommand SqlCmd = null;
			SqlDataReader SqlRdr = null;
			try
			{
				SqlCon = posObjectFactoryDAL.CreateConnection();
				SqlCmd = new SqlCommand("posItemTypeMaster_SelectAll", SqlCon);
				SqlCmd.CommandType = CommandType.StoredProcedure;

				SqlCon.Open();
				SqlRdr = SqlCmd.ExecuteReader();
				List<posItemTypeMasterDAL> lstItemTypeMasterDAL = SetListPropertiesFromSqlDataReader(SqlRdr);
				SqlRdr.Close();
				SqlCon.Close();

				return lstItemTypeMasterDAL;
			}
			catch (Exception ex)
			{
				posGlobalsDAL.SaveError(ex);
				return null;
			}
			finally
			{
				posObjectFactoryDAL.DisposeDataReader(SqlRdr);
				posObjectFactoryDAL.DisposeCommand(SqlCmd);
				posObjectFactoryDAL.DisposeConnection(SqlCon);
			}
		}

		public static List<posItemTypeMasterDAL> SelectAllItemTypeMasterItemType()
		{
			SqlConnection SqlCon = null;
			SqlCommand SqlCmd = null;
			SqlDataReader SqlRdr = null;
			try
			{
				SqlCon = posObjectFactoryDAL.CreateConnection();
				SqlCmd = new SqlCommand("posItemTypeMasterItemType_SelectAll", SqlCon);
				SqlCmd.CommandType = CommandType.StoredProcedure;

				SqlCon.Open();
				SqlRdr = SqlCmd.ExecuteReader();
				List<posItemTypeMasterDAL> lstItemTypeMasterDAL = new List<posItemTypeMasterDAL>();
				posItemTypeMasterDAL objItemTypeMasterDAL = null;
				while (SqlRdr.Read())
				{
					objItemTypeMasterDAL = new posItemTypeMasterDAL();
					objItemTypeMasterDAL.ItemTypeMasterId = Convert.ToInt16(SqlRdr["ItemTypeMasterId"]);
					objItemTypeMasterDAL.ItemType = Convert.ToString(SqlRdr["ItemType"]);
					lstItemTypeMasterDAL.Add(objItemTypeMasterDAL);
				}
				SqlRdr.Close();
				SqlCon.Close();

				return lstItemTypeMasterDAL;
			}
			catch (Exception ex)
			{
				posGlobalsDAL.SaveError(ex);
				return null;
			}
			finally
			{
				posObjectFactoryDAL.DisposeDataReader(SqlRdr);
				posObjectFactoryDAL.DisposeCommand(SqlCmd);
				posObjectFactoryDAL.DisposeConnection(SqlCon);
			}
		}
		#endregion
	}
}
