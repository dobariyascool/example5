using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace posLibrary
{
    /// <summary>
    /// Class for posTaxMaster
    /// </summary>
    public class posTaxMasterDAL
    {
        #region Properties
        public short TaxMasterId { get; set; }
        public string TaxName { get; set; }
        public decimal TaxRate { get; set; }
        public short linktoBusinessMasterId { get; set; }
        public short TaxIndex { get; set; }
        public bool? IsEnabled { get; set; }
        public DateTime CreateDateTime { get; set; }
        public short linktoUserMasterIdCreatedBy { get; set; }
        public DateTime? UpdateDateTime { get; set; }
        public short? linktoUserMasterIdUpdatedBy { get; set; }

        /// Extra
        public string TaxRateString { get; set; }
        #endregion

        #region Class Methods
        private List<posTaxMasterDAL> SetListPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            List<posTaxMasterDAL> lstTaxMaster = new List<posTaxMasterDAL>();
            posTaxMasterDAL objTaxMaster = null;
            while (sqlRdr.Read())
            {
                objTaxMaster = new posTaxMasterDAL();
                objTaxMaster.TaxMasterId = Convert.ToInt16(sqlRdr["TaxMasterId"]);
                objTaxMaster.TaxName = Convert.ToString(sqlRdr["TaxName"]);
                objTaxMaster.TaxIndex = Convert.ToInt16(sqlRdr["TaxIndex"]);
                objTaxMaster.TaxRate = Convert.ToDecimal(sqlRdr["TaxRate"]);
                objTaxMaster.linktoBusinessMasterId = Convert.ToInt16(sqlRdr["linktoBusinessMasterId"]);
                objTaxMaster.IsEnabled = Convert.ToBoolean(sqlRdr["IsEnabled"]);
                objTaxMaster.CreateDateTime = Convert.ToDateTime(sqlRdr["CreateDateTime"]);
                objTaxMaster.linktoUserMasterIdCreatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdCreatedBy"]);
                if (sqlRdr["UpdateDateTime"] != DBNull.Value)
                {
                    objTaxMaster.UpdateDateTime = Convert.ToDateTime(sqlRdr["UpdateDateTime"]);
                }
                if (sqlRdr["linktoUserMasterIdUpdatedBy"] != DBNull.Value)
                {
                    objTaxMaster.linktoUserMasterIdUpdatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdUpdatedBy"]);
                }
                objTaxMaster.TaxRateString = objTaxMaster.TaxRate + " %";
                lstTaxMaster.Add(objTaxMaster);
            }
            return lstTaxMaster;
        }
        #endregion

        #region Insert
        public posRecordStatus InsertTaxMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posTaxMaster_Insert", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@TaxMasterId", SqlDbType.SmallInt).Direction = ParameterDirection.Output;
                SqlCmd.Parameters.Add("@TaxName", SqlDbType.VarChar).Value = this.TaxName;
                SqlCmd.Parameters.Add("@TaxIndex", SqlDbType.SmallInt).Value = this.TaxIndex;
                SqlCmd.Parameters.Add("@TaxRate", SqlDbType.Decimal).Value = this.TaxRate;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCmd.Parameters.Add("@IsEnabled", SqlDbType.Bit).Value = this.IsEnabled;
                SqlCmd.Parameters.Add("@CreateDateTime", SqlDbType.DateTime).Value = this.CreateDateTime;
                SqlCmd.Parameters.Add("@linktoUserMasterIdCreatedBy", SqlDbType.SmallInt).Value = this.linktoUserMasterIdCreatedBy;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                this.TaxMasterId = Convert.ToInt16(SqlCmd.Parameters["@TaxMasterId"].Value);
                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public posRecordStatus InsertTaxMaster(SqlConnection SqlCon, SqlTransaction SqlTran, List<posTaxMasterDAL> lstTaxMasterDAL)
        {
            SqlCommand SqlCmd = null;
            try
            {
                posRecordStatus rs = posRecordStatus.Error;
                SqlCmd = new SqlCommand("posTaxMaster_Insert", SqlCon, SqlTran);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                foreach (posTaxMasterDAL objTaxMasterDAL in lstTaxMasterDAL)
                {   
                    SqlCmd.Parameters.Clear();
                    SqlCmd.Parameters.Add("@TaxMasterId", SqlDbType.SmallInt).Direction = ParameterDirection.Output;
                    SqlCmd.Parameters.Add("@TaxName", SqlDbType.VarChar).Value = objTaxMasterDAL.TaxName;
                    SqlCmd.Parameters.Add("@TaxIndex", SqlDbType.SmallInt).Value = objTaxMasterDAL.TaxIndex;
                    SqlCmd.Parameters.Add("@TaxRate", SqlDbType.Decimal).Value = objTaxMasterDAL.TaxRate;
                    SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                    SqlCmd.Parameters.Add("@IsEnabled", SqlDbType.Bit).Value = objTaxMasterDAL.IsEnabled;
                    SqlCmd.Parameters.Add("@CreateDateTime", SqlDbType.DateTime).Value = objTaxMasterDAL.CreateDateTime;
                    SqlCmd.Parameters.Add("@linktoUserMasterIdCreatedBy", SqlDbType.SmallInt).Value = this.linktoUserMasterIdCreatedBy;
                    SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                    SqlCmd.ExecuteNonQuery();

                    this.TaxMasterId = Convert.ToInt16(SqlCmd.Parameters["@TaxMasterId"].Value);
                    rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                    if (rs != posRecordStatus.Success)
                    {
                        return rs;
                    }
                }
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
            }
        }

        public posRecordStatus InsertTaxMaster(List<posTaxMasterDAL> lstTaxMasterDAL, posItemRateTranDAL objItemRateTranDAL, short option)
        {
            SqlConnection SqlCon = null;
            SqlTransaction SqlTran = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCon.Open();
                SqlTran = SqlCon.BeginTransaction();

                posRecordStatus rs = posRecordStatus.Success;
                if (option != 3)
                {
                    rs = objItemRateTranDAL.UpdateItemRateTran(posGlobalsDAL.UserInfo.BusinessMasterId, option, SqlCon, SqlTran);
                    if (rs != posRecordStatus.Success)
                    {
                        SqlTran.Rollback();
                        SqlCon.Close();
                        return rs;
                    }
                }

                SqlCmd = new SqlCommand("posTaxMaster_Insert", SqlCon, SqlTran);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                foreach (posTaxMasterDAL objTaxMasterDAL in lstTaxMasterDAL)
                {
                    SqlCmd.Parameters.Clear();
                    SqlCmd.Parameters.Add("@TaxMasterId", SqlDbType.SmallInt).Direction = ParameterDirection.Output;
                    SqlCmd.Parameters.Add("@TaxName", SqlDbType.VarChar).Value = objTaxMasterDAL.TaxName;
                    SqlCmd.Parameters.Add("@TaxIndex", SqlDbType.SmallInt).Value = objTaxMasterDAL.TaxIndex;
                    SqlCmd.Parameters.Add("@TaxRate", SqlDbType.Decimal).Value = objTaxMasterDAL.TaxRate;
                    SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = posGlobalsDAL.UserInfo.BusinessMasterId;
                    SqlCmd.Parameters.Add("@IsEnabled", SqlDbType.Bit).Value = objTaxMasterDAL.IsEnabled;
                    SqlCmd.Parameters.Add("@CreateDateTime", SqlDbType.DateTime).Value = objTaxMasterDAL.CreateDateTime;
                    SqlCmd.Parameters.Add("@linktoUserMasterIdCreatedBy", SqlDbType.SmallInt).Value = this.linktoUserMasterIdCreatedBy;
                    SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                    SqlCmd.ExecuteNonQuery();

                    this.TaxMasterId = Convert.ToInt16(SqlCmd.Parameters["@TaxMasterId"].Value);
                    rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                    if (rs != posRecordStatus.Success)
                    {
                        SqlTran.Rollback();
                        SqlCon.Close();
                        return rs;
                    }
                }
             

                SqlTran.Commit();
                SqlCon.Close();
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region SelectAll
        public List<posTaxMasterDAL> SelectAllTaxMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posTaxMaster_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCmd.Parameters.Add("@IsEnabled", SqlDbType.Bit).Value = this.IsEnabled;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<posTaxMasterDAL> lstTaxMasterDAL = SetListPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                return lstTaxMasterDAL;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

       

    }
}
