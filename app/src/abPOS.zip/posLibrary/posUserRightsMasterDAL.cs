using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace posLibrary
{
	/// <summary>
	/// Class for posUserRightsMaster
	/// </summary>
    public class posUserRightsMasterDAL
	{
		#region Properties
		public short UserRightsMasterId { get; set; }
		public string UserRight { get; set; }
		public short linktoUserRightsGroupMasterId { get; set; }

        /// Extra
        public bool IsUpdated { get; set; }
		#endregion

		#region Class Methods
		private List<posUserRightsMasterDAL> SetListPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
		{
			List<posUserRightsMasterDAL> lstUserRightsMaster = new List<posUserRightsMasterDAL>();
			posUserRightsMasterDAL objUserRightsMaster = null;
			while (sqlRdr.Read())
			{
				objUserRightsMaster = new posUserRightsMasterDAL();
				objUserRightsMaster.UserRightsMasterId = Convert.ToInt16(sqlRdr["UserRightsMasterId"]);
				objUserRightsMaster.UserRight = Convert.ToString(sqlRdr["UserRight"]);
				objUserRightsMaster.linktoUserRightsGroupMasterId = Convert.ToInt16(sqlRdr["linktoUserRightsGroupMasterId"]);
                objUserRightsMaster.IsUpdated = false;
				lstUserRightsMaster.Add(objUserRightsMaster);
			}
			return lstUserRightsMaster;
		}
		#endregion

		#region SelectAll
		public List<posUserRightsMasterDAL> SelectAllUserRightsMaster()
		{
			SqlConnection SqlCon = null;
			SqlCommand SqlCmd = null;
			SqlDataReader SqlRdr = null;
			try
			{
				SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posUserRightsMaster_SelectAll", SqlCon);
				SqlCmd.CommandType = CommandType.StoredProcedure;           

				SqlCon.Open();
				SqlRdr = SqlCmd.ExecuteReader();
				List<posUserRightsMasterDAL> lstUserRightsMasterDAL = SetListPropertiesFromSqlDataReader(SqlRdr);
				SqlRdr.Close();
				SqlCon.Close();

				return lstUserRightsMasterDAL;
			}
			catch (Exception ex)
			{
				posGlobalsDAL.SaveError(ex);
				return null;
			}
			finally
			{
				posObjectFactoryDAL.DisposeDataReader(SqlRdr);
				posObjectFactoryDAL.DisposeCommand(SqlCmd);
				posObjectFactoryDAL.DisposeConnection(SqlCon);
			}
		}
		#endregion
	}
}
