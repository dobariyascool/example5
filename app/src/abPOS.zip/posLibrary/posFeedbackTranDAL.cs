using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace posLibrary
{
    /// <summary>
    /// Class for posFeedbackTran
    /// </summary>
    public class posFeedbackTranDAL
    {
        #region Properties
        public int FeedbackTranId { get; set; }
        public int linktoFeedbackMasterId { get; set; }
        public int linktoFeedbackQuestionMasterId { get; set; }
        public int? linktoFeedbackAnswerMasterId { get; set; }
        public string Answer { get; set; }

        /// Extra 
        public string FeedbackTranIds { get; set; }
        public string FeedbackQuestion { get; set; }
        public string FeedbackAnswer { get; set; }
        public DateTime FeebackDate { get; set; }
        public DateTime FeebackDateTo { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }
        public string Phone { get; set; }
        public int QuestionType { get; set; }
        public string AnswerMultiOrSingle { get; set; }

        #endregion

        #region Class Methods
        private List<posFeedbackTranDAL> SetListPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            List<posFeedbackTranDAL> lstFeedbackTran = new List<posFeedbackTranDAL>();
            posFeedbackTranDAL objFeedbackTran = null;
            while (sqlRdr.Read())
            {
                objFeedbackTran = new posFeedbackTranDAL();

                objFeedbackTran.linktoFeedbackMasterId = Convert.ToInt32(sqlRdr["linktoFeedbackMasterId"]);
                objFeedbackTran.linktoFeedbackQuestionMasterId = Convert.ToInt32(sqlRdr["linktoFeedbackQuestionMasterId"]);

                /// Extra 
                objFeedbackTran.FeedbackTranIds = Convert.ToString(sqlRdr["FeedbackTranIds"]);
                objFeedbackTran.FeedbackQuestion = Convert.ToString(sqlRdr["FeedbackQuestion"]);
                objFeedbackTran.FeedbackAnswer = Convert.ToString(sqlRdr["FeedbackAnswer"]);

                objFeedbackTran.Name = Convert.ToString(sqlRdr["Name"]);
                objFeedbackTran.Email = Convert.ToString(sqlRdr["Email"]);
                objFeedbackTran.Phone = Convert.ToString(sqlRdr["Phone"]);
                objFeedbackTran.Answer = Convert.ToString(sqlRdr["Answer"]);
                if (Convert.ToInt16(sqlRdr["QuestionType"]) == posFeedbackQuestionType.Rating.GetHashCode())
                {
                    objFeedbackTran.Answer = Convert.ToString(sqlRdr["Answer"]) + " Stars";
                }
                if (sqlRdr["AnswerMultiOrSingle"] != DBNull.Value)
                {
                    objFeedbackTran.Answer = Convert.ToString(sqlRdr["AnswerMultiOrSingle"]);
                }
              
                lstFeedbackTran.Add(objFeedbackTran);
            }

            return lstFeedbackTran;
        }
        #endregion

        #region Insert
        public static posRecordStatus InsertFeedbackTran(int linktoFeedbackMasterId, List<posFeedbackTranDAL> lstFeedbackTranDAL, SqlConnection sqlCon, SqlTransaction sqlTran)
        {
            SqlCommand SqlCmd = null;
            posRecordStatus rs = posRecordStatus.Error;
            try
            {
                SqlCmd = new SqlCommand("posFeedbackTran_Insert", sqlCon, sqlTran);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                foreach (posFeedbackTranDAL objFeedbackTranDAL in lstFeedbackTranDAL)
                {
                    SqlCmd.Parameters.Clear();
                    SqlCmd.Parameters.Add("@FeedbackTranId", SqlDbType.Int).Direction = ParameterDirection.Output;
                    SqlCmd.Parameters.Add("@linktoFeedbackMasterId", SqlDbType.Int).Value = linktoFeedbackMasterId;
                    SqlCmd.Parameters.Add("@linktoFeedbackQuestionMasterId", SqlDbType.Int).Value = objFeedbackTranDAL.linktoFeedbackQuestionMasterId;

                    if (objFeedbackTranDAL.linktoFeedbackAnswerMasterId > 0)
                    {
                        SqlCmd.Parameters.Add("@linktoFeedbackAnswerMasterId", SqlDbType.Int).Value = objFeedbackTranDAL.linktoFeedbackAnswerMasterId;
                    }

                    SqlCmd.Parameters.Add("@Answer", SqlDbType.VarChar).Value = objFeedbackTranDAL.Answer;
                    SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                    SqlCmd.ExecuteNonQuery();
                    rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                }
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
            }
        }
        #endregion

        #region DeleteAll
        public static posRecordStatus DeleteAllFeedbackTran(string feedbackTranIds)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posFeedbackTran_DeleteAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@FeedbackTranIds", SqlDbType.VarChar).Value = feedbackTranIds;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region SelectAll
        public List<posFeedbackTranDAL> SelectAllFeedbackTran()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posFeedbackTranQuestionWise_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                if (this.linktoFeedbackQuestionMasterId > 0)
                {
                    SqlCmd.Parameters.Add("@linktoFeedbackQuestionMasterId", SqlDbType.Int).Value = this.linktoFeedbackQuestionMasterId;
                }
                if (this.FeebackDate != new DateTime())
                {
                    SqlCmd.Parameters.Add("@FeebackDate", SqlDbType.Date).Value = this.FeebackDate;
                }
                if (this.FeebackDateTo != new DateTime())
                {
                    SqlCmd.Parameters.Add("@FeebackDateTo", SqlDbType.Date).Value = this.FeebackDateTo;
                }
                SqlCmd.Parameters.Add("@Name", SqlDbType.VarChar).Value = this.Name;
                SqlCmd.Parameters.Add("@Phone", SqlDbType.VarChar).Value = this.Phone;
                SqlCmd.Parameters.Add("@Email", SqlDbType.VarChar).Value = this.Email;
                SqlCmd.Parameters.Add("@FeedbackMasterID", SqlDbType.Int).Value = this.linktoFeedbackMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<posFeedbackTranDAL> lstFeedbackTranDAL = SetListPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                return lstFeedbackTranDAL;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion
    }
}
