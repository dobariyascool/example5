using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace posLibrary
{
    /// <summary>
    /// Class for posBusinessInfoAnswerMaster
    /// </summary>
    public class posBusinessInfoAnswerMasterDAL
    {
        #region Properties
        public int BusinessInfoAnswerMasterId { get; set; }
        public int linktoBusinessInfoQuestionMasterId { get; set; }
        public string Answer { get; set; }
        public bool IsEnabled { get; set; }

        /// Extra
        public string BusinessInfoQuestion { get; set; }
        public int BusinessInfoAnswerTranId { get; set; }
        public string QuestionType { get; set; }
        public bool IsAnswer { get; set; }
        #endregion

        #region Class Methods
        private List<posBusinessInfoAnswerMasterDAL> SetListPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            List<posBusinessInfoAnswerMasterDAL> lstBusinessInfoAnswerMaster = new List<posBusinessInfoAnswerMasterDAL>();
            posBusinessInfoAnswerMasterDAL objBusinessInfoAnswerMaster = null;
            while (sqlRdr.Read())
            {
                objBusinessInfoAnswerMaster = new posBusinessInfoAnswerMasterDAL();
                objBusinessInfoAnswerMaster.BusinessInfoAnswerMasterId = Convert.ToInt32(sqlRdr["BusinessInfoAnswerMasterId"]);
                objBusinessInfoAnswerMaster.linktoBusinessInfoQuestionMasterId = Convert.ToInt32(sqlRdr["linktoBusinessInfoQuestionMasterId"]);
                objBusinessInfoAnswerMaster.Answer = Convert.ToString(sqlRdr["Answer"]);
                objBusinessInfoAnswerMaster.IsEnabled = Convert.ToBoolean(sqlRdr["IsEnabled"]);

                /// Extra
                objBusinessInfoAnswerMaster.BusinessInfoQuestion = Convert.ToString(sqlRdr["BusinessInfoQuestion"]);
                if (sqlRdr["BusinessInfoAnswerTranId"] != DBNull.Value)
                {
                    objBusinessInfoAnswerMaster.BusinessInfoAnswerTranId = Convert.ToInt32(sqlRdr["BusinessInfoAnswerTranId"]);
                }
                lstBusinessInfoAnswerMaster.Add(objBusinessInfoAnswerMaster);
            }
            return lstBusinessInfoAnswerMaster;
        }
        #endregion

        #region SelectAll
        public List<posBusinessInfoAnswerMasterDAL> SelectAllBusinessInfoAnswerMaster(short linktoBusinessTypeMasterId, short linktoBusinessMasterId)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posBusinessInfoAnswerMasterBylinktoQuestionMasterId_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@linktoBusinessInfoQuestionMasterId", SqlDbType.Int).Value = this.linktoBusinessInfoQuestionMasterId;
                SqlCmd.Parameters.Add("@linktoBusinessTypeMasterId", SqlDbType.SmallInt).Value = linktoBusinessTypeMasterId;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = linktoBusinessMasterId;
                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<posBusinessInfoAnswerMasterDAL> lstBusinessInfoAnswerMasterDAL = SetListPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                return lstBusinessInfoAnswerMasterDAL;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public static List<posBusinessInfoAnswerMasterDAL> SelectAllBusinessInfoAnswerMasterByBusinessMasterId(short linktoBusinessTypeMasterId, short linktoBusinessMasterId)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posBusinessInfoAnswerMasterByBusinessTypeMasterId_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@linktoBusinessTypeMasterId", SqlDbType.SmallInt).Value = linktoBusinessTypeMasterId;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = linktoBusinessMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<posBusinessInfoAnswerMasterDAL> lstBusinessInfoAnswerMasterDAL = new List<posBusinessInfoAnswerMasterDAL>();
                posBusinessInfoAnswerMasterDAL objBusinessInfoAnswerMasterDAL = null;
                while (SqlRdr.Read())
                {
                    objBusinessInfoAnswerMasterDAL = new posBusinessInfoAnswerMasterDAL();
                    objBusinessInfoAnswerMasterDAL.linktoBusinessInfoQuestionMasterId = Convert.ToInt32(SqlRdr["BusinessInfoQuestionMasterId"]);
                    objBusinessInfoAnswerMasterDAL.BusinessInfoQuestion = Convert.ToString(SqlRdr["BusinessInfoQuestion"]);
                    objBusinessInfoAnswerMasterDAL.QuestionType = Convert.ToString(SqlRdr["QuestionType"]);
                    objBusinessInfoAnswerMasterDAL.Answer = Convert.ToString(SqlRdr["Answer"]);
                    lstBusinessInfoAnswerMasterDAL.Add(objBusinessInfoAnswerMasterDAL);

                }
                SqlRdr.Close();
                SqlCon.Close();

                return lstBusinessInfoAnswerMasterDAL;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion
    }
}
