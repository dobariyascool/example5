using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace posLibrary
{
    /// <summary>
    /// Class for posBusinessGalleryTran
    /// </summary>
    public class posBusinessGalleryTranDAL
    {
        #region Properties
        public int BusinessGalleryTranId { get; set; }
        public string ImageTitle { get; set; }
        public string ImageName { get; set; }
        public short linktoBusinessMasterId { get; set; }
        public short? SortOrder { get; set; }

        // Image Property
        public string xs_ImagePhysicalName { get; set; }
        public string sm_ImagePhysicalName { get; set; }
        public string md_ImagePhysicalName { get; set; }
        public string lg_ImagePhysicalName { get; set; }
        public string xl_ImagePhysicalName { get; set; }

        /// Extra
        public string Business { get; set; }
        #endregion

        #region Class Methods
        private bool SetClassPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            if (sqlRdr.Read())
            {
                this.BusinessGalleryTranId = Convert.ToInt32(sqlRdr["BusinessGalleryTranId"]);
                this.ImageTitle = Convert.ToString(sqlRdr["ImageTitle"]);
                this.linktoBusinessMasterId = Convert.ToInt16(sqlRdr["linktoBusinessMasterId"]);
                if (sqlRdr["SortOrder"] != DBNull.Value)
                {
                    this.SortOrder = Convert.ToInt16(sqlRdr["SortOrder"]);
                }

                if (sqlRdr["ImageName"] != DBNull.Value)
                {
                    this.ImageName = Convert.ToString(sqlRdr["ImageName"]);

                    this.xs_ImagePhysicalName = "xs_" + Convert.ToString(sqlRdr["ImageName"]);
                    this.sm_ImagePhysicalName = "sm_" + Convert.ToString(sqlRdr["ImageName"]);
                    this.md_ImagePhysicalName = "md_" + Convert.ToString(sqlRdr["ImageName"]);
                    this.lg_ImagePhysicalName = "lg_" + Convert.ToString(sqlRdr["ImageName"]);
                    this.xl_ImagePhysicalName = "xl_" + Convert.ToString(sqlRdr["ImageName"]);
                }
                /// Extra
                this.Business = Convert.ToString(sqlRdr["Business"]);
                return true;
            }
            return false;
        }

        private List<posBusinessGalleryTranDAL> SetListPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            List<posBusinessGalleryTranDAL> lstBusinessGalleryTran = new List<posBusinessGalleryTranDAL>();
            posBusinessGalleryTranDAL objBusinessGalleryTran = null;
            while (sqlRdr.Read())
            {
                objBusinessGalleryTran = new posBusinessGalleryTranDAL();
                objBusinessGalleryTran.BusinessGalleryTranId = Convert.ToInt32(sqlRdr["BusinessGalleryTranId"]);
                objBusinessGalleryTran.ImageTitle = Convert.ToString(sqlRdr["ImageTitle"]);
                objBusinessGalleryTran.ImageName = Convert.ToString(sqlRdr["ImageName"]);
                objBusinessGalleryTran.linktoBusinessMasterId = Convert.ToInt16(sqlRdr["linktoBusinessMasterId"]);
                if (sqlRdr["SortOrder"] != DBNull.Value)
                {
                    objBusinessGalleryTran.SortOrder = Convert.ToInt16(sqlRdr["SortOrder"]);
                }

                if (sqlRdr["ImageName"] != DBNull.Value)
                {
                    this.ImageName = Convert.ToString(sqlRdr["ImageName"]);

                    objBusinessGalleryTran.xs_ImagePhysicalName = "xs_" + Convert.ToString(sqlRdr["ImageName"]);
                    objBusinessGalleryTran.sm_ImagePhysicalName = "sm_" + Convert.ToString(sqlRdr["ImageName"]);
                    objBusinessGalleryTran.md_ImagePhysicalName = "md_" + Convert.ToString(sqlRdr["ImageName"]);
                    objBusinessGalleryTran.lg_ImagePhysicalName = "lg_" + Convert.ToString(sqlRdr["ImageName"]);
                    objBusinessGalleryTran.xl_ImagePhysicalName = "xl_" + Convert.ToString(sqlRdr["ImageName"]);
                }               
                /// Extra
                objBusinessGalleryTran.Business = Convert.ToString(sqlRdr["Business"]);
                lstBusinessGalleryTran.Add(objBusinessGalleryTran);
            }
            return lstBusinessGalleryTran;
        }
        #endregion

        #region Insert
        public posRecordStatus InsertBusinessGalleryTran()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posBusinessGalleryTran_Insert", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@BusinessGalleryTranId", SqlDbType.Int).Direction = ParameterDirection.Output;
                SqlCmd.Parameters.Add("@ImageTitle", SqlDbType.VarChar).Value = this.ImageTitle;
                SqlCmd.Parameters.Add("@ImageName", SqlDbType.VarChar).Value = this.ImageName;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCmd.Parameters.Add("@SortOrder", SqlDbType.SmallInt).Value = this.SortOrder;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                this.BusinessGalleryTranId = Convert.ToInt32(SqlCmd.Parameters["@BusinessGalleryTranId"].Value);
                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region Update
        public posRecordStatus UpdateBusinessGalleryTran()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posBusinessGalleryTran_Update", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@BusinessGalleryTranId", SqlDbType.Int).Value = this.BusinessGalleryTranId;
                SqlCmd.Parameters.Add("@ImageTitle", SqlDbType.VarChar).Value = this.ImageTitle;
                SqlCmd.Parameters.Add("@ImageName", SqlDbType.VarChar).Value = this.ImageName;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCmd.Parameters.Add("@SortOrder", SqlDbType.SmallInt).Value = this.SortOrder;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region DeleteAll
        public static posRecordStatus DeleteAllBusinessGalleryTran(string businessGalleryTranIds)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posBusinessGalleryTran_DeleteAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@BusinessGalleryTranIds", SqlDbType.VarChar).Value = businessGalleryTranIds;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region Select
        public bool SelectBusinessGalleryTran()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posBusinessGalleryTran_Select", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@BusinessGalleryTranId", SqlDbType.Int).Value = this.BusinessGalleryTranId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                bool IsSelected = SetClassPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                return IsSelected;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return false;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region SelectAll
        public List<posBusinessGalleryTranDAL> SelectAllBusinessGalleryTran()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posBusinessGalleryTran_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                if (this.linktoBusinessMasterId > 0)
                {
                    SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                }

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<posBusinessGalleryTranDAL> lstBusinessGalleryTranDAL = SetListPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                return lstBusinessGalleryTranDAL;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion
    }
}
