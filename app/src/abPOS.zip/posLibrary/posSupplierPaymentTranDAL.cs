using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace posLibrary
{
    /// <summary>
    /// Class for posSupplierPaymentTran
    /// </summary>
    public class posSupplierPaymentTranDAL
    {
        #region Properties
        public int SupplierPaymentTranId { get; set; }
        public short linktoSupplierMasterId { get; set; }
        public short linktoPaymentTypeMasterId { get; set; }
        public int? linktoPurchaseMasterId { get; set; }
        public DateTime PaymentDate { get; set; }
        public string ReceiptNumber { get; set; }
        public double Amount { get; set; }
        public string Remark { get; set; }
        public bool IsDeleted { get; set; }
        public DateTime CreateDateTime { get; set; }
        public short linktoUserMasterIdCreatedBy { get; set; }
        public DateTime? UpdateDateTime { get; set; }
        public short? linktoUserMasterIdUpdatedBy { get; set; }

        /// Extra
        public string Supplier { get; set; }
        public string PaymentType { get; set; }
        public string Purchase { get; set; }
        public DateTime PaymentToDate { get; set; }
        #endregion

        #region Class Methods
        private bool SetClassPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            if (sqlRdr.Read())
            {
                this.SupplierPaymentTranId = Convert.ToInt32(sqlRdr["SupplierPaymentTranId"]);
                this.linktoSupplierMasterId = Convert.ToInt16(sqlRdr["linktoSupplierMasterId"]);
                this.linktoPaymentTypeMasterId = Convert.ToInt16(sqlRdr["linktoPaymentTypeMasterId"]);
                if (sqlRdr["linktoPurchaseMasterId"] != DBNull.Value)
                {
                    this.linktoPurchaseMasterId = Convert.ToInt32(sqlRdr["linktoPurchaseMasterId"]);
                }
                this.PaymentDate = Convert.ToDateTime(sqlRdr["PaymentDate"]);
                this.ReceiptNumber = Convert.ToString(sqlRdr["ReceiptNumber"]);
                this.Amount = Convert.ToDouble(sqlRdr["Amount"]);
                this.Remark = Convert.ToString(sqlRdr["Remark"]);
                this.IsDeleted = Convert.ToBoolean(sqlRdr["IsDeleted"]);
                this.CreateDateTime = Convert.ToDateTime(sqlRdr["CreateDateTime"]);
                this.linktoUserMasterIdCreatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdCreatedBy"]);
                if (sqlRdr["UpdateDateTime"] != DBNull.Value)
                {
                    this.UpdateDateTime = Convert.ToDateTime(sqlRdr["UpdateDateTime"]);
                }
                if (sqlRdr["linktoUserMasterIdUpdatedBy"] != DBNull.Value)
                {
                    this.linktoUserMasterIdUpdatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdUpdatedBy"]);
                }

                /// Extra
                this.Supplier = Convert.ToString(sqlRdr["Supplier"]);
                this.PaymentType = Convert.ToString(sqlRdr["PaymentType"]);
                this.Purchase = Convert.ToString(sqlRdr["Purchase"]);
                return true;
            }
            return false;
        }

        private List<posSupplierPaymentTranDAL> SetListPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            List<posSupplierPaymentTranDAL> lstSupplierPaymentTran = new List<posSupplierPaymentTranDAL>();
            posSupplierPaymentTranDAL objSupplierPaymentTran = null;
            while (sqlRdr.Read())
            {
                objSupplierPaymentTran = new posSupplierPaymentTranDAL();
                objSupplierPaymentTran.SupplierPaymentTranId = Convert.ToInt32(sqlRdr["SupplierPaymentTranId"]);
                objSupplierPaymentTran.linktoSupplierMasterId = Convert.ToInt16(sqlRdr["linktoSupplierMasterId"]);
                objSupplierPaymentTran.linktoPaymentTypeMasterId = Convert.ToInt16(sqlRdr["linktoPaymentTypeMasterId"]);
                if (sqlRdr["linktoPurchaseMasterId"] != DBNull.Value)
                {
                    objSupplierPaymentTran.linktoPurchaseMasterId = Convert.ToInt32(sqlRdr["linktoPurchaseMasterId"]);
                }
                objSupplierPaymentTran.PaymentDate = Convert.ToDateTime(sqlRdr["PaymentDate"]);
                objSupplierPaymentTran.ReceiptNumber = Convert.ToString(sqlRdr["ReceiptNumber"]);
                objSupplierPaymentTran.Amount = Convert.ToDouble(sqlRdr["Amount"]);
                objSupplierPaymentTran.Remark = Convert.ToString(sqlRdr["Remark"]);
                objSupplierPaymentTran.IsDeleted = Convert.ToBoolean(sqlRdr["IsDeleted"]);
                objSupplierPaymentTran.CreateDateTime = Convert.ToDateTime(sqlRdr["CreateDateTime"]);
                objSupplierPaymentTran.linktoUserMasterIdCreatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdCreatedBy"]);
                if (sqlRdr["UpdateDateTime"] != DBNull.Value)
                {
                    objSupplierPaymentTran.UpdateDateTime = Convert.ToDateTime(sqlRdr["UpdateDateTime"]);
                }
                if (sqlRdr["linktoUserMasterIdUpdatedBy"] != DBNull.Value)
                {
                    objSupplierPaymentTran.linktoUserMasterIdUpdatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdUpdatedBy"]);
                }

                /// Extra
                objSupplierPaymentTran.Supplier = Convert.ToString(sqlRdr["Supplier"]);
                objSupplierPaymentTran.PaymentType = Convert.ToString(sqlRdr["PaymentType"]);
                objSupplierPaymentTran.Purchase = Convert.ToString(sqlRdr["Purchase"]);
                lstSupplierPaymentTran.Add(objSupplierPaymentTran);
            }
            return lstSupplierPaymentTran;
        }
        #endregion

        #region Insert
        public posRecordStatus InsertSupplierPaymentTran()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posSupplierPaymentTran_Insert", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@SupplierPaymentTranId", SqlDbType.Int).Direction = ParameterDirection.Output;
                SqlCmd.Parameters.Add("@linktoSupplierMasterId", SqlDbType.SmallInt).Value = this.linktoSupplierMasterId;
                SqlCmd.Parameters.Add("@linktoPaymentTypeMasterId", SqlDbType.SmallInt).Value = this.linktoPaymentTypeMasterId;
                SqlCmd.Parameters.Add("@linktoPurchaseMasterId", SqlDbType.Int).Value = this.linktoPurchaseMasterId;
                SqlCmd.Parameters.Add("@PaymentDate", SqlDbType.Date).Value = this.PaymentDate;
                SqlCmd.Parameters.Add("@ReceiptNumber", SqlDbType.VarChar).Value = this.ReceiptNumber;
                SqlCmd.Parameters.Add("@Amount", SqlDbType.Money).Value = this.Amount;
                SqlCmd.Parameters.Add("@Remark", SqlDbType.VarChar).Value = this.Remark;
                SqlCmd.Parameters.Add("@IsDeleted", SqlDbType.Bit).Value = this.IsDeleted;
                SqlCmd.Parameters.Add("@CreateDateTime", SqlDbType.DateTime).Value = this.CreateDateTime;
                SqlCmd.Parameters.Add("@linktoUserMasterIdCreatedBy", SqlDbType.SmallInt).Value = this.linktoUserMasterIdCreatedBy;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                this.SupplierPaymentTranId = Convert.ToInt32(SqlCmd.Parameters["@SupplierPaymentTranId"].Value);
                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region Update
        public posRecordStatus UpdateSupplierPaymentTran()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posSupplierPaymentTran_Update", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@SupplierPaymentTranId", SqlDbType.Int).Value = this.SupplierPaymentTranId;
                SqlCmd.Parameters.Add("@linktoSupplierMasterId", SqlDbType.SmallInt).Value = this.linktoSupplierMasterId;
                SqlCmd.Parameters.Add("@linktoPaymentTypeMasterId", SqlDbType.SmallInt).Value = this.linktoPaymentTypeMasterId;
                SqlCmd.Parameters.Add("@linktoPurchaseMasterId", SqlDbType.Int).Value = this.linktoPurchaseMasterId;
                SqlCmd.Parameters.Add("@PaymentDate", SqlDbType.Date).Value = this.PaymentDate;
                SqlCmd.Parameters.Add("@ReceiptNumber", SqlDbType.VarChar).Value = this.ReceiptNumber;
                SqlCmd.Parameters.Add("@Amount", SqlDbType.Money).Value = this.Amount;
                SqlCmd.Parameters.Add("@Remark", SqlDbType.VarChar).Value = this.Remark;
                SqlCmd.Parameters.Add("@IsDeleted", SqlDbType.Bit).Value = this.IsDeleted;
                SqlCmd.Parameters.Add("@UpdateDateTime", SqlDbType.DateTime).Value = this.UpdateDateTime;
                SqlCmd.Parameters.Add("@linktoUserMasterIdUpdatedBy", SqlDbType.SmallInt).Value = this.linktoUserMasterIdUpdatedBy;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region Delete
        public posRecordStatus DeleteSupplierPaymentTran()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posSupplierPaymentTran_Delete", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@SupplierPaymentTranId", SqlDbType.Int).Value = this.SupplierPaymentTranId;
                SqlCmd.Parameters.Add("@UpdateDateTime", SqlDbType.DateTime).Value = this.UpdateDateTime;
                SqlCmd.Parameters.Add("@linktoUserMasterIdUpdatedBy", SqlDbType.SmallInt).Value = this.linktoUserMasterIdUpdatedBy;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region DeleteAll

        public static posRecordStatus DeleteAllSupplierPaymentTran(string SupplierPaymentIds, short linktoUserMasterIdUpdatedBy, DateTime UpdateDateTime)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posSupplierPaymentTran_DeleteAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@SupplierPaymentIds", SqlDbType.VarChar).Value = SupplierPaymentIds;
                SqlCmd.Parameters.Add("@UpdateDateTime", SqlDbType.DateTime).Value = UpdateDateTime;
                SqlCmd.Parameters.Add("@linktoUserMasterIdUpdatedBy", SqlDbType.SmallInt).Value = linktoUserMasterIdUpdatedBy;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        #endregion

        #region Select
        public bool SelectSupplierPaymentTran()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posSupplierPaymentTran_Select", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@SupplierPaymentTranId", SqlDbType.Int).Value = this.SupplierPaymentTranId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                bool IsSelected = SetClassPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                return IsSelected;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return false;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region SelectAll

        public List<posSupplierPaymentTranDAL> SelectAllSupplierPaymentTran()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posSupplierPaymentTran_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@linktoSupplierMasterId", SqlDbType.SmallInt).Value = this.linktoSupplierMasterId;
                SqlCmd.Parameters.Add("@linktoPurchaseMasterId", SqlDbType.Int).Value = this.linktoPurchaseMasterId;
                SqlCmd.Parameters.Add("@PaymentDate", SqlDbType.DateTime).Value = this.PaymentDate;
                SqlCmd.Parameters.Add("@PaymentToDate", SqlDbType.DateTime).Value = this.PaymentToDate;
                SqlCmd.Parameters.Add("@ReceiptNumber", SqlDbType.VarChar).Value = this.ReceiptNumber;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<posSupplierPaymentTranDAL> lstSupplierPaymentTranDAL = SetListPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                return lstSupplierPaymentTranDAL;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion
    }
}
