using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace posLibrary
{
	/// <summary>
	/// Class for posCustomerInvoiceTran
	/// </summary>
	public class posCustomerInvoiceTranDAL
	{
		#region Properties
		public int CustomerInvoiceTranId { get; set; }
		public int linktoCustomerInvoiceMasterId { get; set; }
		public long linktoSalesMasterId { get; set; }
		public double TotalAmount { get; set; }

		/// Extra
		public string CustomerInvoice { get; set; }
		public string Sales { get; set; }
		#endregion

		#region Class Methods
		private List<posCustomerInvoiceTranDAL> SetListPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
		{
			List<posCustomerInvoiceTranDAL> lstCustomerInvoiceTran = new List<posCustomerInvoiceTranDAL>();
			posCustomerInvoiceTranDAL objCustomerInvoiceTran = null;
			while (sqlRdr.Read())
			{
				objCustomerInvoiceTran = new posCustomerInvoiceTranDAL();
				objCustomerInvoiceTran.CustomerInvoiceTranId = Convert.ToInt32(sqlRdr["CustomerInvoiceTranId"]);
				objCustomerInvoiceTran.linktoCustomerInvoiceMasterId = Convert.ToInt32(sqlRdr["linktoCustomerInvoiceMasterId"]);
				objCustomerInvoiceTran.linktoSalesMasterId = Convert.ToInt64(sqlRdr["linktoSalesMasterId"]);
				objCustomerInvoiceTran.TotalAmount = Convert.ToDouble(sqlRdr["TotalAmount"]);

				/// Extra
				objCustomerInvoiceTran.CustomerInvoice = Convert.ToString(sqlRdr["CustomerInvoice"]);
				objCustomerInvoiceTran.Sales = Convert.ToString(sqlRdr["Sales"]);
				lstCustomerInvoiceTran.Add(objCustomerInvoiceTran);
			}
			return lstCustomerInvoiceTran;
		}
		#endregion

		#region Insert
		public posRecordStatus InsertCustomerInvoiceTran(SqlConnection SqlCon,SqlTransaction SqlTran)
		{
			SqlCommand SqlCmd = null;
			try
			{
				SqlCmd = new SqlCommand("posCustomerInvoiceTran_Insert", SqlCon,SqlTran);
				SqlCmd.CommandType = CommandType.StoredProcedure;

				SqlCmd.Parameters.Add("@CustomerInvoiceTranId", SqlDbType.Int).Direction = ParameterDirection.Output;
				SqlCmd.Parameters.Add("@linktoCustomerInvoiceMasterId", SqlDbType.Int).Value = this.linktoCustomerInvoiceMasterId;
				SqlCmd.Parameters.Add("@linktoSalesMasterId", SqlDbType.BigInt).Value = this.linktoSalesMasterId;
				SqlCmd.Parameters.Add("@TotalAmount", SqlDbType.Money).Value = this.TotalAmount;
				SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

				SqlCmd.ExecuteNonQuery();

				this.CustomerInvoiceTranId = Convert.ToInt32(SqlCmd.Parameters["@CustomerInvoiceTranId"].Value);
				posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;

				return rs;
			}
			catch (Exception ex)
			{
				posGlobalsDAL.SaveError(ex);
				return posRecordStatus.Error;
			}
			finally
			{
				posObjectFactoryDAL.DisposeCommand(SqlCmd);
			}
		}
		#endregion

		#region SelectAll
		public List<posCustomerInvoiceTranDAL> SelectAllCustomerInvoiceTran()
		{
			SqlConnection SqlCon = null;
			SqlCommand SqlCmd = null;
			SqlDataReader SqlRdr = null;
			try
			{
				SqlCon = posObjectFactoryDAL.CreateConnection();
				SqlCmd = new SqlCommand("posCustomerInvoiceTran_SelectAll", SqlCon);
				SqlCmd.CommandType = CommandType.StoredProcedure;

				SqlCon.Open();
				SqlRdr = SqlCmd.ExecuteReader();
				List<posCustomerInvoiceTranDAL> lstCustomerInvoiceTranDAL = SetListPropertiesFromSqlDataReader(SqlRdr);
				SqlRdr.Close();
				SqlCon.Close();

				return lstCustomerInvoiceTranDAL;
			}
			catch (Exception ex)
			{
				posGlobalsDAL.SaveError(ex);
				return null;
			}
			finally
			{
				posObjectFactoryDAL.DisposeDataReader(SqlRdr);
				posObjectFactoryDAL.DisposeCommand(SqlCmd);
				posObjectFactoryDAL.DisposeConnection(SqlCon);
			}
		}
		#endregion
	}
}
