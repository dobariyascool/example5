using System;
using System.Data;
using System.Data.SqlClient;
using System.Collections.Generic;

namespace posLibrary
{
	/// <summary>
	/// Class for posDiscountCustomerTran
	/// </summary>
	public class posDiscountCustomerTranDAL
	{
		#region Properties
		public int DiscountCustomerTranId { get; set; }
		public int linktoDiscountMasterId { get; set; }
		public int linktoCustomerMasterId { get; set; }

		/// Extra
		public string Discount { get; set; }
		public string CustomerName { get; set; }
        public string CustomerType { get; set; }
        public string Phone1 { get; set; }
        public string Email1 { get; set; }
        public int CustomerMasterId { get; set; } 
		#endregion

		#region Class Methods
		private bool SetClassPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
		{
			if (sqlRdr.Read())
			{
				this.DiscountCustomerTranId = Convert.ToInt32(sqlRdr["DiscountCustomerTranId"]);
				this.linktoDiscountMasterId = Convert.ToInt32(sqlRdr["linktoDiscountMasterId"]);
				this.linktoCustomerMasterId = Convert.ToInt32(sqlRdr["linktoCustomerMasterId"]);

				/// Extra
				this.Discount = Convert.ToString(sqlRdr["Discount"]);
				this.CustomerName = Convert.ToString(sqlRdr["CustomerName"]);
				return true;
			}
			return false;
		}

		private List<posDiscountCustomerTranDAL> SetListPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
		{
			List<posDiscountCustomerTranDAL> lstDiscountCustomerTran = new List<posDiscountCustomerTranDAL>();
			posDiscountCustomerTranDAL objDiscountCustomerTran = null;
			while (sqlRdr.Read())
			{
				objDiscountCustomerTran = new posDiscountCustomerTranDAL();
				objDiscountCustomerTran.DiscountCustomerTranId = Convert.ToInt32(sqlRdr["DiscountCustomerTranId"]);
				objDiscountCustomerTran.linktoDiscountMasterId = Convert.ToInt32(sqlRdr["linktoDiscountMasterId"]);
				objDiscountCustomerTran.linktoCustomerMasterId = Convert.ToInt32(sqlRdr["linktoCustomerMasterId"]);

				/// Extra
				objDiscountCustomerTran.Discount = Convert.ToString(sqlRdr["Discount"]);
				objDiscountCustomerTran.CustomerName = Convert.ToString(sqlRdr["CustomerName"]);
				lstDiscountCustomerTran.Add(objDiscountCustomerTran);
			}
			return lstDiscountCustomerTran;
		}
		#endregion  

		#region SelectAll 
        public List<posDiscountCustomerTranDAL> SelectAllDiscountCustomerTran()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posDiscountCustomerTran_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@linktoDiscountMasterId", SqlDbType.Int).Value = this.linktoDiscountMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<posDiscountCustomerTranDAL> lstDiscountCustomerTranDAL = new List<posDiscountCustomerTranDAL>();
                posDiscountCustomerTranDAL objDiscountCustomerTran = null; 
                while (SqlRdr.Read())
                { 
                    objDiscountCustomerTran = new posDiscountCustomerTranDAL();
                    if (SqlRdr["DiscountCustomerTranId"] != DBNull.Value)
                    { 
                        objDiscountCustomerTran.DiscountCustomerTranId = Convert.ToInt32(SqlRdr["DiscountCustomerTranId"]);
                    } 
                    objDiscountCustomerTran.CustomerMasterId = Convert.ToInt32(SqlRdr["CustomerMasterId"]);
                    objDiscountCustomerTran.CustomerName = Convert.ToString(SqlRdr["CustomerName"]);
                    if (Convert.ToInt32(SqlRdr["CustomerType"]) == posCustomerType.Creditor.GetHashCode())
                    {
                        objDiscountCustomerTran.CustomerType = posCustomerType.Creditor.ToString().Replace("_", " ");
                    }
                   else if (Convert.ToInt32(SqlRdr["CustomerType"]) == posCustomerType.Customer.GetHashCode())
                    {
                        objDiscountCustomerTran.CustomerType = posCustomerType.Customer.ToString().Replace("_", " ");
                    }
                    else if (Convert.ToInt32(SqlRdr["CustomerType"]) == posCustomerType.Registered_User.GetHashCode())
                    {
                        objDiscountCustomerTran.CustomerType = posCustomerType.Registered_User.ToString().Replace("_", " ");
                    }
                 
                    objDiscountCustomerTran.Phone1 = Convert.ToString(SqlRdr["Phone1"]);
                    objDiscountCustomerTran.Email1 = Convert.ToString(SqlRdr["Email1"]); 

                    lstDiscountCustomerTranDAL.Add(objDiscountCustomerTran);
                }
                SqlRdr.Close();
                SqlCon.Close();

                return lstDiscountCustomerTranDAL;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
		#endregion
	}
}
