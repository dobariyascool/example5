using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace posLibrary
{
    /// <summary>
    /// Class for posFeedbackQuestionGroupMaster
    /// </summary>
    public class posFeedbackQuestionGroupMasterDAL
    {
        #region Properties
        public short FeedbackQuestionGroupMasterId { get; set; }
        public short linktoBusinessMasterId { get; set; }
        public string GroupName { get; set; }
        public bool IsDeleted { get; set; }

        /// Extra
        public string Business { get; set; }
        public short TotalNullGroupFeedbackQuestion { get; set; }
        #endregion

        #region Class Methods
        private List<posFeedbackQuestionGroupMasterDAL> SetListPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            List<posFeedbackQuestionGroupMasterDAL> lstFeedbackQuestionGroupMaster = new List<posFeedbackQuestionGroupMasterDAL>();
            posFeedbackQuestionGroupMasterDAL objFeedbackQuestionGroupMaster = null;
            while (sqlRdr.Read())
            {
                objFeedbackQuestionGroupMaster = new posFeedbackQuestionGroupMasterDAL();
                objFeedbackQuestionGroupMaster.FeedbackQuestionGroupMasterId = Convert.ToInt16(sqlRdr["FeedbackQuestionGroupMasterId"]);
                objFeedbackQuestionGroupMaster.linktoBusinessMasterId = Convert.ToInt16(sqlRdr["linktoBusinessMasterId"]);
                objFeedbackQuestionGroupMaster.GroupName = Convert.ToString(sqlRdr["GroupName"]);
                objFeedbackQuestionGroupMaster.IsDeleted = Convert.ToBoolean(sqlRdr["IsDeleted"]);

                /// Extra
                objFeedbackQuestionGroupMaster.Business = Convert.ToString(sqlRdr["Business"]);
                objFeedbackQuestionGroupMaster.TotalNullGroupFeedbackQuestion = Convert.ToInt16(sqlRdr["TotalNullGroupFeedbackQuestion"]);
                lstFeedbackQuestionGroupMaster.Add(objFeedbackQuestionGroupMaster);
            }
            return lstFeedbackQuestionGroupMaster;
        }
        #endregion

        #region Insert
        public posRecordStatus InsertFeedbackQuestionGroupMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posFeedbackQuestionGroupMaster_Insert", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@FeedbackQuestionGroupMasterId", SqlDbType.SmallInt).Direction = ParameterDirection.Output;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCmd.Parameters.Add("@GroupName", SqlDbType.VarChar).Value = this.GroupName;
                SqlCmd.Parameters.Add("@IsDeleted", SqlDbType.Bit).Value = this.IsDeleted;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                this.FeedbackQuestionGroupMasterId = Convert.ToInt16(SqlCmd.Parameters["@FeedbackQuestionGroupMasterId"].Value);
                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region Update
        public posRecordStatus UpdateFeedbackQuestionGroupMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posFeedbackQuestionGroupMaster_Update", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@FeedbackQuestionGroupMasterId", SqlDbType.SmallInt).Value = this.FeedbackQuestionGroupMasterId;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCmd.Parameters.Add("@GroupName", SqlDbType.VarChar).Value = this.GroupName;
                SqlCmd.Parameters.Add("@IsDeleted", SqlDbType.Bit).Value = this.IsDeleted;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region Delete
        public posRecordStatus DeleteFeedbackQuestionGroupMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posFeedbackQuestionGroupMaster_Delete", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@FeedbackQuestionGroupMasterId", SqlDbType.SmallInt).Value = this.FeedbackQuestionGroupMasterId;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region SelectAll
        public List<posFeedbackQuestionGroupMasterDAL> SelectAllFeedbackQuestionGroupMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posFeedbackQuestionGroupMaster_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                if (this.linktoBusinessMasterId > 0)
                {
                    SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                }

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<posFeedbackQuestionGroupMasterDAL> lstFeedbackQuestionGroupMasterDAL = SetListPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                return lstFeedbackQuestionGroupMasterDAL;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public static List<posFeedbackQuestionGroupMasterDAL> SelectAllFeedbackQuestionGroupMasterGroupName(short linktoBusinessMasterId)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posFeedbackQuestionGroupMasterGroupName_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = linktoBusinessMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<posFeedbackQuestionGroupMasterDAL> lstFeedbackQuestionGroupMasterDAL = new List<posFeedbackQuestionGroupMasterDAL>();
                posFeedbackQuestionGroupMasterDAL objFeedbackQuestionGroupMasterDAL = null;
                while (SqlRdr.Read())
                {
                    objFeedbackQuestionGroupMasterDAL = new posFeedbackQuestionGroupMasterDAL();
                    objFeedbackQuestionGroupMasterDAL.FeedbackQuestionGroupMasterId = Convert.ToInt16(SqlRdr["FeedbackQuestionGroupMasterId"]);
                    objFeedbackQuestionGroupMasterDAL.GroupName = Convert.ToString(SqlRdr["GroupName"]);
                    lstFeedbackQuestionGroupMasterDAL.Add(objFeedbackQuestionGroupMasterDAL);
                }
                SqlRdr.Close();
                SqlCon.Close();

                return lstFeedbackQuestionGroupMasterDAL;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion
    }
}
