using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace posLibrary
{
	/// <summary>
	/// Class for posSalesTaxTran
	/// </summary>
	public class posSalesTaxTranDAL
	{
		#region Properties
		public long SalesTaxTranId { get; set; }
		public long linktoSalesMasterId { get; set; }
		public short linktoTaxMasterId { get; set; }
		public string TaxName { get; set; }
		public decimal TaxRate { get; set; }

		/// Extra
        public short TaxIndex { get; set; }
        public double TaxAmount { get; set; }
		#endregion

		#region Class Methods
		private List<posSalesTaxTranDAL> SetListPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
		{
			List<posSalesTaxTranDAL> lstSalesTaxTran = new List<posSalesTaxTranDAL>();
			posSalesTaxTranDAL objSalesTaxTran = null;
			while (sqlRdr.Read())
			{
				objSalesTaxTran = new posSalesTaxTranDAL();
				objSalesTaxTran.SalesTaxTranId = Convert.ToInt64(sqlRdr["SalesTaxTranId"]);
				objSalesTaxTran.linktoSalesMasterId = Convert.ToInt64(sqlRdr["linktoSalesMasterId"]);
				objSalesTaxTran.linktoTaxMasterId = Convert.ToInt16(sqlRdr["linktoTaxMasterId"]);
				objSalesTaxTran.TaxName = Convert.ToString(sqlRdr["TaxName"]);
                objSalesTaxTran.TaxRate = Convert.ToDecimal(sqlRdr["TaxRate"]);
                				
				lstSalesTaxTran.Add(objSalesTaxTran);
			}
			return lstSalesTaxTran;
		}
		#endregion

		#region Insert
        public static posRecordStatus InsertSalesTaxTran(List<posSalesTaxTranDAL> lstSalesTaxTran, long linktoSalesMasterId, SqlConnection SqlCon, SqlTransaction SqlTran)
		{			
			SqlCommand SqlCmd = null;
            posRecordStatus rs = posRecordStatus.Error;
			try
			{				
				SqlCmd = new SqlCommand("posSalesTaxTran_Insert", SqlCon,SqlTran);
				SqlCmd.CommandType = CommandType.StoredProcedure;

                if (lstSalesTaxTran != null || lstSalesTaxTran.Count > 0)
                {
                    foreach (posSalesTaxTranDAL objSalesTaxTranDAL in lstSalesTaxTran)
                    {
                        SqlCmd.Parameters.Clear();
                        SqlCmd.Parameters.Add("@SalesTaxTranId", SqlDbType.BigInt).Direction = ParameterDirection.Output;
                        SqlCmd.Parameters.Add("@linktoSalesMasterId", SqlDbType.BigInt).Value = linktoSalesMasterId;
                        SqlCmd.Parameters.Add("@linktoTaxMasterId", SqlDbType.SmallInt).Value = objSalesTaxTranDAL.linktoTaxMasterId;
                        SqlCmd.Parameters.Add("@TaxName", SqlDbType.VarChar).Value = objSalesTaxTranDAL.TaxName;
                        SqlCmd.Parameters.Add("@TaxRate", SqlDbType.Decimal).Value = objSalesTaxTranDAL.TaxRate;
                        SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                        SqlCmd.ExecuteNonQuery();

                        rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;

                        if (rs != posRecordStatus.Success)
                        {
                            return posRecordStatus.Error;
                        }
                    }
                }
				return rs;
			}
			catch (Exception ex)
			{
				posGlobalsDAL.SaveError(ex);
				return posRecordStatus.Error;
			}
			finally
			{
				posObjectFactoryDAL.DisposeCommand(SqlCmd);				
			}
		}

        public posRecordStatus InsertSalesTaxTran(SqlConnection SqlCon, SqlTransaction SqlTran, short linktoBusinessMasterId)
        {
            SqlCommand SqlCmd = null;
            try
            {
                SqlCmd = new SqlCommand("posSalesTaxTranForKOT_Insert", SqlCon, SqlTran);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@SalesTaxTranId", SqlDbType.BigInt).Direction = ParameterDirection.Output;
                SqlCmd.Parameters.Add("@linktoSalesMasterId", SqlDbType.BigInt).Value = this.linktoSalesMasterId;
                SqlCmd.Parameters.Add("@TaxIndex", SqlDbType.SmallInt).Value = this.TaxIndex;
                SqlCmd.Parameters.Add("@TaxRate", SqlDbType.Decimal).Value = this.TaxRate;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = linktoBusinessMasterId;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCmd.ExecuteNonQuery();

                this.SalesTaxTranId = Convert.ToInt64(SqlCmd.Parameters["@SalesTaxTranId"].Value);
                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
            }
        }
		#endregion		

		#region Delete
        public static posRecordStatus DeleteSalesTaxTran(long linktoSalesMasterId, SqlConnection SqlCon, SqlTransaction SqlTran)
		{			
			SqlCommand SqlCmd = null;
			try
			{				
				SqlCmd = new SqlCommand("posSalesTaxTran_Delete", SqlCon,SqlTran);
				SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@linktoSalesMasterId", SqlDbType.BigInt).Value = linktoSalesMasterId;
				SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

				SqlCmd.ExecuteNonQuery();
				
				posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
				return rs;
			}
			catch (Exception ex)
			{
				posGlobalsDAL.SaveError(ex);
				return posRecordStatus.Error;
			}
			finally
			{
				posObjectFactoryDAL.DisposeCommand(SqlCmd);				
			}
		}
		#endregion

		#region SelectAll

		public List<posSalesTaxTranDAL> SelectAllSalesTaxTranForBill()
		{
			SqlConnection SqlCon = null;
			SqlCommand SqlCmd = null;
			SqlDataReader SqlRdr = null;
			try
			{
				SqlCon = posObjectFactoryDAL.CreateConnection();
				SqlCmd = new SqlCommand("posSalesTaxTranForBill_SelectAll", SqlCon);
				SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@linktoSalesMasterId", SqlDbType.BigInt).Value = this.linktoSalesMasterId;

				SqlCon.Open();
				SqlRdr = SqlCmd.ExecuteReader();
                List<posSalesTaxTranDAL> lstSalesTaxTranDAL = new List<posSalesTaxTranDAL>();
                posSalesTaxTranDAL objSalesTaxTran;
                while (SqlRdr.Read())
                {
                    objSalesTaxTran = new posSalesTaxTranDAL();
                    objSalesTaxTran.TaxName = Convert.ToString(SqlRdr["TaxName"]);
                    objSalesTaxTran.TaxRate = Convert.ToDecimal(SqlRdr["TaxRate"]);
                    objSalesTaxTran.TaxAmount = Convert.ToDouble(SqlRdr["TaxAmount"]);

                    lstSalesTaxTranDAL.Add(objSalesTaxTran);
                }

				SqlRdr.Close();
				SqlCon.Close();

				return lstSalesTaxTranDAL;
			}
			catch (Exception ex)
			{
				posGlobalsDAL.SaveError(ex);
				return null;
			}
			finally
			{
				posObjectFactoryDAL.DisposeDataReader(SqlRdr);
				posObjectFactoryDAL.DisposeCommand(SqlCmd);
				posObjectFactoryDAL.DisposeConnection(SqlCon);
			}
		}
		#endregion
	}
}
