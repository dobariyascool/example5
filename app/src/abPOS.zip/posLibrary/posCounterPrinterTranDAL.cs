using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace posLibrary
{
    /// <summary>
    /// Class for posCounterPrinterTran
    /// </summary>
    public class posCounterPrinterTranDAL
    {
        #region Properties
        public short CounterPrinterTranId { get; set; }
        public string PrinterName { get; set; }
        public short Copy { get; set; }
        public short Size { get; set; }
        public string SizeEnumName { get; set; }
        public bool IsReceiptPrinter { get; set; }
        public short linktoCounterMasterId { get; set; }
        public short? linktoCategoryMasterId { get; set; }

        /// Extra
        public string Counter { get; set; }
        public string Category { get; set; }

        #endregion

        #region Class Methods
        private List<posCounterPrinterTranDAL> SetListPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            List<posCounterPrinterTranDAL> lstCounterPrinterTran = new List<posCounterPrinterTranDAL>();
            posCounterPrinterTranDAL objCounterPrinterTran = null;
            while (sqlRdr.Read())
            {
                objCounterPrinterTran = new posCounterPrinterTranDAL();
                if (sqlRdr["CounterPrinterTranId"] != DBNull.Value)
                {
                    objCounterPrinterTran.CounterPrinterTranId = Convert.ToInt16(sqlRdr["CounterPrinterTranId"]);
                }
                if (sqlRdr["PrinterName"] != DBNull.Value)
                {
                    objCounterPrinterTran.PrinterName = Convert.ToString(sqlRdr["PrinterName"]);
                }
                if (sqlRdr["Copy"] != DBNull.Value)
                {
                    objCounterPrinterTran.Copy = Convert.ToInt16(sqlRdr["Copy"]);
                }
                if (sqlRdr["Size"] != DBNull.Value)
                {
                    List<KeyValuePair<string, string>> lstSize = new List<KeyValuePair<string, string>>();
                    Array Sizes = Enum.GetValues(typeof(posReportPrintSize));

                    foreach (posReportPrintSize s in Sizes)
                    {
                        if (s.GetHashCode() == Convert.ToInt32(sqlRdr["Size"].ToString()))
                        {
                            objCounterPrinterTran.SizeEnumName = s.ToString().Remove(0, 1).Replace('_', ' ');
                        }
                    }
                    objCounterPrinterTran.Size = short.Parse(sqlRdr["Size"].ToString());
                }
                if (sqlRdr["IsReceiptPrinter"] != DBNull.Value)
                {
                    objCounterPrinterTran.IsReceiptPrinter = Convert.ToBoolean(sqlRdr["IsReceiptPrinter"]);
                }
                if (sqlRdr["linktoCounterMasterId"] != DBNull.Value)
                {
                    objCounterPrinterTran.linktoCounterMasterId = Convert.ToInt16(sqlRdr["linktoCounterMasterId"]);
                }
                if (sqlRdr["linktoCategoryMasterId"] != DBNull.Value)
                {
                    objCounterPrinterTran.linktoCategoryMasterId = Convert.ToInt16(sqlRdr["linktoCategoryMasterId"]);
                }

                /// Extra
                if (sqlRdr["CounterName"] != DBNull.Value)
                {
                    objCounterPrinterTran.Counter = Convert.ToString(sqlRdr["CounterName"]);
                }
                if (sqlRdr["CategoryName"] != DBNull.Value)
                {
                    objCounterPrinterTran.Category = Convert.ToString(sqlRdr["CategoryName"]);
                }
                lstCounterPrinterTran.Add(objCounterPrinterTran);
            }
            return lstCounterPrinterTran;
        }
        #endregion

        #region Insert
        public posRecordStatus InsertCounterPrinterTran()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posCounterPrinterTran_Insert", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@CounterPrinterTranId", SqlDbType.SmallInt).Direction = ParameterDirection.Output;
                SqlCmd.Parameters.Add("@PrinterName", SqlDbType.VarChar).Value = this.PrinterName;
                SqlCmd.Parameters.Add("@Copy", SqlDbType.SmallInt).Value = this.Copy;
                SqlCmd.Parameters.Add("@Size", SqlDbType.SmallInt).Value = this.Size;
                SqlCmd.Parameters.Add("@IsReceiptPrinter", SqlDbType.Bit).Value = this.IsReceiptPrinter;
                SqlCmd.Parameters.Add("@linktoCounterMasterId", SqlDbType.SmallInt).Value = this.linktoCounterMasterId;
                if (IsReceiptPrinter == false)
                {
                    SqlCmd.Parameters.Add("@linktoCategoryMasterId", SqlDbType.SmallInt).Value = this.linktoCategoryMasterId;
                }
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                this.CounterPrinterTranId = Convert.ToInt16(SqlCmd.Parameters["@CounterPrinterTranId"].Value);
                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region Update
        public posRecordStatus UpdateCounterPrinterTran()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posCounterPrinterTran_Update", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@CounterPrinterTranId", SqlDbType.SmallInt).Value = this.CounterPrinterTranId;
                SqlCmd.Parameters.Add("@PrinterName", SqlDbType.VarChar).Value = this.PrinterName;
                SqlCmd.Parameters.Add("@Copy", SqlDbType.SmallInt).Value = this.Copy;
                SqlCmd.Parameters.Add("@Size", SqlDbType.SmallInt).Value = this.Size;
                SqlCmd.Parameters.Add("@IsReceiptPrinter", SqlDbType.Bit).Value = this.IsReceiptPrinter;
                SqlCmd.Parameters.Add("@linktoCounterMasterId", SqlDbType.SmallInt).Value = this.linktoCounterMasterId;
                SqlCmd.Parameters.Add("@linktoCategoryMasterId", SqlDbType.SmallInt).Value = this.linktoCategoryMasterId;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region DeleteAll
        public posRecordStatus DeleteCounterPrinterTranDAL()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("CounterPrinterTran_Delete", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@CounterPrinterTranId", SqlDbType.SmallInt).Value = this.CounterPrinterTranId;

                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region SelectAll
        public List<posCounterPrinterTranDAL> SelectAllCounterPrinterTran(short linktoUserMasterId)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posCounterPrinterTran_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@IsReceiptPrinter", SqlDbType.Bit).Value = this.IsReceiptPrinter;
                SqlCmd.Parameters.Add("@linktoUserMasterId", SqlDbType.SmallInt).Value = linktoUserMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<posCounterPrinterTranDAL> lstCounterPrinterTranDAL = SetListPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                return lstCounterPrinterTranDAL;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public List<posCounterPrinterTranDAL> SelectAllCounterPrinterTranByCounter()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posCounterPrinterTranByCounter_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@IsReceiptPrinter", SqlDbType.Bit).Value = this.IsReceiptPrinter;
                SqlCmd.Parameters.Add("@linktoCounterMasterId", SqlDbType.SmallInt).Value = this.linktoCounterMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<posCounterPrinterTranDAL> lstCounterPrinterTranDAL = SetListPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                return lstCounterPrinterTranDAL;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion
    }
}
