using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace posLibrary
{
    /// <summary>
    /// Class for posItemModifierTran
    /// </summary>
    public class posItemModifierTranDAL
    {
        #region Properties
        public int ItemModifierTranId { get; set; }
        public int linktoItemMasterId { get; set; }
        public int linktoItemMasterModifierId { get; set; }

        /// Extra
        public int ItemMasterId { get; set; }
        public string ShortName { get; set; }
        public string ModifierName { get; set; }
        public string Description { get; set; }
        public double ModifierRate { get; set; }
        public bool IsSelected { get; set; }
        #endregion

        #region Class Methods
        private List<posItemModifierTranDAL> SetListPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            List<posItemModifierTranDAL> lstItemModifierTran = new List<posItemModifierTranDAL>();
            posItemModifierTranDAL objItemModifierTran = null;
            while (sqlRdr.Read())
            {
                objItemModifierTran = new posItemModifierTranDAL();

                if (sqlRdr["ItemModifierTranId"] != DBNull.Value)
                {
                    objItemModifierTran.ItemModifierTranId = Convert.ToInt32(sqlRdr["ItemModifierTranId"]);
                }

                if (sqlRdr["linktoItemMasterId"] != DBNull.Value)
                {
                    objItemModifierTran.linktoItemMasterId = Convert.ToInt32(sqlRdr["linktoItemMasterId"]);
                    objItemModifierTran.IsSelected = true;
                }
                if (sqlRdr["linktoItemMasterModifierId"] != DBNull.Value)
                {
                    objItemModifierTran.linktoItemMasterModifierId = Convert.ToInt32(sqlRdr["linktoItemMasterModifierId"]);
                }

                /// Extra
                objItemModifierTran.ItemMasterId = Convert.ToInt32(sqlRdr["ItemMasterId"]);
                objItemModifierTran.ShortName = Convert.ToString(sqlRdr["ShortName"]);
                objItemModifierTran.ModifierName = Convert.ToString(sqlRdr["ItemName"]);
                objItemModifierTran.Description = Convert.ToString(sqlRdr["ShortDescription"]);
                objItemModifierTran.ModifierRate = Convert.ToDouble(sqlRdr["MRP"]);
                //  objItemModifierTran.ItemType = Convert.ToInt16(sqlRdr["ItemType"]);

                lstItemModifierTran.Add(objItemModifierTran);
            }
            return lstItemModifierTran;
        }
        #endregion

        #region Insert
        public static posRecordStatus InsertItemModifierTran(string itemModifierTranIds, int ItemMasterId, SqlConnection SqlCon, SqlTransaction SqlTran)
        {
            //SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCmd = new SqlCommand("posItemModifierTran_Insert", SqlCon, SqlTran);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@ItemModifierMasterIds", SqlDbType.VarChar).Value = itemModifierTranIds;
                SqlCmd.Parameters.Add("@ItemMasterId", SqlDbType.Int).Value = ItemMasterId;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCmd.ExecuteNonQuery();

                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                //posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region SelectAll
        public List<posItemModifierTranDAL> SelectAllItemModifierTran(short linktoBusinessMasterId)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posItemModifierTran_SelectAll", SqlCon);
                SqlCmd.Parameters.Add("@linktoItemMasterId", SqlDbType.Int).Value = linktoItemMasterId;
                SqlCmd.Parameters.Add("@ItemType", SqlDbType.SmallInt).Value = short.Parse(posItemType.Modifier.GetHashCode().ToString());
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = linktoBusinessMasterId;
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<posItemModifierTranDAL> lstItemModifierTranDAL = SetListPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                return lstItemModifierTranDAL;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion
    }
}
