using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace posLibrary
{
	/// <summary>
	/// Class for posAppThemeMaster
	/// </summary>
	public class posAppThemeMasterDAL
	{
		#region Properties
		public int AppThemeMasterId { get; set; }
		public string LogoImageName { get; set; }
		public string ProfileImageName { get; set; }
		public string BackImageName1 { get; set; }
		public string BackImageName2 { get; set; }
        public string WelcomeBackImage { get; set; }
		public string ContactMap { get; set; }
		public string ColorPrimary { get; set; }
		public string ColorPrimaryDark { get; set; }
		public string ColorPrimaryLight { get; set; }
		public string ColorAccent { get; set; }
		public string ColorAccentDark { get; set; }
		public string ColorAccentLight { get; set; }
		public string ColorTextPrimary { get; set; }
        public string ColorFloatingButton { get; set; }
		public string ColorButtonRipple { get; set; }
		public string ColorCardView { get; set; }
		public string ColorCardViewRipple { get; set; }
		public string ColorCardText { get; set; }
		public string ColorHeaderText { get; set; }
        public int linktoBusinessMasterId { get; set; }

		#endregion

		#region Class Methods
		private bool SetClassPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
		{
			string ImageRetrievePath = System.Configuration.ConfigurationManager.AppSettings["ImageRetrievePath"] + "AppTheme\\";
			if (sqlRdr.Read())
			{
				this.AppThemeMasterId = Convert.ToInt32(sqlRdr["AppThemeMasterId"]);
				this.LogoImageName = Convert.ToString(sqlRdr["LogoImageName"]);
				this.ProfileImageName = Convert.ToString(sqlRdr["ProfileImageName"]);
				this.BackImageName1 = Convert.ToString(sqlRdr["BackImageName1"]);
				this.BackImageName2 = Convert.ToString(sqlRdr["BackImageName2"]);
                this.WelcomeBackImage = Convert.ToString(sqlRdr["WelcomeBackImage"]);
				this.ContactMap = Convert.ToString(sqlRdr["ContactMap"]);
				this.ColorPrimary = Convert.ToString(sqlRdr["ColorPrimary"]);
				this.ColorPrimaryDark = Convert.ToString(sqlRdr["ColorPrimaryDark"]);
				this.ColorPrimaryLight = Convert.ToString(sqlRdr["ColorPrimaryLight"]);
				this.ColorAccent = Convert.ToString(sqlRdr["ColorAccent"]);
				this.ColorAccentDark = Convert.ToString(sqlRdr["ColorAccentDark"]);
				this.ColorAccentLight = Convert.ToString(sqlRdr["ColorAccentLight"]);
				this.ColorTextPrimary = Convert.ToString(sqlRdr["ColorTextPrimary"]);
                this.ColorFloatingButton = Convert.ToString(sqlRdr["ColorFloatingButton"]);
				this.ColorButtonRipple = Convert.ToString(sqlRdr["ColorButtonRipple"]);
				this.ColorCardView = Convert.ToString(sqlRdr["ColorCardView"]);
				this.ColorCardViewRipple = Convert.ToString(sqlRdr["ColorCardViewRipple"]);
				this.ColorCardText = Convert.ToString(sqlRdr["ColorCardText"]);
				this.ColorHeaderText = Convert.ToString(sqlRdr["ColorHeaderText"]);
                this.linktoBusinessMasterId = Convert.ToInt32(sqlRdr["linktoBusinessMasterId"]);
				/// Extra
				return true;
			}
			return false;
		}

		private List<posAppThemeMasterDAL> SetListPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
		{
			string ImageRetrievePath = System.Configuration.ConfigurationManager.AppSettings["ImageRetrievePath"] + "AppTheme\\";
			List<posAppThemeMasterDAL> lstAppThemeMaster = new List<posAppThemeMasterDAL>();
			posAppThemeMasterDAL objAppThemeMaster = null;
			while (sqlRdr.Read())
			{
				objAppThemeMaster = new posAppThemeMasterDAL();
				objAppThemeMaster.AppThemeMasterId = Convert.ToInt32(sqlRdr["AppThemeMasterId"]);
				objAppThemeMaster.LogoImageName = Convert.ToString(sqlRdr["LogoImageName"]);
				objAppThemeMaster.ProfileImageName = Convert.ToString(sqlRdr["ProfileImageName"]);
				objAppThemeMaster.BackImageName1 = Convert.ToString(sqlRdr["BackImageName1"]);
				objAppThemeMaster.BackImageName2 = Convert.ToString(sqlRdr["BackImageName2"]);
                objAppThemeMaster.WelcomeBackImage = Convert.ToString(sqlRdr["WelcomeBackImage"]); 
                objAppThemeMaster.ContactMap = Convert.ToString(sqlRdr["ContactMap"]);
				objAppThemeMaster.ColorPrimary = Convert.ToString(sqlRdr["ColorPrimary"]);
				objAppThemeMaster.ColorPrimaryDark = Convert.ToString(sqlRdr["ColorPrimaryDark"]);
				objAppThemeMaster.ColorPrimaryLight = Convert.ToString(sqlRdr["ColorPrimaryLight"]);
				objAppThemeMaster.ColorAccent = Convert.ToString(sqlRdr["ColorAccent"]);
				objAppThemeMaster.ColorAccentDark = Convert.ToString(sqlRdr["ColorAccentDark"]);
				objAppThemeMaster.ColorAccentLight = Convert.ToString(sqlRdr["ColorAccentLight"]);
				objAppThemeMaster.ColorTextPrimary = Convert.ToString(sqlRdr["ColorTextPrimary"]);
                objAppThemeMaster.ColorFloatingButton = Convert.ToString(sqlRdr["ColorFloatingButton"]);
				objAppThemeMaster.ColorButtonRipple = Convert.ToString(sqlRdr["ColorButtonRipple"]);
				objAppThemeMaster.ColorCardView = Convert.ToString(sqlRdr["ColorCardView"]);
				objAppThemeMaster.ColorCardViewRipple = Convert.ToString(sqlRdr["ColorCardViewRipple"]);
				objAppThemeMaster.ColorCardText = Convert.ToString(sqlRdr["ColorCardText"]);
				objAppThemeMaster.ColorHeaderText = Convert.ToString(sqlRdr["ColorHeaderText"]);
                objAppThemeMaster.linktoBusinessMasterId = Convert.ToInt32(sqlRdr["linktoBusinessMasterId"]);
				/// Extra
				lstAppThemeMaster.Add(objAppThemeMaster);
			}
			return lstAppThemeMaster;
		}
		#endregion

		#region Select
		public bool SelectAppThemeMaster()
		{
			SqlConnection SqlCon = null;
			SqlCommand SqlCmd = null;
			SqlDataReader SqlRdr = null;
			try
			{
				SqlCon = posObjectFactoryDAL.CreateConnection();
				SqlCmd = new SqlCommand("posAppThemeMaster_Select", SqlCon);
				SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.Int).Value = this.linktoBusinessMasterId;

				SqlCon.Open();
				SqlRdr = SqlCmd.ExecuteReader();
				bool IsSelected = SetClassPropertiesFromSqlDataReader(SqlRdr);
				SqlRdr.Close();
				SqlCon.Close();

				return IsSelected;
			}
			catch (Exception ex)
			{
				posGlobalsDAL.SaveError(ex);
				return false;
			}
			finally
			{
				posObjectFactoryDAL.DisposeDataReader(SqlRdr);
				posObjectFactoryDAL.DisposeCommand(SqlCmd);
				posObjectFactoryDAL.DisposeConnection(SqlCon);
			}
		}
		#endregion

		#region SelectAll
		public List<posAppThemeMasterDAL> SelectAllAppThemeMaster()
		{
			SqlConnection SqlCon = null;
			SqlCommand SqlCmd = null;
			SqlDataReader SqlRdr = null;
			try
			{
				SqlCon = posObjectFactoryDAL.CreateConnection();
				SqlCmd = new SqlCommand("posAppThemeMaster_SelectAll", SqlCon);
				SqlCmd.CommandType = CommandType.StoredProcedure;

				SqlCon.Open();
				SqlRdr = SqlCmd.ExecuteReader();
				List<posAppThemeMasterDAL> lstAppThemeMasterDAL = SetListPropertiesFromSqlDataReader(SqlRdr);
				SqlRdr.Close();
				SqlCon.Close();

				return lstAppThemeMasterDAL;
			}
			catch (Exception ex)
			{
				posGlobalsDAL.SaveError(ex);
				return null;
			}
			finally
			{
				posObjectFactoryDAL.DisposeDataReader(SqlRdr);
				posObjectFactoryDAL.DisposeCommand(SqlCmd);
				posObjectFactoryDAL.DisposeConnection(SqlCon);
			}
		}
		#endregion
	}
}
