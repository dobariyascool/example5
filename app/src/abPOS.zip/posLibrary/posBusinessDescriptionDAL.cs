using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace posLibrary
{
    /// <summary>
    /// Class for posBusinessDescription
    /// </summary>
    public class posBusinessDescriptionDAL
    {
        #region Properties
        public short BusinessDescriptionId { get; set; }
        public string Title { get; set; }
        public string Description { get; set; }
        public short linktoBusinessMasterId { get; set; }
        public bool IsDefault { get; set; }
        public short linktoUserMasterIdCreatedBy { get; set; }
        public DateTime CreateDateTime { get; set; }
        public short? linktoUserMasterIdUpdatedBy { get; set; }
        public DateTime? UpdateDateTime { get; set; }
        #endregion

        #region Class Methods
        private bool SetClassPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            if (sqlRdr.Read())
            {
                this.BusinessDescriptionId = Convert.ToInt16(sqlRdr["BusinessDescriptionId"]);
                this.Title = Convert.ToString(sqlRdr["Title"]);
                this.Description = Convert.ToString(sqlRdr["Description"]);
                this.linktoBusinessMasterId = Convert.ToInt16(sqlRdr["linktoBusinessMasterId"]);
                this.IsDefault = Convert.ToBoolean(sqlRdr["IsDefault"]);
                this.linktoUserMasterIdCreatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdCreatedBy"]);
                this.CreateDateTime = Convert.ToDateTime(sqlRdr["CreateDateTime"]);
                if (sqlRdr["linktoUserMasterIdUpdatedBy"] != DBNull.Value)
                {
                    this.linktoUserMasterIdUpdatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdUpdatedBy"]);
                }
                if (sqlRdr["UpdateDateTime"] != DBNull.Value)
                {
                    this.UpdateDateTime = Convert.ToDateTime(sqlRdr["UpdateDateTime"]);
                }
                return true;
            }
            return false;
        }

        private List<posBusinessDescriptionDAL> SetListPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            List<posBusinessDescriptionDAL> lstBusinessDescription = new List<posBusinessDescriptionDAL>();
            posBusinessDescriptionDAL objBusinessDescription = null;
            while (sqlRdr.Read())
            {
                objBusinessDescription = new posBusinessDescriptionDAL();
                objBusinessDescription.BusinessDescriptionId = Convert.ToInt16(sqlRdr["BusinessDescriptionId"]);
                objBusinessDescription.Title = Convert.ToString(sqlRdr["Title"]);
                objBusinessDescription.Description = Convert.ToString(sqlRdr["Description"]);
                objBusinessDescription.linktoBusinessMasterId = Convert.ToInt16(sqlRdr["linktoBusinessMasterId"]);
                objBusinessDescription.IsDefault = Convert.ToBoolean(sqlRdr["IsDefault"]);
                objBusinessDescription.linktoUserMasterIdCreatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdCreatedBy"]);
                objBusinessDescription.CreateDateTime = Convert.ToDateTime(sqlRdr["CreateDateTime"]);
                if (sqlRdr["linktoUserMasterIdUpdatedBy"] != DBNull.Value)
                {
                    objBusinessDescription.linktoUserMasterIdUpdatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdUpdatedBy"]);
                }
                if (sqlRdr["UpdateDateTime"] != DBNull.Value)
                {
                    objBusinessDescription.UpdateDateTime = Convert.ToDateTime(sqlRdr["UpdateDateTime"]);
                }

                lstBusinessDescription.Add(objBusinessDescription);
            }
            return lstBusinessDescription;
        }
        #endregion

        #region Insert
        public posRecordStatus InsertBusinessDescription()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posBusinessDescription_Insert", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@BusinessDescriptionId", SqlDbType.SmallInt).Direction = ParameterDirection.Output;
                SqlCmd.Parameters.Add("@Title", SqlDbType.VarChar).Value = this.Title;
                SqlCmd.Parameters.Add("@Description", SqlDbType.VarChar).Value = this.Description;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCmd.Parameters.Add("@IsDefault", SqlDbType.Bit).Value = this.IsDefault;
                SqlCmd.Parameters.Add("@linktoUserMasterIdCreatedBy", SqlDbType.SmallInt).Value = this.linktoUserMasterIdCreatedBy;
                SqlCmd.Parameters.Add("@CreateDateTime", SqlDbType.DateTime).Value = this.CreateDateTime;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                this.BusinessDescriptionId = Convert.ToInt16(SqlCmd.Parameters["@BusinessDescriptionId"].Value);
                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region Update
        public posRecordStatus UpdateBusinessDescription()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posBusinessDescription_Update", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@BusinessDescriptionId", SqlDbType.SmallInt).Value = this.BusinessDescriptionId;
                SqlCmd.Parameters.Add("@Title", SqlDbType.VarChar).Value = this.Title;
                SqlCmd.Parameters.Add("@Description", SqlDbType.VarChar).Value = this.Description;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCmd.Parameters.Add("@linktoUserMasterIdUpdatedBy", SqlDbType.SmallInt).Value = this.linktoUserMasterIdUpdatedBy;
                SqlCmd.Parameters.Add("@UpdateDateTime", SqlDbType.DateTime).Value = this.UpdateDateTime;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region DeleteAll
        public posRecordStatus DeleteAllBusinessDescription(string businessDescriptionIds)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posBusinessDescription_DeleteAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@BusinessDescriptionIds", SqlDbType.VarChar).Value = businessDescriptionIds;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region Select
        public bool SelectBusinessDescription()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posBusinessDescription_Select", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                if (BusinessDescriptionId > 0)
                {
                    SqlCmd.Parameters.Add("@BusinessDescriptionId", SqlDbType.SmallInt).Value = this.BusinessDescriptionId;
                }
                if (Title != null)
                {
                    SqlCmd.Parameters.Add("@Title", SqlDbType.VarChar).Value = this.Title;
                }
                if (linktoBusinessMasterId > 0)
                {
                    SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                }

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                bool IsSelected = SetClassPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                return IsSelected;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return false;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region SelectAll
        public List<posBusinessDescriptionDAL> SelectAllBusinessDescription()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posBusinessDescription_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<posBusinessDescriptionDAL> lstBusinessDescriptionDAL = SetListPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                return lstBusinessDescriptionDAL;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion
    }
}
