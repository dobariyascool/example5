using System;
using System.Data;
using System.Data.SqlClient;
using System.Collections.Generic;

namespace posLibrary
{
    /// <summary>
    /// Class for posOfferCodesTran
    /// </summary>
    public class posOfferCodesTranDAL
    {
        #region Properties
        public long OfferCodesTranId { get; set; }
        public int? linktoOfferMasterId { get; set; }
        public string OfferCode { get; set; }
        public int? linktoCustomerMasterId { get; set; }
        public int? linktoItemMasterId { get; set; }
        public DateTime CreateDateTime { get; set; }
        public short linktoUserMasterIdCreatedBy { get; set; }
        public DateTime? RedeemDateTime { get; set; }
        public int? linktoUserMasterIdRedeemedBy { get; set; }
        public short? linktoSourceMasterId { get; set; }

        /// Extra
        public string Offer { get; set; }
        public string RegistredUser { get; set; }
        public string Item { get; set; }
        public string Source { get; set; }
        #endregion

        #region Insert
        public posRecordStatus InsertOfferCodesTran(SqlConnection SqlCon, SqlTransaction SqlTran)
        {
            SqlCommand SqlCmd = null;
            try
            {
                SqlCmd = new SqlCommand("posOfferCodesTran_Insert", SqlCon,SqlTran);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@OfferCodesTranId", SqlDbType.BigInt).Direction = ParameterDirection.Output;
                SqlCmd.Parameters.Add("@linktoOfferMasterId", SqlDbType.Int).Value = this.linktoOfferMasterId;
                SqlCmd.Parameters.Add("@OfferCode", SqlDbType.VarChar).Value = this.OfferCode;
                SqlCmd.Parameters.Add("@linktoCustomerMasterId", SqlDbType.Int).Value = this.linktoCustomerMasterId;
                SqlCmd.Parameters.Add("@linktoItemMasterId", SqlDbType.Int).Value = this.linktoItemMasterId;
                SqlCmd.Parameters.Add("@CreateDateTime", SqlDbType.DateTime).Value = this.CreateDateTime;
                SqlCmd.Parameters.Add("@linktoUserMasterIdCreatedBy", SqlDbType.SmallInt).Value = this.linktoUserMasterIdCreatedBy;
                SqlCmd.Parameters.Add("@RedeemDateTime", SqlDbType.DateTime).Value = this.RedeemDateTime;
                SqlCmd.Parameters.Add("@linktoUserMasterIdRedeemedBy", SqlDbType.Int).Value = this.linktoUserMasterIdRedeemedBy;
                SqlCmd.Parameters.Add("@linktoSourceMasterId", SqlDbType.SmallInt).Value = this.linktoSourceMasterId;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCmd.ExecuteNonQuery();

                this.OfferCodesTranId = Convert.ToInt64(SqlCmd.Parameters["@OfferCodesTranId"].Value);
                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
            }
        }
        #endregion    

        #region Delete
        public posRecordStatus DeleteOfferCodesTran(SqlConnection SqlCon, SqlTransaction SqlTran)
        {
            SqlCommand SqlCmd = null;
            try
            {               
                SqlCmd = new SqlCommand("posOfferCodesTran_Delete", SqlCon,SqlTran);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@linktoOfferMasterId", SqlDbType.SmallInt).Value = this.linktoOfferMasterId;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCmd.ExecuteNonQuery();
     
                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                //posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion      

        #region Select
        public bool SelectOfferCodesTranByOfferCode(string offerCode)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posOfferCodesTranByOfferCode_Select", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@OfferCode", SqlDbType.VarChar).Value = offerCode;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                bool IsSelected = false;
                while (SqlRdr.Read())
                {
                    this.OfferCode = Convert.ToString(SqlRdr["OfferCode"]);
                    if (!string.IsNullOrEmpty(this.OfferCode))
                    {
                        IsSelected = true;
                    }
                }
                SqlRdr.Close();
                SqlCon.Close();

                return IsSelected;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return false;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion
    }
}
