﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Drawing.Printing;

namespace posLibrary
{
    public class posReport
    {
        #region Properties
        public posReportHeader objReportHeader { get; set; }
        public posReportSettings objReportSettings { get; set; }

        public List<posTableMasterDAL> lstTableMasterDAL { get; set; }
        public List<posOrderItemTranDAL> lstposOrderItemTranDAL { get; set; }
        public List<posOrderItemTranDAL> lstposOrderItemTranDALHeader { get; set; }
        public List<posSalesPaymentTranDAL> lstSalesPaymentTranDAL { get; set; }
        public List<posPurchaseMasterDAL> lstPurchaseMasterDAL { get; set; }
        public List<posSalesMasterDAL> lstSalesMasterDAL { get; set; }
        public List<posItemStockTranDAL> lstItemStockTranDAL { get; set; }
        public List<posSalesItemTranDAL> lstSalesItemTranDAL { get; set; }
        public List<posItemMasterDAL> lstItemMasterDAL { get; set; }
        public List<posCustomerMasterDAL> lstCustomerMasterDAL { get; set; }
        public List<posIssueItemMasterDAL> lstIssueItemMasterDAL { get; set; }
        public List<posSalesItemTranDAL> lstposSalesItemTranDAL { get; set; }
        public List<posSalesItemTranDAL> lstposSalesItemTranDALHeader { get; set; }
        #endregion

        #region Private Methods
        public static posReportSettings GetSettings()
        {
            posReportSettings objReportSettings;
            //labPropertyMasterDAL objPropertyMasterDAL;
            try
            {
                objReportSettings = new posReportSettings();
                objReportSettings.Margin_Left = 0;//Convert.ToDecimal(posGlobalsDAL.GetSetting(posSetting.MARGIN_LEFT));
                objReportSettings.Margin_Right = 0;//Convert.ToDecimal(posGlobalsDAL.GetSetting(posSetting.MARGIN_RIGHT));
                objReportSettings.Margin_Top = 0;//Convert.ToDecimal(posGlobalsDAL.GetSetting(posSetting.MARGIN_TOP));
                objReportSettings.Margin_Bottom = 0;//Convert.ToDecimal(posGlobalsDAL.GetSetting(posSetting.MARGIN_BOTTOM));
                objReportSettings.PrinterName = new PrinterSettings().PrinterName;//posGlobalsDAL.GetSetting(posSetting.DEFAULT_PRINTER);
                objReportSettings.PageSize = "A4";//posGlobalsDAL.GetSetting(posSetting.PAGE_SIZE);
                objReportSettings.NumberOfCopies = 1;// posGlobalsDAL.GetSetting(posSetting.NUMBER_OF_COPIES);
                //objReportSettings.HeaderAlign = posGlobalsDAL.GetSetting(posSetting.HEADER_ALIGN);
                //if (Convert.ToBoolean(posGlobalsDAL.GetSetting(posSetting.SHOW_LOGO)))
                {
                    posGlobalsDAL.LoginNetwork();

                    //objPropertyMasterDAL = new labPropertyMasterDAL();
                    //objPropertyMasterDAL.PropertyMasterId = 1; /// DEFAULT 1
                    //objPropertyMasterDAL.SelectPropertyMaster();

                    //objReportSettings.Logo = "file:\\\\\\D:\\PROJECTS\\Web\\abPOS\\abPOS\\bin\\Debug\\Logo\\Logo.jpg";    // @"file:\\\\" + "D:\\PROJECTS\\Web\\abPOS\\abPOS\\bin\\Debug\\Logo\\Logo.jpg"; 
                    // file:\\\\\\D:\\PROJECTS\\Web\\abPOS\\abPOS\\bin\\Debug\\Logo\\ArrayBit Logo White.jpg
                    //objReportSettings.Logo = @"file:\\\" + objPropertyMasterDAL.LogoImageName;
                }
                //objReportSettings.ShowLogo = Convert.ToBoolean(posGlobalsDAL.GetSetting(posSetting.SHOW_LOGO));
                //objReportSettings.ShowPrintHeader = Convert.ToBoolean(posGlobalsDAL.GetSetting(posSetting.SHOW_PRINT_HEADER));
                //objReportSettings.ShowPrintPreview = Convert.ToBoolean(posGlobalsDAL.GetSetting(posSetting.SHOW_PRINT_PREVIEW));
                //objReportSettings.HeaderLine1 = posGlobalsDAL.GetSetting(posSetting.HEADER_LINE1);
                //objReportSettings.HeaderLine2 = posGlobalsDAL.GetSetting(posSetting.HEADER_LINE2);
                //objReportSettings.Headerline3 = posGlobalsDAL.GetSetting(posSetting.HEADER_LINE3);
                //objReportSettings.Leftfooterline1 = posGlobalsDAL.GetSetting(posSetting.LEFT_FOOTER_LINE1);
                //objReportSettings.Leftfooterline2 = posGlobalsDAL.GetSetting(posSetting.LEFT_FOOTER_LINE2);
                //objReportSettings.Leftfooterline3 = posGlobalsDAL.GetSetting(posSetting.LEFT_FOOTER_LINE3);
                //objReportSettings.Centerfooterline1 = posGlobalsDAL.GetSetting(posSetting.CENTER_FOOTER_LINE1);
                //objReportSettings.Centerfooterline2 = posGlobalsDAL.GetSetting(posSetting.CENTER_FOOTER_LINE2);
                //objReportSettings.Centerfooterline3 = posGlobalsDAL.GetSetting(posSetting.CENTER_FOOTER_LINE3);
                //objReportSettings.Rightfooterline1 = posGlobalsDAL.GetSetting(posSetting.RIGHT_FOOTER_LINE1);
                //objReportSettings.Rightfooterline2 = posGlobalsDAL.GetSetting(posSetting.RIGHT_FOOTER_LINE2);
                //objReportSettings.Rightfooterline3 = posGlobalsDAL.GetSetting(posSetting.RIGHT_FOOTER_LINE3);
                //objReportSettings.Summaryline1 = posGlobalsDAL.GetSetting(posSetting.SUMMARY_LINE1);
                //objReportSettings.Summaryline2 = posGlobalsDAL.GetSetting(posSetting.SUMMARY_LINE2);
                //objReportSettings.Summaryline3 = posGlobalsDAL.GetSetting(posSetting.SUMMARY_LINE3);
                //objReportSettings.IsPrint = Convert.ToBoolean(posGlobalsDAL.GetSetting(posSetting.IS_PRINT));
                //objReportSettings.IsMail = Convert.ToBoolean(posGlobalsDAL.GetSetting(posSetting.IS_MAIL));
                //objReportSettings.IsSMS = Convert.ToBoolean(posGlobalsDAL.GetSetting(posSetting.IS_SMS));
                //objReportSettings.IsEnableSSL = Convert.ToBoolean(posGlobalsDAL.GetSetting(posSetting.IS_ENABLE_SSL));
                //objReportSettings.HostName = posGlobalsDAL.GetSetting(posSetting.HOST);
                //objReportSettings.HostPort = posGlobalsDAL.GetSetting(posSetting.HOST_PORT);
                //objReportSettings.HostPassword = posGlobalsDAL.GetSetting(posSetting.HOST_PASSWORD);
                //objReportSettings.HostEmail = posGlobalsDAL.GetSetting(posSetting.HOST_EMAIL);
                //objReportSettings.SenderId = posGlobalsDAL.GetSetting(posSetting.SENDER_ID);
                //objReportSettings.SenderPort = posGlobalsDAL.GetSetting(posSetting.SENDER_PORT);
                //objReportSettings.SenderUserName = posGlobalsDAL.GetSetting(posSetting.SENDER_USERNAME);
                //objReportSettings.SenderPassword = posGlobalsDAL.GetSetting(posSetting.SENDER_PASSWORD);
                //objReportSettings.IsHeaderLine1Bold = Convert.ToBoolean(posGlobalsDAL.GetSetting(posSetting.IS_HEADER_LINE1_BOLD));
                //objReportSettings.IsHeaderOtherLineBold = Convert.ToBoolean(posGlobalsDAL.GetSetting(posSetting.IS_HEADER_OTHER_LINE_BOLD));
                //objReportSettings.IsHeaderLine1Italic = Convert.ToBoolean(posGlobalsDAL.GetSetting(posSetting.IS_HEADER_LINE1_ITALIC));
                //objReportSettings.IsHeaderOtherLineItalic = Convert.ToBoolean(posGlobalsDAL.GetSetting(posSetting.IS_HEADER_OTHER_LINE_ITALIC));
                //objReportSettings.IsHeaderLine1Underline = Convert.ToBoolean(posGlobalsDAL.GetSetting(posSetting.IS_HEADER_LINE1_UNDERLINE));
                //objReportSettings.IsHeaderOtherLineUnderline = Convert.ToBoolean(posGlobalsDAL.GetSetting(posSetting.IS_HEADER_OTHER_LINE_UNDERLINE));
                //objReportSettings.IsContentBold = Convert.ToBoolean(posGlobalsDAL.GetSetting(posSetting.IS_CONTENT_BOLD));
                //objReportSettings.IsContentItalic = Convert.ToBoolean(posGlobalsDAL.GetSetting(posSetting.IS_CONTENT_ITALIC));
                //objReportSettings.IsContentUnderline = Convert.ToBoolean(posGlobalsDAL.GetSetting(posSetting.IS_CONTENT_UNDERLINE));
                //objReportSettings.HeaderLine1Font = posGlobalsDAL.GetSetting(posSetting.HEADER_LINE1_FONT);
                //objReportSettings.HeaderOtherFont = posGlobalsDAL.GetSetting(posSetting.HEADER_OTHER_FONT);
                //objReportSettings.ContentFont = posGlobalsDAL.GetSetting(posSetting.CONTENT_FONT);
                //objReportSettings.FooterFont = posGlobalsDAL.GetSetting(posSetting.FOOTER_FONT);
                //objReportSettings.HeaderLine1Color = posGlobalsDAL.GetSetting(posSetting.HEADER_LINE1_COLOR);
                //objReportSettings.ContentColor = posGlobalsDAL.GetSetting(posSetting.CONTENT_COLOR);
                //objReportSettings.HeaderOtherColor = posGlobalsDAL.GetSetting(posSetting.HEADER_OTHER_COLOR);
                return objReportSettings;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                //objPropertyMasterDAL = null;
            }
        }
        #endregion
    }

    public class posReportHeader
    {
        #region Properties
        public string BusinessName { get; set; }
        public string Logo { get; set; }
        public string HeaderText { get; set; }
        public string FooterText { get; set; }

        public DateTime DateFrom { get; set; }
        public DateTime DateTo { get; set; }
        public string Title { get; set; }
        public string PrintedBy { get; set; }
        public string Name { get; set; }
        public List<posReportSettings> lstReportSettings { get; set; }
        #endregion
    }

    public class posReportSettings
    {
        #region Properties
        //private int PageWidth { get; set; }
        //private int PageHeight { get; set; }

        public bool ShowLogo { get; set; }
        //public bool ShowPrintHeader { get; set; }
        public bool ShowPrintPreview { get; set; }
        //public bool IsPrint { get; set; }
        //public bool IsMail { get; set; }
        //public bool IsSMS { get; set; }
        //public bool IsEnableSSL { get; set; }

        //public bool IsHeaderLine1Bold { get; set; }
        //public bool IsHeaderOtherLineBold { get; set; }
        //public bool IsHeaderLine1Italic { get; set; }
        //public bool IsHeaderOtherLineItalic { get; set; }
        //public bool IsHeaderLine1Underline { get; set; }
        //public bool IsHeaderOtherLineUnderline { get; set; }
        //public bool IsContentBold { get; set; }
        //public bool IsContentItalic { get; set; }
        //public bool IsContentUnderline { get; set; }

        public decimal Margin_Top { get; set; }
        public decimal Margin_Bottom { get; set; }
        public decimal Margin_Left { get; set; }
        public decimal Margin_Right { get; set; }

        public string PrinterName { get; set; }
        public string PageSize { get; set; }
        public short NumberOfCopies { get; set; }
        //public string Logo { get; set; }
        //public string HeaderAlign { get; set; }
        //public string HeaderLine1 { get; set; }
        //public string HeaderLine2 { get; set; }
        //public string Headerline3 { get; set; }
        //public string FooterMessage { get; set; }
        //public string Leftfooterline1 { get; set; }
        //public string Leftfooterline2 { get; set; }
        //public string Leftfooterline3 { get; set; }
        //public string Centerfooterline1 { get; set; }
        //public string Centerfooterline2 { get; set; }
        //public string Centerfooterline3 { get; set; }
        //public string Rightfooterline1 { get; set; }
        //public string Rightfooterline2 { get; set; }
        //public string Rightfooterline3 { get; set; }
        //public string Summaryline1 { get; set; }
        //public string Summaryline2 { get; set; }
        //public string Summaryline3 { get; set; }
        //public string HostName { get; set; }
        //public string HostPort { get; set; }
        //public string HostEmail { get; set; }
        //public string HostPassword { get; set; }
        //public string SenderId { get; set; }
        //public string SenderPort { get; set; }
        //public string SenderUserName { get; set; }
        //public string SenderPassword { get; set; }
        //public string HeaderLine1Font { get; set; }
        //public string HeaderOtherFont { get; set; }
        //public string HeaderLine1Color { get; set; }
        //public string HeaderOtherColor { get; set; }
        //public string ContentColor { get; set; }
        //public string ContentFont { get; set; }
        //public string FooterFont { get; set; }

        #endregion
    }

    public class posKOTSaleReport
    {
        public DateTime KOTBillDateTime { get; set; }
        public string KOTNumber { get; set; }
        public string BillNumber { get; set; }
        public string Counter { get; set; }
        public string Table { get; set; }
        public string Waiter { get; set; }
        public string OrderType { get; set; }
        public double TotalAmount { get; set; }
        public double TotalDiscount { get; set; }
        public double Rounding { get; set; }
        public double NetAmount { get; set; }
        public double ReceivedAmount { get; set; }
        public double BalanceAmount { get; set; }
        public string OrderRemark { get; set; }
    }
}
