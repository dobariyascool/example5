using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace posLibrary
{
	/// <summary>
	/// Class for posOptionMaster
	/// </summary>
	public class posOptionMasterDAL
	{
		#region Properties
		public short OptionMasterId { get; set; }
		public string OptionName { get; set; }
		public short linktoBusinessTypeMasterId { get; set; }
		public short? SortOrder { get; set; }
		public bool IsDeleted { get; set; }
        public bool IsDefault { get; set; }

		/// Extra
        /// 
        public string OptionValue { get; set; }
		#endregion

		#region Class Methods
		private List<posOptionMasterDAL> SetListPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
		{
			List<posOptionMasterDAL> lstOptionMaster = new List<posOptionMasterDAL>();
			posOptionMasterDAL objOptionMaster = null;
			while (sqlRdr.Read())
			{
				objOptionMaster = new posOptionMasterDAL();
				objOptionMaster.OptionMasterId = Convert.ToInt16(sqlRdr["OptionMasterId"]);
				objOptionMaster.OptionName = Convert.ToString(sqlRdr["OptionName"]);
				objOptionMaster.linktoBusinessTypeMasterId = Convert.ToInt16(sqlRdr["linktoBusinessTypeMasterId"]);
				if (sqlRdr["SortOrder"] != DBNull.Value)
				{
					objOptionMaster.SortOrder = Convert.ToInt16(sqlRdr["SortOrder"]);
				}
				objOptionMaster.IsDeleted = Convert.ToBoolean(sqlRdr["IsDeleted"]);
                objOptionMaster.IsDefault = Convert.ToBoolean(sqlRdr["IsDefault"]);
                if (sqlRdr["OptionValue"] != DBNull.Value)
                {
                    objOptionMaster.OptionValue = Convert.ToString(sqlRdr["OptionValue"]);
                }
				/// Extra
				lstOptionMaster.Add(objOptionMaster);
			}
			return lstOptionMaster;
		}
		#endregion

		#region Insert
		public posRecordStatus InsertOptionMaster()
		{
			SqlConnection SqlCon = null;
			SqlCommand SqlCmd = null;
			try
			{
				SqlCon = posObjectFactoryDAL.CreateConnection();
				SqlCmd = new SqlCommand("posOptionMaster_Insert", SqlCon);
				SqlCmd.CommandType = CommandType.StoredProcedure;

				SqlCmd.Parameters.Add("@OptionMasterId", SqlDbType.SmallInt).Direction = ParameterDirection.Output;
				SqlCmd.Parameters.Add("@OptionName", SqlDbType.VarChar).Value = this.OptionName;
				SqlCmd.Parameters.Add("@linktoBusinessTypeMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessTypeMasterId;
				SqlCmd.Parameters.Add("@SortOrder", SqlDbType.SmallInt).Value = this.SortOrder;
				SqlCmd.Parameters.Add("@IsDeleted", SqlDbType.Bit).Value = this.IsDeleted;
                SqlCmd.Parameters.Add("@IsDefault", SqlDbType.Bit).Value = this.IsDefault;
				SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

				SqlCon.Open();
				SqlCmd.ExecuteNonQuery();
				SqlCon.Close();

				this.OptionMasterId = Convert.ToInt16(SqlCmd.Parameters["@OptionMasterId"].Value);
				posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
				return rs;
			}
			catch (Exception ex)
			{
				posGlobalsDAL.SaveError(ex);
				return posRecordStatus.Error;
			}
			finally
			{
				posObjectFactoryDAL.DisposeCommand(SqlCmd);
				posObjectFactoryDAL.DisposeConnection(SqlCon);
			}
		}
		#endregion

		#region Update
		public posRecordStatus UpdateOptionMaster()
		{
			SqlConnection SqlCon = null;
			SqlCommand SqlCmd = null;
			try
			{
				SqlCon = posObjectFactoryDAL.CreateConnection();
				SqlCmd = new SqlCommand("posOptionMaster_Update", SqlCon);
				SqlCmd.CommandType = CommandType.StoredProcedure;

				SqlCmd.Parameters.Add("@OptionMasterId", SqlDbType.SmallInt).Value = this.OptionMasterId;
				SqlCmd.Parameters.Add("@OptionName", SqlDbType.VarChar).Value = this.OptionName;
				SqlCmd.Parameters.Add("@linktoBusinessTypeMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessTypeMasterId;
				SqlCmd.Parameters.Add("@SortOrder", SqlDbType.SmallInt).Value = this.SortOrder;
				SqlCmd.Parameters.Add("@IsDeleted", SqlDbType.Bit).Value = this.IsDeleted;
				SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

				SqlCon.Open();
				SqlCmd.ExecuteNonQuery();
				SqlCon.Close();

				posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
				return rs;
			}
			catch (Exception ex)
			{
				posGlobalsDAL.SaveError(ex);
				return posRecordStatus.Error;
			}
			finally
			{
				posObjectFactoryDAL.DisposeCommand(SqlCmd);
				posObjectFactoryDAL.DisposeConnection(SqlCon);
			}
		}
		#endregion

		#region Delete
		public posRecordStatus DeleteOptionMaster()
		{
			SqlConnection SqlCon = null;
			SqlCommand SqlCmd = null;
			try
			{
				SqlCon = posObjectFactoryDAL.CreateConnection();
				SqlCmd = new SqlCommand("posOptionMaster_Delete", SqlCon);
				SqlCmd.CommandType = CommandType.StoredProcedure;

				SqlCmd.Parameters.Add("@OptionMasterId", SqlDbType.SmallInt).Value = this.OptionMasterId;
				SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

				SqlCon.Open();
				SqlCmd.ExecuteNonQuery();
				SqlCon.Close();

				posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
				return rs;
			}
			catch (Exception ex)
			{
				posGlobalsDAL.SaveError(ex);
				return posRecordStatus.Error;
			}
			finally
			{
				posObjectFactoryDAL.DisposeCommand(SqlCmd);
				posObjectFactoryDAL.DisposeConnection(SqlCon);
			}
		}
		#endregion	

		#region SelectAll
		public List<posOptionMasterDAL> SelectAllOptionMaster(short linktoBusinessMasterId)
		{
			SqlConnection SqlCon = null;
			SqlCommand SqlCmd = null;
			SqlDataReader SqlRdr = null;
			try
			{
				SqlCon = posObjectFactoryDAL.CreateConnection();
				SqlCmd = new SqlCommand("posOptionMaster_SelectAll", SqlCon);
				SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@linktoBusinessTypeMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessTypeMasterId;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = linktoBusinessMasterId;

				SqlCon.Open();
				SqlRdr = SqlCmd.ExecuteReader();
				List<posOptionMasterDAL> lstOptionMasterDAL = SetListPropertiesFromSqlDataReader(SqlRdr);
				SqlRdr.Close();
				SqlCon.Close();

				return lstOptionMasterDAL;
			}
			catch (Exception ex)
			{
				posGlobalsDAL.SaveError(ex);
				return null;
			}
			finally
			{
				posObjectFactoryDAL.DisposeDataReader(SqlRdr);
				posObjectFactoryDAL.DisposeCommand(SqlCmd);
				posObjectFactoryDAL.DisposeConnection(SqlCon);
			}
		}
		#endregion
	}
}
