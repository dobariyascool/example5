﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace posLibrary
{
    /// <summary>
    /// Class for posItemMaster
    /// </summary>
    public class posItemMasterDAL : posItemRateTranDAL
    {
        #region Properties
        public int ItemMasterId { get; set; }
        public string ShortName { get; set; }
        public string ItemName { get; set; }
        public string ItemCode { get; set; }
        public string BarCode { get; set; }
        public string ShortDescription { get; set; }
        public short? linktoUnitMasterId { get; set; }
        public short linktoCategoryMasterId { get; set; }
        public bool? IsFavourite { get; set; }
        public string ImageName { get; set; }
        public short ItemPoint { get; set; }
        public short PriceByPoint { get; set; }
        public string SearchWords { get; set; }
        public short linktoBusinessMasterId { get; set; }
        public int? SortOrder { get; set; }
        public bool IsEnabled { get; set; }
        public bool IsDeleted { get; set; }
        public short ItemType { get; set; }
        public DateTime CreateDateTime { get; set; }
        public short linktoUserMasterIdCreatedBy { get; set; }
        public DateTime? UpdateDateTime { get; set; }
        public short? linktoUserMasterIdUpdatedBy { get; set; }
        public bool IsDineInOnly { get; set; }

        /// Extra
        public string Unit { get; set; }

        public string UnitName { get; set; }
        public short CounterMasterId { get; set; }
        public string ItemModifierMasterIds { get; set; }
        public posItemRateTranDAL objItemRateTran { get; set; }

        public double ActualSaleRate { get; set; }
        public int Quantity { get; set; }
        public List<posItemStockTranDAL> lstItemStockTran { get; set; }

        public string CategoryName { get; set; }
        public string CounterName { get; set; }
        public long linktoOrderMasterId { get; set; }
        public bool IsSelected { get; set; }

        //TEMP data
        public string Remark { get; set; }
        public int KOTItemId { get; set; }
        public int TempItemMasterId { get; set; }

        //Extra For Bulk Entry
        public int linktoSupplierMasterId { get; set; }
        public string Supplier { get; set; }
        public double InHand { get; set; }

        public string OptionValueTranIds { get; set; }
        public long OrderItemTranId { get; set; }
        public double Discount { get; set; }
        public bool IsPercentage { get; set; }

        public string xs_ImagePhysicalName { get; set; }
        public string sm_ImagePhysicalName { get; set; }
        public string md_ImagePhysicalName { get; set; }
        public string lg_ImagePhysicalName { get; set; }
        public string xl_ImagePhysicalName { get; set; }

        public double? TaxRate { get; set; }
        public string Tax { get; set; }
        public short RateIndex { get; set; }
        public int linktoOptionValueTranId { get; set; }
        #endregion

        #region Class Methods
        private bool SetClassPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            if (sqlRdr.Read())
            {
                this.ItemMasterId = Convert.ToInt32(sqlRdr["ItemMasterId"]);
                this.ItemName = Convert.ToString(sqlRdr["ItemName"]);
                this.ShortName = Convert.ToString(sqlRdr["ShortName"]);
                this.ItemCode = Convert.ToString(sqlRdr["ItemCode"]);
                this.ShortDescription = Convert.ToString(sqlRdr["ShortDescription"]);
                this.ItemPoint = Convert.ToInt16(sqlRdr["ItemPoint"]);
                this.PriceByPoint = Convert.ToInt16(sqlRdr["PriceByPoint"]);
                this.linktoUnitMasterId = Convert.ToInt16(sqlRdr["linktoUnitMasterId"]);
                this.SearchWords = Convert.ToString(sqlRdr["SearchWords"]);

                if (sqlRdr["ImageName"] != DBNull.Value)
                {
                    this.ImageName = Convert.ToString(sqlRdr["ImageName"]);

                    this.xs_ImagePhysicalName = "xs_" + Convert.ToString(sqlRdr["ImageName"]);
                    this.sm_ImagePhysicalName = "sm_" + Convert.ToString(sqlRdr["ImageName"]);
                    this.md_ImagePhysicalName = "md_" + Convert.ToString(sqlRdr["ImageName"]);
                    this.lg_ImagePhysicalName = "lg_" + Convert.ToString(sqlRdr["ImageName"]);
                    this.xl_ImagePhysicalName = "xl_" + Convert.ToString(sqlRdr["ImageName"]);

                }

                if (sqlRdr["SortOrder"] != DBNull.Value)
                {
                    this.SortOrder = Convert.ToInt32(sqlRdr["SortOrder"]);
                }
                this.CreateDateTime = Convert.ToDateTime(sqlRdr["CreateDateTime"]);
                this.linktoUserMasterIdCreatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdCreatedBy"]);
                if (sqlRdr["UpdateDateTime"] != DBNull.Value)
                {
                    this.UpdateDateTime = Convert.ToDateTime(sqlRdr["UpdateDateTime"]);
                }
                if (sqlRdr["linktoUserMasterIdUpdatedBy"] != DBNull.Value)
                {
                    this.linktoUserMasterIdUpdatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdUpdatedBy"]);
                }
                this.linktoBusinessMasterId = Convert.ToInt16(sqlRdr["linktoBusinessMasterId"]);
                this.BarCode = Convert.ToString(sqlRdr["BarCode"]);
                this.ItemType = Convert.ToInt16(sqlRdr["ItemType"]);
                this.IsFavourite = Convert.ToBoolean(sqlRdr["IsFavourite"]);
                this.IsDineInOnly = Convert.ToBoolean(sqlRdr["IsDineInOnly"]);
                this.IsEnabled = Convert.ToBoolean(sqlRdr["IsEnabled"]);
                this.IsDeleted = Convert.ToBoolean(sqlRdr["IsDeleted"]);
                this.linktoCategoryMasterId = Convert.ToInt16(sqlRdr["linktoCategoryMasterId"]);
                /// Extra

                this.Unit = Convert.ToString(sqlRdr["Unit"]);
                return true;
            }
            return false;
        }

        private List<posItemMasterDAL> SetListPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            List<posItemMasterDAL> lstItemMaster = new List<posItemMasterDAL>();
            posItemMasterDAL objItemMaster = null;
            while (sqlRdr.Read())
            {
                objItemMaster = new posItemMasterDAL();
                objItemMaster.ItemMasterId = Convert.ToInt32(sqlRdr["ItemMasterId"]);
                objItemMaster.ItemName = Convert.ToString(sqlRdr["ItemName"]);
                objItemMaster.ShortName = Convert.ToString(sqlRdr["ShortName"]);
                objItemMaster.ItemCode = Convert.ToString(sqlRdr["ItemCode"]);
                objItemMaster.BarCode = Convert.ToString(sqlRdr["BarCode"]);
                objItemMaster.ShortDescription = Convert.ToString(sqlRdr["ShortDescription"]);
                objItemMaster.ItemPoint = Convert.ToInt16(sqlRdr["ItemPoint"]);
                objItemMaster.PriceByPoint = Convert.ToInt16(sqlRdr["PriceByPoint"]);
                objItemMaster.linktoUnitMasterId = Convert.ToInt16(sqlRdr["linktoUnitMasterId"]);
                objItemMaster.SearchWords = Convert.ToString(sqlRdr["SearchWords"]);
                objItemMaster.ImageName = Convert.ToString(sqlRdr["ImageName"]);

                if (sqlRdr["SortOrder"] != DBNull.Value)
                {
                    objItemMaster.SortOrder = Convert.ToInt32(sqlRdr["SortOrder"]);
                }
                objItemMaster.CreateDateTime = Convert.ToDateTime(sqlRdr["CreateDateTime"]);
                objItemMaster.linktoUserMasterIdCreatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdCreatedBy"]);
                if (sqlRdr["UpdateDateTime"] != DBNull.Value)
                {
                    objItemMaster.UpdateDateTime = Convert.ToDateTime(sqlRdr["UpdateDateTime"]);
                }
                if (sqlRdr["linktoUserMasterIdUpdatedBy"] != DBNull.Value)
                {
                    objItemMaster.linktoUserMasterIdUpdatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdUpdatedBy"]);
                }
                objItemMaster.linktoBusinessMasterId = Convert.ToInt16(sqlRdr["linktoBusinessMasterId"]);

                objItemMaster.ItemType = Convert.ToInt16(sqlRdr["ItemType"]);
                objItemMaster.IsFavourite = Convert.ToBoolean(sqlRdr["IsFavourite"]);
                objItemMaster.IsDineInOnly = Convert.ToBoolean(sqlRdr["IsDineInOnly"]);

                objItemMaster.IsEnabled = Convert.ToBoolean(sqlRdr["IsEnabled"]);
                objItemMaster.IsDeleted = Convert.ToBoolean(sqlRdr["IsDeleted"]);
                objItemMaster.linktoCategoryMasterId = Convert.ToInt16(sqlRdr["linktoCategoryMasterId"]);
                /// Extra

                objItemMaster.Unit = Convert.ToString(sqlRdr["Unit"]);
                if (sqlRdr["CategoryName"] != DBNull.Value)
                {
                    objItemMaster.CategoryName = Convert.ToString(sqlRdr["CategoryName"]);
                }
                if (sqlRdr["ImageName"] != DBNull.Value)
                {
                    objItemMaster.ImageName = Convert.ToString(sqlRdr["ImageName"]);

                    objItemMaster.xs_ImagePhysicalName = "xs_" + Convert.ToString(sqlRdr["ImageName"]);
                    objItemMaster.sm_ImagePhysicalName = "sm_" + Convert.ToString(sqlRdr["ImageName"]);
                    objItemMaster.md_ImagePhysicalName = "md_" + Convert.ToString(sqlRdr["ImageName"]);
                    objItemMaster.lg_ImagePhysicalName = "lg_" + Convert.ToString(sqlRdr["ImageName"]);
                    objItemMaster.xl_ImagePhysicalName = "xl_" + Convert.ToString(sqlRdr["ImageName"]);

                }
                lstItemMaster.Add(objItemMaster);
            }
            return lstItemMaster;
        }
        #endregion

        #region Insert
        public posRecordStatus InsertItemMaster(List<posItemOptionTranDAL> lstItemOptionTranDAL, string itemCategoryMasterIds, string itemComboItemMasterIds)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlTransaction SqlTran = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCon.Open();
                SqlTran = SqlCon.BeginTransaction();
                SqlCmd = new SqlCommand("posItemMaster_Insert", SqlCon, SqlTran);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@ItemMasterId", SqlDbType.Int).Direction = ParameterDirection.Output;
                SqlCmd.Parameters.Add("@ItemName", SqlDbType.VarChar).Value = this.ItemName;
                SqlCmd.Parameters.Add("@ShortName", SqlDbType.VarChar).Value = this.ShortName;
                SqlCmd.Parameters.Add("@ItemCode", SqlDbType.VarChar).Value = this.ItemCode;
                SqlCmd.Parameters.Add("@ShortDescription", SqlDbType.VarChar).Value = this.ShortDescription;
                SqlCmd.Parameters.Add("@ItemPoint", SqlDbType.SmallInt).Value = this.ItemPoint;
                SqlCmd.Parameters.Add("@PriceByPoint", SqlDbType.SmallInt).Value = this.PriceByPoint;
                SqlCmd.Parameters.Add("@BarCode", SqlDbType.VarChar).Value = this.BarCode;
                SqlCmd.Parameters.Add("@IsFavourite", SqlDbType.Bit).Value = this.IsFavourite;
                SqlCmd.Parameters.Add("@ItemType", SqlDbType.SmallInt).Value = this.ItemType;
                SqlCmd.Parameters.Add("@linktoUnitMasterId", SqlDbType.SmallInt).Value = this.linktoUnitMasterId;
                SqlCmd.Parameters.Add("@linktoCategoryMasterId", SqlDbType.SmallInt).Value = this.linktoCategoryMasterId;
                SqlCmd.Parameters.Add("@SearchWords", SqlDbType.VarChar).Value = this.SearchWords;
                SqlCmd.Parameters.Add("@ImageName", SqlDbType.VarChar).Value = this.ImageName;
                SqlCmd.Parameters.Add("@SortOrder", SqlDbType.Int).Value = this.SortOrder;
                SqlCmd.Parameters.Add("@CreateDateTime", SqlDbType.DateTime).Value = this.CreateDateTime;
                SqlCmd.Parameters.Add("@linktoUserMasterIdCreatedBy", SqlDbType.SmallInt).Value = this.linktoUserMasterIdCreatedBy;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCmd.Parameters.Add("@IsEnabled", SqlDbType.Bit).Value = this.IsEnabled;
                SqlCmd.Parameters.Add("@IsDineInOnly", SqlDbType.Bit).Value = this.IsDineInOnly;
                SqlCmd.Parameters.Add("@IsDeleted", SqlDbType.Bit).Value = this.IsDeleted;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCmd.ExecuteNonQuery();

                this.ItemMasterId = Convert.ToInt32(SqlCmd.Parameters["@ItemMasterId"].Value);
                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;

                if (rs == posRecordStatus.Success)
                {
                    if (posItemRateTranDAL.InsertItemRateTran(this.objItemRateTran, this.ItemMasterId, SqlCon, SqlTran) == posRecordStatus.Error)
                    {
                        SqlTran.Rollback();
                        SqlCon.Close();
                        return posRecordStatus.Error;
                    }
                }
                if (rs == posRecordStatus.Success)
                {
                    if (posItemModifierTranDAL.InsertItemModifierTran(this.ItemModifierMasterIds, this.ItemMasterId, SqlCon, SqlTran) == posRecordStatus.Error)
                    {
                        SqlTran.Rollback();
                        SqlCon.Close();
                        return posRecordStatus.Error;
                    }
                }

                if (rs == posRecordStatus.Success)
                {
                    if (posItemCategoryTranDAL.InsertItemCategoryTran(itemCategoryMasterIds, this.ItemMasterId, SqlCon, SqlTran) == posRecordStatus.Error)
                    {
                        SqlTran.Rollback();
                        SqlCon.Close();
                        return posRecordStatus.Error;
                    }
                }
                if (rs == posRecordStatus.Success)
                {
                    if (ItemType == short.Parse(posItemType.Combo_Item.GetHashCode().ToString()))
                    {
                        if (posItemComboTranDAL.InsertItemComboTran(itemComboItemMasterIds, this.ItemMasterId, SqlCon, SqlTran) == posRecordStatus.Error)
                        {
                            SqlTran.Rollback();
                            SqlCon.Close();
                            return posRecordStatus.Error;
                        }
                    }
                }
                if (lstItemOptionTranDAL != null)
                {
                    posItemOptionTranDAL objItemOptionTran = new posItemOptionTranDAL();
                    objItemOptionTran.linktoItemMasterId = this.ItemMasterId;
                    if (objItemOptionTran.DeleteAllItemOptionTranByItemMasterID(SqlCon, SqlTran) != posRecordStatus.Success)
                    {
                        SqlTran.Rollback();
                        SqlCon.Close();
                        return posRecordStatus.Error;
                    }
                    foreach (posItemOptionTranDAL objItemOptionTranDAL in lstItemOptionTranDAL)
                    {
                        objItemOptionTranDAL.linktoItemMasterId = this.ItemMasterId;
                        if (objItemOptionTranDAL.InsertItemOptionTran(SqlCon, SqlTran) != posRecordStatus.Success)
                        {
                            SqlTran.Rollback();
                            SqlCon.Close();
                            return posRecordStatus.Error;
                        }
                    }
                }

                SqlTran.Commit();
                SqlCon.Close();
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
                posObjectFactoryDAL.DisposeTransaction(SqlTran);
            }
        }

        public posRecordStatus InsertItemMasterRawMaterial()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlTransaction SqlTran = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCon.Open();
                SqlTran = SqlCon.BeginTransaction();
                SqlCmd = new SqlCommand("posItemMaster_Insert", SqlCon, SqlTran);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@ItemMasterId", SqlDbType.Int).Direction = ParameterDirection.Output;
                SqlCmd.Parameters.Add("@ItemName", SqlDbType.VarChar).Value = this.ItemName;
                SqlCmd.Parameters.Add("@ShortName", SqlDbType.VarChar).Value = this.ShortName;
                SqlCmd.Parameters.Add("@ItemCode", SqlDbType.VarChar).Value = this.ItemCode;
                SqlCmd.Parameters.Add("@ShortDescription", SqlDbType.VarChar).Value = this.ShortDescription;
                SqlCmd.Parameters.Add("@ItemPoint", SqlDbType.SmallInt).Value = this.ItemPoint;
                SqlCmd.Parameters.Add("@PriceByPoint", SqlDbType.SmallInt).Value = this.PriceByPoint;
                SqlCmd.Parameters.Add("@BarCode", SqlDbType.VarChar).Value = this.BarCode;
                SqlCmd.Parameters.Add("@IsFavourite", SqlDbType.Bit).Value = this.IsFavourite;
                SqlCmd.Parameters.Add("@ItemType", SqlDbType.SmallInt).Value = this.ItemType;
                SqlCmd.Parameters.Add("@linktoUnitMasterId", SqlDbType.SmallInt).Value = this.linktoUnitMasterId;
                SqlCmd.Parameters.Add("@linktoCategoryMasterId", SqlDbType.SmallInt).Value = this.linktoCategoryMasterId;
                SqlCmd.Parameters.Add("@SearchWords", SqlDbType.VarChar).Value = this.SearchWords;
                SqlCmd.Parameters.Add("@ImageName", SqlDbType.VarChar).Value = this.ImageName;

                SqlCmd.Parameters.Add("@SortOrder", SqlDbType.Int).Value = this.SortOrder;
                SqlCmd.Parameters.Add("@CreateDateTime", SqlDbType.DateTime).Value = this.CreateDateTime;
                SqlCmd.Parameters.Add("@linktoUserMasterIdCreatedBy", SqlDbType.SmallInt).Value = this.linktoUserMasterIdCreatedBy;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCmd.Parameters.Add("@IsDineInOnly", SqlDbType.Bit).Value = this.IsDineInOnly;
                SqlCmd.Parameters.Add("@IsEnabled", SqlDbType.Bit).Value = this.IsEnabled;
                SqlCmd.Parameters.Add("@IsDeleted", SqlDbType.Bit).Value = this.IsDeleted;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCmd.ExecuteNonQuery();

                this.ItemMasterId = Convert.ToInt32(SqlCmd.Parameters["@ItemMasterId"].Value);
                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;

                if (rs == posRecordStatus.Success)
                {
                    if (posItemRateTranDAL.InsertItemRateTran(this.objItemRateTran, this.ItemMasterId, SqlCon, SqlTran) == posRecordStatus.Error)
                    {
                        SqlTran.Rollback();
                        return posRecordStatus.Error;
                    }
                }
                if (rs == posRecordStatus.Success)
                {
                    if (posItemStockTranDAL.DeleteItemStockTran(this.ItemMasterId, SqlCon, SqlTran) == posRecordStatus.Error)
                    {
                        SqlTran.Rollback();
                        return posRecordStatus.Error;
                    }
                    else
                    {
                        foreach (posItemStockTranDAL objItemStockTranDAL in lstItemStockTran)
                        {
                            if (posItemStockTranDAL.InsertItemStockTran(objItemStockTranDAL, this.ItemMasterId, SqlCon, SqlTran) == posRecordStatus.Error)
                            {
                                SqlTran.Rollback();
                                return posRecordStatus.Error;
                            }
                        }
                    }
                }
                SqlTran.Commit();
                SqlCon.Close();
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public posRecordStatus InsertItemMasterMdifier()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlTransaction SqlTran = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCon.Open();
                SqlTran = SqlCon.BeginTransaction();
                SqlCmd = new SqlCommand("posItemMaster_Insert", SqlCon, SqlTran);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@ItemMasterId", SqlDbType.Int).Direction = ParameterDirection.Output;
                SqlCmd.Parameters.Add("@ItemName", SqlDbType.VarChar).Value = this.ItemName;
                SqlCmd.Parameters.Add("@ShortName", SqlDbType.VarChar).Value = this.ShortName;
                SqlCmd.Parameters.Add("@ItemCode", SqlDbType.VarChar).Value = this.ItemCode;
                SqlCmd.Parameters.Add("@ShortDescription", SqlDbType.VarChar).Value = this.ShortDescription;
                SqlCmd.Parameters.Add("@ItemPoint", SqlDbType.SmallInt).Value = this.ItemPoint;
                SqlCmd.Parameters.Add("@PriceByPoint", SqlDbType.SmallInt).Value = this.PriceByPoint;
                SqlCmd.Parameters.Add("@ItemType", SqlDbType.SmallInt).Value = this.ItemType;
                SqlCmd.Parameters.Add("@IsFavourite", SqlDbType.Bit).Value = this.IsFavourite;
                SqlCmd.Parameters.Add("@linktoUnitMasterId", SqlDbType.SmallInt).Value = this.linktoUnitMasterId;
                SqlCmd.Parameters.Add("@linktoCategoryMasterId", SqlDbType.SmallInt).Value = this.linktoCategoryMasterId;
                SqlCmd.Parameters.Add("@ImageName", SqlDbType.VarChar).Value = this.ImageName;
                SqlCmd.Parameters.Add("@CreateDateTime", SqlDbType.DateTime).Value = this.CreateDateTime;
                SqlCmd.Parameters.Add("@linktoUserMasterIdCreatedBy", SqlDbType.SmallInt).Value = this.linktoUserMasterIdCreatedBy;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCmd.Parameters.Add("@IsDineInOnly", SqlDbType.Bit).Value = this.IsDineInOnly;
                SqlCmd.Parameters.Add("@IsEnabled", SqlDbType.Bit).Value = this.IsEnabled;
                SqlCmd.Parameters.Add("@IsDeleted", SqlDbType.Bit).Value = this.IsDeleted;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCmd.ExecuteNonQuery();

                this.ItemMasterId = Convert.ToInt32(SqlCmd.Parameters["@ItemMasterId"].Value);
                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;

                if (rs == posRecordStatus.Success)
                {
                    if (posItemRateTranDAL.InsertItemRateTran(this.objItemRateTran, this.ItemMasterId, SqlCon, SqlTran) == posRecordStatus.Error)
                    {
                        SqlTran.Rollback();
                        return posRecordStatus.Error;
                    }
                }
                SqlTran.Commit();
                SqlCon.Close();
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public static posRecordStatus InsertItemMasterBulkEntry(List<posItemMasterDAL> lstItemMasterDAL, short counterMasterId)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlTransaction SqlTran = null;
            bool IsAllreadyExists = false;

            posRecordStatus rs = posRecordStatus.Success;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCon.Open();
                SqlTran = SqlCon.BeginTransaction();
                SqlCmd = new SqlCommand("posItemMaster_Insert", SqlCon, SqlTran);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                foreach (posItemMasterDAL objItemMasterDAL in lstItemMasterDAL)
                {
                    SqlCmd.Parameters.Clear();
                    SqlCmd.Parameters.Add("@ItemMasterId", SqlDbType.Int).Direction = ParameterDirection.Output;
                    SqlCmd.Parameters.Add("@ItemName", SqlDbType.VarChar).Value = objItemMasterDAL.ItemName;
                    SqlCmd.Parameters.Add("@ItemCode", SqlDbType.VarChar).Value = objItemMasterDAL.ItemCode;
                    SqlCmd.Parameters.Add("@BarCode", SqlDbType.VarChar).Value = objItemMasterDAL.BarCode;
                    SqlCmd.Parameters.Add("@IsFavourite", SqlDbType.Bit).Value = objItemMasterDAL.IsFavourite;
                    SqlCmd.Parameters.Add("@ItemType", SqlDbType.SmallInt).Value = objItemMasterDAL.ItemType;
                    SqlCmd.Parameters.Add("@ItemPoint", SqlDbType.SmallInt).Value = objItemMasterDAL.ItemPoint;
                    SqlCmd.Parameters.Add("@IsDineInOnly", SqlDbType.Bit).Value = objItemMasterDAL.IsDineInOnly;
                    SqlCmd.Parameters.Add("@PriceByPoint", SqlDbType.SmallInt).Value = objItemMasterDAL.PriceByPoint;
                    SqlCmd.Parameters.Add("@linktoUnitMasterId", SqlDbType.SmallInt).Value = objItemMasterDAL.linktoUnitMasterId;
                    SqlCmd.Parameters.Add("@linktoCategoryMasterId", SqlDbType.SmallInt).Value = objItemMasterDAL.linktoCategoryMasterId;
                    SqlCmd.Parameters.Add("@CreateDateTime", SqlDbType.DateTime).Value = objItemMasterDAL.CreateDateTime;
                    SqlCmd.Parameters.Add("@linktoUserMasterIdCreatedBy", SqlDbType.SmallInt).Value = objItemMasterDAL.linktoUserMasterIdCreatedBy;
                    SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = objItemMasterDAL.linktoBusinessMasterId;
                    SqlCmd.Parameters.Add("@IsEnabled", SqlDbType.Bit).Value = objItemMasterDAL.IsEnabled;
                    SqlCmd.Parameters.Add("@IsDeleted", SqlDbType.Bit).Value = objItemMasterDAL.IsDeleted;
                    SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                    SqlCmd.ExecuteNonQuery();

                    objItemMasterDAL.ItemMasterId = Convert.ToInt32(SqlCmd.Parameters["@ItemMasterId"].Value);
                    rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;

                    if (rs == posRecordStatus.Error)
                    {
                        SqlTran.Rollback();
                        SqlCon.Close();
                        return rs;
                    }
                    if (rs == posRecordStatus.RecordAlreadyExist)
                    {
                        IsAllreadyExists = true;
                    }

                    rs = posItemRateTranDAL.InsertItemRateTran(objItemMasterDAL.objItemRateTran, objItemMasterDAL.ItemMasterId, SqlCon, SqlTran);
                    if (rs == posRecordStatus.Error)
                    {
                        SqlTran.Rollback();
                        SqlCon.Close();
                        return rs;
                    }

                    rs = posItemCategoryTranDAL.InsertItemCategoryTran(objItemMasterDAL.linktoCategoryMasterId.ToString(), objItemMasterDAL.ItemMasterId, SqlCon, SqlTran);
                    if (rs == posRecordStatus.Error)
                    {
                        SqlTran.Rollback();
                        SqlCon.Close();
                        return rs;
                    }

                    rs = posCounterItemTranDAL.InsertCounterItemTran(counterMasterId, objItemMasterDAL.ItemMasterId, SqlCon, SqlTran);
                    if (rs == posRecordStatus.Error)
                    {
                        SqlTran.Rollback();
                        SqlCon.Close();
                        return rs;
                    }

                    if (objItemMasterDAL.ItemType == (int)posItemType.Raw_Material)
                    {
                        if (objItemMasterDAL.lstItemStockTran != null && objItemMasterDAL.lstItemStockTran.Count > 0)
                        {
                            rs = posItemStockTranDAL.InsertItemStockTran(objItemMasterDAL.lstItemStockTran[0], objItemMasterDAL.ItemMasterId, SqlCon, SqlTran);
                            if (rs == posRecordStatus.Error)
                            {
                                SqlTran.Rollback();
                                SqlCon.Close();
                                return rs;
                            }
                        }
                        rs = posSupplierItemTranDAL.InsertAllSupplierItemTran(objItemMasterDAL.linktoSupplierMasterId, objItemMasterDAL.ItemMasterId, SqlCon, SqlTran);
                        if (rs == posRecordStatus.Error)
                        {
                            SqlTran.Rollback();
                            SqlCon.Close();
                            return rs;
                        }
                    }
                }

                if (IsAllreadyExists)
                {
                    rs = posRecordStatus.RecordAlreadyExist;
                    //return rs;
                }
                SqlTran.Commit();
                SqlCon.Close();
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public posRecordStatus InsertItemMasterFromExcelFile(List<posItemMasterDAL> lstItemMaster, out string itemNames)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;

            bool IsAllreadyExists = false;
            itemNames = string.Empty;

            posRecordStatus rs = posRecordStatus.Success;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCon.Open();
                SqlCmd = new SqlCommand("posItemMasterImport_Insert", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                foreach (posItemMasterDAL objItemMasterDAL in lstItemMaster)
                {
                    SqlCmd.Parameters.Clear();
                    SqlCmd.Parameters.Add("@ItemMasterId", SqlDbType.Int).Direction = ParameterDirection.Output;
                    SqlCmd.Parameters.Add("@ItemName", SqlDbType.VarChar).Value = objItemMasterDAL.ItemName;
                    SqlCmd.Parameters.Add("@ItemCode", SqlDbType.VarChar).Value = objItemMasterDAL.ItemCode;
                    SqlCmd.Parameters.Add("@IsFavourite", SqlDbType.Bit).Value = objItemMasterDAL.IsFavourite;
                    SqlCmd.Parameters.Add("@ItemType", SqlDbType.SmallInt).Value = objItemMasterDAL.ItemType;
                    SqlCmd.Parameters.Add("@ItemPoint", SqlDbType.SmallInt).Value = objItemMasterDAL.ItemPoint;
                    SqlCmd.Parameters.Add("@PriceByPoint", SqlDbType.SmallInt).Value = objItemMasterDAL.PriceByPoint;
                    SqlCmd.Parameters.Add("@IsRateTaxInclusive", SqlDbType.Bit).Value = objItemMasterDAL.IsRateTaxInclusive;
                    SqlCmd.Parameters.Add("@CreateDateTime", SqlDbType.DateTime).Value = objItemMasterDAL.CreateDateTime;
                    SqlCmd.Parameters.Add("@linktoUserMasterIdCreatedBy", SqlDbType.SmallInt).Value = objItemMasterDAL.linktoUserMasterIdCreatedBy;
                    SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = objItemMasterDAL.linktoBusinessMasterId;
                    SqlCmd.Parameters.Add("@IsEnabled", SqlDbType.Bit).Value = objItemMasterDAL.IsEnabled;
                    SqlCmd.Parameters.Add("@IsDeleted", SqlDbType.Bit).Value = objItemMasterDAL.IsDeleted;
                    SqlCmd.Parameters.Add("@CategoryName", SqlDbType.VarChar).Value = objItemMasterDAL.CategoryName;
                    SqlCmd.Parameters.Add("@IsDineInOnly", SqlDbType.Bit).Value = objItemMasterDAL.IsDineInOnly;
                    SqlCmd.Parameters.Add("@Unit", SqlDbType.VarChar).Value = objItemMasterDAL.Unit;
                    SqlCmd.Parameters.Add("@MRP", SqlDbType.Money).Value = objItemMasterDAL.MRP;
                    SqlCmd.Parameters.Add("@Rate1", SqlDbType.Money).Value = objItemMasterDAL.Rate1;

                    SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                    SqlCmd.ExecuteNonQuery();

                    objItemMasterDAL.ItemMasterId = Convert.ToInt32(SqlCmd.Parameters["@ItemMasterId"].Value);
                    rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                    if (rs == posRecordStatus.RecordAlreadyExist)
                    {
                        itemNames += objItemMasterDAL.ItemName + ", ";
                        IsAllreadyExists = true;
                    }
                }
                SqlCon.Close();
                if (IsAllreadyExists)
                {
                    rs = posRecordStatus.RecordAlreadyExist;
                }
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region Update
        public posRecordStatus UpdateItemMaster(List<posItemOptionTranDAL> lstItemOptionTranDAL, string itemCategoryMasterIds, string itemComboItemMasterIds)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlTransaction SqlTran = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCon.Open();
                SqlTran = SqlCon.BeginTransaction();
                SqlCmd = new SqlCommand("posItemMaster_Update", SqlCon, SqlTran);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@ItemMasterId", SqlDbType.Int).Value = this.ItemMasterId;
                SqlCmd.Parameters.Add("@ItemName", SqlDbType.VarChar).Value = this.ItemName;
                SqlCmd.Parameters.Add("@ShortName", SqlDbType.VarChar).Value = this.ShortName;
                SqlCmd.Parameters.Add("@ItemCode", SqlDbType.VarChar).Value = this.ItemCode;
                SqlCmd.Parameters.Add("@ShortDescription", SqlDbType.VarChar).Value = this.ShortDescription;
                SqlCmd.Parameters.Add("@ItemPoint", SqlDbType.SmallInt).Value = this.ItemPoint;
                SqlCmd.Parameters.Add("@PriceByPoint", SqlDbType.SmallInt).Value = this.PriceByPoint;
                SqlCmd.Parameters.Add("@BarCode", SqlDbType.VarChar).Value = this.BarCode;
                SqlCmd.Parameters.Add("@IsFavourite", SqlDbType.Bit).Value = this.IsFavourite;
                SqlCmd.Parameters.Add("@linktoUnitMasterId", SqlDbType.SmallInt).Value = this.linktoUnitMasterId;
                SqlCmd.Parameters.Add("@SearchWords", SqlDbType.VarChar).Value = this.SearchWords;
                SqlCmd.Parameters.Add("@ImageName", SqlDbType.VarChar).Value = this.ImageName;
                SqlCmd.Parameters.Add("@linktoCategoryMasterId", SqlDbType.SmallInt).Value = this.linktoCategoryMasterId;
                SqlCmd.Parameters.Add("@ItemType", SqlDbType.SmallInt).Value = this.ItemType;
                SqlCmd.Parameters.Add("@SortOrder", SqlDbType.Int).Value = this.SortOrder;
                SqlCmd.Parameters.Add("@UpdateDateTime", SqlDbType.DateTime).Value = this.UpdateDateTime;
                SqlCmd.Parameters.Add("@linktoUserMasterIdUpdatedBy", SqlDbType.SmallInt).Value = this.linktoUserMasterIdUpdatedBy;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCmd.Parameters.Add("@IsDineInOnly", SqlDbType.Bit).Value = this.IsDineInOnly;
                SqlCmd.Parameters.Add("@IsEnabled", SqlDbType.Bit).Value = this.IsEnabled;
                SqlCmd.Parameters.Add("@IsDeleted", SqlDbType.Bit).Value = this.IsDeleted;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCmd.ExecuteNonQuery();
                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;

                if (rs == posRecordStatus.Success)
                {
                    if (posItemRateTranDAL.UpdateItemRateTran(this.objItemRateTran, this.ItemMasterId, SqlCon, SqlTran) == posRecordStatus.Error)
                    {
                        SqlTran.Rollback();
                        SqlCon.Close();
                        return posRecordStatus.Error;
                    }
                }
                if (rs == posRecordStatus.Success)
                {
                    if (posItemModifierTranDAL.InsertItemModifierTran(this.ItemModifierMasterIds, this.ItemMasterId, SqlCon, SqlTran) == posRecordStatus.Error)
                    {
                        SqlTran.Rollback();
                        SqlCon.Close();
                        return posRecordStatus.Error;
                    }
                }
                if (rs == posRecordStatus.Success)
                {
                    if (posItemCategoryTranDAL.InsertItemCategoryTran(itemCategoryMasterIds, this.ItemMasterId, SqlCon, SqlTran) == posRecordStatus.Error)
                    {
                        SqlTran.Rollback();
                        SqlCon.Close();
                        return posRecordStatus.Error;
                    }
                }
                if (rs == posRecordStatus.Success)
                {
                    if (ItemType == short.Parse(posItemType.Combo_Item.GetHashCode().ToString()))
                    {
                        if (posItemComboTranDAL.InsertItemComboTran(itemComboItemMasterIds, this.ItemMasterId, SqlCon, SqlTran) == posRecordStatus.Error)
                        {
                            SqlTran.Rollback();
                            SqlCon.Close();
                            return posRecordStatus.Error;
                        }
                    }
                }
                if (rs == posRecordStatus.Success)
                {
                    if (lstItemOptionTranDAL != null)
                    {
                        posItemOptionTranDAL objItemOptionTran = new posItemOptionTranDAL();
                        objItemOptionTran.linktoItemMasterId = this.ItemMasterId;
                        if (objItemOptionTran.DeleteAllItemOptionTranByItemMasterID(SqlCon, SqlTran) != posRecordStatus.Success)
                        {
                            SqlTran.Rollback();
                            SqlCon.Close();
                            return posRecordStatus.Error;
                        }
                        foreach (posItemOptionTranDAL objItemOptionTranDAL in lstItemOptionTranDAL)
                        {

                            objItemOptionTranDAL.linktoItemMasterId = this.ItemMasterId;
                            if (objItemOptionTranDAL.InsertItemOptionTran(SqlCon, SqlTran) != posRecordStatus.Success)
                            {
                                SqlTran.Rollback();
                                SqlCon.Close();
                                return posRecordStatus.Error;
                            }
                        }
                    }
                }
                SqlTran.Commit();
                SqlCon.Close();
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
                posObjectFactoryDAL.DisposeTransaction(SqlTran);
            }
        }

        public posRecordStatus UpdateItemMasterRawMaterial()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlTransaction SqlTran = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCon.Open();
                SqlTran = SqlCon.BeginTransaction();
                SqlCmd = new SqlCommand("posItemMasterRawMaterial_Update", SqlCon, SqlTran);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@ItemMasterId", SqlDbType.Int).Value = this.ItemMasterId;
                SqlCmd.Parameters.Add("@ItemName", SqlDbType.VarChar).Value = this.ItemName;
                SqlCmd.Parameters.Add("@ShortName", SqlDbType.VarChar).Value = this.ShortName;
                SqlCmd.Parameters.Add("@ItemCode", SqlDbType.VarChar).Value = this.ItemCode;
                SqlCmd.Parameters.Add("@ShortDescription", SqlDbType.VarChar).Value = this.ShortDescription;
                SqlCmd.Parameters.Add("@linktoUnitMasterId", SqlDbType.SmallInt).Value = this.linktoUnitMasterId;
                SqlCmd.Parameters.Add("@ItemType", SqlDbType.SmallInt).Value = this.ItemType;
                SqlCmd.Parameters.Add("@linktoCategoryMasterId", SqlDbType.SmallInt).Value = this.linktoCategoryMasterId;
                SqlCmd.Parameters.Add("@UpdateDateTime", SqlDbType.DateTime).Value = this.UpdateDateTime;
                SqlCmd.Parameters.Add("@linktoUserMasterIdUpdatedBy", SqlDbType.SmallInt).Value = this.linktoUserMasterIdUpdatedBy;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCmd.Parameters.Add("@IsEnabled", SqlDbType.Bit).Value = this.IsEnabled;
                SqlCmd.Parameters.Add("@IsDeleted", SqlDbType.Bit).Value = this.IsDeleted;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCmd.ExecuteNonQuery();

                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;

                if (rs == posRecordStatus.Success)
                {
                    if (posItemRateTranDAL.UpdateItemRateTran(this.objItemRateTran, this.ItemMasterId, SqlCon, SqlTran) == posRecordStatus.Error)
                    {
                        SqlTran.Rollback();
                        return posRecordStatus.Error;
                    }
                }

                if (rs == posRecordStatus.Success)
                {
                    posItemStockTranDAL objposItemStockTranDAL = new posItemStockTranDAL();
                    objposItemStockTranDAL.linktoItemMasterId = this.ItemMasterId;
                    if (posItemStockTranDAL.DeleteItemStockTran(this.ItemMasterId, SqlCon, SqlTran) == posRecordStatus.Error)
                    {
                        SqlTran.Rollback();
                        return posRecordStatus.Error;
                    }
                    else
                    {
                        foreach (posItemStockTranDAL objItemStockTranDAL in lstItemStockTran)
                        {
                            if (posItemStockTranDAL.InsertItemStockTran(objItemStockTranDAL, this.ItemMasterId, SqlCon, SqlTran) == posRecordStatus.Error)
                            {
                                SqlTran.Rollback();
                                return posRecordStatus.Error;
                            }
                        }
                    }
                }
                SqlTran.Commit();
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public posRecordStatus UpdateItemMasterMdifier()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlTransaction SqlTran = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCon.Open();
                SqlTran = SqlCon.BeginTransaction();
                SqlCmd = new SqlCommand("posItemMaster_Update", SqlCon, SqlTran);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@ItemMasterId", SqlDbType.Int).Value = this.ItemMasterId;
                SqlCmd.Parameters.Add("@ItemName", SqlDbType.VarChar).Value = this.ItemName;
                SqlCmd.Parameters.Add("@ShortName", SqlDbType.VarChar).Value = this.ShortName;
                SqlCmd.Parameters.Add("@ItemCode", SqlDbType.VarChar).Value = this.ItemCode;
                SqlCmd.Parameters.Add("@ShortDescription", SqlDbType.VarChar).Value = this.ShortDescription;
                SqlCmd.Parameters.Add("@ItemPoint", SqlDbType.SmallInt).Value = this.ItemPoint;
                SqlCmd.Parameters.Add("@PriceByPoint", SqlDbType.SmallInt).Value = this.PriceByPoint;
                SqlCmd.Parameters.Add("@BarCode", SqlDbType.VarChar).Value = this.BarCode;
                SqlCmd.Parameters.Add("@IsFavourite", SqlDbType.Bit).Value = this.IsFavourite;
                SqlCmd.Parameters.Add("@linktoUnitMasterId", SqlDbType.SmallInt).Value = this.linktoUnitMasterId;
                SqlCmd.Parameters.Add("@SearchWords", SqlDbType.VarChar).Value = this.SearchWords;
                SqlCmd.Parameters.Add("@ImageName", SqlDbType.VarChar).Value = this.ImageName;
                SqlCmd.Parameters.Add("@ItemType", SqlDbType.SmallInt).Value = this.ItemType;
                SqlCmd.Parameters.Add("@linktoCategoryMasterId", SqlDbType.SmallInt).Value = this.linktoCategoryMasterId;
                SqlCmd.Parameters.Add("@UpdateDateTime", SqlDbType.DateTime).Value = this.UpdateDateTime;
                SqlCmd.Parameters.Add("@linktoUserMasterIdUpdatedBy", SqlDbType.SmallInt).Value = this.linktoUserMasterIdUpdatedBy;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCmd.Parameters.Add("@IsDineInOnly", SqlDbType.Bit).Value = this.IsDineInOnly;
                SqlCmd.Parameters.Add("@IsEnabled", SqlDbType.Bit).Value = this.IsEnabled;
                SqlCmd.Parameters.Add("@IsDeleted", SqlDbType.Bit).Value = this.IsDeleted;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCmd.ExecuteNonQuery();

                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;

                if (rs == posRecordStatus.Success)
                {
                    if (posItemRateTranDAL.UpdateItemRateTran(this.objItemRateTran, this.ItemMasterId, SqlCon, SqlTran) == posRecordStatus.Error)
                    {
                        SqlTran.Rollback();
                        return posRecordStatus.Error;
                    }
                }
                SqlTran.Commit();
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public posRecordStatus UpdateItemMasterBulkItem(out string itemNames, List<posItemMasterDAL> lstItemMasterDAL)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlTransaction SqlTran = null;
            posItemRateTranDAL objItemRateTranDAL = null;
            itemNames = string.Empty;
            bool IsAllreadyExists = false;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCon.Open();
                SqlTran = SqlCon.BeginTransaction();
                SqlCmd = new SqlCommand("posItemMasterBulkItems_Update", SqlCon, SqlTran);
                SqlCmd.CommandType = CommandType.StoredProcedure;
                posRecordStatus rs = posRecordStatus.Error;
                foreach (posItemMasterDAL item in lstItemMasterDAL)
                {
                    SqlCmd.Parameters.Clear();
                    SqlCmd.Parameters.Add("@ItemMasterId", SqlDbType.Int).Value = item.ItemMasterId;
                    SqlCmd.Parameters.Add("@ItemName", SqlDbType.VarChar).Value = item.ItemName;
                    SqlCmd.Parameters.Add("@ItemCode", SqlDbType.VarChar).Value = item.ItemCode;
                    SqlCmd.Parameters.Add("@BarCode", SqlDbType.VarChar).Value = item.BarCode;
                    SqlCmd.Parameters.Add("@IsFavourite", SqlDbType.Bit).Value = item.IsFavourite;
                    SqlCmd.Parameters.Add("@linktoUnitMasterId", SqlDbType.SmallInt).Value = item.linktoUnitMasterId;
                    SqlCmd.Parameters.Add("@linktoCategoryMasterId", SqlDbType.SmallInt).Value = item.linktoCategoryMasterId;
                    SqlCmd.Parameters.Add("@ItemType", SqlDbType.SmallInt).Value = item.ItemType;
                    SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = item.linktoBusinessMasterId;
                    SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                    SqlCmd.ExecuteNonQuery();
                    rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                    if (rs == posRecordStatus.RecordAlreadyExist)
                    {
                        itemNames += item.ItemName + ", ";
                        IsAllreadyExists = true;
                    }
                    else if (rs != posRecordStatus.Error)
                    {
                        objItemRateTranDAL = new posItemRateTranDAL();
                        objItemRateTranDAL.ItemRateTranId = item.ItemRateTranId;
                        objItemRateTranDAL.linktoItemMasterId = item.ItemMasterId;
                        objItemRateTranDAL.PurchaseRate = item.PurchaseRate;
                        objItemRateTranDAL.MRP = item.MRP;
                        objItemRateTranDAL.SaleRate = item.SaleRate;
                        objItemRateTranDAL.Rate1 = item.Rate1;
                        objItemRateTranDAL.Rate2 = item.Rate2;
                        objItemRateTranDAL.Rate3 = item.Rate3;
                        objItemRateTranDAL.Rate4 = item.Rate4;
                        objItemRateTranDAL.Rate5 = item.Rate5;
                        objItemRateTranDAL.Tax1 = item.Tax1;
                        objItemRateTranDAL.Tax2 = item.Tax2;
                        objItemRateTranDAL.Tax3 = item.Tax3;
                        objItemRateTranDAL.Tax4 = item.Tax4;
                        objItemRateTranDAL.Tax5 = item.Tax5;
                        objItemRateTranDAL.IsRateTaxInclusive = item.IsRateTaxInclusive;
                        objItemRateTranDAL.RateUpdateDateTime = item.RateUpdateDateTime;
                        objItemRateTranDAL.RatelinktoUserMasterIdUpdatedBy = item.RatelinktoUserMasterIdUpdatedBy;

                        rs = posItemRateTranDAL.UpdateItemRateTran(objItemRateTranDAL, item.ItemMasterId, SqlCon, SqlTran);
                        if (rs == posRecordStatus.Error)
                        {
                            SqlTran.Rollback();
                            SqlCon.Close();
                            return posRecordStatus.Error;
                        }

                        rs = posItemCategoryTranDAL.InsertItemCategoryTran(item.linktoCategoryMasterId.ToString(), item.ItemMasterId, SqlCon, SqlTran);
                        if (rs == posRecordStatus.Error)
                        {
                            SqlTran.Rollback();
                            SqlCon.Close();
                            return rs;
                        }
                    }
                }
                if (IsAllreadyExists)
                {
                    SqlTran.Rollback();
                    SqlCon.Close();
                    return posRecordStatus.RecordAlreadyExist;
                }

                SqlTran.Commit();
                SqlCon.Close();
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
                posObjectFactoryDAL.DisposeTransaction(SqlTran);
            }
        }


        #endregion

        #region DeleteAll
        public static posRecordStatus DeleteAllItemMaster(string itemMasterIds, DateTime updateDateTime, short linkToUserMasterIdUpdatedBy, short ItemType)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posItemMaster_DeleteAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@ItemMasterIds", SqlDbType.VarChar).Value = itemMasterIds;
                SqlCmd.Parameters.Add("@UpdateDateTime", SqlDbType.DateTime).Value = updateDateTime;
                SqlCmd.Parameters.Add("@linktoUserMasterIdUpdatedBy", SqlDbType.SmallInt).Value = linkToUserMasterIdUpdatedBy;
                SqlCmd.Parameters.Add("@ItemType", SqlDbType.SmallInt).Value = ItemType;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region Select
        public bool SelectItemMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posItemMaster_Select", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@ItemMasterId", SqlDbType.Int).Value = this.ItemMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                bool IsSelected = SetClassPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                return IsSelected;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return false;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public bool SelectItemMasterModifier()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posItemMasterModifier_Select", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@ItemMasterId", SqlDbType.Int).Value = this.ItemMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                while (SqlRdr.Read())
                {
                    this.ItemMasterId = Convert.ToInt32(SqlRdr["ItemMasterId"]);
                    this.ItemName = Convert.ToString(SqlRdr["ItemName"]);
                    this.ShortName = Convert.ToString(SqlRdr["ShortName"]);
                    this.ShortDescription = Convert.ToString(SqlRdr["ShortDescription"]);
                    this.MRP = Convert.ToDouble(SqlRdr["MRP"]);
                    this.IsEnabled = Convert.ToBoolean(SqlRdr["IsEnabled"]);
                    if (SqlRdr["ImageName"] != DBNull.Value)
                    {
                        this.ImageName = Convert.ToString(SqlRdr["ImageName"]);

                        this.xs_ImagePhysicalName = "xs_" + Convert.ToString(SqlRdr["ImageName"]);
                        this.sm_ImagePhysicalName = "sm_" + Convert.ToString(SqlRdr["ImageName"]);
                        this.md_ImagePhysicalName = "md_" + Convert.ToString(SqlRdr["ImageName"]);
                        this.lg_ImagePhysicalName = "lg_" + Convert.ToString(SqlRdr["ImageName"]);
                        this.xl_ImagePhysicalName = "xl_" + Convert.ToString(SqlRdr["ImageName"]);
                    }
                }
                SqlRdr.Close();
                SqlCon.Close();

                return true;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return false;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public bool SelectItemMasterKOTItem(short tableMasterId, short orderTypeMasterId)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            bool IsSelected = false;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posItemMasterKOTItem_Select", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@ItemMasterId", SqlDbType.Int).Value = this.ItemMasterId;
                SqlCmd.Parameters.Add("@CounterMasterId", SqlDbType.SmallInt).Value = this.CounterMasterId;
                SqlCmd.Parameters.Add("@linktoOrderTypeMasterId", SqlDbType.SmallInt).Value = orderTypeMasterId;
                SqlCmd.Parameters.Add("@linktoTableMasterId", SqlDbType.SmallInt).Value = tableMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();

                if (SqlRdr.Read())
                {
                    this.ItemMasterId = Convert.ToInt32(SqlRdr["ItemMasterId"]);
                    this.ItemName = Convert.ToString(SqlRdr["ItemName"]);
                    this.ItemCode = Convert.ToString(SqlRdr["ItemCode"]);
                    this.Unit = Convert.ToString(SqlRdr["UnitName"]);
                    this.Quantity = 1;
                    this.CounterMasterId = short.Parse(SqlRdr["linktoCounterMasterId"].ToString());
                    this.SaleRate = Double.Parse(SqlRdr["SellPrice"].ToString());
                    this.ActualSaleRate = Double.Parse(SqlRdr["SellPrice"].ToString());
                    this.ItemModifierMasterIds = "0";

                    IsSelected = true;
                }

                SqlRdr.Close();
                SqlCon.Close();

                return IsSelected;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return false;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public bool SelectItemMasterCounter(short orderTypeMasterId)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            bool IsSelected = false;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posItemMasterByCounterId_Select", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@ItemMasterId", SqlDbType.Int).Value = this.ItemMasterId;
                SqlCmd.Parameters.Add("@CounterMasterId", SqlDbType.SmallInt).Value = this.CounterMasterId;
                SqlCmd.Parameters.Add("@linktoOrderTypeMasterId", SqlDbType.SmallInt).Value = orderTypeMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();

                if (SqlRdr.Read())
                {
                    this.ItemMasterId = Convert.ToInt32(SqlRdr["ItemMasterId"]);
                    this.ItemName = Convert.ToString(SqlRdr["ItemName"]);
                    this.ShortName = Convert.ToString(SqlRdr["ShortName"]);
                    this.ItemCode = Convert.ToString(SqlRdr["ItemCode"]);
                    this.ShortDescription = Convert.ToString(SqlRdr["ShortDescription"]);
                    this.ItemPoint = Convert.ToInt16(SqlRdr["ItemPoint"]);
                    this.PriceByPoint = Convert.ToInt16(SqlRdr["PriceByPoint"]);
                    this.linktoUnitMasterId = Convert.ToInt16(SqlRdr["linktoUnitMasterId"]);
                    this.SearchWords = Convert.ToString(SqlRdr["SearchWords"]);
                    this.ImageName = Convert.ToString(SqlRdr["ImageName"]);

                    if (SqlRdr["SortOrder"] != DBNull.Value)
                    {
                        this.SortOrder = Convert.ToInt32(SqlRdr["SortOrder"]);
                    }
                    this.CreateDateTime = Convert.ToDateTime(SqlRdr["CreateDateTime"]);
                    this.linktoUserMasterIdCreatedBy = Convert.ToInt16(SqlRdr["linktoUserMasterIdCreatedBy"]);
                    if (SqlRdr["UpdateDateTime"] != DBNull.Value)
                    {
                        this.UpdateDateTime = Convert.ToDateTime(SqlRdr["UpdateDateTime"]);
                    }
                    if (SqlRdr["linktoUserMasterIdUpdatedBy"] != DBNull.Value)
                    {
                        this.linktoUserMasterIdUpdatedBy = Convert.ToInt16(SqlRdr["linktoUserMasterIdUpdatedBy"]);
                    }
                    this.linktoBusinessMasterId = Convert.ToInt16(SqlRdr["linktoBusinessMasterId"]);
                    this.BarCode = Convert.ToString(SqlRdr["BarCode"]);
                    this.ItemType = Convert.ToInt16(SqlRdr["ItemType"]);
                    this.IsFavourite = Convert.ToBoolean(SqlRdr["IsFavourite"]);
                    this.IsEnabled = Convert.ToBoolean(SqlRdr["IsEnabled"]);
                    this.IsDeleted = Convert.ToBoolean(SqlRdr["IsDeleted"]);
                    this.linktoCategoryMasterId = Convert.ToInt16(SqlRdr["linktoCategoryMasterId"]);
                    /// Extra

                    this.Unit = Convert.ToString(SqlRdr["Unit"]);
                    if (SqlRdr["Price"] != DBNull.Value)
                    {
                        this.SaleRate = Convert.ToDouble(SqlRdr["Price"]);
                    }
                    if (SqlRdr["MRP"] != DBNull.Value)
                    {
                        this.MRP = Convert.ToDouble(SqlRdr["MRP"]);
                    }
                    if (SqlRdr["TaxRate"] != DBNull.Value)
                    {
                        this.TaxRate = Convert.ToDouble(SqlRdr["TaxRate"]);
                    }
                    this.RateIndex = Convert.ToInt16(SqlRdr["RateIndex"]);
                    this.Tax = Convert.ToString(SqlRdr["Tax"]);
                }

                SqlRdr.Close();
                SqlCon.Close();

                return IsSelected;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return false;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region SelectAll
        public List<posItemMasterDAL> SelectAllItemMasterByCategoryMasterId(short orderTypeMasterId, string itemMasterIds)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posItemMasterByCategoryMasterId_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                if (linktoCategoryMasterId > 0)
                {
                    SqlCmd.Parameters.Add("@linktoCategoryMasterId", SqlDbType.SmallInt).Value = this.linktoCategoryMasterId;
                }
                SqlCmd.Parameters.Add("@linktoCounterMasterId", SqlDbType.SmallInt).Value = this.CounterMasterId;
                SqlCmd.Parameters.Add("@linktoOrderTypeMasterId", SqlDbType.SmallInt).Value = orderTypeMasterId;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = linktoBusinessMasterId;
                if (IsFavourite != null)
                {
                    SqlCmd.Parameters.Add("@IsFavourite", SqlDbType.Bit).Value = this.IsFavourite;
                }
                if (itemMasterIds != "null")
                {
                    SqlCmd.Parameters.Add("@ItemMasterIds", SqlDbType.VarChar).Value = itemMasterIds;
                }

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<posItemMasterDAL> lstItemMasterDAL = new List<posItemMasterDAL>();
                posItemMasterDAL objItemMasterDAL = null;

                while (SqlRdr.Read())
                {
                    objItemMasterDAL = new posItemMasterDAL();
                    objItemMasterDAL.ItemMasterId = Convert.ToInt32(SqlRdr["ItemMasterId"]);
                    objItemMasterDAL.ItemName = Convert.ToString(SqlRdr["ItemName"]);
                    objItemMasterDAL.ShortName = Convert.ToString(SqlRdr["ShortName"]);
                    objItemMasterDAL.ItemCode = Convert.ToString(SqlRdr["ItemCode"]);
                    objItemMasterDAL.BarCode = Convert.ToString(SqlRdr["BarCode"]);
                    objItemMasterDAL.ShortDescription = Convert.ToString(SqlRdr["ShortDescription"]);
                    objItemMasterDAL.ItemPoint = Convert.ToInt16(SqlRdr["ItemPoint"]);
                    objItemMasterDAL.PriceByPoint = Convert.ToInt16(SqlRdr["PriceByPoint"]);
                    objItemMasterDAL.linktoUnitMasterId = Convert.ToInt16(SqlRdr["linktoUnitMasterId"]);
                    objItemMasterDAL.SearchWords = Convert.ToString(SqlRdr["SearchWords"]);
                    if (SqlRdr["ImageName"] != DBNull.Value)
                    {
                        objItemMasterDAL.ImageName = Convert.ToString(SqlRdr["ImageName"]);

                        objItemMasterDAL.xs_ImagePhysicalName = "xs_" + Convert.ToString(SqlRdr["ImageName"]);
                        objItemMasterDAL.sm_ImagePhysicalName = "sm_" + Convert.ToString(SqlRdr["ImageName"]);
                        objItemMasterDAL.md_ImagePhysicalName = "md_" + Convert.ToString(SqlRdr["ImageName"]);
                        objItemMasterDAL.lg_ImagePhysicalName = "lg_" + Convert.ToString(SqlRdr["ImageName"]);
                        objItemMasterDAL.xl_ImagePhysicalName = "xl_" + Convert.ToString(SqlRdr["ImageName"]);

                    }

                    if (SqlRdr["SortOrder"] != DBNull.Value)
                    {
                        objItemMasterDAL.SortOrder = Convert.ToInt32(SqlRdr["SortOrder"]);
                    }
                    objItemMasterDAL.CreateDateTime = Convert.ToDateTime(SqlRdr["CreateDateTime"]);
                    objItemMasterDAL.linktoUserMasterIdCreatedBy = Convert.ToInt16(SqlRdr["linktoUserMasterIdCreatedBy"]);
                    if (SqlRdr["UpdateDateTime"] != DBNull.Value)
                    {
                        objItemMasterDAL.UpdateDateTime = Convert.ToDateTime(SqlRdr["UpdateDateTime"]);
                    }
                    if (SqlRdr["linktoUserMasterIdUpdatedBy"] != DBNull.Value)
                    {
                        objItemMasterDAL.linktoUserMasterIdUpdatedBy = Convert.ToInt16(SqlRdr["linktoUserMasterIdUpdatedBy"]);
                    }
                    objItemMasterDAL.linktoBusinessMasterId = Convert.ToInt16(SqlRdr["linktoBusinessMasterId"]);

                    objItemMasterDAL.ItemType = Convert.ToInt16(SqlRdr["ItemType"]);
                    objItemMasterDAL.IsFavourite = Convert.ToBoolean(SqlRdr["IsFavourite"]);
                    objItemMasterDAL.IsEnabled = Convert.ToBoolean(SqlRdr["IsEnabled"]);
                    objItemMasterDAL.IsDeleted = Convert.ToBoolean(SqlRdr["IsDeleted"]);
                    objItemMasterDAL.linktoCategoryMasterId = Convert.ToInt16(SqlRdr["linktoCategoryMasterId"]);
                    /// Extra

                    objItemMasterDAL.Unit = Convert.ToString(SqlRdr["Unit"]);

                    if (SqlRdr["CategoryName"] != DBNull.Value)
                    {
                        objItemMasterDAL.CategoryName = Convert.ToString(SqlRdr["CategoryName"]);
                    }
                    if (SqlRdr["MRP"] != DBNull.Value)
                    {
                        objItemMasterDAL.MRP = Convert.ToDouble(SqlRdr["MRP"]);
                    }
                    if (SqlRdr["Price"] != DBNull.Value)
                    {
                        objItemMasterDAL.SaleRate = Convert.ToDouble(SqlRdr["Price"]);
                    }
                    if (SqlRdr["TaxRate"] != DBNull.Value)
                    {
                        objItemMasterDAL.TaxRate = Convert.ToDouble(SqlRdr["TaxRate"]);
                    }
                    if (SqlRdr["RateIndex"] != DBNull.Value)
                    {
                        objItemMasterDAL.RateIndex = Convert.ToInt16(SqlRdr["RateIndex"]);
                    }
                    objItemMasterDAL.Tax = Convert.ToString(SqlRdr["Tax"]);
                    objItemMasterDAL.OptionValueTranIds = Convert.ToString(SqlRdr["OptionValueTranIds"]);
                    objItemMasterDAL.ItemModifierMasterIds = Convert.ToString(SqlRdr["ItemModifierMasterIds"]);
                    objItemMasterDAL.IsDineInOnly = Convert.ToBoolean(SqlRdr["IsDineInOnly"]);
                    lstItemMasterDAL.Add(objItemMasterDAL);
                }
                SqlRdr.Close();
                SqlCon.Close();

                return lstItemMasterDAL;
            }
            catch (Exception ex)
            {
                //totalRecords = 0;
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public List<posItemMasterDAL> SelectAllItemMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posItemMaster_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@ItemName", SqlDbType.VarChar).Value = this.ItemName;
                SqlCmd.Parameters.Add("@IsFavourite", SqlDbType.Bit).Value = this.IsFavourite;
                if (this.linktoCategoryMasterId > 0)
                {
                    SqlCmd.Parameters.Add("@CategoryMasterId", SqlDbType.SmallInt).Value = this.linktoCategoryMasterId;
                }
                SqlCmd.Parameters.Add("@ItemType", SqlDbType.SmallInt).Value = this.ItemType;
                SqlCmd.Parameters.Add("@IsEnabled", SqlDbType.Bit).Value = this.IsEnabled;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<posItemMasterDAL> lstItemMasterDAL = SetListPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                return lstItemMasterDAL;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public List<posItemMasterDAL> SelectAllItemMasterBYAddlessMasterID(short? addLessMasterId)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posItemMasterWithAddlessTran_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@linktoAddLessMasterId", SqlDbType.SmallInt).Value = addLessMasterId;
                SqlCmd.Parameters.Add("@ItemType", SqlDbType.SmallInt).Value = this.ItemType;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<posItemMasterDAL> lstItemMasterDAL = new List<posItemMasterDAL>();
                posItemMasterDAL objItemMasterDAL = null;
                while (SqlRdr.Read())
                {
                    objItemMasterDAL = new posItemMasterDAL();
                    objItemMasterDAL.ItemMasterId = Convert.ToInt32(SqlRdr["ItemMasterId"]);
                    objItemMasterDAL.ItemName = Convert.ToString(SqlRdr["ItemName"]) + " (" + Convert.ToString(SqlRdr["ItemCode"]) + ")";
                    objItemMasterDAL.ItemCode = Convert.ToString(SqlRdr["ItemCode"]);
                    if (SqlRdr["Category"] != DBNull.Value)
                    {
                        objItemMasterDAL.CategoryName = Convert.ToString(SqlRdr["Category"]);
                    }
                    if (SqlRdr["AddLessItemTranId"] != DBNull.Value)
                    {
                        objItemMasterDAL.IsSelected = true;
                    }
                    lstItemMasterDAL.Add(objItemMasterDAL);
                }

                SqlRdr.Close();
                SqlCon.Close();

                return lstItemMasterDAL;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public List<posItemMasterDAL> SelectAllItemMasterByItemMasterIds(string itemMasterIds)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posItemMasterByItemMasterIds_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@ItemMasterIds", SqlDbType.VarChar).Value = itemMasterIds;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<posItemMasterDAL> lstItemMasterDAL = new List<posItemMasterDAL>();
                posItemMasterDAL objItemMasterDAL = null;
                while (SqlRdr.Read())
                {
                    objItemMasterDAL = new posItemMasterDAL();
                    objItemMasterDAL.ItemMasterId = Convert.ToInt32(SqlRdr["ItemMasterId"]);
                    objItemMasterDAL.ItemName = Convert.ToString(SqlRdr["ItemName"]);
                    objItemMasterDAL.ItemCode = Convert.ToString(SqlRdr["ItemCode"]);
                    objItemMasterDAL.BarCode = Convert.ToString(SqlRdr["BarCode"]);
                    objItemMasterDAL.linktoUnitMasterId = Convert.ToInt16(SqlRdr["linktoUnitMasterId"]);
                    objItemMasterDAL.linktoCategoryMasterId = Convert.ToInt16(SqlRdr["linktoCategoryMasterId"]);
                    objItemMasterDAL.IsFavourite = Convert.ToBoolean(SqlRdr["IsFavourite"]);
                    objItemMasterDAL.PurchaseRate = Convert.ToDouble(SqlRdr["PurchaseRate"]);
                    objItemMasterDAL.MRP = Convert.ToDouble(SqlRdr["MRP"]);
                    objItemMasterDAL.SaleRate = Convert.ToDouble(SqlRdr["SaleRate"]);
                    objItemMasterDAL.Rate1 = Convert.ToDouble(SqlRdr["Rate1"]);
                    objItemMasterDAL.Rate2 = Convert.ToDouble(SqlRdr["Rate2"]);
                    objItemMasterDAL.Rate3 = Convert.ToDouble(SqlRdr["Rate3"]);
                    objItemMasterDAL.Rate4 = Convert.ToDouble(SqlRdr["Rate4"]);
                    objItemMasterDAL.Rate5 = Convert.ToDouble(SqlRdr["Rate5"]);
                    objItemMasterDAL.Tax1 = Convert.ToDecimal(SqlRdr["Tax1"]);
                    objItemMasterDAL.Tax2 = Convert.ToDecimal(SqlRdr["Tax2"]);
                    objItemMasterDAL.Tax3 = Convert.ToDecimal(SqlRdr["Tax3"]);
                    objItemMasterDAL.Tax4 = Convert.ToDecimal(SqlRdr["Tax4"]);
                    objItemMasterDAL.Tax5 = Convert.ToDecimal(SqlRdr["Tax5"]);
                    objItemMasterDAL.IsRateTaxInclusive = Convert.ToBoolean(SqlRdr["IsRateTaxInclusive"]);
                    lstItemMasterDAL.Add(objItemMasterDAL);
                }

                SqlRdr.Close();
                SqlCon.Close();

                return lstItemMasterDAL;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public static List<posItemMasterDAL> SelectAllItemMasterItemName(short Itemtype, short linktoBusinessMasterId, int linkToCategoryMasterId = 0)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posItemMasterItemName_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;
                SqlCmd.Parameters.Add("@ItemType", SqlDbType.SmallInt).Value = Itemtype;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = linktoBusinessMasterId;
                SqlCmd.Parameters.Add("@linkToCategoryMasterId", SqlDbType.SmallInt).Value = linkToCategoryMasterId;
                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<posItemMasterDAL> lstItemMasterDAL = new List<posItemMasterDAL>();
                posItemMasterDAL objItemMasterDAL = null;
                while (SqlRdr.Read())
                {
                    objItemMasterDAL = new posItemMasterDAL();
                    objItemMasterDAL.ItemMasterId = Convert.ToInt32(SqlRdr["ItemMasterId"]);
                    objItemMasterDAL.ItemName = Convert.ToString(SqlRdr["ItemName"]);
                    objItemMasterDAL.ItemCode = Convert.ToString(SqlRdr["ItemCode"]);
                    objItemMasterDAL.linktoUnitMasterId = Convert.ToInt16(SqlRdr["linktoUnitMasterId"]);
                    objItemMasterDAL.Unit = Convert.ToString(SqlRdr["Unit"]);
                    if (SqlRdr["linktoCategoryMasterId"] != DBNull.Value)
                    {
                        objItemMasterDAL.linktoCategoryMasterId = Convert.ToInt16(SqlRdr["linktoCategoryMasterId"]);
                    }
                    lstItemMasterDAL.Add(objItemMasterDAL);
                }
                SqlRdr.Close();
                SqlCon.Close();

                return lstItemMasterDAL;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public static List<posItemMasterDAL> SelectAllItemMasterItemNameSupplierWise(short Itemtype, short linktoBusinessMasterId, string CategoryMasterIds, short SupplierMasterId)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posItemMasterItemNameSupplierWise_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@ItemType", SqlDbType.SmallInt).Value = Itemtype;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = linktoBusinessMasterId;
                SqlCmd.Parameters.Add("@CategoryMasterIds", SqlDbType.VarChar).Value = CategoryMasterIds;
                SqlCmd.Parameters.Add("@linktoSupplierMasterId", SqlDbType.SmallInt).Value = SupplierMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<posItemMasterDAL> lstItemMasterDAL = new List<posItemMasterDAL>();
                posItemMasterDAL objItemMasterDAL = null;
                while (SqlRdr.Read())
                {
                    objItemMasterDAL = new posItemMasterDAL();
                    objItemMasterDAL.ItemMasterId = Convert.ToInt32(SqlRdr["ItemMasterId"]);
                    objItemMasterDAL.ItemName = Convert.ToString(SqlRdr["ItemName"]);
                    objItemMasterDAL.ItemCode = Convert.ToString(SqlRdr["ItemCode"]);

                    lstItemMasterDAL.Add(objItemMasterDAL);
                }
                SqlRdr.Close();
                SqlCon.Close();

                return lstItemMasterDAL;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public List<posItemMasterDAL> SelectAllItemMasterByCategoryAndCounter(int? CustomerMasterId = null)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            posItemMasterDAL objItemMaster = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posItemMasterByCategory_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@ItemType", SqlDbType.SmallInt).Value = this.ItemType;
                SqlCmd.Parameters.Add("@linktoCategoryMasterId", SqlDbType.SmallInt).Value = this.linktoCategoryMasterId;
                SqlCmd.Parameters.Add("@CounterMasterId", SqlDbType.SmallInt).Value = this.CounterMasterId;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                if (CustomerMasterId > 0)
                {
                    SqlCmd.Parameters.Add("@CustomerMasterId", SqlDbType.Int).Value = CustomerMasterId;
                }

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<posItemMasterDAL> lstItemMasterDAL = new List<posItemMasterDAL>();

                while (SqlRdr.Read())
                {
                    objItemMaster = new posItemMasterDAL();
                    objItemMaster.ItemMasterId = Convert.ToInt32(SqlRdr["ItemMasterId"]);
                    objItemMaster.ItemName = Convert.ToString(SqlRdr["ItemName"]);
                    objItemMaster.ShortName = Convert.ToString(SqlRdr["ShortName"]);
                    objItemMaster.ItemCode = Convert.ToString(SqlRdr["ItemCode"]);

                    objItemMaster.ItemType = Convert.ToInt16(SqlRdr["ItemType"]);
                    objItemMaster.IsFavourite = Convert.ToBoolean(SqlRdr["IsFavourite"]);
                    objItemMaster.IsDineInOnly = Convert.ToBoolean(SqlRdr["IsDineInOnly"]);
                    objItemMaster.linktoCategoryMasterId = Convert.ToInt16(SqlRdr["linktoCategoryMasterId"]);

                    if (SqlRdr["Discount"] != DBNull.Value)
                    {
                        objItemMaster.Discount = Convert.ToDouble(SqlRdr["Discount"]);
                        objItemMaster.IsPercentage = Convert.ToBoolean(SqlRdr["IsPercentage"]);
                    }

                    if (SqlRdr["ImageName"] != DBNull.Value)
                    {
                        objItemMaster.ImageName = Convert.ToString(SqlRdr["ImageName"]);

                        objItemMaster.xs_ImagePhysicalName = "xs_" + Convert.ToString(SqlRdr["ImageName"]);
                        objItemMaster.sm_ImagePhysicalName = "sm_" + Convert.ToString(SqlRdr["ImageName"]);
                        objItemMaster.md_ImagePhysicalName = "md_" + Convert.ToString(SqlRdr["ImageName"]);
                        objItemMaster.lg_ImagePhysicalName = "lg_" + Convert.ToString(SqlRdr["ImageName"]);
                        objItemMaster.xl_ImagePhysicalName = "xl_" + Convert.ToString(SqlRdr["ImageName"]);

                    }
                    if (SqlRdr["linktoOptionValueTranId"] != DBNull.Value)
                    {
                        objItemMaster.linktoOptionValueTranId = Convert.ToInt32(SqlRdr["linktoOptionValueTranId"]);
                    }
                    objItemMaster.MRP = Convert.ToDouble(SqlRdr["MRP"]);
                    objItemMaster.Rate1 = Convert.ToDouble(SqlRdr["Rate1"]);
                    objItemMaster.Rate2 = Convert.ToDouble(SqlRdr["Rate2"]);
                    objItemMaster.Rate3 = Convert.ToDouble(SqlRdr["Rate3"]);
                    objItemMaster.Rate4 = Convert.ToDouble(SqlRdr["Rate4"]);
                    objItemMaster.Rate5 = Convert.ToDouble(SqlRdr["Rate5"]);
                    objItemMaster.IsRateTaxInclusive = Convert.ToBoolean(SqlRdr["IsRateTaxInclusive"]);
                    objItemMaster.Tax1 = Convert.ToDecimal(SqlRdr["Tax1"]);
                    objItemMaster.Tax2 = Convert.ToDecimal(SqlRdr["Tax2"]);
                    objItemMaster.Tax3 = Convert.ToDecimal(SqlRdr["Tax3"]);
                    objItemMaster.Tax4 = Convert.ToDecimal(SqlRdr["Tax4"]);
                    objItemMaster.Tax5 = Convert.ToDecimal(SqlRdr["Tax5"]);

                    lstItemMasterDAL.Add(objItemMaster);
                }
                SqlRdr.Close();
                SqlCon.Close();
                return lstItemMasterDAL;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public List<posItemMasterDAL> SelectAllItemMasterPriceCounterWiseReport(string itemCategoryMasterIds, string itemMasterIds)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posItemMasterPriceCounterWiseReport_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@ItemMasterIds", SqlDbType.VarChar).Value = itemMasterIds;
                SqlCmd.Parameters.Add("@CategoryMasterIds", SqlDbType.VarChar).Value = itemCategoryMasterIds;


                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<posItemMasterDAL> lstItemMasterDAL = new List<posItemMasterDAL>();
                posItemMasterDAL objItemMasterDAL = null;
                while (SqlRdr.Read())
                {
                    objItemMasterDAL = new posItemMasterDAL();
                    objItemMasterDAL.ItemMasterId = Convert.ToInt32(SqlRdr["ItemMasterId"]);
                    objItemMasterDAL.ItemName = Convert.ToString(SqlRdr["ItemName"]);
                    objItemMasterDAL.ItemCode = Convert.ToString(SqlRdr["ItemCode"]);
                    objItemMasterDAL.CategoryName = Convert.ToString(SqlRdr["CategoryName"]);
                    objItemMasterDAL.CounterName = Convert.ToString(SqlRdr["CounterName"]);
                    objItemMasterDAL.SaleRate = Convert.ToDouble(SqlRdr["Price"]);
                    lstItemMasterDAL.Add(objItemMasterDAL);
                }
                SqlRdr.Close();
                SqlCon.Close();

                return lstItemMasterDAL;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public List<posItemMasterDAL> SelectAllItemMasterModifier()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posItemMasterModifier_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@IsEnabled", SqlDbType.Bit).Value = this.IsEnabled;
                SqlCmd.Parameters.Add("@ItemType", SqlDbType.SmallInt).Value = this.ItemType;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<posItemMasterDAL> lstItemMasterDAL = new List<posItemMasterDAL>();
                posItemMasterDAL objItemMasterDAL = null;
                while (SqlRdr.Read())
                {
                    objItemMasterDAL = new posItemMasterDAL();

                    objItemMasterDAL.ItemMasterId = Convert.ToInt32(SqlRdr["ItemMasterId"]);
                    objItemMasterDAL.ItemName = Convert.ToString(SqlRdr["ItemName"]);
                    objItemMasterDAL.ShortName = Convert.ToString(SqlRdr["ShortName"]);
                    objItemMasterDAL.ShortDescription = Convert.ToString(SqlRdr["ShortDescription"]);
                    objItemMasterDAL.MRP = Convert.ToDouble(SqlRdr["MRP"]);
                    lstItemMasterDAL.Add(objItemMasterDAL);
                }
                SqlRdr.Close();
                SqlCon.Close();

                return lstItemMasterDAL;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public List<posItemMasterDAL> SelectAllItemMasterByTableMasterIds(string tableMasterIds)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posItemMasterByTableMasterIds_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@TableMasterIds", SqlDbType.VarChar).Value = tableMasterIds;
                SqlCmd.Parameters.Add("@FromDate", SqlDbType.DateTime).Value = this.CreateDateTime;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<posItemMasterDAL> lstItemMasterDAL = new List<posItemMasterDAL>();
                posItemMasterDAL objItemMasterDAL = null;
                while (SqlRdr.Read())
                {
                    objItemMasterDAL = new posItemMasterDAL();
                    objItemMasterDAL.ItemMasterId = Convert.ToInt32(SqlRdr["ItemMasterId"]);
                    objItemMasterDAL.ItemName = Convert.ToString(SqlRdr["ItemName"]);
                    objItemMasterDAL.ItemCode = Convert.ToString(SqlRdr["ItemCode"]);
                    objItemMasterDAL.Unit = Convert.ToString(SqlRdr["UnitName"]);
                    objItemMasterDAL.Quantity = Convert.ToInt16(SqlRdr["Quantity"]);
                    objItemMasterDAL.SaleRate = Double.Parse(SqlRdr["Rate"].ToString());
                    objItemMasterDAL.ActualSaleRate = Double.Parse(SqlRdr["ActualPrice"].ToString());
                    objItemMasterDAL.ItemModifierMasterIds = Convert.ToString(SqlRdr["ItemModifierMasterIds"]);
                    objItemMasterDAL.Remark = Convert.ToString(SqlRdr["ItemRemark"]);
                    objItemMasterDAL.ItemPoint = Convert.ToInt16(SqlRdr["ItemPoint"]);
                    objItemMasterDAL.linktoOrderMasterId = Convert.ToInt16(SqlRdr["OrderMasterId"]);
                    objItemMasterDAL.linktoUnitMasterId = Convert.ToInt16(SqlRdr["linktoUnitMasterId"]);
                    objItemMasterDAL.OrderItemTranId = Convert.ToInt16(SqlRdr["OrderItemTranId"]);
                    objItemMasterDAL.Tax1 = Convert.ToDecimal(SqlRdr["Tax1"]);
                    objItemMasterDAL.Tax2 = Convert.ToDecimal(SqlRdr["Tax2"]);
                    objItemMasterDAL.Tax3 = Convert.ToDecimal(SqlRdr["Tax3"]);
                    objItemMasterDAL.Tax4 = Convert.ToDecimal(SqlRdr["Tax4"]);
                    objItemMasterDAL.Tax5 = Convert.ToDecimal(SqlRdr["Tax5"]);
                    //objItemMasterDAL.Discount = Convert.ToDouble(SqlRdr["Discount"]);
                    lstItemMasterDAL.Add(objItemMasterDAL);
                }

                SqlRdr.Close();
                SqlCon.Close();
                return lstItemMasterDAL;

            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }

        }

        public List<posItemMasterDAL> SelectAllItemMasterComboItems()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posItemMasterComboItem_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;
                SqlCmd.Parameters.Add("@ItemType", SqlDbType.SmallInt).Value = this.ItemType;
                SqlCmd.Parameters.Add("@linktoItemMasterId", SqlDbType.SmallInt).Value = this.ItemMasterId;
                SqlCmd.Parameters.Add("@linktobusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<posItemMasterDAL> lstItemMasterDAL = new List<posItemMasterDAL>();
                posItemMasterDAL objItemMasterDAL = null;
                while (SqlRdr.Read())
                {
                    objItemMasterDAL = new posItemMasterDAL();
                    objItemMasterDAL.ItemMasterId = Convert.ToInt32(SqlRdr["ItemMasterId"]);
                    objItemMasterDAL.ItemName = Convert.ToString(SqlRdr["ItemName"]) + " (" + Convert.ToString(SqlRdr["ItemCode"]) + ")";
                    if (SqlRdr["ItemComboTranId"] != DBNull.Value)
                    {
                        objItemMasterDAL.IsSelected = true;
                    }
                    else
                    {
                        objItemMasterDAL.IsSelected = false;
                    }
                    objItemMasterDAL.CategoryName = Convert.ToString(SqlRdr["CategoryName"]);
                    lstItemMasterDAL.Add(objItemMasterDAL);
                }
                SqlRdr.Close();
                SqlCon.Close();

                return lstItemMasterDAL;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public List<posItemMasterDAL> SelectAllItemMasterSaleItemBySalesMasterID(long salesMasterId)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;

            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posItemMasterSaleItemBySalesMasterID_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@SalesMasterId", SqlDbType.BigInt).Value = salesMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<posItemMasterDAL> lstItemMasterDAL = new List<posItemMasterDAL>();
                posItemMasterDAL objItemMasterDAL = null;
                while (SqlRdr.Read())
                {
                    objItemMasterDAL = new posItemMasterDAL();
                    objItemMasterDAL.ItemMasterId = Convert.ToInt32(SqlRdr["ItemMasterId"]);
                    objItemMasterDAL.ItemName = Convert.ToString(SqlRdr["ItemName"]);
                    objItemMasterDAL.ItemCode = Convert.ToString(SqlRdr["ItemCode"]);
                    objItemMasterDAL.Unit = Convert.ToString(SqlRdr["UnitName"]);
                    objItemMasterDAL.Quantity = Convert.ToInt16(SqlRdr["Quantity"]);
                    objItemMasterDAL.CounterMasterId = short.Parse(SqlRdr["linktoCounterMasterId"].ToString());
                    objItemMasterDAL.SaleRate = Double.Parse(SqlRdr["Rate"].ToString());
                    objItemMasterDAL.ActualSaleRate = Double.Parse(SqlRdr["ActualPrice"].ToString());
                    objItemMasterDAL.ItemModifierMasterIds = Convert.ToString(SqlRdr["ItemModifierMasterIds"]);
                    objItemMasterDAL.Remark = Convert.ToString(SqlRdr["ItemRemark"]);
                    lstItemMasterDAL.Add(objItemMasterDAL);
                }

                SqlRdr.Close();
                SqlCon.Close();
                return lstItemMasterDAL;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public List<posItemMasterDAL> SelectAllCounterItemTranWithAddlessTran(short? addLessMasterId)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posCounterItemTranWithAddlessTran_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@linktoAddLessMasterId", SqlDbType.SmallInt).Value = addLessMasterId;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();

                List<posItemMasterDAL> lstItemMasterDAL = new List<posItemMasterDAL>();
                posItemMasterDAL objItemMasterDAL = null;
                while (SqlRdr.Read())
                {
                    objItemMasterDAL = new posItemMasterDAL();
                    objItemMasterDAL.ItemMasterId = Convert.ToInt32(SqlRdr["ItemMasterId"]);
                    objItemMasterDAL.ItemName = Convert.ToString(SqlRdr["ItemName"]) + " (" + Convert.ToString(SqlRdr["ItemCode"]) + ")";
                    objItemMasterDAL.ItemCode = Convert.ToString(SqlRdr["ItemCode"]);
                    if (SqlRdr["Category"] != DBNull.Value)
                    {
                        objItemMasterDAL.CategoryName = Convert.ToString(SqlRdr["Category"]);
                    }
                    if (SqlRdr["AddLessItemTranId"] != DBNull.Value)
                    {
                        objItemMasterDAL.IsSelected = true;
                    }
                    lstItemMasterDAL.Add(objItemMasterDAL);
                }

                SqlRdr.Close();
                SqlCon.Close();
                return lstItemMasterDAL;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public List<posItemMasterDAL> SelectAllItemMasterNameFromCatertoryTran()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posItemMasterItemNameByCategory_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<posItemMasterDAL> lstItemMasterDAL = new List<posItemMasterDAL>();
                posItemMasterDAL objItemMasterDAL = null;
                while (SqlRdr.Read())
                {
                    objItemMasterDAL = new posItemMasterDAL();
                    objItemMasterDAL.ItemMasterId = Convert.ToInt32(SqlRdr["ItemMasterId"]);
                    objItemMasterDAL.ItemName = Convert.ToString(SqlRdr["ItemName"]);
                    objItemMasterDAL.linktoCategoryMasterId = Convert.ToInt16(SqlRdr["CategoryMasterId"]);
                    lstItemMasterDAL.Add(objItemMasterDAL);
                }

                SqlRdr.Close();
                SqlCon.Close();

                return lstItemMasterDAL;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public static List<posItemMasterDAL> SelectAllItemMasterByMostSellingItems(DateTime FromDate, DateTime ToDate, short linktoBusinessMasterId)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posItemMasterByMostSellingItems_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@FromDate", SqlDbType.DateTime).Value = FromDate;
                SqlCmd.Parameters.Add("@ToDate", SqlDbType.DateTime).Value = ToDate;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = linktoBusinessMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<posItemMasterDAL> lstItemMasterDAL = new List<posItemMasterDAL>();
                posItemMasterDAL objItemMasterDAL = null;
                while (SqlRdr.Read())
                {
                    objItemMasterDAL = new posItemMasterDAL();
                    objItemMasterDAL.ItemMasterId = Convert.ToInt32(SqlRdr["ItemMasterId"]);
                    objItemMasterDAL.ItemName = Convert.ToString(SqlRdr["ItemName"]);
                    lstItemMasterDAL.Add(objItemMasterDAL);
                }

                SqlRdr.Close();
                SqlCon.Close();

                return lstItemMasterDAL;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public static List<posItemMasterDAL> SelectAllItemMasterBySupplierMasterId(short linktoSupplierMasterId, short linktoBusinessMasterId)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posItemMasterBySupplierMasterId_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;
                SqlCmd.Parameters.Add("@linktoSupplierMasterId", SqlDbType.SmallInt).Value = linktoSupplierMasterId;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = linktoBusinessMasterId;
                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<posItemMasterDAL> lstItemMasterDAL = new List<posItemMasterDAL>();
                posItemMasterDAL objItemMasterDAL = null;
                while (SqlRdr.Read())
                {
                    objItemMasterDAL = new posItemMasterDAL();
                    objItemMasterDAL.ItemMasterId = Convert.ToInt32(SqlRdr["ItemMasterId"]);
                    objItemMasterDAL.ItemName = Convert.ToString(SqlRdr["ItemName"]);
                    objItemMasterDAL.ItemCode = Convert.ToString(SqlRdr["ItemCode"]);
                    objItemMasterDAL.linktoUnitMasterId = Convert.ToInt16(SqlRdr["linktoUnitMasterId"]);
                    objItemMasterDAL.Unit = Convert.ToString(SqlRdr["UnitName"]);

                    lstItemMasterDAL.Add(objItemMasterDAL);
                }
                SqlRdr.Close();
                SqlCon.Close();

                return lstItemMasterDAL;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public List<posItemMasterDAL> SelectAllItemSuggested(int linktoItemMasterId)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posItemSuggested_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCmd.Parameters.Add("@linktoItemMasterId", SqlDbType.Int).Value = linktoItemMasterId;
                SqlCmd.Parameters.Add("@RateIndex", SqlDbType.SmallInt).Value = RateIndex;
                if (IsDineInOnly)
                {
                    SqlCmd.Parameters.Add("@IsDineInOnly", SqlDbType.Bit).Value = IsDineInOnly;
                }
                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<posItemMasterDAL> lstItemMasterDAL = new List<posItemMasterDAL>();
                posItemMasterDAL objItemMasterDAL;
                while (SqlRdr.Read())
                {
                    objItemMasterDAL = new posItemMasterDAL();
                    objItemMasterDAL.ItemMasterId = Convert.ToInt32(SqlRdr["ItemMasterId"]);
                    objItemMasterDAL.ItemName = Convert.ToString(SqlRdr["ItemName"]);
                    objItemMasterDAL.ShortName = Convert.ToString(SqlRdr["ShortName"]);
                    objItemMasterDAL.ItemCode = Convert.ToString(SqlRdr["ItemCode"]);
                    objItemMasterDAL.BarCode = Convert.ToString(SqlRdr["BarCode"]);
                    objItemMasterDAL.ShortDescription = Convert.ToString(SqlRdr["ShortDescription"]);
                    objItemMasterDAL.ItemPoint = Convert.ToInt16(SqlRdr["ItemPoint"]);
                    objItemMasterDAL.PriceByPoint = Convert.ToInt16(SqlRdr["PriceByPoint"]);
                    objItemMasterDAL.linktoUnitMasterId = Convert.ToInt16(SqlRdr["linktoUnitMasterId"]);
                    objItemMasterDAL.SearchWords = Convert.ToString(SqlRdr["SearchWords"]);
                    if (SqlRdr["ImageName"] != DBNull.Value)
                    {
                        objItemMasterDAL.ImageName = Convert.ToString(SqlRdr["ImageName"]);

                        objItemMasterDAL.xs_ImagePhysicalName = "xs_" + Convert.ToString(SqlRdr["ImageName"]);
                        objItemMasterDAL.sm_ImagePhysicalName = "sm_" + Convert.ToString(SqlRdr["ImageName"]);
                        objItemMasterDAL.md_ImagePhysicalName = "md_" + Convert.ToString(SqlRdr["ImageName"]);
                        objItemMasterDAL.lg_ImagePhysicalName = "lg_" + Convert.ToString(SqlRdr["ImageName"]);
                        objItemMasterDAL.xl_ImagePhysicalName = "xl_" + Convert.ToString(SqlRdr["ImageName"]);

                    }

                    if (SqlRdr["SortOrder"] != DBNull.Value)
                    {
                        objItemMasterDAL.SortOrder = Convert.ToInt32(SqlRdr["SortOrder"]);
                    }
                    objItemMasterDAL.CreateDateTime = Convert.ToDateTime(SqlRdr["CreateDateTime"]);
                    objItemMasterDAL.linktoUserMasterIdCreatedBy = Convert.ToInt16(SqlRdr["linktoUserMasterIdCreatedBy"]);
                    if (SqlRdr["UpdateDateTime"] != DBNull.Value)
                    {
                        objItemMasterDAL.UpdateDateTime = Convert.ToDateTime(SqlRdr["UpdateDateTime"]);
                    }
                    if (SqlRdr["linktoUserMasterIdUpdatedBy"] != DBNull.Value)
                    {
                        objItemMasterDAL.linktoUserMasterIdUpdatedBy = Convert.ToInt16(SqlRdr["linktoUserMasterIdUpdatedBy"]);
                    }
                    objItemMasterDAL.linktoBusinessMasterId = Convert.ToInt16(SqlRdr["linktoBusinessMasterId"]);

                    objItemMasterDAL.ItemType = Convert.ToInt16(SqlRdr["ItemType"]);
                    objItemMasterDAL.IsFavourite = Convert.ToBoolean(SqlRdr["IsFavourite"]);
                    objItemMasterDAL.IsEnabled = Convert.ToBoolean(SqlRdr["IsEnabled"]);
                    objItemMasterDAL.IsDeleted = Convert.ToBoolean(SqlRdr["IsDeleted"]);
                    objItemMasterDAL.linktoCategoryMasterId = Convert.ToInt16(SqlRdr["linktoCategoryMasterId"]);
                    /// Extra

                    objItemMasterDAL.Unit = Convert.ToString(SqlRdr["Unit"]);

                    if (SqlRdr["CategoryName"] != DBNull.Value)
                    {
                        objItemMasterDAL.CategoryName = Convert.ToString(SqlRdr["CategoryName"]);
                    }
                    if (SqlRdr["MRP"] != DBNull.Value)
                    {
                        objItemMasterDAL.MRP = Convert.ToDouble(SqlRdr["MRP"]);
                    }
                    if (SqlRdr["Price"] != DBNull.Value)
                    {
                        objItemMasterDAL.SaleRate = Convert.ToDouble(SqlRdr["Price"]);
                    }
                    if (SqlRdr["TaxRate"] != DBNull.Value)
                    {
                        objItemMasterDAL.TaxRate = Convert.ToDouble(SqlRdr["TaxRate"]);
                    }
                    objItemMasterDAL.RateIndex = Convert.ToInt16(SqlRdr["RateIndex"]);
                    objItemMasterDAL.Tax = Convert.ToString(SqlRdr["Tax"]);
                    objItemMasterDAL.OptionValueTranIds = Convert.ToString(SqlRdr["OptionValueTranIds"]);
                    objItemMasterDAL.ItemModifierMasterIds = Convert.ToString(SqlRdr["ItemModifierMasterIds"]);
                    objItemMasterDAL.IsDineInOnly = Convert.ToBoolean(SqlRdr["IsDineInOnly"]);
                    lstItemMasterDAL.Add(objItemMasterDAL);
                }
                SqlRdr.Close();
                SqlCon.Close();

                return lstItemMasterDAL;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public List<posItemMasterDAL> SelectAllItemMasterRawMaterial(string itemMasterIds)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posItemMaterRawMaterial_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;
                SqlCmd.Parameters.Add("@ItemMasterIds", SqlDbType.VarChar).Value = itemMasterIds;
                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<posItemMasterDAL> lstItemMasterDAL = new List<posItemMasterDAL>();
                posItemMasterDAL objItemMasterDAL = null;
                while (SqlRdr.Read())
                {
                    objItemMasterDAL = new posItemMasterDAL();
                    objItemMasterDAL.ItemMasterId = Convert.ToInt32(SqlRdr["ItemMasterId"]);
                    objItemMasterDAL.ItemName = Convert.ToString(SqlRdr["ItemName"]);
                    objItemMasterDAL.ItemCode = Convert.ToString(SqlRdr["ItemCode"]);
                    objItemMasterDAL.linktoUnitMasterId = Convert.ToInt16(SqlRdr["linktoUnitMasterId"]);
                    objItemMasterDAL.linktoCategoryMasterId = Convert.ToInt16(SqlRdr["linktoCategoryMasterId"]);
                    objItemMasterDAL.UnitName = Convert.ToString(SqlRdr["UnitName"]);
                    objItemMasterDAL.CategoryName = Convert.ToString(SqlRdr["CategoryName"]);

                    objItemMasterDAL.PurchaseRate = Convert.ToDouble(SqlRdr["PurchaseRate"]);
                    lstItemMasterDAL.Add(objItemMasterDAL);
                }
                SqlRdr.Close();
                SqlCon.Close();

                return lstItemMasterDAL;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion
    }
}
