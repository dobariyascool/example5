using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace posLibrary
{
    /// <summary>
    /// Class for posTableMaster
    /// </summary>
    public class posTableMasterDAL
    {
        #region Properties
        public short TableMasterId { get; set; }
        public string TableName { get; set; }
        public string ShortName { get; set; }
        public string Description { get; set; }
        public short MinPerson { get; set; }
        public short MaxPerson { get; set; }
        public short linktoTableStatusMasterId { get; set; }
        public short linktoOrderTypeMasterId { get; set; }
        public int? linktoWaiterMasterId { get; set; }
        public int OriginX { get; set; }
        public int OriginY { get; set; }
        public double Height { get; set; }
        public double Width { get; set; }
        public string TableColor { get; set; }
        public short TableType { get; set; }
        public DateTime CreateDateTime { get; set; }
        public short linktoUserMasterIdCreatedBy { get; set; }
        public DateTime? UpdateDateTime { get; set; }
        public short? linktoUserMasterIdUpdatedBy { get; set; }
        public short linktoBusinessMasterId { get; set; }
        public bool IsEnabled { get; set; }
        public DateTime? StatusUpdateDateTime { get; set; }
        public int? linktoCaptainMasterId { get; set; }
        public bool? IsBookingAvailable { get; set; }
        public double? HourlyBookingRate { get; set; }
        public double? DailyBookingRate { get; set; }

        /// Extra
        public string TableStatus { get; set; }
        public string StatusColor { get; set; }
        public string Waiter { get; set; }
        public short linktoCounterMasterId { get; set; }
        public string OrderType { get; set; }
        public string CaptainName { get; set; }
        public int TempMasterId { get; set; }
        public string WaitingPersonName { get; set; }
        #endregion

        #region Class Methods
        private bool SetClassPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            if (sqlRdr.Read())
            {
                this.TableMasterId = Convert.ToInt16(sqlRdr["TableMasterId"]);
                this.TableName = Convert.ToString(sqlRdr["TableName"]);
                this.ShortName = Convert.ToString(sqlRdr["ShortName"]);
                this.Description = Convert.ToString(sqlRdr["Description"]);
                this.MinPerson = Convert.ToInt16(sqlRdr["MinPerson"]);
                this.MaxPerson = Convert.ToInt16(sqlRdr["MaxPerson"]);
                this.linktoTableStatusMasterId = Convert.ToInt16(sqlRdr["linktoTableStatusMasterId"]);
                this.linktoOrderTypeMasterId = Convert.ToInt16(sqlRdr["linktoOrderTypeMasterId"]);
                if (sqlRdr["linktoWaiterMasterId"] != DBNull.Value)
                {
                    this.linktoWaiterMasterId = Convert.ToInt32(sqlRdr["linktoWaiterMasterId"]);
                }
                this.OriginX = Convert.ToInt32(sqlRdr["OriginX"]);
                this.OriginY = Convert.ToInt32(sqlRdr["OriginY"]);
                this.Height = Convert.ToDouble(sqlRdr["Height"]);
                this.Width = Convert.ToDouble(sqlRdr["Width"]);
                this.TableColor = Convert.ToString(sqlRdr["TableColor"]);
                this.TableType = Convert.ToInt16(sqlRdr["TableType"]);
                this.CreateDateTime = Convert.ToDateTime(sqlRdr["CreateDateTime"]);
                this.linktoUserMasterIdCreatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdCreatedBy"]);
                if (sqlRdr["UpdateDateTime"] != DBNull.Value)
                {
                    this.UpdateDateTime = Convert.ToDateTime(sqlRdr["UpdateDateTime"]);
                }
                if (sqlRdr["linktoUserMasterIdUpdatedBy"] != DBNull.Value)
                {
                    this.linktoUserMasterIdUpdatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdUpdatedBy"]);
                }
                this.linktoBusinessMasterId = Convert.ToInt16(sqlRdr["linktoBusinessMasterId"]);
                this.IsEnabled = Convert.ToBoolean(sqlRdr["IsEnabled"]);

                /// Extra
                this.TableStatus = Convert.ToString(sqlRdr["TableStatus"]);
                this.StatusColor = Convert.ToString(sqlRdr["StatusColor"]);
                this.Waiter = Convert.ToString(sqlRdr["Waiter"]);
                if (sqlRdr["Captain"] != DBNull.Value)
                {
                    this.CaptainName = Convert.ToString(sqlRdr["Captain"]);
                }
                if (sqlRdr["linktoCaptainMasterId"] != DBNull.Value)
                {
                    this.linktoCaptainMasterId = Convert.ToInt32(sqlRdr["linktoCaptainMasterId"]);
                }
                this.IsBookingAvailable = Convert.ToBoolean(sqlRdr["IsBookingAvailable"]);
                if (sqlRdr["HourlyBookingRate"] != DBNull.Value)
                {
                    this.HourlyBookingRate = Convert.ToDouble(sqlRdr["HourlyBookingRate"]);
                }
                if (sqlRdr["DailyBookingRate"] != DBNull.Value)
                {
                    this.DailyBookingRate = Convert.ToDouble(sqlRdr["DailyBookingRate"]);
                }
                if (sqlRdr["StatusUpdateDateTime"] != DBNull.Value)
                {
                    this.StatusUpdateDateTime = Convert.ToDateTime(sqlRdr["StatusUpdateDateTime"]);
                }
                return true;
            }
            return false;
        }

        private List<posTableMasterDAL> SetListPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            List<posTableMasterDAL> lstTableMaster = new List<posTableMasterDAL>();
            posTableMasterDAL objTableMaster = null;
            while (sqlRdr.Read())
            {
                objTableMaster = new posTableMasterDAL();
                objTableMaster.TableMasterId = Convert.ToInt16(sqlRdr["TableMasterId"]);
                objTableMaster.TableName = Convert.ToString(sqlRdr["TableName"]);
                objTableMaster.ShortName = Convert.ToString(sqlRdr["ShortName"]);
                objTableMaster.Description = Convert.ToString(sqlRdr["Description"]);
                objTableMaster.MinPerson = Convert.ToInt16(sqlRdr["MinPerson"]);
                objTableMaster.MaxPerson = Convert.ToInt16(sqlRdr["MaxPerson"]);
                objTableMaster.linktoTableStatusMasterId = Convert.ToInt16(sqlRdr["linktoTableStatusMasterId"]);
                objTableMaster.linktoOrderTypeMasterId = Convert.ToInt16(sqlRdr["linktoOrderTypeMasterId"]);
                if (sqlRdr["linktoWaiterMasterId"] != DBNull.Value)
                {
                    this.linktoWaiterMasterId = Convert.ToInt32(sqlRdr["linktoWaiterMasterId"]);
                }
                objTableMaster.OriginX = Convert.ToInt32(sqlRdr["OriginX"]);
                objTableMaster.OriginY = Convert.ToInt32(sqlRdr["OriginY"]);
                objTableMaster.Height = Convert.ToDouble(sqlRdr["Height"]);
                objTableMaster.Width = Convert.ToDouble(sqlRdr["Width"]);
                objTableMaster.TableColor = Convert.ToString(sqlRdr["TableColor"]);
                objTableMaster.TableType = Convert.ToInt16(sqlRdr["TableType"]);
                objTableMaster.CreateDateTime = Convert.ToDateTime(sqlRdr["CreateDateTime"]);
                objTableMaster.linktoUserMasterIdCreatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdCreatedBy"]);
                if (sqlRdr["UpdateDateTime"] != DBNull.Value)
                {
                    objTableMaster.UpdateDateTime = Convert.ToDateTime(sqlRdr["UpdateDateTime"]);
                }
                if (sqlRdr["linktoUserMasterIdUpdatedBy"] != DBNull.Value)
                {
                    objTableMaster.linktoUserMasterIdUpdatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdUpdatedBy"]);
                }
                objTableMaster.linktoBusinessMasterId = Convert.ToInt16(sqlRdr["linktoBusinessMasterId"]);
                objTableMaster.IsEnabled = Convert.ToBoolean(sqlRdr["IsEnabled"]);

                /// Extra
                objTableMaster.TableStatus = Convert.ToString(sqlRdr["TableStatus"]);
                objTableMaster.StatusColor = Convert.ToString(sqlRdr["StatusColor"]);
                objTableMaster.Waiter = Convert.ToString(sqlRdr["Waiter"]);
                objTableMaster.OrderType = Convert.ToString(sqlRdr["OrderType"]);
                objTableMaster.CaptainName = Convert.ToString(sqlRdr["CaptainName"]);
                if (sqlRdr["linktoCaptainMasterId"] != DBNull.Value)
                {
                    objTableMaster.linktoCaptainMasterId = Convert.ToInt32(sqlRdr["linktoCaptainMasterId"]);
                }
                objTableMaster.IsBookingAvailable = Convert.ToBoolean(sqlRdr["IsBookingAvailable"]);
                if (sqlRdr["HourlyBookingRate"] != DBNull.Value)
                {
                    objTableMaster.HourlyBookingRate = Convert.ToDouble(sqlRdr["HourlyBookingRate"]);
                }
                if (sqlRdr["DailyBookingRate"] != DBNull.Value)
                {
                    objTableMaster.DailyBookingRate = Convert.ToDouble(sqlRdr["DailyBookingRate"]);
                }
                if (sqlRdr["StatusUpdateDateTime"] != DBNull.Value)
                {
                    objTableMaster.StatusUpdateDateTime = Convert.ToDateTime(sqlRdr["StatusUpdateDateTime"]);
                }
                lstTableMaster.Add(objTableMaster);
            }
            return lstTableMaster;
        }
        #endregion

        #region Insert
        public posRecordStatus InsertTableMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posTableMaster_Insert", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@TableMasterId", SqlDbType.SmallInt).Direction = ParameterDirection.Output;
                SqlCmd.Parameters.Add("@TableName", SqlDbType.VarChar).Value = this.TableName;
                SqlCmd.Parameters.Add("@ShortName", SqlDbType.VarChar).Value = this.ShortName;
                SqlCmd.Parameters.Add("@Description", SqlDbType.VarChar).Value = this.Description;
                SqlCmd.Parameters.Add("@MinPerson", SqlDbType.SmallInt).Value = this.MinPerson;
                SqlCmd.Parameters.Add("@MaxPerson", SqlDbType.SmallInt).Value = this.MaxPerson;
                SqlCmd.Parameters.Add("@linktoTableStatusMasterId", SqlDbType.SmallInt).Value = this.linktoTableStatusMasterId;
                SqlCmd.Parameters.Add("@linktoOrderTypeMasterId", SqlDbType.SmallInt).Value = this.linktoOrderTypeMasterId;
                SqlCmd.Parameters.Add("@OriginX", SqlDbType.Int).Value = this.OriginX;
                SqlCmd.Parameters.Add("@OriginY", SqlDbType.Int).Value = this.OriginY;
                SqlCmd.Parameters.Add("@Height", SqlDbType.Decimal).Value = this.Height;
                SqlCmd.Parameters.Add("@Width", SqlDbType.Decimal).Value = this.Width;
                SqlCmd.Parameters.Add("@TableColor", SqlDbType.VarChar).Value = this.TableColor;
                SqlCmd.Parameters.Add("@CreateDateTime", SqlDbType.DateTime).Value = this.CreateDateTime;
                SqlCmd.Parameters.Add("@linktoUserMasterIdCreatedBy", SqlDbType.SmallInt).Value = this.linktoUserMasterIdCreatedBy;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCmd.Parameters.Add("@IsBookingAvailable", SqlDbType.Bit).Value = this.IsBookingAvailable;
                SqlCmd.Parameters.Add("@DailyBookingRate", SqlDbType.Decimal).Value = this.DailyBookingRate;
                SqlCmd.Parameters.Add("@HourlyBookingRate", SqlDbType.Decimal).Value = this.HourlyBookingRate;
                SqlCmd.Parameters.Add("@IsEnabled", SqlDbType.Bit).Value = this.IsEnabled;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                this.TableMasterId = Convert.ToInt16(SqlCmd.Parameters["@TableMasterId"].Value);
                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public static posRecordStatus InsertTableMasterBulkEntry(List<posTableMasterDAL> lstTableMaster)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            bool IsAllreadyExists = false;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCon.Open();
                posRecordStatus rs = posRecordStatus.RecordAlreadyExist;
                foreach (posTableMasterDAL obj in lstTableMaster)
                {
                    SqlCmd = new SqlCommand("posTableMaster_Insert", SqlCon);
                    SqlCmd.CommandType = CommandType.StoredProcedure;

                    SqlCmd.Parameters.Add("@TableMasterId", SqlDbType.SmallInt).Direction = ParameterDirection.Output;
                    SqlCmd.Parameters.Add("@TableName", SqlDbType.VarChar).Value = obj.TableName;
                    SqlCmd.Parameters.Add("@ShortName", SqlDbType.VarChar).Value = obj.ShortName;
                    if (obj.Description != null)
                    {
                        SqlCmd.Parameters.Add("@Description", SqlDbType.VarChar).Value = obj.Description;
                    }
                    SqlCmd.Parameters.Add("@MinPerson", SqlDbType.SmallInt).Value = obj.MinPerson;
                    SqlCmd.Parameters.Add("@MaxPerson", SqlDbType.SmallInt).Value = obj.MaxPerson;
                    SqlCmd.Parameters.Add("@linktoTableStatusMasterId", SqlDbType.SmallInt).Value = obj.linktoTableStatusMasterId;
                    SqlCmd.Parameters.Add("@linktoOrderTypeMasterId", SqlDbType.SmallInt).Value = obj.linktoOrderTypeMasterId;
                    SqlCmd.Parameters.Add("@OriginX", SqlDbType.Int).Value = obj.OriginX;
                    SqlCmd.Parameters.Add("@OriginY", SqlDbType.Int).Value = obj.OriginY;
                    SqlCmd.Parameters.Add("@Height", SqlDbType.Decimal).Value = obj.Height;
                    SqlCmd.Parameters.Add("@Width", SqlDbType.Decimal).Value = obj.Width;
                    SqlCmd.Parameters.Add("@IsBookingAvailable", SqlDbType.Bit).Value = obj.IsBookingAvailable;
                    SqlCmd.Parameters.Add("@DailyBookingRate", SqlDbType.Decimal).Value = obj.DailyBookingRate;
                    SqlCmd.Parameters.Add("@HourlyBookingRate", SqlDbType.Decimal).Value = obj.HourlyBookingRate;
                    SqlCmd.Parameters.Add("@TableColor", SqlDbType.VarChar).Value = obj.TableColor;
                    SqlCmd.Parameters.Add("@CreateDateTime", SqlDbType.DateTime).Value = obj.CreateDateTime;
                    SqlCmd.Parameters.Add("@linktoUserMasterIdCreatedBy", SqlDbType.SmallInt).Value = obj.linktoUserMasterIdCreatedBy;
                    SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = obj.linktoBusinessMasterId;
                    SqlCmd.Parameters.Add("@IsEnabled", SqlDbType.Bit).Value = obj.IsEnabled;
                    SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                    SqlCmd.ExecuteNonQuery();

                    obj.TableMasterId = Convert.ToInt16(SqlCmd.Parameters["@TableMasterId"].Value);

                    rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                    if (rs == posRecordStatus.RecordAlreadyExist)
                    {
                        IsAllreadyExists = true;
                    }
                }
                SqlCon.Close();
                if (IsAllreadyExists)
                {
                    rs = posRecordStatus.RecordAlreadyExist;
                }
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public posRecordStatus InsertTableMaster(SqlConnection SqlCon, SqlTransaction SqlTran, List<posTableMasterDAL> lstTableMaster)
        {
            SqlCommand SqlCmd = null;
            try
            {
                posRecordStatus rs = posRecordStatus.RecordAlreadyExist;
                SqlCmd = new SqlCommand("posTableMaster_Insert", SqlCon, SqlTran);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                foreach (posTableMasterDAL objTableMasterDAL in lstTableMaster)
                {
                    SqlCmd.Parameters.Clear();
                    SqlCmd.Parameters.Add("@TableMasterId", SqlDbType.SmallInt).Direction = ParameterDirection.Output;
                    SqlCmd.Parameters.Add("@TableName", SqlDbType.VarChar).Value = objTableMasterDAL.TableName;
                    SqlCmd.Parameters.Add("@ShortName", SqlDbType.VarChar).Value = objTableMasterDAL.ShortName;
                    if (objTableMasterDAL.Description != null)
                    {
                        SqlCmd.Parameters.Add("@Description", SqlDbType.VarChar).Value = objTableMasterDAL.Description;
                    }
                    SqlCmd.Parameters.Add("@MinPerson", SqlDbType.SmallInt).Value = objTableMasterDAL.MinPerson;
                    SqlCmd.Parameters.Add("@MaxPerson", SqlDbType.SmallInt).Value = objTableMasterDAL.MaxPerson;
                    SqlCmd.Parameters.Add("@linktoTableStatusMasterId", SqlDbType.SmallInt).Value = objTableMasterDAL.linktoTableStatusMasterId;
                    SqlCmd.Parameters.Add("@linktoOrderTypeMasterId", SqlDbType.SmallInt).Value = objTableMasterDAL.linktoOrderTypeMasterId;
                    SqlCmd.Parameters.Add("@OriginX", SqlDbType.Int).Value = objTableMasterDAL.OriginX;
                    SqlCmd.Parameters.Add("@OriginY", SqlDbType.Int).Value = objTableMasterDAL.OriginY;
                    SqlCmd.Parameters.Add("@Height", SqlDbType.Decimal).Value = objTableMasterDAL.Height;
                    SqlCmd.Parameters.Add("@Width", SqlDbType.Decimal).Value = objTableMasterDAL.Width;
                    SqlCmd.Parameters.Add("@IsBookingAvailable", SqlDbType.Bit).Value = objTableMasterDAL.IsBookingAvailable;
                    SqlCmd.Parameters.Add("@DailyBookingRate", SqlDbType.Decimal).Value = objTableMasterDAL.DailyBookingRate;
                    SqlCmd.Parameters.Add("@HourlyBookingRate", SqlDbType.Decimal).Value = objTableMasterDAL.HourlyBookingRate;
                    SqlCmd.Parameters.Add("@TableColor", SqlDbType.VarChar).Value = objTableMasterDAL.TableColor;
                    SqlCmd.Parameters.Add("@CreateDateTime", SqlDbType.DateTime).Value = objTableMasterDAL.CreateDateTime;
                    SqlCmd.Parameters.Add("@linktoUserMasterIdCreatedBy", SqlDbType.SmallInt).Value = this.linktoUserMasterIdCreatedBy;
                    SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                    SqlCmd.Parameters.Add("@IsEnabled", SqlDbType.Bit).Value = objTableMasterDAL.IsEnabled;
                    SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                    SqlCmd.ExecuteNonQuery();

                    objTableMasterDAL.TableMasterId = Convert.ToInt16(SqlCmd.Parameters["@TableMasterId"].Value);

                    rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                    if (rs == posRecordStatus.Error)
                    {
                        return rs;
                    }
                }
                return posRecordStatus.Success;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
            }
        }
        #endregion

        #region Update
        public posRecordStatus UpdateTableMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posTableMaster_Update", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@TableMasterId", SqlDbType.SmallInt).Value = this.TableMasterId;
                SqlCmd.Parameters.Add("@TableName", SqlDbType.VarChar).Value = this.TableName;
                SqlCmd.Parameters.Add("@ShortName", SqlDbType.VarChar).Value = this.ShortName;
                SqlCmd.Parameters.Add("@Description", SqlDbType.VarChar).Value = this.Description;
                SqlCmd.Parameters.Add("@MinPerson", SqlDbType.SmallInt).Value = this.MinPerson;
                SqlCmd.Parameters.Add("@MaxPerson", SqlDbType.SmallInt).Value = this.MaxPerson;
                SqlCmd.Parameters.Add("@linktoOrderTypeMasterId", SqlDbType.SmallInt).Value = this.linktoOrderTypeMasterId;
                SqlCmd.Parameters.Add("@OriginX", SqlDbType.Int).Value = this.OriginX;
                SqlCmd.Parameters.Add("@OriginY", SqlDbType.Int).Value = this.OriginY;
                SqlCmd.Parameters.Add("@Height", SqlDbType.Decimal).Value = this.Height;
                SqlCmd.Parameters.Add("@Width", SqlDbType.Decimal).Value = this.Width;
                SqlCmd.Parameters.Add("@TableColor", SqlDbType.VarChar).Value = this.TableColor;
                SqlCmd.Parameters.Add("@UpdateDateTime", SqlDbType.DateTime).Value = this.UpdateDateTime;
                SqlCmd.Parameters.Add("@linktoUserMasterIdUpdatedBy", SqlDbType.SmallInt).Value = this.linktoUserMasterIdUpdatedBy;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCmd.Parameters.Add("@IsBookingAvailable", SqlDbType.Bit).Value = this.IsBookingAvailable;
                SqlCmd.Parameters.Add("@DailyBookingRate", SqlDbType.Decimal).Value = this.DailyBookingRate;
                SqlCmd.Parameters.Add("@HourlyBookingRate", SqlDbType.Decimal).Value = this.HourlyBookingRate;
                SqlCmd.Parameters.Add("@IsEnabled", SqlDbType.Bit).Value = this.IsEnabled;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public posRecordStatus UpdateTableMasterWaiter()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posTableMasterWaiter_Update", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@TableMasterId", SqlDbType.VarChar).Value = this.TableMasterId;
                SqlCmd.Parameters.Add("@linktoWaiterMasterId", SqlDbType.SmallInt).Value = this.linktoWaiterMasterId;
                SqlCmd.Parameters.Add("@linktoCaptainMasterId", SqlDbType.Int).Value = this.linktoCaptainMasterId;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public posRecordStatus UpdateTableMasterTableStatus()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posTableMasterTableStatus_Update", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@TableMasterId", SqlDbType.SmallInt).Value = this.TableMasterId;
                SqlCmd.Parameters.Add("@linktoTableStatusMasterId", SqlDbType.SmallInt).Value = this.linktoTableStatusMasterId;
                SqlCmd.Parameters.Add("@StatusUpdateDateTime", SqlDbType.DateTime).Value = this.StatusUpdateDateTime;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public posRecordStatus UpdateTableMasterDesign(List<posTableMasterDAL> lstTableMasterDAL)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlTransaction SqlTran = null;
            posRecordStatus rs = posRecordStatus.Error;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCon.Open();
                SqlTran = SqlCon.BeginTransaction();
                SqlCmd = new SqlCommand("posTableMasterDesign_Update", SqlCon, SqlTran);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                foreach (posTableMasterDAL obj in lstTableMasterDAL)
                {
                    SqlCmd.Parameters.Clear();
                    SqlCmd.Parameters.Add("@TableMasterId", SqlDbType.SmallInt).Value = obj.TableMasterId;
                    SqlCmd.Parameters.Add("@OriginX", SqlDbType.Int).Value = obj.OriginX;
                    SqlCmd.Parameters.Add("@OriginY", SqlDbType.Int).Value = obj.OriginY;
                    SqlCmd.Parameters.Add("@Height", SqlDbType.Decimal).Value = obj.Height;
                    SqlCmd.Parameters.Add("@Width", SqlDbType.Decimal).Value = obj.Width;
                    SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;
                    SqlCmd.ExecuteNonQuery();
                    rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                    if (rs == posRecordStatus.Error)
                    {
                        SqlTran.Rollback();
                        return posRecordStatus.Error;
                    }
                }
                SqlTran.Commit();
                SqlCon.Close();
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public posRecordStatus UpdateTableMasterBulkUpdate(List<posTableMasterDAL> lstTableMasterDAL, out string tables)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlTransaction SqlTran = null;
            tables = string.Empty;
            bool IsAllreadyExists = false;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCon.Open();
                SqlTran = SqlCon.BeginTransaction();

                SqlCmd = new SqlCommand("posTableMasterBulkUpdate_Update", SqlCon, SqlTran);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                posRecordStatus rs = posRecordStatus.RecordAlreadyExist;
                foreach (posTableMasterDAL obj in lstTableMasterDAL)
                {
                    SqlCmd.Parameters.Clear();
                    SqlCmd.Parameters.Add("@TableMasterId", SqlDbType.SmallInt).Value = obj.TableMasterId;
                    SqlCmd.Parameters.Add("@TableName", SqlDbType.VarChar).Value = obj.TableName;
                    SqlCmd.Parameters.Add("@ShortName", SqlDbType.VarChar).Value = obj.ShortName;
                    SqlCmd.Parameters.Add("@MinPerson", SqlDbType.SmallInt).Value = obj.MinPerson;
                    SqlCmd.Parameters.Add("@MaxPerson", SqlDbType.SmallInt).Value = obj.MaxPerson;
                    SqlCmd.Parameters.Add("@linktoOrderTypeMasterId", SqlDbType.SmallInt).Value = obj.linktoOrderTypeMasterId;
                    SqlCmd.Parameters.Add("@UpdateDateTime", SqlDbType.DateTime).Value = obj.UpdateDateTime;
                    SqlCmd.Parameters.Add("@linktoUserMasterIdUpdatedBy", SqlDbType.SmallInt).Value = obj.linktoUserMasterIdUpdatedBy;
                    SqlCmd.Parameters.Add("@IsBookingAvailable", SqlDbType.Bit).Value = obj.IsBookingAvailable;
                    SqlCmd.Parameters.Add("@DailyBookingRate", SqlDbType.Decimal).Value = obj.DailyBookingRate;
                    SqlCmd.Parameters.Add("@HourlyBookingRate", SqlDbType.Decimal).Value = obj.HourlyBookingRate;
                    SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.Decimal).Value = obj.linktoBusinessMasterId;
                    SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                    SqlCmd.ExecuteNonQuery();
                    rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                    if (rs == posRecordStatus.RecordAlreadyExist)
                    {
                        tables += obj.TableName + ", ";
                        IsAllreadyExists = true;
                    }
                }
                if (!IsAllreadyExists)
                {
                    SqlTran.Commit();
                }
                else
                {
                    SqlTran.Rollback();
                    rs = posRecordStatus.RecordAlreadyExist;
                }

                SqlCon.Close();
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
                posObjectFactoryDAL.DisposeTransaction(SqlTran);
            }
        }
        #endregion

        #region DeleteAll
        public posRecordStatus DeleteAllTableMaster(string tableMasterIds)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posTableMaster_DeleteAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@TableMasterIds", SqlDbType.VarChar).Value = tableMasterIds;
                SqlCmd.Parameters.Add("@StatusUpdateDateTime", SqlDbType.DateTime).Value = this.StatusUpdateDateTime;
                SqlCmd.Parameters.Add("@linktoUserMasterIdUpdatedBy", SqlDbType.SmallInt).Value = this.linktoUserMasterIdUpdatedBy;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region Select
        public bool SelectTableMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posTableMaster_Select", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@TableMasterId", SqlDbType.SmallInt).Value = this.TableMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                bool IsSelected = SetClassPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                return IsSelected;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return false;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region SelectAll
        public static List<posTableMasterDAL> SelectAllTableStatusMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posTableStatusMaster_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<posTableMasterDAL> lstTableMasterDAL = new List<posTableMasterDAL>();
                posTableMasterDAL objTableMasterDAL = null;
                while (SqlRdr.Read())
                {
                    objTableMasterDAL = new posTableMasterDAL();
                    objTableMasterDAL.linktoTableStatusMasterId = Convert.ToInt16(SqlRdr["TableStatusMasterId"]);
                    objTableMasterDAL.StatusColor = Convert.ToString(SqlRdr["StatusColor"]);
                    lstTableMasterDAL.Add(objTableMasterDAL);
                }

                SqlRdr.Close();
                SqlCon.Close();

                return lstTableMasterDAL;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public List<posTableMasterDAL> SelectAllTableMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posTableMaster_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@TableName", SqlDbType.VarChar).Value = this.TableName;
                if (this.MinPerson > 0)
                {
                    SqlCmd.Parameters.Add("@MinPerson", SqlDbType.SmallInt).Value = this.MinPerson;
                }
                if (this.MaxPerson > 0)
                {
                    SqlCmd.Parameters.Add("@MaxPerson", SqlDbType.SmallInt).Value = this.MaxPerson;
                }
                SqlCmd.Parameters.Add("@IsEnabled", SqlDbType.Bit).Value = this.IsEnabled;

                if (this.linktoTableStatusMasterId > 0)
                {
                    SqlCmd.Parameters.Add("@linktoTableStatusMasterId", SqlDbType.Bit).Value = this.linktoTableStatusMasterId;
                }
                SqlCmd.Parameters.Add("@IsBookingAvailable", SqlDbType.Bit).Value = this.IsBookingAvailable;
                if (this.linktoOrderTypeMasterId > 0)
                {
                    SqlCmd.Parameters.Add("@linktoOrderTypeMasterId", SqlDbType.SmallInt).Value = this.linktoOrderTypeMasterId;
                }
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<posTableMasterDAL> lstTableMasterDAL = SetListPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                return lstTableMasterDAL;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public static List<posTableMasterDAL> SelectAllTableMasterTableName(short linktoBusinessMasterId)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posTableMasterTableName_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = linktoBusinessMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<posTableMasterDAL> lstTableMasterDAL = new List<posTableMasterDAL>();
                posTableMasterDAL objTableMasterDAL = null;
                while (SqlRdr.Read())
                {
                    objTableMasterDAL = new posTableMasterDAL();
                    objTableMasterDAL.TableMasterId = Convert.ToInt16(SqlRdr["TableMasterId"]);
                    objTableMasterDAL.TableName = Convert.ToString(SqlRdr["TableName"]);
                    lstTableMasterDAL.Add(objTableMasterDAL);
                }
                SqlRdr.Close();
                SqlCon.Close();

                return lstTableMasterDAL;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public List<posTableMasterDAL> SelectAllTableMasterByBusinessMasterId()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posTableMasterByBusinessMasterId_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@linktoCounterMasterId", SqlDbType.SmallInt).Value = this.linktoCounterMasterId;
                if (this.linktoTableStatusMasterId > 0)
                {
                    SqlCmd.Parameters.Add("@linktoTableStatusMasterId", SqlDbType.SmallInt).Value = this.linktoTableStatusMasterId;
                }
                if (this.linktoOrderTypeMasterId > 0)
                {
                    SqlCmd.Parameters.Add("@linktoOrderTypeMasterId", SqlDbType.SmallInt).Value = this.linktoOrderTypeMasterId;
                }
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCmd.Parameters.Add("@FromDate", SqlDbType.DateTime).Value = this.CreateDateTime;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<posTableMasterDAL> lstTableMasterDAL = new List<posTableMasterDAL>();
                posTableMasterDAL objTableMaster = null;
                while (SqlRdr.Read())
                {
                    objTableMaster = new posTableMasterDAL();
                    objTableMaster = new posTableMasterDAL();
                    objTableMaster.TableMasterId = Convert.ToInt16(SqlRdr["TableMasterId"]);
                    objTableMaster.TableName = Convert.ToString(SqlRdr["TableName"]);
                    objTableMaster.ShortName = Convert.ToString(SqlRdr["ShortName"]);
                    objTableMaster.Description = Convert.ToString(SqlRdr["Description"]);
                    objTableMaster.MinPerson = Convert.ToInt16(SqlRdr["MinPerson"]);
                    objTableMaster.MaxPerson = Convert.ToInt16(SqlRdr["MaxPerson"]);
                    objTableMaster.linktoTableStatusMasterId = Convert.ToInt16(SqlRdr["linktoTableStatusMasterId"]);
                    objTableMaster.linktoOrderTypeMasterId = Convert.ToInt16(SqlRdr["linktoOrderTypeMasterId"]);
                    if (SqlRdr["linktoWaiterMasterId"] != DBNull.Value)
                    {
                        this.linktoWaiterMasterId = Convert.ToInt32(SqlRdr["linktoWaiterMasterId"]);
                    }
                    objTableMaster.OriginX = Convert.ToInt32(SqlRdr["OriginX"]);
                    objTableMaster.OriginY = Convert.ToInt32(SqlRdr["OriginY"]);
                    objTableMaster.Height = Convert.ToDouble(SqlRdr["Height"]);
                    objTableMaster.Width = Convert.ToDouble(SqlRdr["Width"]);
                    objTableMaster.TableColor = Convert.ToString(SqlRdr["TableColor"]);
                    objTableMaster.TableType = Convert.ToInt16(SqlRdr["TableType"]);
                    objTableMaster.CreateDateTime = Convert.ToDateTime(SqlRdr["CreateDateTime"]);
                    objTableMaster.linktoUserMasterIdCreatedBy = Convert.ToInt16(SqlRdr["linktoUserMasterIdCreatedBy"]);
                    if (SqlRdr["UpdateDateTime"] != DBNull.Value)
                    {
                        objTableMaster.UpdateDateTime = Convert.ToDateTime(SqlRdr["UpdateDateTime"]);
                    }
                    if (SqlRdr["linktoUserMasterIdUpdatedBy"] != DBNull.Value)
                    {
                        objTableMaster.linktoUserMasterIdUpdatedBy = Convert.ToInt16(SqlRdr["linktoUserMasterIdUpdatedBy"]);
                    }
                    objTableMaster.linktoBusinessMasterId = Convert.ToInt16(SqlRdr["linktoBusinessMasterId"]);
                    objTableMaster.IsEnabled = Convert.ToBoolean(SqlRdr["IsEnabled"]);

                    /// Extra
                    objTableMaster.TableStatus = Convert.ToString(SqlRdr["TableStatus"]);
                    objTableMaster.StatusColor = Convert.ToString(SqlRdr["StatusColor"]);
                    objTableMaster.Waiter = Convert.ToString(SqlRdr["Waiter"]);
                    objTableMaster.OrderType = Convert.ToString(SqlRdr["OrderType"]);
                    objTableMaster.CaptainName = Convert.ToString(SqlRdr["CaptainName"]);
                    if (SqlRdr["linktoCaptainMasterId"] != DBNull.Value)
                    {
                        objTableMaster.linktoCaptainMasterId = Convert.ToInt32(SqlRdr["linktoCaptainMasterId"]);
                    }
                    objTableMaster.IsBookingAvailable = Convert.ToBoolean(SqlRdr["IsBookingAvailable"]);
                    if (SqlRdr["HourlyBookingRate"] != DBNull.Value)
                    {
                        objTableMaster.HourlyBookingRate = Convert.ToDouble(SqlRdr["HourlyBookingRate"]);
                    }
                    if (SqlRdr["DailyBookingRate"] != DBNull.Value)
                    {
                        objTableMaster.DailyBookingRate = Convert.ToDouble(SqlRdr["DailyBookingRate"]);
                    }
                    if (SqlRdr["StatusUpdateDateTime"] != DBNull.Value)
                    {
                        objTableMaster.StatusUpdateDateTime = Convert.ToDateTime(SqlRdr["StatusUpdateDateTime"]);
                    }
                    objTableMaster.WaitingPersonName = Convert.ToString(SqlRdr["WaitingPersonName"]);
                    lstTableMasterDAL.Add(objTableMaster);
                }
                SqlRdr.Close();
                SqlCon.Close();

                return lstTableMasterDAL;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public static List<posTableMasterDAL> SelectAllTableMasterByCounterMasterId(short CounterMasterID, short linktoOrderTypeMasterId, short linktoBusinessMasterId)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader sqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posTableMasterByCounterMasterId_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@CounterMasterID", SqlDbType.SmallInt).Value = CounterMasterID;
                SqlCmd.Parameters.Add("@linkToOrderTypeMasterId", SqlDbType.SmallInt).Value = linktoOrderTypeMasterId;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = linktoBusinessMasterId;

                SqlCon.Open();
                sqlRdr = SqlCmd.ExecuteReader();
                List<posTableMasterDAL> lstTableMasterDAL = new List<posTableMasterDAL>();
                posTableMasterDAL objTableMaster = null;
                while (sqlRdr.Read())
                {
                    objTableMaster = new posTableMasterDAL();
                    objTableMaster.TableMasterId = Convert.ToInt16(sqlRdr["TableMasterId"]);
                    objTableMaster.TableName = Convert.ToString(sqlRdr["TableName"]);
                    objTableMaster.MaxPerson = Convert.ToInt16(sqlRdr["MaxPerson"]);
                    objTableMaster.ShortName = Convert.ToString(sqlRdr["ShortName"]);
                    objTableMaster.TableColor = Convert.ToString(sqlRdr["TableColor"]);
                    objTableMaster.TableType = Convert.ToInt16(sqlRdr["TableType"]);
                    objTableMaster.Waiter = Convert.ToString(sqlRdr["WaiterName"]);
                    objTableMaster.StatusColor = Convert.ToString(sqlRdr["StatusColor"]);
                    objTableMaster.linktoTableStatusMasterId = Convert.ToInt16(sqlRdr["linktoTableStatusMasterId"]);
                    if (sqlRdr["linktoWaiterMasterId"] != DBNull.Value)
                    {
                        objTableMaster.linktoWaiterMasterId = Convert.ToInt16(sqlRdr["linktoWaiterMasterId"]);
                    }
                    objTableMaster.linktoOrderTypeMasterId = Convert.ToInt16(sqlRdr["linktoOrderTypeMasterId"]);
                    objTableMaster.OrderType = Convert.ToString(sqlRdr["OrderType"]);
                    objTableMaster.OriginX = Convert.ToInt32(sqlRdr["OriginX"]);
                    objTableMaster.OriginY = Convert.ToInt32(sqlRdr["OriginY"]);
                    objTableMaster.Height = Convert.ToDouble(sqlRdr["Height"]);
                    objTableMaster.Width = Convert.ToDouble(sqlRdr["Width"]);
                    if (sqlRdr["StatusUpdateDateTime"] != DBNull.Value)
                    {
                        objTableMaster.StatusUpdateDateTime = Convert.ToDateTime(sqlRdr["StatusUpdateDateTime"]);
                    }
                    //if (sqlRdr["TableRateIndex"] != DBNull.Value)
                    //{
                    //    objTableMaster.RateIndex = Convert.ToInt16(sqlRdr["TableRateIndex"]);
                    //}
                    //if (sqlRdr["RateName"] != DBNull.Value)
                    //{
                    //    objTableMaster.RateName = Convert.ToString(sqlRdr["RateName"]);
                    //}
                    lstTableMasterDAL.Add(objTableMaster);
                }
                sqlRdr.Close();
                SqlCon.Close();

                return lstTableMasterDAL;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(sqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public List<posTableMasterDAL> SelectAllTableMasterByTableMasterIDs(string tableMasterIDs)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posTableMasterbyTableMasterIDs_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@TableMasterIDs", SqlDbType.VarChar).Value = tableMasterIDs;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<posTableMasterDAL> lstTableMasterDAL = SetListPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                return lstTableMasterDAL;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion
    }
}
