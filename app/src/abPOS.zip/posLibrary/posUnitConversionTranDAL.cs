using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace posLibrary
{
	/// <summary>
	/// Class for posUnitConversionTran
	/// </summary>
	public class posUnitConversionTranDAL
	{
		#region Properties
		public int UnitConversionTranId { get; set; }
		public int? linktoItemMasterId { get; set; }
		public short linktoUnitMasterIdFrom { get; set; }
		public short linktoUnitMasterIdTo { get; set; }
		public double Quantity { get; set; }

		/// Extra
		public string Item { get; set; }
		public string UnitFrom { get; set; }
		public string UnitTo { get; set; }
        public short UnitMasterId { get; set; }
        public string UnitName { get; set; }
		#endregion

		#region Class Methods
		private List<posUnitConversionTranDAL> SetListPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
		{
			List<posUnitConversionTranDAL> lstUnitConversionTran = new List<posUnitConversionTranDAL>();
			posUnitConversionTranDAL objUnitConversionTran = null;
			while (sqlRdr.Read())
			{
				objUnitConversionTran = new posUnitConversionTranDAL();
				objUnitConversionTran.UnitConversionTranId = Convert.ToInt32(sqlRdr["UnitConversionTranId"]);
				if (sqlRdr["linktoItemMasterId"] != DBNull.Value)
				{
					objUnitConversionTran.linktoItemMasterId = Convert.ToInt32(sqlRdr["linktoItemMasterId"]);
				}
				objUnitConversionTran.linktoUnitMasterIdFrom = Convert.ToInt16(sqlRdr["linktoUnitMasterIdFrom"]);
				objUnitConversionTran.linktoUnitMasterIdTo = Convert.ToInt16(sqlRdr["linktoUnitMasterIdTo"]);
				objUnitConversionTran.Quantity = Convert.ToDouble(sqlRdr["Quantity"]);

				/// Extra
				objUnitConversionTran.Item = Convert.ToString(sqlRdr["Item"]);
				objUnitConversionTran.UnitFrom = Convert.ToString(sqlRdr["UnitFrom"]);
				objUnitConversionTran.UnitTo = Convert.ToString(sqlRdr["UnitTo"]);
				lstUnitConversionTran.Add(objUnitConversionTran);
			}
			return lstUnitConversionTran;
		}
		#endregion

		#region Insert
		public posRecordStatus InsertUnitConversionTran()
		{
			SqlConnection SqlCon = null;
			SqlCommand SqlCmd = null;
			try
			{
				SqlCon = posObjectFactoryDAL.CreateConnection();
				SqlCmd = new SqlCommand("posUnitConversionTran_Insert", SqlCon);
				SqlCmd.CommandType = CommandType.StoredProcedure;

				SqlCmd.Parameters.Add("@UnitConversionTranId", SqlDbType.Int).Direction = ParameterDirection.Output;
				SqlCmd.Parameters.Add("@linktoItemMasterId", SqlDbType.Int).Value = this.linktoItemMasterId;
				SqlCmd.Parameters.Add("@linktoUnitMasterIdFrom", SqlDbType.SmallInt).Value = this.linktoUnitMasterIdFrom;
				SqlCmd.Parameters.Add("@linktoUnitMasterIdTo", SqlDbType.SmallInt).Value = this.linktoUnitMasterIdTo;
				SqlCmd.Parameters.Add("@Quantity", SqlDbType.Decimal).Value = this.Quantity;
				SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

				SqlCon.Open();
				SqlCmd.ExecuteNonQuery();
				SqlCon.Close();

				this.UnitConversionTranId = Convert.ToInt32(SqlCmd.Parameters["@UnitConversionTranId"].Value);
				posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
				return rs;
			}
			catch (Exception ex)
			{
				posGlobalsDAL.SaveError(ex);
				return posRecordStatus.Error;
			}
			finally
			{
				posObjectFactoryDAL.DisposeCommand(SqlCmd);
				posObjectFactoryDAL.DisposeConnection(SqlCon);
			}
		}
		#endregion

		#region Delete
		public posRecordStatus DeleteUnitConversionTran()
		{
			SqlConnection SqlCon = null;
			SqlCommand SqlCmd = null;
			try
			{
				SqlCon = posObjectFactoryDAL.CreateConnection();
				SqlCmd = new SqlCommand("posUnitConversionTran_Delete", SqlCon);
				SqlCmd.CommandType = CommandType.StoredProcedure;

				SqlCmd.Parameters.Add("@UnitConversionTranId", SqlDbType.Int).Value = this.UnitConversionTranId;
				SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

				SqlCon.Open();
				SqlCmd.ExecuteNonQuery();
				SqlCon.Close();

				posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
				return rs;
			}
			catch (Exception ex)
			{
				posGlobalsDAL.SaveError(ex);
				return posRecordStatus.Error;
			}
			finally
			{
				posObjectFactoryDAL.DisposeCommand(SqlCmd);
				posObjectFactoryDAL.DisposeConnection(SqlCon);
			}
		}
		#endregion

		#region SelectAll
		public List<posUnitConversionTranDAL> SelectAllUnitConversionTran()
		{
			SqlConnection SqlCon = null;
			SqlCommand SqlCmd = null;
			SqlDataReader SqlRdr = null;
			try
			{
				SqlCon = posObjectFactoryDAL.CreateConnection();
				SqlCmd = new SqlCommand("posUnitConversionTran_SelectAll", SqlCon);
				SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@linktoItemMasterId", SqlDbType.SmallInt).Value = this.linktoItemMasterId;

				SqlCon.Open();
				SqlRdr = SqlCmd.ExecuteReader();
				List<posUnitConversionTranDAL> lstUnitConversionTranDAL = SetListPropertiesFromSqlDataReader(SqlRdr);
				SqlRdr.Close();
				SqlCon.Close();

				return lstUnitConversionTranDAL;
			}
			catch (Exception ex)
			{
				posGlobalsDAL.SaveError(ex);
				return null;
			}
			finally
			{
				posObjectFactoryDAL.DisposeDataReader(SqlRdr);
				posObjectFactoryDAL.DisposeCommand(SqlCmd);
				posObjectFactoryDAL.DisposeConnection(SqlCon);
			}
		}

        public static List<posUnitConversionTranDAL> SelectAllUnitConversionTranUnitName(int ItemMasterId)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posUnitConversionTranUnitNames_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;
                SqlCmd.Parameters.Add("@linktoItemMasterId", SqlDbType.Int).Value = ItemMasterId;
				

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<posUnitConversionTranDAL> lstUnitConversionTranDAL = new List<posUnitConversionTranDAL>();
                posUnitConversionTranDAL objUnitConversionTranDAL = null;
                while (SqlRdr.Read())
                {
                    objUnitConversionTranDAL = new posUnitConversionTranDAL();
                    objUnitConversionTranDAL.UnitMasterId = Convert.ToInt16(SqlRdr["UnitMasterId"]);
                    objUnitConversionTranDAL.UnitName = Convert.ToString(SqlRdr["UnitName"]);
                    lstUnitConversionTranDAL.Add(objUnitConversionTranDAL);
                }
                SqlRdr.Close();
                SqlCon.Close();

                return lstUnitConversionTranDAL;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
		#endregion
	}
}
