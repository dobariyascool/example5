using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient; 

namespace posLibrary
{
    /// <summary>
    /// Class for posUserMaster
    /// </summary>
    public class posUserMasterDAL
    {
        #region Properties
        public short UserMasterId { get; set; }
        public string Username { get; set; }
        public string Password { get; set; }
        public short linktoRoleMasterId { get; set; }
        public short? linktoUserTypeMasterId { get; set; }
        public DateTime CreateDateTime { get; set; }
        public short linktoUserMasterIdCreatedBy { get; set; }
        public DateTime? UpdateDateTime { get; set; }
        public short? linktoUserMasterIdUpdatedBy { get; set; }
        public DateTime? LastLoginDateTime { get; set; }
        public short LoginFailCount { get; set; }
        public DateTime? LastLockoutDateTime { get; set; }
        public DateTime? LastPasswordChangedDateTime { get; set; }
        public string Comment { get; set; }
        public short linktoBusinessMasterId { get; set; }
        public bool IsEnabled { get; set; }
        public bool IsDeleted { get; set; }

        //Extra
        public string Role { get; set; }
        public short linktoBusinessTypeMasterId { get; set; }
        public short linktoCityMasterId { get; set; }
        public string BusinessName { get; set; }

        public int? WaiterMasterId { get; set; }
        public int? WaiterMasterIdCaptian { get; set; }
        public int? WaiterMasterIdDeliveryPerson { get; set; }
        #endregion

        #region Class Methods
        private bool SetClassPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            if (sqlRdr.Read())
            {
                this.UserMasterId = Convert.ToInt16(sqlRdr["UserMasterId"]);
                this.Username = Convert.ToString(sqlRdr["Username"]);
                this.Password = Convert.ToString(sqlRdr["Password"]);
                this.linktoRoleMasterId = Convert.ToInt16(sqlRdr["linktoRoleMasterId"]);
                this.CreateDateTime = Convert.ToDateTime(sqlRdr["CreateDateTime"]);
                this.linktoUserMasterIdCreatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdCreatedBy"]);
                if (sqlRdr["linktoUserTypeMasterId"] != DBNull.Value)
                {
                    this.linktoUserTypeMasterId = Convert.ToInt16(sqlRdr["linktoUserTypeMasterId"]);
                }
                if (sqlRdr["UpdateDateTime"] != DBNull.Value)
                {
                    this.UpdateDateTime = Convert.ToDateTime(sqlRdr["UpdateDateTime"]);
                }
                if (sqlRdr["linktoUserMasterIdUpdatedBy"] != DBNull.Value)
                {
                    this.linktoUserMasterIdUpdatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdUpdatedBy"]);
                }
                if (sqlRdr["LastLoginDateTime"] != DBNull.Value)
                {
                    this.LastLoginDateTime = Convert.ToDateTime(sqlRdr["LastLoginDateTime"]);
                }
                this.LoginFailCount = Convert.ToInt16(sqlRdr["LoginFailCount"]);
                if (sqlRdr["LastLockoutDateTime"] != DBNull.Value)
                {
                    this.LastLockoutDateTime = Convert.ToDateTime(sqlRdr["LastLockoutDateTime"]);
                }
                if (sqlRdr["LastPasswordChangedDateTime"] != DBNull.Value)
                {
                    this.LastPasswordChangedDateTime = Convert.ToDateTime(sqlRdr["LastPasswordChangedDateTime"]);
                }

                this.Comment = Convert.ToString(sqlRdr["Comment"]);
                this.linktoBusinessMasterId = Convert.ToInt16(sqlRdr["linktoBusinessMasterId"]);
                this.IsEnabled = Convert.ToBoolean(sqlRdr["IsEnabled"]);
                this.IsDeleted = Convert.ToBoolean(sqlRdr["IsDeleted"]);

                //Extra
                this.Role = Convert.ToString(sqlRdr["Role"]);
                if (sqlRdr["BusinessTypeMasterId"] != DBNull.Value)
                {
                    this.linktoBusinessTypeMasterId = Convert.ToInt16(sqlRdr["BusinessTypeMasterId"]);
                }
                if (sqlRdr["WaiterMasterId"] != DBNull.Value)
                {
                    this.WaiterMasterId = Convert.ToInt32(sqlRdr["WaiterMasterId"]);
                }
                this.BusinessName = Convert.ToString(sqlRdr["BusinessName"]);
                this.linktoCityMasterId = Convert.ToInt16(sqlRdr["linktoCityMasterId"]);
                return true;
            }
            return false;
        }

        private List<posUserMasterDAL> SetListPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            List<posUserMasterDAL> lstUserMaster = new List<posUserMasterDAL>();
            posUserMasterDAL objUserMaster = null;
            while (sqlRdr.Read())
            {
                objUserMaster = new posUserMasterDAL();
                objUserMaster.UserMasterId = Convert.ToInt16(sqlRdr["UserMasterId"]);
                objUserMaster.Username = Convert.ToString(sqlRdr["Username"]);
                objUserMaster.Password = Convert.ToString(sqlRdr["Password"]);
                objUserMaster.linktoRoleMasterId = Convert.ToInt16(sqlRdr["linktoRoleMasterId"]);
                objUserMaster.CreateDateTime = Convert.ToDateTime(sqlRdr["CreateDateTime"]);
                if (sqlRdr["linktoUserTypeMasterId"] != DBNull.Value)
                {
                    objUserMaster.linktoUserTypeMasterId = Convert.ToInt16(sqlRdr["linktoUserTypeMasterId"]);
                }
                objUserMaster.linktoUserMasterIdCreatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdCreatedBy"]);
                if (sqlRdr["UpdateDateTime"] != DBNull.Value)
                {
                    objUserMaster.UpdateDateTime = Convert.ToDateTime(sqlRdr["UpdateDateTime"]);
                }
                if (sqlRdr["linktoUserMasterIdUpdatedBy"] != DBNull.Value)
                {
                    objUserMaster.linktoUserMasterIdUpdatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdUpdatedBy"]);
                }
                if (sqlRdr["LastLoginDateTime"] != DBNull.Value)
                {
                    objUserMaster.LastLoginDateTime = Convert.ToDateTime(sqlRdr["LastLoginDateTime"]);
                }
                objUserMaster.LoginFailCount = Convert.ToInt16(sqlRdr["LoginFailCount"]);
                if (sqlRdr["LastLockoutDateTime"] != DBNull.Value)
                {
                    objUserMaster.LastLockoutDateTime = Convert.ToDateTime(sqlRdr["LastLockoutDateTime"]);
                }
                if (sqlRdr["LastPasswordChangedDateTime"] != DBNull.Value)
                {
                    objUserMaster.LastPasswordChangedDateTime = Convert.ToDateTime(sqlRdr["LastPasswordChangedDateTime"]);
                }

                objUserMaster.linktoBusinessMasterId = Convert.ToInt16(sqlRdr["linktoBusinessMasterId"]);
                objUserMaster.Comment = Convert.ToString(sqlRdr["Comment"]);
                objUserMaster.IsEnabled = Convert.ToBoolean(sqlRdr["IsEnabled"]);
                objUserMaster.IsDeleted = Convert.ToBoolean(sqlRdr["IsDeleted"]);

                //Extra
                objUserMaster.Role = Convert.ToString(sqlRdr["Role"]);
                if (sqlRdr["WaiterMasterId"] != DBNull.Value)
                {
                    objUserMaster.WaiterMasterId = Convert.ToInt32(sqlRdr["WaiterMasterId"]);
                }
                lstUserMaster.Add(objUserMaster);
            }
            return lstUserMaster;
        }
        #endregion

        #region Insert
        public posRecordStatus InsertUserMaster(string linktoCounterMasterIds)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlTransaction SqlTran = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCon.Open();
                SqlTran = SqlCon.BeginTransaction();
                SqlCmd = new SqlCommand("posUserMaster_Insert", SqlCon, SqlTran);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@UserMasterId", SqlDbType.SmallInt).Direction = ParameterDirection.Output;
                SqlCmd.Parameters.Add("@Username", SqlDbType.NVarChar).Value = this.Username;
                SqlCmd.Parameters.Add("@Password", SqlDbType.NVarChar).Value = this.Password;
                SqlCmd.Parameters.Add("@linktoRoleMasterId", SqlDbType.SmallInt).Value = this.linktoRoleMasterId;
                SqlCmd.Parameters.Add("@CreateDateTime", SqlDbType.DateTime).Value = this.CreateDateTime;
                SqlCmd.Parameters.Add("@linktoUserMasterIdCreatedBy", SqlDbType.SmallInt).Value = this.linktoUserMasterIdCreatedBy;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCmd.Parameters.Add("@LastLoginDateTime", SqlDbType.DateTime).Value = this.LastLoginDateTime;
                SqlCmd.Parameters.Add("@LoginFailCount", SqlDbType.SmallInt).Value = this.LoginFailCount;
                SqlCmd.Parameters.Add("@LastLockoutDateTime", SqlDbType.DateTime).Value = this.LastLockoutDateTime;
                SqlCmd.Parameters.Add("@LastPasswordChangedDateTime", SqlDbType.DateTime).Value = this.LastPasswordChangedDateTime;
                SqlCmd.Parameters.Add("@Comment", SqlDbType.NVarChar).Value = this.Comment;
                SqlCmd.Parameters.Add("@IsEnabled", SqlDbType.Bit).Value = this.IsEnabled;
                SqlCmd.Parameters.Add("@IsDeleted", SqlDbType.Bit).Value = this.IsDeleted;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCmd.ExecuteNonQuery();

                this.UserMasterId = Convert.ToInt16(SqlCmd.Parameters["@UserMasterId"].Value);
                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;

                if (rs == posRecordStatus.Success)
                {
                    if (posUserCounterTranDAL.DeleteUserCounterTran(this.UserMasterId, SqlCon, SqlTran) == posRecordStatus.Error)
                    {
                        SqlTran.Rollback();
                        SqlCon.Close();
                        return rs;
                    }
                    else if (posUserCounterTranDAL.InsertUserCounterTran(this.UserMasterId, linktoCounterMasterIds, SqlCon, SqlTran) == posRecordStatus.Error)
                    {
                        SqlTran.Rollback();
                        SqlCon.Close();
                        return rs;
                    }
                }

                SqlTran.Commit();
                SqlCon.Close();
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region Update
        public posRecordStatus UpdateUserMaster(string linktoCounterMasterIds)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlTransaction SqlTran = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCon.Open();
                SqlTran = SqlCon.BeginTransaction();
                SqlCmd = new SqlCommand("posUserMaster_Update", SqlCon, SqlTran);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@UserMasterId", SqlDbType.SmallInt).Value = this.UserMasterId;
                SqlCmd.Parameters.Add("@Username", SqlDbType.NVarChar).Value = this.Username;
                SqlCmd.Parameters.Add("@Password", SqlDbType.NVarChar).Value = this.Password;
                SqlCmd.Parameters.Add("@linktoRoleMasterId", SqlDbType.SmallInt).Value = this.linktoRoleMasterId;
                SqlCmd.Parameters.Add("@UpdateDateTime", SqlDbType.DateTime).Value = this.UpdateDateTime;
                SqlCmd.Parameters.Add("@linktoUserMasterIdUpdatedBy", SqlDbType.SmallInt).Value = this.linktoUserMasterIdUpdatedBy;
                SqlCmd.Parameters.Add("@Comment", SqlDbType.NVarChar).Value = this.Comment;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCmd.Parameters.Add("@IsEnabled", SqlDbType.Bit).Value = this.IsEnabled;
                SqlCmd.Parameters.Add("@IsDeleted", SqlDbType.Bit).Value = this.IsDeleted;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCmd.ExecuteNonQuery();
                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;

                if (rs == posRecordStatus.Success)
                {
                    if (posUserCounterTranDAL.DeleteUserCounterTran(this.UserMasterId, SqlCon, SqlTran) == posRecordStatus.Error)
                    {
                        SqlTran.Rollback();
                        SqlCon.Close();
                        return rs;
                    }
                    else if (posUserCounterTranDAL.InsertUserCounterTran(this.UserMasterId, linktoCounterMasterIds, SqlCon, SqlTran) == posRecordStatus.Error)
                    {
                        SqlTran.Rollback();
                        SqlCon.Close();
                        return rs;
                    }
                }

                SqlTran.Commit();
                SqlCon.Close();
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public posRecordStatus UpdateUserMasterByPassword(string oldPassword)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posUserMasterByPassword_Update", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@UserMasterId", SqlDbType.SmallInt).Value = this.UserMasterId;
                SqlCmd.Parameters.Add("@Password", SqlDbType.VarChar).Value = this.Password;
                SqlCmd.Parameters.Add("@OldPassword", SqlDbType.VarChar).Value = oldPassword;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public posRecordStatus UpdateUserMasterLastLoginDateTime()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posUserMasterLastLoginDatetime_Update", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@UserMasterId", SqlDbType.SmallInt).Value = this.UserMasterId;
                SqlCmd.Parameters.Add("@LastLoginDateTime", SqlDbType.DateTime).Value = this.LastLoginDateTime;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;

                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;
                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();
                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public posRecordStatus UpdateUserMasterLastLoginFailCount()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posUserMasterLastLoginFailCount_Update", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@UserMasterId", SqlDbType.SmallInt).Value = this.UserMasterId;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;

                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;
                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();
                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public posRecordStatus UpdateUserMasterUnBlockUser()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posUserMasterUnblockUser_Update", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@UserMasterId", SqlDbType.SmallInt).Value = this.UserMasterId;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;
                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();
                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region DeleteAll

        public posRecordStatus DeleteAllUserMaster(string userMasterIds)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posUserMaster_DeleteAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@UserMasterIds", SqlDbType.VarChar).Value = userMasterIds;
                SqlCmd.Parameters.Add("@UpdateDateTime", SqlDbType.DateTime).Value = this.UpdateDateTime;
                SqlCmd.Parameters.Add("@linktoUserMasterIdUpdatedBy", SqlDbType.SmallInt).Value = this.linktoUserMasterIdUpdatedBy;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region Select
        public bool SelectUserMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader sqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posUserMaster_Select", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@UserMasterId", SqlDbType.SmallInt).Value = this.UserMasterId;

                SqlCon.Open();
                sqlRdr = SqlCmd.ExecuteReader();
                if (sqlRdr.Read())
                {
                    this.UserMasterId = Convert.ToInt16(sqlRdr["UserMasterId"]);
                    this.Username = Convert.ToString(sqlRdr["Username"]);
                    this.Password = Convert.ToString(sqlRdr["Password"]);
                    this.linktoRoleMasterId = Convert.ToInt16(sqlRdr["linktoRoleMasterId"]);
                    this.IsEnabled = Convert.ToBoolean(sqlRdr["IsEnabled"]);
                    this.Role = Convert.ToString(sqlRdr["Role"]);
                }
                sqlRdr.Close();
                SqlCon.Close();

                return true;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return false;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(sqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public bool SelectUserMasterByUsername()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posUserMasterByUsername_Select", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;
                if (this.linktoBusinessMasterId > 0)
                {
                    SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                }
                SqlCmd.Parameters.Add("@Username", SqlDbType.VarChar).Value = this.Username;
                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                bool IsSelected = SetClassPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                return IsSelected;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return false;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region SelectAll
        public List<posUserMasterDAL> SelectAllUserMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posUserMaster_SelectAll", SqlCon);
                SqlCmd.Parameters.Add("@IsEnabled", SqlDbType.Bit).Value = this.IsEnabled;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<posUserMasterDAL> lstUserMasterDAL = SetListPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                return lstUserMasterDAL;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public static List<posUserMasterDAL> SelectAllUserMasterUsername(short linktoBusinessMasterId)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posUserMasterUsername_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = linktoBusinessMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<posUserMasterDAL> lstUserMasterDAL = new List<posUserMasterDAL>();
                posUserMasterDAL objUserMasterDAL = null;
                while (SqlRdr.Read())
                {
                    objUserMasterDAL = new posUserMasterDAL();
                    objUserMasterDAL.UserMasterId = Convert.ToInt16(SqlRdr["UserMasterId"]);
                    objUserMasterDAL.Username = Convert.ToString(SqlRdr["Username"]);
                    lstUserMasterDAL.Add(objUserMasterDAL);
                }
                SqlRdr.Close();
                SqlCon.Close();

                return lstUserMasterDAL;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public static List<posUserMasterDAL> SelectAllUserMasterWaiterTypeWise()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posUserMasterWaiterTypeWise_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<posUserMasterDAL> lstUserMasterDAL = new List<posUserMasterDAL>();
                posUserMasterDAL objUserMasterDAL = null;
                while (SqlRdr.Read())
                {
                    objUserMasterDAL = new posUserMasterDAL();
                    objUserMasterDAL.UserMasterId = Convert.ToInt16(SqlRdr["UserMasterId"]);
                    objUserMasterDAL.Username = Convert.ToString(SqlRdr["Username"]);
                    if (SqlRdr["WaiterMasterId"] != DBNull.Value)
                    {
                        objUserMasterDAL.WaiterMasterId = Convert.ToInt32(SqlRdr["WaiterMasterId"]);
                    }
                    if (SqlRdr["WaiterMasterIdCaptian"] != DBNull.Value)
                    {
                        objUserMasterDAL.WaiterMasterIdCaptian = Convert.ToInt32(SqlRdr["WaiterMasterIdCaptian"]);
                    }
                    if (SqlRdr["WaiterMasterIdDeliveryPerson"] != DBNull.Value)
                    {
                        objUserMasterDAL.WaiterMasterIdDeliveryPerson = Convert.ToInt32(SqlRdr["WaiterMasterIdDeliveryPerson"]);
                    }
                    objUserMasterDAL.linktoBusinessMasterId = Convert.ToInt16(SqlRdr["linktoBusinessMasterId"]);
                    lstUserMasterDAL.Add(objUserMasterDAL);
                }
                SqlRdr.Close();
                SqlCon.Close();

                return lstUserMasterDAL;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion
    }
}
