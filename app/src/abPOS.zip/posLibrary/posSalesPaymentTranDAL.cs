using System;
using System.Data;
using System.Data.SqlClient;
using System.Collections.Generic;

namespace posLibrary
{
    /// <summary>
    /// Class for posSalesPaymentTran
    /// </summary>
    public class posSalesPaymentTranDAL
    {
        #region Properties
        public long SalesPaymentTranId { get; set; }
        public long linktoSalesMasterId { get; set; }
        public short linktoPaymentTypeMasterId { get; set; }
        public int? linktoCustomerMasterId { get; set; }
        public DateTime PaymentDateTime { get; set; }
        public double AmountPaid { get; set; }
        public string Remark { get; set; }
        public bool IsDeleted { get; set; }
        public DateTime CreateDateTime { get; set; }
        public short linktoUserMasterIdCreatedBy { get; set; }
        public DateTime? UpdateDateTime { get; set; }
        public short? linktoUserMasterIdUpdatedBy { get; set; }

        /// Extra
        public string PaymentType { get; set; }
        public string PaymentDay { get; set; }
        public string ReportPaymentDate { get; set; }
        public int SalesIdTemp { get; set; }
        //public short PersonsVisited { get; set; }
        //public string UserName { get; set; }

        #endregion

        #region Class Methods
        private List<posSalesPaymentTranDAL> SetListPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            List<posSalesPaymentTranDAL> lstSalesPaymentTran = new List<posSalesPaymentTranDAL>();
            posSalesPaymentTranDAL objSalesPaymentTran = null;
            int Count = 1;
            while (sqlRdr.Read())
            {
                objSalesPaymentTran = new posSalesPaymentTranDAL();
                objSalesPaymentTran.SalesPaymentTranId = Convert.ToInt64(sqlRdr["SalesPaymentTranId"]);
                objSalesPaymentTran.linktoSalesMasterId = Convert.ToInt64(sqlRdr["linktoSalesMasterId"]);
                if (sqlRdr["linktoPaymentTypeMasterId"] != DBNull.Value)
                {
                    objSalesPaymentTran.linktoPaymentTypeMasterId = Convert.ToInt16(sqlRdr["linktoPaymentTypeMasterId"]);
                }
                if (sqlRdr["linktoCustomerMasterId"] != DBNull.Value)
                {
                    objSalesPaymentTran.linktoCustomerMasterId = Convert.ToInt16(sqlRdr["linktoCustomerMasterId"]);
                }
                objSalesPaymentTran.PaymentDateTime = Convert.ToDateTime(sqlRdr["PaymentDateTime"]);
                objSalesPaymentTran.AmountPaid = Convert.ToDouble(sqlRdr["AmountPaid"]);
                objSalesPaymentTran.Remark = Convert.ToString(sqlRdr["Remark"]);
                objSalesPaymentTran.IsDeleted = Convert.ToBoolean(sqlRdr["IsDeleted"]);
                objSalesPaymentTran.CreateDateTime = Convert.ToDateTime(sqlRdr["CreateDateTime"]);
                objSalesPaymentTran.linktoUserMasterIdCreatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdCreatedBy"]);
                if (sqlRdr["UpdateDateTime"] != DBNull.Value)
                {
                    objSalesPaymentTran.UpdateDateTime = Convert.ToDateTime(sqlRdr["UpdateDateTime"]);
                }
                if (sqlRdr["linktoUserMasterIdUpdatedBy"] != DBNull.Value)
                {
                    objSalesPaymentTran.linktoUserMasterIdUpdatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdUpdatedBy"]);
                }

                /// Extra                
                objSalesPaymentTran.PaymentType = Convert.ToString(sqlRdr["PaymentType"]);
                // objSalesPaymentTran.Customer = Convert.ToString(sqlRdr["Customer"]);
                objSalesPaymentTran.SalesIdTemp = Count;
                lstSalesPaymentTran.Add(objSalesPaymentTran);
                Count++;
            }
            return lstSalesPaymentTran;
        }
        #endregion

        #region Insert
        public posRecordStatus InsertSalesPaymentTran(SqlConnection SqlCon, SqlTransaction SqlTran)
        {
            SqlCommand SqlCmd = null;
            try
            {
                SqlCmd = new SqlCommand("posSalesPaymentTran_Insert", SqlCon, SqlTran);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@SalesPaymentTranId", SqlDbType.BigInt).Direction = ParameterDirection.Output;
                SqlCmd.Parameters.Add("@linktoSalesMasterId", SqlDbType.BigInt).Value = this.linktoSalesMasterId;
                SqlCmd.Parameters.Add("@linktoPaymentTypeMasterId", SqlDbType.SmallInt).Value = this.linktoPaymentTypeMasterId;
                SqlCmd.Parameters.Add("@linktoCustomerMasterId", SqlDbType.Int).Value = this.linktoCustomerMasterId;
                SqlCmd.Parameters.Add("@PaymentDateTime", SqlDbType.DateTime).Value = this.PaymentDateTime;
                SqlCmd.Parameters.Add("@AmountPaid", SqlDbType.Money).Value = this.AmountPaid;
                SqlCmd.Parameters.Add("@Remark", SqlDbType.VarChar).Value = this.Remark;
                SqlCmd.Parameters.Add("@IsDeleted", SqlDbType.Bit).Value = this.IsDeleted;
                SqlCmd.Parameters.Add("@CreateDateTime", SqlDbType.DateTime).Value = this.CreateDateTime;
                SqlCmd.Parameters.Add("@linktoUserMasterIdCreatedBy", SqlDbType.SmallInt).Value = this.linktoUserMasterIdCreatedBy;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCmd.ExecuteNonQuery();

                this.SalesPaymentTranId = Convert.ToInt64(SqlCmd.Parameters["@SalesPaymentTranId"].Value);
                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
            }
        }
        #endregion

        #region Update
        public posRecordStatus UpdateSalesPaymentTran(SqlConnection SqlCon, SqlTransaction SqlTran)
        {
            SqlCommand SqlCmd = null;
            try
            {
                SqlCmd = new SqlCommand("posSalesPaymentTran_Update", SqlCon, SqlTran);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@SalesPaymentTranId", SqlDbType.BigInt).Value = this.SalesPaymentTranId;
                SqlCmd.Parameters.Add("@linktoSalesMasterId", SqlDbType.BigInt).Value = this.linktoSalesMasterId;
                SqlCmd.Parameters.Add("@linktoPaymentTypeMasterId", SqlDbType.SmallInt).Value = this.linktoPaymentTypeMasterId;
                SqlCmd.Parameters.Add("@linktoCustomerMasterId", SqlDbType.Int).Value = this.linktoCustomerMasterId;
                SqlCmd.Parameters.Add("@PaymentDateTime", SqlDbType.DateTime).Value = this.PaymentDateTime;
                SqlCmd.Parameters.Add("@AmountPaid", SqlDbType.Money).Value = this.AmountPaid;
                SqlCmd.Parameters.Add("@Remark", SqlDbType.VarChar).Value = this.Remark;
                SqlCmd.Parameters.Add("@IsDeleted", SqlDbType.Bit).Value = this.IsDeleted;
                SqlCmd.Parameters.Add("@UpdateDateTime", SqlDbType.DateTime).Value = this.UpdateDateTime;
                SqlCmd.Parameters.Add("@linktoUserMasterIdUpdatedBy", SqlDbType.SmallInt).Value = this.linktoUserMasterIdUpdatedBy;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCmd.ExecuteNonQuery();

                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
            }
        }
        #endregion

        #region SelectAll

        public List<posSalesPaymentTranDAL> SelectAllSalesPaymentTran()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posSalesPaymentTran_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;
                SqlCmd.Parameters.Add("@linktoSalesMasterId", SqlDbType.BigInt).Value = this.linktoSalesMasterId;
                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<posSalesPaymentTranDAL> lstSalesPaymentTranDAL = SetListPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                return lstSalesPaymentTranDAL;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public List<posSalesPaymentTranDAL> SelectAllSalesPaymentTranReport(DateTime FromDate, DateTime ToDate, int linktoBusinessMasterId)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader sqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection(); 
                SqlCmd = new SqlCommand("posSalesPaymentTranReport_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.Int).Value = linktoBusinessMasterId;
                SqlCmd.Parameters.Add("@FromDate", SqlDbType.DateTime).Value = FromDate;
                SqlCmd.Parameters.Add("@ToDate", SqlDbType.DateTime).Value = ToDate;


                SqlCon.Open();
                sqlRdr = SqlCmd.ExecuteReader();
                List<posSalesPaymentTranDAL> lstSalesPaymentTran = new List<posSalesPaymentTranDAL>();
                posSalesPaymentTranDAL objSalesPaymentTran = null;
                while (sqlRdr.Read())
                {
                    objSalesPaymentTran = new posSalesPaymentTranDAL();

                    objSalesPaymentTran.AmountPaid = Convert.ToDouble(sqlRdr["AmountPaid"]);
                    /// Extra
                    objSalesPaymentTran.PaymentType = Convert.ToString(sqlRdr["PaymentType"]);

                    lstSalesPaymentTran.Add(objSalesPaymentTran);
                }
                return lstSalesPaymentTran;

            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(sqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }


        public List<posSalesPaymentTranDAL> SelectAllSalesPaymentTranDayWiseReport(DateTime FromDate, DateTime ToDate, int linktoBusinessMasterId)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader sqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posSalesPaymentTranDayWiseReport_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@FromDate", SqlDbType.DateTime).Value = FromDate;
                SqlCmd.Parameters.Add("@ToDate", SqlDbType.DateTime).Value = ToDate;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.Int).Value = linktoBusinessMasterId;

                SqlCon.Open();
                sqlRdr = SqlCmd.ExecuteReader();
                List<posSalesPaymentTranDAL> lstSalesPaymentTran = new List<posSalesPaymentTranDAL>();
                posSalesPaymentTranDAL objSalesPaymentTran = null;
                while (sqlRdr.Read())
                {
                    objSalesPaymentTran = new posSalesPaymentTranDAL();
                    // objSalesPaymentTran.SalesPaymentTranId = Convert.ToInt64(sqlRdr["SalesPaymentTranId"]);
                    objSalesPaymentTran.AmountPaid = Convert.ToDouble(sqlRdr["AmountPaid"]);
                    objSalesPaymentTran.ReportPaymentDate = Convert.ToDateTime((sqlRdr["PaymentDateTime"])).ToShortDateString();
                    /// Extra
                    //objSalesPaymentTran.PaymentType = Convert.ToString(sqlRdr["PaymentType"]);
                    objSalesPaymentTran.PaymentDay = Convert.ToString(sqlRdr["PaymentDay"]);
                    lstSalesPaymentTran.Add(objSalesPaymentTran);
                }
                return lstSalesPaymentTran;

            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(sqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion
    }
}
