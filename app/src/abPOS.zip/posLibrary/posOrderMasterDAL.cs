using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace posLibrary
{
    /// <summary>
    /// Class for posOrderMaster
    /// </summary>
    public class posOrderMasterDAL
    {
        #region Properties
        public long OrderMasterId { get; set; }
        public string OrderNumber { get; set; }
        public DateTime OrderDateTime { get; set; }
        public short linktoCounterMasterId { get; set; }
        public string linktoTableMasterIds { get; set; }
        public int? linktoCustomerMasterId { get; set; }
        public short linktoOrderTypeMasterId { get; set; }
        public short? linktoOrderStatusMasterId { get; set; }
        public double TotalAmount { get; set; }
        public double TotalTax { get; set; }
        public double DiscountAmount { get; set; }
        public double DiscountPercentage { get; set; }
        public double NetAmount { get; set; }
        public double ExtraAmount { get; set; }
        public short TotalItemPoint { get; set; }
        public short TotalDeductedPoint { get; set; }
        public string Remark { get; set; }
        public long? linktoSalesMasterId { get; set; }
        public DateTime CreateDateTime { get; set; }
        public short linktoUserMasterIdCreatedBy { get; set; }
        public DateTime? UpdateDateTime { get; set; }
        public short? linktoUserMasterIdUpdatedBy { get; set; }
        public short? linktoWaiterMasterId { get; set; }
        public short? linktoWaiterMasterIdCaptain { get; set; }
        public short NoOfAdults { get; set; }
        public short NoOfChildren { get; set; }
        public short? RateIndex { get; set; }
        public short linktoBusinessMasterId { get; set; }
        public short? PrintCount { get; set; }
        public short? linktoSourceMasterId { get; set; }

        /// Extra
        public string Counter { get; set; }
        public string Customer { get; set; }
        public string OrderType { get; set; }
        public string TableName { get; set; }
        public int TotalItem { get; set; }
        public DateTime ToDateTime { get; set; }
        public string WaiterName { get; set; }
        public string CaptainName { get; set; }
        public int TotalKOT { get; set; }
        public string RateName { get; set; }
        public bool isPercentage { get; set; }
        #endregion

        #region Class Methods
        private List<posOrderMasterDAL> SetListPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            List<posOrderMasterDAL> lstOrderMaster = new List<posOrderMasterDAL>();
            posOrderMasterDAL objOrderMaster = null;
            while (sqlRdr.Read())
            {
                objOrderMaster = new posOrderMasterDAL();
                objOrderMaster.OrderMasterId = Convert.ToInt64(sqlRdr["OrderMasterId"]);
                objOrderMaster.OrderNumber = Convert.ToString(sqlRdr["OrderNumber"]);
                objOrderMaster.OrderDateTime = Convert.ToDateTime(sqlRdr["OrderDateTime"]);
                objOrderMaster.linktoCounterMasterId = Convert.ToInt16(sqlRdr["linktoCounterMasterId"]);
                objOrderMaster.linktoTableMasterIds = Convert.ToString(sqlRdr["linktoTableMasterIds"]);
                if (sqlRdr["linktoCustomerMasterId"] != DBNull.Value)
                {
                    objOrderMaster.linktoCustomerMasterId = Convert.ToInt32(sqlRdr["linktoCustomerMasterId"]);
                }
                objOrderMaster.linktoOrderTypeMasterId = Convert.ToInt16(sqlRdr["linktoOrderTypeMasterId"]);
                if (sqlRdr["linktoOrderStatusMasterId"] != DBNull.Value)
                {
                    objOrderMaster.linktoOrderStatusMasterId = Convert.ToInt16(sqlRdr["linktoOrderStatusMasterId"]);
                }
                objOrderMaster.TotalAmount = Convert.ToDouble(sqlRdr["TotalAmount"]);
                objOrderMaster.TotalTax = Convert.ToDouble(sqlRdr["TotalTax"]);
                objOrderMaster.DiscountAmount = Convert.ToDouble(sqlRdr["Discount"]);
                objOrderMaster.ExtraAmount = Convert.ToDouble(sqlRdr["ExtraAmount"]);
                objOrderMaster.NetAmount = Convert.ToDouble(sqlRdr["NetAmount"]);
                objOrderMaster.TotalItemPoint = Convert.ToInt16(sqlRdr["TotalItemPoint"]);
                objOrderMaster.TotalDeductedPoint = Convert.ToInt16(sqlRdr["TotalDeductedPoint"]);
                objOrderMaster.Remark = Convert.ToString(sqlRdr["Remark"]);
                if (sqlRdr["linktoSalesMasterId"] != DBNull.Value)
                {
                    objOrderMaster.linktoSalesMasterId = Convert.ToInt64(sqlRdr["linktoSalesMasterId"]);
                }
                else
                {
                    objOrderMaster.linktoSalesMasterId = 0;
                }
                objOrderMaster.CreateDateTime = Convert.ToDateTime(sqlRdr["CreateDateTime"]);
                objOrderMaster.linktoUserMasterIdCreatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdCreatedBy"]);
                if (sqlRdr["UpdateDateTime"] != DBNull.Value)
                {
                    objOrderMaster.UpdateDateTime = Convert.ToDateTime(sqlRdr["UpdateDateTime"]);
                }
                if (sqlRdr["linktoUserMasterIdUpdatedBy"] != DBNull.Value)
                {
                    objOrderMaster.linktoUserMasterIdUpdatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdUpdatedBy"]);
                }
                if (sqlRdr["linktoWaiterMasterIdCaptain"] != DBNull.Value)
                {
                    objOrderMaster.linktoWaiterMasterIdCaptain = Convert.ToInt16(sqlRdr["linktoWaiterMasterIdCaptain"]);
                }
                if (sqlRdr["linktoWaiterMasterId"] != DBNull.Value)
                {
                    objOrderMaster.linktoWaiterMasterId = Convert.ToInt16(sqlRdr["linktoWaiterMasterId"]);
                }
                /// Extra
                objOrderMaster.Counter = Convert.ToString(sqlRdr["Counter"]);
                //objOrderMaster.Customer = Convert.ToString(sqlRdr["Customer"]);
                objOrderMaster.OrderType = Convert.ToString(sqlRdr["OrderType"]);
                objOrderMaster.WaiterName = Convert.ToString(sqlRdr["WaiterName"]);
                objOrderMaster.TableName = Convert.ToString(sqlRdr["TableName"]);
                objOrderMaster.CaptainName = Convert.ToString(sqlRdr["CaptainName"]);

                lstOrderMaster.Add(objOrderMaster);
            }
            return lstOrderMaster;
        }
        #endregion

        #region Insert
        public posRecordStatus InsertOrderMaster(List<posOrderItemDAL> lstOrderItem, List<posOrderItemDAL> lstItemModifier)//, List<posOrderTaxTranDAL> lstOrderTaxTranDAL)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlTransaction SqlTran = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCon.Open();
                SqlTran = SqlCon.BeginTransaction();
                SqlCmd = new SqlCommand("posOrderMaster_Insert", SqlCon, SqlTran);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@OrderMasterId", SqlDbType.BigInt).Direction = ParameterDirection.Output;
                SqlCmd.Parameters.Add("@OrderNumber", SqlDbType.VarChar).Value = this.OrderNumber;
                SqlCmd.Parameters.Add("@OrderDateTime", SqlDbType.DateTime).Value = this.OrderDateTime;
                SqlCmd.Parameters.Add("@linktoCounterMasterId", SqlDbType.SmallInt).Value = this.linktoCounterMasterId;
                SqlCmd.Parameters.Add("@linktoTableMasterIds", SqlDbType.VarChar).Value = this.linktoTableMasterIds;
                SqlCmd.Parameters.Add("@linktoCustomerMasterId", SqlDbType.Int).Value = this.linktoCustomerMasterId;
                SqlCmd.Parameters.Add("@linktoOrderTypeMasterId", SqlDbType.SmallInt).Value = this.linktoOrderTypeMasterId;
                SqlCmd.Parameters.Add("@linktoOrderStatusMasterId", SqlDbType.SmallInt).Value = this.linktoOrderStatusMasterId;
                SqlCmd.Parameters.Add("@linktoWaiterMasterId", SqlDbType.SmallInt).Value = this.linktoWaiterMasterId;
                SqlCmd.Parameters.Add("@linktoWaiterMasterIdCaptain", SqlDbType.SmallInt).Value = this.linktoWaiterMasterIdCaptain;
                SqlCmd.Parameters.Add("@TotalAmount", SqlDbType.Money).Value = this.TotalAmount;
                SqlCmd.Parameters.Add("@TotalTax", SqlDbType.Money).Value = this.TotalTax;
                SqlCmd.Parameters.Add("@NetAmount", SqlDbType.Money).Value = this.NetAmount;
                SqlCmd.Parameters.Add("@DiscountPercentage", SqlDbType.Money).Value = this.DiscountPercentage;
                SqlCmd.Parameters.Add("@Discount", SqlDbType.Money).Value = this.DiscountAmount;
                SqlCmd.Parameters.Add("@ExtraAmount", SqlDbType.Money).Value = this.ExtraAmount;
                SqlCmd.Parameters.Add("@TotalItemPoint", SqlDbType.SmallInt).Value = this.TotalItemPoint;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCmd.Parameters.Add("@NoOfAdults", SqlDbType.SmallInt).Value = this.NoOfAdults;
                SqlCmd.Parameters.Add("@NoOfChildren", SqlDbType.SmallInt).Value = this.NoOfChildren;
                SqlCmd.Parameters.Add("@RateIndex", SqlDbType.SmallInt).Value = this.RateIndex;
                SqlCmd.Parameters.Add("@TotalDeductedPoint", SqlDbType.SmallInt).Value = this.TotalDeductedPoint;
                SqlCmd.Parameters.Add("@Remark", SqlDbType.VarChar).Value = this.Remark;
                SqlCmd.Parameters.Add("@linktoSalesMasterId", SqlDbType.BigInt).Value = this.linktoSalesMasterId;
                if (this.PrintCount > 0)
                {
                    SqlCmd.Parameters.Add("@PrintCount", SqlDbType.SmallInt).Value = this.PrintCount;
                }
                SqlCmd.Parameters.Add("@linktoSourceMasterId", SqlDbType.SmallInt).Value = this.linktoSourceMasterId;
                SqlCmd.Parameters.Add("@CreateDateTime", SqlDbType.DateTime).Value = this.CreateDateTime;
                SqlCmd.Parameters.Add("@linktoUserMasterIdCreatedBy", SqlDbType.SmallInt).Value = this.linktoUserMasterIdCreatedBy;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCmd.ExecuteNonQuery();

                this.OrderMasterId = Convert.ToInt64(SqlCmd.Parameters["@OrderMasterId"].Value);
                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                if (rs != posRecordStatus.Success)
                {
                    SqlTran.Rollback();
                    SqlCon.Close();
                    return rs;
                }
                rs = posOrderItemTranDAL.InsertOrderItemTran(lstOrderItem, lstItemModifier, this.OrderMasterId, this.RateIndex, this.linktoOrderStatusMasterId, SqlCon, SqlTran);
                if (rs != posRecordStatus.Success)
                {
                    SqlTran.Rollback();
                    SqlCon.Close();
                    return rs;
                }
                rs = posOrderTrackTranDAL.InsertOrderTrackTran(this.OrderMasterId, this.linktoOrderStatusMasterId, this.CreateDateTime, this.linktoUserMasterIdCreatedBy, SqlCon, SqlTran);
                if (rs != posRecordStatus.Success)
                {
                    SqlTran.Rollback();
                    SqlCon.Close();
                    return rs;
                }
                //foreach (posOrderTaxTranDAL objOrderTaxTranDAL in lstOrderTaxTranDAL)
                //{
                //    objOrderTaxTranDAL.linktoOrderMasterId = this.OrderMasterId;
                //    objOrderTaxTranDAL.linktoBusinessMasterId = this.linktoBusinessMasterId;
                //    rs = objOrderTaxTranDAL.InsertOrderTaxTran(SqlCon, SqlTran);
                //    if (rs != posRecordStatus.Success)
                //    {
                //        SqlTran.Rollback();
                //        SqlCon.Close();
                //        return rs;
                //    }
                //}

                SqlTran.Commit();
                SqlCon.Close();
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region Update
        public posRecordStatus UpdateOrderMaster(List<posOrderItemDAL> lstOrderItem, List<posOrderItemDAL> lstItemModifier)//, List<posOrderTaxTranDAL> lstOrderTaxTranDAL)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlTransaction SqlTran = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCon.Open();
                SqlTran = SqlCon.BeginTransaction();
                SqlCmd = new SqlCommand("posOrderMaster_Update", SqlCon, SqlTran);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@OrderMasterId", SqlDbType.BigInt).Value = this.OrderMasterId;
                SqlCmd.Parameters.Add("@OrderNumber", SqlDbType.VarChar).Value = this.OrderNumber;
                SqlCmd.Parameters.Add("@OrderDateTime", SqlDbType.DateTime).Value = this.OrderDateTime;
                SqlCmd.Parameters.Add("@linktoCounterMasterId", SqlDbType.SmallInt).Value = this.linktoCounterMasterId;
                SqlCmd.Parameters.Add("@linktoTableMasterIds", SqlDbType.VarChar).Value = this.linktoTableMasterIds;
                SqlCmd.Parameters.Add("@linktoCustomerMasterId", SqlDbType.Int).Value = this.linktoCustomerMasterId;
                SqlCmd.Parameters.Add("@linktoOrderTypeMasterId", SqlDbType.SmallInt).Value = this.linktoOrderTypeMasterId;
                SqlCmd.Parameters.Add("@linktoOrderStatusMasterId", SqlDbType.SmallInt).Value = this.linktoOrderStatusMasterId;
                SqlCmd.Parameters.Add("@linktoWaiterMasterId", SqlDbType.SmallInt).Value = this.linktoWaiterMasterId;
                SqlCmd.Parameters.Add("@linktoWaiterMasterIdCaptain", SqlDbType.SmallInt).Value = this.linktoWaiterMasterIdCaptain;
                SqlCmd.Parameters.Add("@TotalAmount", SqlDbType.Money).Value = this.TotalAmount;
                SqlCmd.Parameters.Add("@TotalTax", SqlDbType.Money).Value = this.TotalTax;
                SqlCmd.Parameters.Add("@NetAmount", SqlDbType.Money).Value = this.NetAmount;
                SqlCmd.Parameters.Add("@DiscountPercentage", SqlDbType.Money).Value = this.DiscountPercentage;
                SqlCmd.Parameters.Add("@Discount", SqlDbType.Money).Value = this.DiscountAmount;
                SqlCmd.Parameters.Add("@ExtraAmount", SqlDbType.Money).Value = this.ExtraAmount;
                SqlCmd.Parameters.Add("@TotalItemPoint", SqlDbType.SmallInt).Value = this.TotalItemPoint;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCmd.Parameters.Add("@NoOfAdults", SqlDbType.SmallInt).Value = this.NoOfAdults;
                SqlCmd.Parameters.Add("@NoOfChildren", SqlDbType.SmallInt).Value = this.NoOfChildren;
                SqlCmd.Parameters.Add("@RateIndex", SqlDbType.SmallInt).Value = this.RateIndex;
                SqlCmd.Parameters.Add("@TotalDeductedPoint", SqlDbType.SmallInt).Value = this.TotalDeductedPoint;
                SqlCmd.Parameters.Add("@Remark", SqlDbType.VarChar).Value = this.Remark;
                SqlCmd.Parameters.Add("@UpdateDateTime", SqlDbType.DateTime).Value = this.UpdateDateTime;
                SqlCmd.Parameters.Add("@linktoUserMasterIdUpdatedBy", SqlDbType.SmallInt).Value = this.linktoUserMasterIdUpdatedBy;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCmd.ExecuteNonQuery();

                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                if (rs != posRecordStatus.Success)
                {
                    SqlTran.Rollback();
                    SqlCon.Close();
                    return rs;
                }

                rs = posOrderItemTranDAL.DeleteOrderItemTran(this.OrderMasterId, SqlCon, SqlTran);
                if (rs != posRecordStatus.Success)
                {
                    SqlTran.Rollback();
                    SqlCon.Close();
                    return rs;
                }

                rs = posOrderItemTranDAL.InsertOrderItemTran(lstOrderItem, lstItemModifier, this.OrderMasterId, this.RateIndex, this.linktoOrderStatusMasterId, SqlCon, SqlTran);
                if (rs != posRecordStatus.Success)
                {
                    SqlTran.Rollback();
                    SqlCon.Close();
                    return rs;
                }

                //rs = posOrderTaxTranDAL.DeleteOrderTaxTran(this.OrderMasterId, SqlCon, SqlTran);
                //if (rs != posRecordStatus.Success)
                //{
                //    SqlTran.Rollback();
                //    SqlCon.Close();
                //    return rs;
                //}

                //foreach (posOrderTaxTranDAL objOrderTaxTranDAL in lstOrderTaxTranDAL)
                //{
                //    objOrderTaxTranDAL.linktoOrderMasterId = this.OrderMasterId;
                //    objOrderTaxTranDAL.linktoBusinessMasterId = this.linktoBusinessMasterId;
                //    rs = objOrderTaxTranDAL.InsertOrderTaxTran(SqlCon, SqlTran);
                //    if (rs != posRecordStatus.Success)
                //    {
                //        SqlTran.Rollback();
                //        SqlCon.Close();
                //        return rs;
                //    }
                //}

                SqlTran.Commit();
                SqlCon.Close();
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public static posRecordStatus UpdateOrderMasterByHomeDeliveryOrders(string orderMasterIds, short linktoWaiterMasterId, SqlConnection SqlCon, SqlTransaction SqlTran)
        {
            SqlCommand SqlCmd = null;
            try
            {
                SqlCmd = new SqlCommand("posOrderMasterbyHomeDeliveryOrders_Update", SqlCon, SqlTran);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@OrderMasterIds", SqlDbType.VarChar).Value = orderMasterIds;
                SqlCmd.Parameters.Add("@linktoOrderStatusMasterId", SqlDbType.SmallInt).Value = Convert.ToInt16(posOrderStatus.Dispached.GetHashCode());
                SqlCmd.Parameters.Add("@linktoWaiterMasterId", SqlDbType.SmallInt).Value = linktoWaiterMasterId;
                SqlCmd.Parameters.Add("@UpdateDateTime", SqlDbType.DateTime).Value = posGlobalsDAL.GetCurrentDateTime();
                SqlCmd.Parameters.Add("@linktoUserMasterIdUpdatedBy", SqlDbType.SmallInt).Value = posGlobalsDAL.UserInfo.UserMasterId;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCmd.ExecuteNonQuery();
                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
            }
        }

        public static posRecordStatus UpdateOrderMasterlinktoSalesMasterId(string orderMasterIds, long linktoSalesMasterId, DateTime UpdateDateTime, short linktoUserMasterIdUpdatedBy, SqlConnection SqlCon, SqlTransaction SqlTran)
        {
            SqlCommand SqlCmd = null;
            try
            {
                SqlCmd = new SqlCommand("posOrderMasterlinktoSalesMasterId_Update", SqlCon, SqlTran);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@OrderMasterIds", SqlDbType.VarChar).Value = orderMasterIds;
                SqlCmd.Parameters.Add("@linktoSalesMasterId", SqlDbType.SmallInt).Value = linktoSalesMasterId;
                SqlCmd.Parameters.Add("@UpdateDateTime", SqlDbType.DateTime).Value = UpdateDateTime;
                SqlCmd.Parameters.Add("@linktoUserMasterIdUpdatedBy", SqlDbType.SmallInt).Value = linktoUserMasterIdUpdatedBy;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCmd.ExecuteNonQuery();
                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
            }
        }

        public posRecordStatus UpdateOrderMasterOrderStatus()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posOrderMasterByOrderStatus_Update", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@OrderMasterId", SqlDbType.BigInt).Value = this.OrderMasterId;
                SqlCmd.Parameters.Add("@linktoOrderStatusMasterId", SqlDbType.SmallInt).Value = this.linktoOrderStatusMasterId;
                SqlCmd.Parameters.Add("@UpdateDateTime", SqlDbType.DateTime).Value = this.UpdateDateTime;
                SqlCmd.Parameters.Add("@linktoUserMasterIdUpdatedBy", SqlDbType.SmallInt).Value = this.linktoUserMasterIdUpdatedBy;
                SqlCmd.Parameters.Add("@linktoWaiterMasterId", SqlDbType.SmallInt).Value = this.linktoWaiterMasterId;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public posRecordStatus UpdateOrderMasterTotalAmount()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posOrderMasterByTotalAmount_Update", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@OrderMasterId", SqlDbType.BigInt).Value = this.OrderMasterId;
                SqlCmd.Parameters.Add("@TotalAmount", SqlDbType.Money).Value = this.TotalAmount;
                SqlCmd.Parameters.Add("@UpdateDateTime", SqlDbType.DateTime).Value = this.UpdateDateTime;
                SqlCmd.Parameters.Add("@linktoUserMasterIdUpdatedBy", SqlDbType.SmallInt).Value = this.linktoUserMasterIdUpdatedBy;
                SqlCmd.Parameters.Add("@linktoWaiterMasterId", SqlDbType.SmallInt).Value = this.linktoWaiterMasterId;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public posRecordStatus UpdateOrderMasterDiscount(string orderMasterIds)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posOrderMasterDiscountByOrderMasterIds_Update", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@OrderMasterIds", SqlDbType.VarChar).Value = orderMasterIds;
                SqlCmd.Parameters.Add("@Discount", SqlDbType.Money).Value = this.DiscountAmount;
                SqlCmd.Parameters.Add("@isPercentage", SqlDbType.Bit).Value = this.isPercentage;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public static posRecordStatus UpdateOrderMasterPrintCount(long orderMasterId)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posOrderMasterPrintCount_Update", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@OrderMasterId", SqlDbType.BigInt).Value = orderMasterId;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region Select
        public bool SelectOrderMasterLinktoSalesMasterId()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posOrderMasterSalesMasterIdByTableMasterId_Select", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@linktoTableMasterIds", SqlDbType.SmallInt).Value = this.linktoTableMasterIds;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                while (SqlRdr.Read())
                {
                    if (SqlRdr["linktoSalesMasterId"] != DBNull.Value)
                    {
                        this.linktoSalesMasterId = Convert.ToInt16(SqlRdr["linktoSalesMasterId"]);
                    }
                    else
                    {
                        this.linktoSalesMasterId = null;
                    }
                }
                if (this.linktoSalesMasterId == null)
                {
                    SqlRdr.Close();
                    SqlCon.Close();
                    return true;
                }

                SqlRdr.Close();
                SqlCon.Close();
                return false;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return false;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public bool SelectOrderMasterByTableMasterId()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            bool IsSelected = false;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posOrderMasterByTableMasterId_Select", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;
                SqlCmd.Parameters.Add("@linktoTableMasterId", SqlDbType.VarChar).Value = this.linktoTableMasterIds;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCmd.Parameters.Add("@FromDate", SqlDbType.DateTime).Value = this.OrderDateTime;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();

                if (SqlRdr.Read())
                {
                    IsSelected = Convert.ToBoolean(SqlRdr["OrderCount"]);
                }
                SqlRdr.Close();
                SqlCon.Close();

                return IsSelected;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return false;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public bool SelectOrderMasterForKOT()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posOrderMasterForKOT_Select", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;
                SqlCmd.Parameters.Add("@OrderMasterId", SqlDbType.BigInt).Value = this.OrderMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();

                bool IsSelected = false;
                if (SqlRdr.Read())
                {
                    this.OrderMasterId = Convert.ToInt64(SqlRdr["OrderMasterId"]);
                    this.OrderNumber = Convert.ToString(SqlRdr["OrderNumber"]);
                    this.OrderDateTime = Convert.ToDateTime(SqlRdr["OrderDateTime"]);
                    this.WaiterName = Convert.ToString(SqlRdr["WaiterName"]);
                    this.OrderType = Convert.ToString(SqlRdr["OrderType"]);
                    this.Remark = Convert.ToString(SqlRdr["Remark"]);
                    this.TableName = Convert.ToString(SqlRdr["TableName"]);
                    IsSelected = true;
                }
                SqlRdr.Close();
                SqlCon.Close();

                return IsSelected;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return false;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region SelectAll
        public List<posOrderMasterDAL> SelectAllOrderMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posOrderMaster_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;
                if (OrderNumber != null)
                {
                    SqlCmd.Parameters.Add("@OrderNumber", SqlDbType.VarChar).Value = this.OrderNumber;
                }
                if (linktoTableMasterIds != null)
                {
                    SqlCmd.Parameters.Add("@linktoTableMasterIds", SqlDbType.VarChar).Value = this.linktoTableMasterIds;
                }
                if (OrderDateTime != null)
                {
                    SqlCmd.Parameters.Add("@OrderDateTime", SqlDbType.Date).Value = this.OrderDateTime;
                }
                if (ToDateTime != null)
                {
                    SqlCmd.Parameters.Add("@ToDateTime", SqlDbType.Date).Value = this.ToDateTime;
                }
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<posOrderMasterDAL> lstOrderMasterDAL = SetListPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                return lstOrderMasterDAL;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public List<posOrderMasterDAL> SelectAllOrderMasterOrderNumber(int? tableMasterId = null)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posOrderMasterOrderNumber_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;
                SqlCmd.Parameters.Add("@tableMasterId", SqlDbType.VarChar).Value = tableMasterId;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<posOrderMasterDAL> lstOrderMasterDAL = new List<posOrderMasterDAL>();
                posOrderMasterDAL objOrderMasterDAL = null;
                while (SqlRdr.Read())
                {
                    objOrderMasterDAL = new posOrderMasterDAL();
                    objOrderMasterDAL.OrderMasterId = Convert.ToInt64(SqlRdr["OrderMasterId"]);
                    objOrderMasterDAL.OrderNumber = Convert.ToString(SqlRdr["OrderNumber"]);
                    if (SqlRdr["linktoSalesMasterId"] != DBNull.Value)
                    {
                        objOrderMasterDAL.linktoSalesMasterId = Convert.ToInt64(SqlRdr["linktoSalesMasterId"]);
                    }
                    else
                    {
                        objOrderMasterDAL.linktoSalesMasterId = 0;
                    }
                    lstOrderMasterDAL.Add(objOrderMasterDAL);
                }
                SqlRdr.Close();
                SqlCon.Close();

                return lstOrderMasterDAL;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public static List<posOrderMasterDAL> SelectAllOrderMasterBySales(short linktoBusinessMasterId)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posOrderMasterBySales_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = linktoBusinessMasterId;
                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<posOrderMasterDAL> lstOrderMasterDAL = new List<posOrderMasterDAL>();
                posOrderMasterDAL objOrderMasterDAL = null;
                while (SqlRdr.Read())
                {
                    objOrderMasterDAL = new posOrderMasterDAL();
                    objOrderMasterDAL.OrderMasterId = Convert.ToInt64(SqlRdr["OrderMasterId"]);
                    objOrderMasterDAL.OrderNumber = Convert.ToString(SqlRdr["OrderNumber"]);

                    objOrderMasterDAL.linktoTableMasterIds = Convert.ToString(SqlRdr["linktoTableMasterIds"]);

                    if (SqlRdr["linktoSalesMasterId"] != DBNull.Value)
                    {
                        objOrderMasterDAL.linktoSalesMasterId = Convert.ToInt64(SqlRdr["linktoSalesMasterId"]);
                    }
                    objOrderMasterDAL.CreateDateTime = Convert.ToDateTime(SqlRdr["CreateDateTime"]);

                    lstOrderMasterDAL.Add(objOrderMasterDAL);
                }
                SqlRdr.Close();
                SqlCon.Close();

                return lstOrderMasterDAL;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex, false);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public static List<posOrderMasterDAL> SelectAllOrderMasterForPrint(short linktoBusinessMasterId, DateTime systemDateTime)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posOrderMasterForPrint_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = linktoBusinessMasterId;
                SqlCmd.Parameters.Add("@SystemDateTime", SqlDbType.DateTime).Value = systemDateTime;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<posOrderMasterDAL> lstOrderMasterDAL = new List<posOrderMasterDAL>();
                posOrderMasterDAL objOrderMasterDAL = null;
                while (SqlRdr.Read())
                {
                    objOrderMasterDAL = new posOrderMasterDAL();
                    objOrderMasterDAL.OrderMasterId = Convert.ToInt64(SqlRdr["OrderMasterId"]);
                    lstOrderMasterDAL.Add(objOrderMasterDAL);
                }
                SqlRdr.Close();
                SqlCon.Close();

                return lstOrderMasterDAL;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex, false);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public List<posOrderMasterDAL> SelectAllOrderMasterByOrderStatus()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posOrderMasterByOrderStatusMasterId_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@linktoCounterMasterId", SqlDbType.SmallInt).Value = this.linktoCounterMasterId;
                if (linktoOrderStatusMasterId > 0)
                {
                    SqlCmd.Parameters.Add("@linktoOrderStatusMasterId", SqlDbType.SmallInt).Value = this.linktoOrderStatusMasterId;
                }
                if (linktoTableMasterIds != null)
                {
                    SqlCmd.Parameters.Add("@linktoTableMasterIds", SqlDbType.VarChar).Value = this.linktoTableMasterIds;
                }
                if (linktoOrderTypeMasterId > 0)
                {
                    SqlCmd.Parameters.Add("@linktoOrderTypeMasterId", SqlDbType.SmallInt).Value = this.linktoOrderTypeMasterId;
                }
                SqlCmd.Parameters.Add("@FromDate", SqlDbType.DateTime).Value = this.OrderDateTime;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<posOrderMasterDAL> lstOrderMasterDAL = new List<posOrderMasterDAL>();
                posOrderMasterDAL objOrderMasterDAL = null;
                while (SqlRdr.Read())
                {
                    objOrderMasterDAL = new posOrderMasterDAL();
                    objOrderMasterDAL.OrderMasterId = Convert.ToInt64(SqlRdr["OrderMasterId"]);
                    objOrderMasterDAL.OrderNumber = Convert.ToString(SqlRdr["OrderNumber"]);
                    objOrderMasterDAL.OrderDateTime = Convert.ToDateTime(SqlRdr["OrderDateTime"]);
                    objOrderMasterDAL.linktoCounterMasterId = Convert.ToInt16(SqlRdr["linktoCounterMasterId"]);
                    objOrderMasterDAL.linktoTableMasterIds = Convert.ToString(SqlRdr["linktoTableMasterIds"]);
                    if (SqlRdr["linktoCustomerMasterId"] != DBNull.Value)
                    {
                        objOrderMasterDAL.linktoCustomerMasterId = Convert.ToInt32(SqlRdr["linktoCustomerMasterId"]);
                    }
                    objOrderMasterDAL.linktoOrderTypeMasterId = Convert.ToInt16(SqlRdr["linktoOrderTypeMasterId"]);
                    if (SqlRdr["linktoOrderStatusMasterId"] != DBNull.Value)
                    {
                        objOrderMasterDAL.linktoOrderStatusMasterId = Convert.ToInt16(SqlRdr["linktoOrderStatusMasterId"]);
                    }
                    objOrderMasterDAL.TotalAmount = Convert.ToDouble(SqlRdr["TotalAmount"]);
                    objOrderMasterDAL.TotalTax = Convert.ToDouble(SqlRdr["TotalTax"]);
                    objOrderMasterDAL.DiscountAmount = Convert.ToDouble(SqlRdr["Discount"]);
                    objOrderMasterDAL.DiscountPercentage = Convert.ToDouble(SqlRdr["DiscountPercentage"]);
                    objOrderMasterDAL.ExtraAmount = Convert.ToDouble(SqlRdr["ExtraAmount"]);
                    objOrderMasterDAL.TotalItemPoint = Convert.ToInt16(SqlRdr["TotalItemPoint"]);
                    objOrderMasterDAL.TotalDeductedPoint = Convert.ToInt16(SqlRdr["TotalDeductedPoint"]);
                    objOrderMasterDAL.Remark = Convert.ToString(SqlRdr["Remark"]);
                    if (SqlRdr["linktoSalesMasterId"] != DBNull.Value)
                    {
                        objOrderMasterDAL.linktoSalesMasterId = Convert.ToInt64(SqlRdr["linktoSalesMasterId"]);
                    }
                    objOrderMasterDAL.CreateDateTime = Convert.ToDateTime(SqlRdr["CreateDateTime"]);
                    objOrderMasterDAL.linktoUserMasterIdCreatedBy = Convert.ToInt16(SqlRdr["linktoUserMasterIdCreatedBy"]);
                    if (SqlRdr["UpdateDateTime"] != DBNull.Value)
                    {
                        objOrderMasterDAL.UpdateDateTime = Convert.ToDateTime(SqlRdr["UpdateDateTime"]);
                    }
                    if (SqlRdr["linktoUserMasterIdUpdatedBy"] != DBNull.Value)
                    {
                        objOrderMasterDAL.linktoUserMasterIdUpdatedBy = Convert.ToInt16(SqlRdr["linktoUserMasterIdUpdatedBy"]);
                    }

                    /// Extra
                    objOrderMasterDAL.Counter = Convert.ToString(SqlRdr["Counter"]);
                    objOrderMasterDAL.Customer = Convert.ToString(SqlRdr["Customer"]);
                    objOrderMasterDAL.OrderType = Convert.ToString(SqlRdr["OrderType"]);
                    objOrderMasterDAL.TableName = Convert.ToString(SqlRdr["TableName"]);
                    objOrderMasterDAL.TotalItem = Convert.ToInt32(SqlRdr["TotalItem"]);

                    lstOrderMasterDAL.Add(objOrderMasterDAL);

                }
                SqlRdr.Close();
                SqlCon.Close();

                return lstOrderMasterDAL;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public List<posOrderMasterDAL> SelectAllOrderMasterByFromDate()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posOrderMasterByFromDate_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@linktoCounterMasterId", SqlDbType.SmallInt).Value = this.linktoCounterMasterId;
                SqlCmd.Parameters.Add("@FromDate", SqlDbType.DateTime).Value = this.OrderDateTime;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<posOrderMasterDAL> lstOrderMasterDAL = new List<posOrderMasterDAL>();
                posOrderMasterDAL objOrderMasterDAL = null;
                while (SqlRdr.Read())
                {
                    objOrderMasterDAL = new posOrderMasterDAL();
                    objOrderMasterDAL.OrderDateTime = Convert.ToDateTime(SqlRdr["OrderDateTime"]);
                    objOrderMasterDAL.linktoTableMasterIds = Convert.ToString(SqlRdr["linktoTableMasterIds"]);
                    objOrderMasterDAL.TotalAmount = Convert.ToDouble(SqlRdr["TotalAmount"]);
                    objOrderMasterDAL.TableName = Convert.ToString(SqlRdr["TableName"]);
                    objOrderMasterDAL.TotalItem = Convert.ToInt32(SqlRdr["TotalItem"]);
                    objOrderMasterDAL.TotalKOT = Convert.ToInt32(SqlRdr["TotalKOT"]);
                    objOrderMasterDAL.TotalTax = Convert.ToDouble(SqlRdr["TotalTax"]);
                    objOrderMasterDAL.linktoOrderTypeMasterId = Convert.ToInt16(SqlRdr["linktoOrderTypeMasterId"]);

                    lstOrderMasterDAL.Add(objOrderMasterDAL);

                }
                SqlRdr.Close();
                SqlCon.Close();

                return lstOrderMasterDAL;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public List<posOrderMasterDAL> SelectAllOrderMasterByOrderNumbers(string orderMasterIds)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posOrderMasterByOrderNumber_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;
                SqlCmd.Parameters.Add("@OrderMasterIds", SqlDbType.VarChar).Value = orderMasterIds;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();

                List<posOrderMasterDAL> lstOrderMaster = new List<posOrderMasterDAL>();
                posOrderMasterDAL objOrderMaster = null;
                while (SqlRdr.Read())
                {
                    objOrderMaster = new posOrderMasterDAL();
                    objOrderMaster.OrderMasterId = Convert.ToInt64(SqlRdr["OrderMasterId"]);
                    objOrderMaster.OrderNumber = Convert.ToString(SqlRdr["OrderNumber"]);
                    objOrderMaster.OrderDateTime = Convert.ToDateTime(SqlRdr["OrderDateTime"]);
                    objOrderMaster.linktoCounterMasterId = Convert.ToInt16(SqlRdr["linktoCounterMasterId"]);
                    objOrderMaster.linktoTableMasterIds = Convert.ToString(SqlRdr["linktoTableMasterIds"]);
                    if (SqlRdr["linktoCustomerMasterId"] != DBNull.Value)
                    {
                        objOrderMaster.linktoCustomerMasterId = Convert.ToInt32(SqlRdr["linktoCustomerMasterId"]);
                    }
                    objOrderMaster.linktoOrderTypeMasterId = Convert.ToInt16(SqlRdr["linktoOrderTypeMasterId"]);

                    objOrderMaster.Remark = Convert.ToString(SqlRdr["Remark"]);
                    if (SqlRdr["linktoWaiterMasterId"] != DBNull.Value)
                    {
                        objOrderMaster.linktoWaiterMasterId = Convert.ToInt16(SqlRdr["linktoWaiterMasterId"]);
                    }
                    if (SqlRdr["linktoWaiterMasterIdCaptain"] != DBNull.Value)
                    {
                        objOrderMaster.linktoWaiterMasterIdCaptain = Convert.ToInt16(SqlRdr["linktoWaiterMasterIdCaptain"]);
                    }
                    if (SqlRdr["RateIndex"] != DBNull.Value)
                    {
                        objOrderMaster.RateIndex = Convert.ToInt16(SqlRdr["RateIndex"]);
                    }
                    objOrderMaster.NoOfAdults = Convert.ToInt16(SqlRdr["NoOfAdults"]);
                    objOrderMaster.NoOfChildren = Convert.ToInt16(SqlRdr["NoOfChildren"]);
                    objOrderMaster.DiscountPercentage = Convert.ToDouble(SqlRdr["DiscountPercentage"]);
                    objOrderMaster.DiscountAmount = Convert.ToDouble(SqlRdr["Discount"]);
                    /// Extra
                    objOrderMaster.Counter = Convert.ToString(SqlRdr["Counter"]);
                    objOrderMaster.Customer = Convert.ToString(SqlRdr["Customer"]);
                    objOrderMaster.OrderType = Convert.ToString(SqlRdr["OrderType"]);
                    objOrderMaster.WaiterName = Convert.ToString(SqlRdr["WaiterName"]);
                    objOrderMaster.TableName = Convert.ToString(SqlRdr["TableName"]);
                    objOrderMaster.CaptainName = Convert.ToString(SqlRdr["CaptainName"]);
                    objOrderMaster.RateName = Convert.ToString(SqlRdr["RateName"]);
                    lstOrderMaster.Add(objOrderMaster);
                }

                SqlRdr.Close();
                SqlCon.Close();

                return lstOrderMaster;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion
    }
}
