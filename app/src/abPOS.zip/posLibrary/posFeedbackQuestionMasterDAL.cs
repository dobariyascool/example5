using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace posLibrary
{
    /// <summary>
    /// Class for posFeedbackQuestionMaster
    /// </summary>
    public class posFeedbackQuestionMasterDAL
    {
        #region Properties
        public int FeedbackQuestionMasterId { get; set; }
        public short linktoBusinessMasterId { get; set; }
        public string FeedbackQuestion { get; set; }
        public short QuestionType { get; set; }
        public short? linktoFeedbackQuestionGroupMasterId { get; set; }
        public int? SortOrder { get; set; }
        public bool IsEnabled { get; set; }
        public bool IsDeleted { get; set; }
        public List<posFeedbackAnswerMasterDAL> lstFeedbackAnswerMasterDAL { get; set; }

        /// Extra
        public string QuestionTypeName { get; set; }
        public string QuestionGroupName { get; set; }
        #endregion

        #region Class Methods
        private bool SetClassPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            if (sqlRdr.Read())
            {
                this.FeedbackQuestionMasterId = Convert.ToInt32(sqlRdr["FeedbackQuestionMasterId"]);
                this.linktoBusinessMasterId = Convert.ToInt16(sqlRdr["linktoBusinessMasterId"]);
                this.FeedbackQuestion = Convert.ToString(sqlRdr["FeedbackQuestion"]);
                if (sqlRdr["linktoFeedbackQuestionGroupMasterId"] != DBNull.Value)
                {
                    this.linktoFeedbackQuestionGroupMasterId = Convert.ToInt16(sqlRdr["linktoFeedbackQuestionGroupMasterId"]);
                    this.QuestionGroupName = Convert.ToString(sqlRdr["QuestionGroupName"]);
                }
                this.QuestionType = Convert.ToInt16(sqlRdr["QuestionType"]);
                if (sqlRdr["SortOrder"] != DBNull.Value)
                {
                    this.SortOrder = Convert.ToInt32(sqlRdr["SortOrder"]);
                }
                this.IsEnabled = Convert.ToBoolean(sqlRdr["IsEnabled"]);
                this.IsDeleted = Convert.ToBoolean(sqlRdr["IsDeleted"]);

                /// Extra
                /// 
                return true;
            }
            return false;
        }

        private List<posFeedbackQuestionMasterDAL> SetListPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            List<posFeedbackQuestionMasterDAL> lstFeedbackQuestionMaster = new List<posFeedbackQuestionMasterDAL>();
            posFeedbackQuestionMasterDAL objFeedbackQuestionMaster = null;
            while (sqlRdr.Read())
            {
                objFeedbackQuestionMaster = new posFeedbackQuestionMasterDAL();
                objFeedbackQuestionMaster.FeedbackQuestionMasterId = Convert.ToInt32(sqlRdr["FeedbackQuestionMasterId"]);
                objFeedbackQuestionMaster.linktoBusinessMasterId = Convert.ToInt16(sqlRdr["linktoBusinessMasterId"]);
                objFeedbackQuestionMaster.FeedbackQuestion = Convert.ToString(sqlRdr["FeedbackQuestion"]);
                if (sqlRdr["linktoFeedbackQuestionGroupMasterId"] != DBNull.Value)
                {
                    objFeedbackQuestionMaster.linktoFeedbackQuestionGroupMasterId = Convert.ToInt16(sqlRdr["linktoFeedbackQuestionGroupMasterId"]);
                    objFeedbackQuestionMaster.QuestionGroupName = Convert.ToString(sqlRdr["QuestionGroupName"]);
                }
                objFeedbackQuestionMaster.QuestionType = Convert.ToInt16(sqlRdr["QuestionType"]);
                if (sqlRdr["SortOrder"] != DBNull.Value)
                {
                    objFeedbackQuestionMaster.SortOrder = Convert.ToInt32(sqlRdr["SortOrder"]);
                }
                objFeedbackQuestionMaster.IsEnabled = Convert.ToBoolean(sqlRdr["IsEnabled"]);
                objFeedbackQuestionMaster.IsDeleted = Convert.ToBoolean(sqlRdr["IsDeleted"]);

                /// Extra
                if (sqlRdr["QuestionType"] != DBNull.Value)
                {
                    Array Type = Enum.GetValues(typeof(posFeedbackQuestionType));
                    foreach (posFeedbackQuestionType obj in Type)
                    {
                        if (obj.GetHashCode() == Convert.ToInt16(sqlRdr["QuestionType"]))
                        {
                            objFeedbackQuestionMaster.QuestionTypeName = obj.ToString().Replace('_', ' ');
                        }
                    }
                }
                lstFeedbackQuestionMaster.Add(objFeedbackQuestionMaster);
            }
            return lstFeedbackQuestionMaster;
        }
        #endregion

        #region Insert
        public posRecordStatus InsertFeedbackQuestionMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlTransaction sqlTran = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCon.Open();
                sqlTran = SqlCon.BeginTransaction();
                SqlCmd = new SqlCommand("posFeedbackQuestionMaster_Insert", SqlCon, sqlTran);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@FeedbackQuestionMasterId", SqlDbType.Int).Direction = ParameterDirection.Output;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCmd.Parameters.Add("@FeedbackQuestion", SqlDbType.VarChar).Value = this.FeedbackQuestion;

                SqlCmd.Parameters.Add("@linktoFeedbackQuestionGroupMasterId", SqlDbType.SmallInt).Value = this.linktoFeedbackQuestionGroupMasterId;

                SqlCmd.Parameters.Add("@QuestionType", SqlDbType.SmallInt).Value = this.QuestionType;
                SqlCmd.Parameters.Add("@SortOrder", SqlDbType.Int).Value = this.SortOrder;
                SqlCmd.Parameters.Add("@IsEnabled", SqlDbType.Bit).Value = this.IsEnabled;
                SqlCmd.Parameters.Add("@IsDeleted", SqlDbType.Bit).Value = this.IsDeleted;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCmd.ExecuteNonQuery();

                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;

                if (rs != posRecordStatus.RecordNotFound)
                {
                    this.FeedbackQuestionMasterId = Convert.ToInt32(SqlCmd.Parameters["@FeedbackQuestionMasterId"].Value);
                }

                if (rs != posRecordStatus.Success)
                {
                    sqlTran.Rollback();
                    SqlCon.Close();
                    return rs;
                }
                else
                {
                    posRecordStatus rs1 = posRecordStatus.Error;
                    if (this.QuestionType == Convert.ToInt16(posFeedbackQuestionType.Multi_Select.GetHashCode()) || this.QuestionType == Convert.ToInt16(posFeedbackQuestionType.Single_Select.GetHashCode()))
                    {
                        if (lstFeedbackAnswerMasterDAL != null)
                        {
                            foreach (posFeedbackAnswerMasterDAL objFeedbackAnswerMasterDAL in this.lstFeedbackAnswerMasterDAL)
                            {
                                if (objFeedbackAnswerMasterDAL.FeedbackAnswerMasterId > 0)
                                {
                                    objFeedbackAnswerMasterDAL.linktoFeedbackQuestionMasterId = this.FeedbackQuestionMasterId;
                                    rs1 = objFeedbackAnswerMasterDAL.UpdateFeedbackAnswerMaster(SqlCon, sqlTran);
                                }
                                else
                                {
                                    objFeedbackAnswerMasterDAL.linktoFeedbackQuestionMasterId = this.FeedbackQuestionMasterId;
                                    rs1 = objFeedbackAnswerMasterDAL.InsertFeedbackAnswerMaster(SqlCon, sqlTran);
                                }
                                if (rs1 != posRecordStatus.Success)
                                {
                                    sqlTran.Rollback();
                                    SqlCon.Close();
                                    return rs;
                                }
                            }
                        }

                    }
                }
                sqlTran.Commit();
                SqlCon.Close();
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
                posObjectFactoryDAL.DisposeTransaction(sqlTran);
            }
        }
        #endregion

        #region Update
        public posRecordStatus UpdateFeedbackQuestionMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlTransaction sqlTran = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCon.Open();
                sqlTran = SqlCon.BeginTransaction();
                SqlCmd = new SqlCommand("posFeedbackQuestionMaster_Update", SqlCon, sqlTran);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@FeedbackQuestionMasterId", SqlDbType.Int).Value = this.FeedbackQuestionMasterId;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCmd.Parameters.Add("@FeedbackQuestion", SqlDbType.VarChar).Value = this.FeedbackQuestion;
                SqlCmd.Parameters.Add("@QuestionType", SqlDbType.SmallInt).Value = this.QuestionType;

                SqlCmd.Parameters.Add("@linktoFeedbackQuestionGroupMasterId", SqlDbType.SmallInt).Value = this.linktoFeedbackQuestionGroupMasterId;

                SqlCmd.Parameters.Add("@SortOrder", SqlDbType.Int).Value = this.SortOrder;
                SqlCmd.Parameters.Add("@IsEnabled", SqlDbType.Bit).Value = this.IsEnabled;
                SqlCmd.Parameters.Add("@IsDeleted", SqlDbType.Bit).Value = this.IsDeleted;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCmd.ExecuteNonQuery();

                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;

                if (rs != posRecordStatus.Success)
                {
                    sqlTran.Rollback();
                    SqlCon.Close();
                    return rs;
                }
                else
                {
                    posRecordStatus rs1 = posRecordStatus.Error;
                    if (this.QuestionType == Convert.ToInt16(posFeedbackQuestionType.Multi_Select.GetHashCode()) || this.QuestionType == Convert.ToInt16(posFeedbackQuestionType.Single_Select.GetHashCode()))
                    {
                        foreach (posFeedbackAnswerMasterDAL objFeedbackAnswerMasterDAL in this.lstFeedbackAnswerMasterDAL)
                        {
                            if (objFeedbackAnswerMasterDAL.FeedbackAnswerMasterId > 0)
                            {
                                objFeedbackAnswerMasterDAL.linktoFeedbackQuestionMasterId = this.FeedbackQuestionMasterId;
                                rs1 = objFeedbackAnswerMasterDAL.UpdateFeedbackAnswerMaster(SqlCon, sqlTran);
                            }
                            else
                            {
                                objFeedbackAnswerMasterDAL.linktoFeedbackQuestionMasterId = this.FeedbackQuestionMasterId;
                                rs1 = objFeedbackAnswerMasterDAL.InsertFeedbackAnswerMaster(SqlCon, sqlTran);
                            }
                            if (rs1 != posRecordStatus.Success)
                            {
                                sqlTran.Rollback();
                                SqlCon.Close();
                                return rs;
                            }
                        }
                    }

                }
                sqlTran.Commit();
                SqlCon.Close();
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
                posObjectFactoryDAL.DisposeTransaction(sqlTran);
            }
        }
        #endregion

        #region DeleteAll
        public posRecordStatus DeleteAllFeedbackQuestionMaster(string feedbackQuestionMasterIds)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posFeedbackQuestionMaster_DeleteAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@FeedbackQuestionMasterIds", SqlDbType.VarChar).Value = feedbackQuestionMasterIds;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region Select
        public bool SelectFeedbackQuestionMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posFeedbackQuestionMaster_Select", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@FeedbackQuestionMasterId", SqlDbType.Int).Value = this.FeedbackQuestionMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                bool IsSelected = SetClassPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                return IsSelected;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return false;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region SelectAll
        public List<posFeedbackQuestionMasterDAL> SelectAllFeedbackQuestionMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posFeedbackQuestionMaster_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@IsEnabled", SqlDbType.Bit).Value = this.IsEnabled;
                if (this.QuestionType > 0)
                {
                    SqlCmd.Parameters.Add("@QuestionType", SqlDbType.SmallInt).Value = this.QuestionType;
                }
                SqlCmd.Parameters.Add("@FeedbackQuestion", SqlDbType.VarChar).Value = this.FeedbackQuestion;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<posFeedbackQuestionMasterDAL> lstFeedbackQuestionMasterDAL = SetListPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                return lstFeedbackQuestionMasterDAL;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion
    }
}
