using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace posLibrary
{
	/// <summary>
	/// Class for posWaitingStatusMaster
	/// </summary>
	public class posWaitingStatusMasterDAL
	{
		#region Properties
		public short WaitingStatusMasterId { get; set; }
		public string WaitingStatus { get; set; }
		public string StatusColor { get; set; }
		#endregion

		#region Class Methods
		private List<posWaitingStatusMasterDAL> SetListPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
		{
			List<posWaitingStatusMasterDAL> lstWaitingStatusMaster = new List<posWaitingStatusMasterDAL>();
			posWaitingStatusMasterDAL objWaitingStatusMaster = null;
			while (sqlRdr.Read())
			{
				objWaitingStatusMaster = new posWaitingStatusMasterDAL();
				objWaitingStatusMaster.WaitingStatusMasterId = Convert.ToInt16(sqlRdr["WaitingStatusMasterId"]);
				objWaitingStatusMaster.WaitingStatus = Convert.ToString(sqlRdr["WaitingStatus"]);
				objWaitingStatusMaster.StatusColor = Convert.ToString(sqlRdr["StatusColor"]);
				lstWaitingStatusMaster.Add(objWaitingStatusMaster);
			}
			return lstWaitingStatusMaster;
		}
		#endregion

		#region SelectAll

		public List<posWaitingStatusMasterDAL> SelectAllWaitingStatusMaster()
		{
			SqlConnection SqlCon = null;
			SqlCommand SqlCmd = null;
			SqlDataReader SqlRdr = null;
			try
			{
				SqlCon = posObjectFactoryDAL.CreateConnection();
				SqlCmd = new SqlCommand("posWaitingStatusMaster_SelectAll", SqlCon);
				SqlCmd.CommandType = CommandType.StoredProcedure;

				SqlCon.Open();
				SqlRdr = SqlCmd.ExecuteReader();
				List<posWaitingStatusMasterDAL> lstWaitingStatusMasterDAL = SetListPropertiesFromSqlDataReader(SqlRdr);
				SqlRdr.Close();
				SqlCon.Close();

				return lstWaitingStatusMasterDAL;
			}
			catch (Exception ex)
			{
				posGlobalsDAL.SaveError(ex);
				return null;
			}
			finally
			{
				posObjectFactoryDAL.DisposeDataReader(SqlRdr);
				posObjectFactoryDAL.DisposeCommand(SqlCmd);
				posObjectFactoryDAL.DisposeConnection(SqlCon);
			}
		}
		#endregion
	}
}
