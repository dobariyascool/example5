using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace posLibrary
{
    /// <summary>
    /// Class for posMembershipType
    /// </summary>
    public class posMembershipTypeDAL
    {
        #region Properties
        public short MembershipTypeMasterId { get; set; }
        public string MembershipType { get; set; }
        public string Prefix { get; set; }
        public string DisplayFormat { get; set; }
        public bool IsCardOfPoint { get; set; }
        public short TotalDigits { get; set; }
        public double PricePerPoint { get; set; }
        public double? NewCardRate { get; set; }
        public short? NewCardBonusPoints { get; set; }
        public double? NewCardBonusAmount { get; set; }
        public double? CardRenewalRate { get; set; }
        public short? CardRenewalBonusPoints { get; set; }
        public double? CardRenewalBonusAmount { get; set; }
        public short? ValidMonths { get; set; }
        public short MinimumPointsForDeduction { get; set; }
        public string TermsAndConditions { get; set; }
        public bool IsEnabled { get; set; }
        public DateTime CreateDateTime { get; set; }
        public int linktoUserMasterIdCreatedBy { get; set; }
        public DateTime? UpdateDateTime { get; set; }
        public int? linktoUserMasterIdUpdatedBy { get; set; }
        public short linktoBusinessMasterId { get; set; }
        #endregion

        #region Class Methods
        private bool SetClassPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            if (sqlRdr.Read())
            {
                this.MembershipTypeMasterId = Convert.ToInt16(sqlRdr["MembershipTypeMasterId"]);
                this.MembershipType = Convert.ToString(sqlRdr["MembershipType"]);
                this.Prefix = Convert.ToString(sqlRdr["Prefix"]);
                this.DisplayFormat = Convert.ToString(sqlRdr["DisplayFormat"]);
                this.TotalDigits = Convert.ToInt16(sqlRdr["TotalDigits"]);
                this.PricePerPoint = Convert.ToDouble(sqlRdr["PricePerPoint"]);
                this.IsCardOfPoint = Convert.ToBoolean(sqlRdr["IsCardOfPoint"]);
                if (sqlRdr["NewCardRate"] != DBNull.Value)
                {
                    this.NewCardRate = Convert.ToDouble(sqlRdr["NewCardRate"]);
                }
                if (sqlRdr["NewCardBonusPoints"] != DBNull.Value)
                {
                    this.NewCardBonusPoints = Convert.ToInt16(sqlRdr["NewCardBonusPoints"]);
                }
                if (sqlRdr["NewCardBonusAmount"] != DBNull.Value)
                {
                    this.NewCardBonusAmount = Convert.ToDouble(sqlRdr["NewCardBonusAmount"]);
                }
                if (sqlRdr["CardRenewalRate"] != DBNull.Value)
                {
                    this.CardRenewalRate = Convert.ToDouble(sqlRdr["CardRenewalRate"]);
                }
                if (sqlRdr["CardRenewalBonusPoints"] != DBNull.Value)
                {
                    this.CardRenewalBonusPoints = Convert.ToInt16(sqlRdr["CardRenewalBonusPoints"]);
                }
                if (sqlRdr["CardRenewalBonusAmount"] != DBNull.Value)
                {
                    this.CardRenewalBonusAmount = Convert.ToDouble(sqlRdr["CardRenewalBonusAmount"]);
                }
                if (sqlRdr["ValidMonths"] != DBNull.Value)
                {
                    this.ValidMonths = Convert.ToInt16(sqlRdr["ValidMonths"]);
                }
                this.MinimumPointsForDeduction = Convert.ToInt16(sqlRdr["MinimumPointsForDeduction"]);
                this.TermsAndConditions = Convert.ToString(sqlRdr["TermsAndConditions"]);
                this.IsEnabled = Convert.ToBoolean(sqlRdr["IsEnabled"]);
                this.CreateDateTime = Convert.ToDateTime(sqlRdr["CreateDateTime"]);
                this.linktoUserMasterIdCreatedBy = Convert.ToInt32(sqlRdr["linktoUserMasterIdCreatedBy"]);
                if (sqlRdr["UpdateDateTime"] != DBNull.Value)
                {
                    this.UpdateDateTime = Convert.ToDateTime(sqlRdr["UpdateDateTime"]);
                }
                if (sqlRdr["linktoUserMasterIdUpdatedBy"] != DBNull.Value)
                {
                    this.linktoUserMasterIdUpdatedBy = Convert.ToInt32(sqlRdr["linktoUserMasterIdUpdatedBy"]);
                }
                this.linktoBusinessMasterId = Convert.ToInt16(sqlRdr["linktoBusinessMasterId"]);

                /// Extra
                return true;
            }
            return false;
        }

        private List<posMembershipTypeDAL> SetListPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            List<posMembershipTypeDAL> lstMembershipType = new List<posMembershipTypeDAL>();
            posMembershipTypeDAL objMembershipType = null;
            while (sqlRdr.Read())
            {
                objMembershipType = new posMembershipTypeDAL();
                objMembershipType.MembershipTypeMasterId = Convert.ToInt16(sqlRdr["MembershipTypeMasterId"]);
                objMembershipType.MembershipType = Convert.ToString(sqlRdr["MembershipType"]);
                objMembershipType.Prefix = Convert.ToString(sqlRdr["Prefix"]);
                objMembershipType.DisplayFormat = Convert.ToString(sqlRdr["DisplayFormat"]);
                objMembershipType.TotalDigits = Convert.ToInt16(sqlRdr["TotalDigits"]);
                objMembershipType.PricePerPoint = Convert.ToDouble(sqlRdr["PricePerPoint"]);
                objMembershipType.IsCardOfPoint = Convert.ToBoolean(sqlRdr["IsCardOfPoint"]);
                if (sqlRdr["NewCardRate"] != DBNull.Value)
                {
                    objMembershipType.NewCardRate = Convert.ToDouble(sqlRdr["NewCardRate"]);
                }
                if (sqlRdr["NewCardBonusPoints"] != DBNull.Value)
                {
                    objMembershipType.NewCardBonusPoints = Convert.ToInt16(sqlRdr["NewCardBonusPoints"]);
                }
                if (sqlRdr["NewCardBonusAmount"] != DBNull.Value)
                {
                    objMembershipType.NewCardBonusAmount = Convert.ToDouble(sqlRdr["NewCardBonusAmount"]);
                }
                if (sqlRdr["CardRenewalRate"] != DBNull.Value)
                {
                    objMembershipType.CardRenewalRate = Convert.ToDouble(sqlRdr["CardRenewalRate"]);
                }
                if (sqlRdr["CardRenewalBonusPoints"] != DBNull.Value)
                {
                    objMembershipType.CardRenewalBonusPoints = Convert.ToInt16(sqlRdr["CardRenewalBonusPoints"]);
                }
                if (sqlRdr["CardRenewalBonusAmount"] != DBNull.Value)
                {
                    objMembershipType.CardRenewalBonusAmount = Convert.ToDouble(sqlRdr["CardRenewalBonusAmount"]);
                }
                if (sqlRdr["ValidMonths"] != DBNull.Value)
                {
                    objMembershipType.ValidMonths = Convert.ToInt16(sqlRdr["ValidMonths"]);
                }
                objMembershipType.MinimumPointsForDeduction = Convert.ToInt16(sqlRdr["MinimumPointsForDeduction"]);
                objMembershipType.TermsAndConditions = Convert.ToString(sqlRdr["TermsAndConditions"]);
                objMembershipType.IsEnabled = Convert.ToBoolean(sqlRdr["IsEnabled"]);
                objMembershipType.CreateDateTime = Convert.ToDateTime(sqlRdr["CreateDateTime"]);
                objMembershipType.linktoUserMasterIdCreatedBy = Convert.ToInt32(sqlRdr["linktoUserMasterIdCreatedBy"]);
                if (sqlRdr["UpdateDateTime"] != DBNull.Value)
                {
                    objMembershipType.UpdateDateTime = Convert.ToDateTime(sqlRdr["UpdateDateTime"]);
                }
                if (sqlRdr["linktoUserMasterIdUpdatedBy"] != DBNull.Value)
                {
                    objMembershipType.linktoUserMasterIdUpdatedBy = Convert.ToInt32(sqlRdr["linktoUserMasterIdUpdatedBy"]);
                }
                objMembershipType.linktoBusinessMasterId = Convert.ToInt16(sqlRdr["linktoBusinessMasterId"]);

                /// Extra
                lstMembershipType.Add(objMembershipType);
            }
            return lstMembershipType;
        }
        #endregion

        #region Insert
        public posRecordStatus InsertMembershipType()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posMembershipType_Insert", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@MembershipTypeMasterId", SqlDbType.SmallInt).Direction = ParameterDirection.Output;
                SqlCmd.Parameters.Add("@MembershipType", SqlDbType.VarChar).Value = this.MembershipType;
                SqlCmd.Parameters.Add("@Prefix", SqlDbType.VarChar).Value = this.Prefix;
                SqlCmd.Parameters.Add("@DisplayFormat", SqlDbType.VarChar).Value = this.DisplayFormat;
                SqlCmd.Parameters.Add("@TotalDigits", SqlDbType.SmallInt).Value = this.TotalDigits;
                SqlCmd.Parameters.Add("@PricePerPoint", SqlDbType.Money).Value = this.PricePerPoint;
                SqlCmd.Parameters.Add("@IsCardOfPoint", SqlDbType.Bit).Value = this.IsCardOfPoint;
                SqlCmd.Parameters.Add("@NewCardRate", SqlDbType.Money).Value = this.NewCardRate;
                SqlCmd.Parameters.Add("@NewCardBonusPoints", SqlDbType.SmallInt).Value = this.NewCardBonusPoints;
                SqlCmd.Parameters.Add("@NewCardBonusAmount", SqlDbType.Money).Value = this.NewCardBonusAmount;
                SqlCmd.Parameters.Add("@CardRenewalRate", SqlDbType.Money).Value = this.CardRenewalRate;
                SqlCmd.Parameters.Add("@CardRenewalBonusPoints", SqlDbType.SmallInt).Value = this.CardRenewalBonusPoints;
                SqlCmd.Parameters.Add("@CardRenewalBonusAmount", SqlDbType.Money).Value = this.CardRenewalBonusAmount;
                SqlCmd.Parameters.Add("@ValidMonths", SqlDbType.SmallInt).Value = this.ValidMonths;
                SqlCmd.Parameters.Add("@MinimumPointsForDeduction", SqlDbType.SmallInt).Value = this.MinimumPointsForDeduction;
                SqlCmd.Parameters.Add("@TermsAndConditions", SqlDbType.VarChar).Value = this.TermsAndConditions;
                SqlCmd.Parameters.Add("@IsEnabled", SqlDbType.Bit).Value = this.IsEnabled;
                SqlCmd.Parameters.Add("@CreateDateTime", SqlDbType.DateTime).Value = this.CreateDateTime;
                SqlCmd.Parameters.Add("@linktoUserMasterIdCreatedBy", SqlDbType.Int).Value = this.linktoUserMasterIdCreatedBy;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                this.MembershipTypeMasterId = Convert.ToInt16(SqlCmd.Parameters["@MembershipTypeMasterId"].Value);
                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region Update
        public posRecordStatus UpdateMembershipType()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posMembershipType_Update", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@MembershipTypeMasterId", SqlDbType.SmallInt).Value = this.MembershipTypeMasterId;
                SqlCmd.Parameters.Add("@MembershipType", SqlDbType.VarChar).Value = this.MembershipType;
                SqlCmd.Parameters.Add("@Prefix", SqlDbType.VarChar).Value = this.Prefix;
                SqlCmd.Parameters.Add("@DisplayFormat", SqlDbType.VarChar).Value = this.DisplayFormat;
                SqlCmd.Parameters.Add("@TotalDigits", SqlDbType.SmallInt).Value = this.TotalDigits;
                SqlCmd.Parameters.Add("@PricePerPoint", SqlDbType.Money).Value = this.PricePerPoint;
                SqlCmd.Parameters.Add("@IsCardOfPoint", SqlDbType.Bit).Value = this.IsCardOfPoint;
                SqlCmd.Parameters.Add("@NewCardRate", SqlDbType.Money).Value = this.NewCardRate;
                SqlCmd.Parameters.Add("@NewCardBonusPoints", SqlDbType.SmallInt).Value = this.NewCardBonusPoints;
                SqlCmd.Parameters.Add("@NewCardBonusAmount", SqlDbType.Money).Value = this.NewCardBonusAmount;
                SqlCmd.Parameters.Add("@CardRenewalRate", SqlDbType.Money).Value = this.CardRenewalRate;
                SqlCmd.Parameters.Add("@CardRenewalBonusPoints", SqlDbType.SmallInt).Value = this.CardRenewalBonusPoints;
                SqlCmd.Parameters.Add("@CardRenewalBonusAmount", SqlDbType.Money).Value = this.CardRenewalBonusAmount;
                SqlCmd.Parameters.Add("@ValidMonths", SqlDbType.SmallInt).Value = this.ValidMonths;
                SqlCmd.Parameters.Add("@MinimumPointsForDeduction", SqlDbType.SmallInt).Value = this.MinimumPointsForDeduction;
                SqlCmd.Parameters.Add("@TermsAndConditions", SqlDbType.VarChar).Value = this.TermsAndConditions;
                SqlCmd.Parameters.Add("@IsEnabled", SqlDbType.Bit).Value = this.IsEnabled;
                SqlCmd.Parameters.Add("@UpdateDateTime", SqlDbType.DateTime).Value = this.UpdateDateTime;
                SqlCmd.Parameters.Add("@linktoUserMasterIdUpdatedBy", SqlDbType.Int).Value = this.linktoUserMasterIdUpdatedBy;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region DeleteAll
        public posRecordStatus DeleteAllMembershipType(string membershipTypeIds)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posMembershipType_DeleteAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@MembershipTypeIds", SqlDbType.VarChar).Value = membershipTypeIds;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region Select
        public bool SelectMembershipType()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posMembershipType_Select", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@MembershipTypeMasterId", SqlDbType.SmallInt).Value = this.MembershipTypeMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                bool IsSelected = SetClassPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                return IsSelected;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return false;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region SelectAll
        public List<posMembershipTypeDAL> SelectAllMembershipType()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posMembershipType_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCmd.Parameters.Add("@IsEnabled", SqlDbType.Bit).Value = this.IsEnabled;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<posMembershipTypeDAL> lstMembershipTypeDAL = SetListPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                return lstMembershipTypeDAL;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public static List<posMembershipTypeDAL> SelectAllMembershipTypeMembershipType(short linktoBusinessMasterId)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posMembershipTypeMembershipType_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = linktoBusinessMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<posMembershipTypeDAL> lstMembershipTypeDAL = new List<posMembershipTypeDAL>();
                posMembershipTypeDAL objMembershipTypeDAL = null;
                while (SqlRdr.Read())
                {
                    objMembershipTypeDAL = new posMembershipTypeDAL();
                    objMembershipTypeDAL.MembershipTypeMasterId = Convert.ToInt16(SqlRdr["MembershipTypeMasterId"]);
                    objMembershipTypeDAL.MembershipType = Convert.ToString(SqlRdr["MembershipType"]);
                    lstMembershipTypeDAL.Add(objMembershipTypeDAL);
                }
                SqlRdr.Close();
                SqlCon.Close();

                return lstMembershipTypeDAL;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion
    }
}
