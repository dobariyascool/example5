using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace posLibrary
{
    /// <summary>
    /// Class for posCategoryMaster
    /// </summary>
    public class posCategoryMasterDAL
    {
        #region Properties
        public short CategoryMasterId { get; set; }
        public string CategoryName { get; set; }
        public short? linktoCategoryMasterIdParent { get; set; }
        public string ImageName { get; set; }
        public string CategoryColor { get; set; }
        public string Description { get; set; }
        public short linktoBusinessMasterId { get; set; }
        public short? SortOrder { get; set; }
        public bool IsEnabled { get; set; }
        public bool IsDeleted { get; set; }
        public bool IsRawMaterial { get; set; }
        public DateTime CreateDateTime { get; set; }
        public short linktoUserMasterIdCreatedBy { get; set; }
        public DateTime? UpdateDateTime { get; set; }
        public short? linktoUserMasterIdUpdatedBy { get; set; }
        public bool IsHiddenForCustomer { get; set; }

        // Image Property
        public string xs_ImagePhysicalName { get; set; }
        public string sm_ImagePhysicalName { get; set; }
        public string md_ImagePhysicalName { get; set; }
        public string lg_ImagePhysicalName { get; set; }
        public string xl_ImagePhysicalName { get; set; }
        #endregion

        #region Class Methods
        private bool SetClassPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            if (sqlRdr.Read())
            {
                this.CategoryMasterId = Convert.ToInt16(sqlRdr["CategoryMasterId"]);
                this.CategoryName = Convert.ToString(sqlRdr["CategoryName"]);
                if (sqlRdr["linktoCategoryMasterIdParent"] != DBNull.Value)
                {
                    this.linktoCategoryMasterIdParent = Convert.ToInt16(sqlRdr["linktoCategoryMasterIdParent"]);
                }

                this.CategoryColor = Convert.ToString(sqlRdr["CategoryColor"]);
                this.Description = Convert.ToString(sqlRdr["Description"]);
                this.linktoBusinessMasterId = Convert.ToInt16(sqlRdr["linktoBusinessMasterId"]);
                if (sqlRdr["SortOrder"] != DBNull.Value)
                {
                    this.SortOrder = Convert.ToInt16(sqlRdr["SortOrder"]);
                }
                this.IsEnabled = Convert.ToBoolean(sqlRdr["IsEnabled"]);
                this.IsDeleted = Convert.ToBoolean(sqlRdr["IsDeleted"]);
                this.IsRawMaterial = Convert.ToBoolean(sqlRdr["IsRawMaterial"]);
                this.CreateDateTime = Convert.ToDateTime(sqlRdr["CreateDateTime"]);
                this.linktoUserMasterIdCreatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdCreatedBy"]);
                if (sqlRdr["UpdateDateTime"] != DBNull.Value)
                {
                    this.UpdateDateTime = Convert.ToDateTime(sqlRdr["UpdateDateTime"]);
                }
                if (sqlRdr["linktoUserMasterIdUpdatedBy"] != DBNull.Value)
                {
                    this.linktoUserMasterIdUpdatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdUpdatedBy"]);
                }
                this.IsHiddenForCustomer = Convert.ToBoolean(sqlRdr["IsHiddenForCustomer"]);
                if (sqlRdr["ImageName"] != DBNull.Value)
                {
                    this.ImageName = Convert.ToString(sqlRdr["ImageName"]);

                    this.xs_ImagePhysicalName = "xs_" + Convert.ToString(sqlRdr["ImageName"]);
                    this.sm_ImagePhysicalName = "sm_" + Convert.ToString(sqlRdr["ImageName"]);
                    this.md_ImagePhysicalName = "md_" + Convert.ToString(sqlRdr["ImageName"]);
                    this.lg_ImagePhysicalName = "lg_" + Convert.ToString(sqlRdr["ImageName"]);
                    this.xl_ImagePhysicalName = "xl_" + Convert.ToString(sqlRdr["ImageName"]);
                }
                return true;
            }
            return false;
        }

        private List<posCategoryMasterDAL> SetListPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            List<posCategoryMasterDAL> lstCategoryMaster = new List<posCategoryMasterDAL>();
            posCategoryMasterDAL objCategoryMaster = null;
            while (sqlRdr.Read())
            {
                objCategoryMaster = new posCategoryMasterDAL();
                objCategoryMaster.CategoryMasterId = Convert.ToInt16(sqlRdr["CategoryMasterId"]);
                objCategoryMaster.CategoryName = Convert.ToString(sqlRdr["CategoryName"]);
                if (sqlRdr["linktoCategoryMasterIdParent"] != DBNull.Value)
                {
                    objCategoryMaster.linktoCategoryMasterIdParent = Convert.ToInt16(sqlRdr["linktoCategoryMasterIdParent"]);
                }
                objCategoryMaster.ImageName = Convert.ToString(sqlRdr["ImageName"]);
                objCategoryMaster.CategoryColor = Convert.ToString(sqlRdr["CategoryColor"]);
                objCategoryMaster.Description = Convert.ToString(sqlRdr["Description"]);
                objCategoryMaster.linktoBusinessMasterId = Convert.ToInt16(sqlRdr["linktoBusinessMasterId"]);
                if (sqlRdr["SortOrder"] != DBNull.Value)
                {
                    objCategoryMaster.SortOrder = Convert.ToInt16(sqlRdr["SortOrder"]);
                }
                objCategoryMaster.IsEnabled = Convert.ToBoolean(sqlRdr["IsEnabled"]);
                objCategoryMaster.IsDeleted = Convert.ToBoolean(sqlRdr["IsDeleted"]);
                objCategoryMaster.IsRawMaterial = Convert.ToBoolean(sqlRdr["IsRawMaterial"]);
                objCategoryMaster.CreateDateTime = Convert.ToDateTime(sqlRdr["CreateDateTime"]);
                objCategoryMaster.linktoUserMasterIdCreatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdCreatedBy"]);
                if (sqlRdr["UpdateDateTime"] != DBNull.Value)
                {
                    objCategoryMaster.UpdateDateTime = Convert.ToDateTime(sqlRdr["UpdateDateTime"]);
                }
                if (sqlRdr["linktoUserMasterIdUpdatedBy"] != DBNull.Value)
                {
                    objCategoryMaster.linktoUserMasterIdUpdatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdUpdatedBy"]);
                }
                objCategoryMaster.IsHiddenForCustomer = Convert.ToBoolean(sqlRdr["IsHiddenForCustomer"]);
                if (sqlRdr["ImageName"] != DBNull.Value)
                {
                    objCategoryMaster.ImageName = Convert.ToString(sqlRdr["ImageName"]);

                    objCategoryMaster.xs_ImagePhysicalName = "xs_" + Convert.ToString(sqlRdr["ImageName"]);
                    objCategoryMaster.sm_ImagePhysicalName = "sm_" + Convert.ToString(sqlRdr["ImageName"]);
                    objCategoryMaster.md_ImagePhysicalName = "md_" + Convert.ToString(sqlRdr["ImageName"]);
                    objCategoryMaster.lg_ImagePhysicalName = "lg_" + Convert.ToString(sqlRdr["ImageName"]);
                    objCategoryMaster.xl_ImagePhysicalName = "xl_" + Convert.ToString(sqlRdr["ImageName"]);

                }
                lstCategoryMaster.Add(objCategoryMaster);
            }
            return lstCategoryMaster;
        }
        #endregion

        #region Insert
        public posRecordStatus InsertCategoryMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posCategoryMaster_Insert", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@CategoryMasterId", SqlDbType.SmallInt).Direction = ParameterDirection.Output;
                SqlCmd.Parameters.Add("@CategoryName", SqlDbType.VarChar).Value = this.CategoryName;
                SqlCmd.Parameters.Add("@linktoCategoryMasterIdParent", SqlDbType.SmallInt).Value = this.linktoCategoryMasterIdParent;
                SqlCmd.Parameters.Add("@ImageName", SqlDbType.VarChar).Value = this.ImageName;
                SqlCmd.Parameters.Add("@CategoryColor", SqlDbType.VarChar).Value = this.CategoryColor;
                SqlCmd.Parameters.Add("@Description", SqlDbType.VarChar).Value = this.Description;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCmd.Parameters.Add("@SortOrder", SqlDbType.SmallInt).Value = this.SortOrder;
                SqlCmd.Parameters.Add("@IsEnabled", SqlDbType.Bit).Value = this.IsEnabled;
                SqlCmd.Parameters.Add("@IsRawMaterial", SqlDbType.Bit).Value = this.IsRawMaterial;
                SqlCmd.Parameters.Add("@IsDeleted", SqlDbType.Bit).Value = this.IsDeleted;
                SqlCmd.Parameters.Add("@CreateDateTime", SqlDbType.DateTime).Value = this.CreateDateTime;
                SqlCmd.Parameters.Add("@linktoUserMasterIdCreatedBy", SqlDbType.SmallInt).Value = this.linktoUserMasterIdCreatedBy;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                this.CategoryMasterId = Convert.ToInt16(SqlCmd.Parameters["@CategoryMasterId"].Value);
                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public posRecordStatus InsertCategoryMaster(List<posCategoryMasterDAL> lstCategoryMasterDAL, SqlConnection SqlCon, SqlTransaction SqlTran)
        {
            SqlCommand SqlCmd = null;
            try
            {
                posRecordStatus rs = posRecordStatus.Success;

                SqlCmd = new SqlCommand("posCategoryMaster_Insert", SqlCon, SqlTran);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                foreach (posCategoryMasterDAL objCategoryMasterDAL in lstCategoryMasterDAL)
                {
                    SqlCmd.Parameters.Clear();
                    SqlCmd.Parameters.Add("@CategoryMasterId", SqlDbType.SmallInt).Direction = ParameterDirection.Output;
                    SqlCmd.Parameters.Add("@CategoryName", SqlDbType.VarChar).Value = objCategoryMasterDAL.CategoryName;
                    SqlCmd.Parameters.Add("@linktoCategoryMasterIdParent", SqlDbType.SmallInt).Value = objCategoryMasterDAL.linktoCategoryMasterIdParent;
                    SqlCmd.Parameters.Add("@ImageName", SqlDbType.VarChar).Value = objCategoryMasterDAL.ImageName;
                    SqlCmd.Parameters.Add("@CategoryColor", SqlDbType.VarChar).Value = objCategoryMasterDAL.CategoryColor;
                    SqlCmd.Parameters.Add("@Description", SqlDbType.VarChar).Value = objCategoryMasterDAL.Description;
                    SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                    SqlCmd.Parameters.Add("@SortOrder", SqlDbType.SmallInt).Value = objCategoryMasterDAL.SortOrder;
                    SqlCmd.Parameters.Add("@IsEnabled", SqlDbType.Bit).Value = objCategoryMasterDAL.IsEnabled;
                    SqlCmd.Parameters.Add("@IsRawMaterial", SqlDbType.Bit).Value = objCategoryMasterDAL.IsRawMaterial;
                    SqlCmd.Parameters.Add("@IsDeleted", SqlDbType.Bit).Value = objCategoryMasterDAL.IsDeleted;
                    SqlCmd.Parameters.Add("@CreateDateTime", SqlDbType.DateTime).Value = objCategoryMasterDAL.CreateDateTime;
                    SqlCmd.Parameters.Add("@linktoUserMasterIdCreatedBy", SqlDbType.SmallInt).Value = this.linktoUserMasterIdCreatedBy;
                    SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                    SqlCmd.ExecuteNonQuery();

                    this.CategoryMasterId = Convert.ToInt16(SqlCmd.Parameters["@CategoryMasterId"].Value);
                    rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;

                    if (rs == posRecordStatus.Error)
                    {
                        return rs;
                    }
                }
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
            }
        }
        #endregion

        #region Update
        public posRecordStatus UpdateCategoryMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posCategoryMaster_Update", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@CategoryMasterId", SqlDbType.SmallInt).Value = this.CategoryMasterId;
                SqlCmd.Parameters.Add("@CategoryName", SqlDbType.VarChar).Value = this.CategoryName;
                SqlCmd.Parameters.Add("@linktoCategoryMasterIdParent", SqlDbType.SmallInt).Value = this.linktoCategoryMasterIdParent;
                SqlCmd.Parameters.Add("@ImageName", SqlDbType.VarChar).Value = this.ImageName;
                SqlCmd.Parameters.Add("@CategoryColor", SqlDbType.VarChar).Value = this.CategoryColor;
                SqlCmd.Parameters.Add("@Description", SqlDbType.VarChar).Value = this.Description;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCmd.Parameters.Add("@SortOrder", SqlDbType.SmallInt).Value = this.SortOrder;
                SqlCmd.Parameters.Add("@IsEnabled", SqlDbType.Bit).Value = this.IsEnabled;
                SqlCmd.Parameters.Add("@IsRawMaterial", SqlDbType.Bit).Value = this.IsRawMaterial;
                SqlCmd.Parameters.Add("@IsDeleted", SqlDbType.Bit).Value = this.IsDeleted;
                SqlCmd.Parameters.Add("@UpdateDateTime", SqlDbType.DateTime).Value = this.UpdateDateTime;
                SqlCmd.Parameters.Add("@linktoUserMasterIdUpdatedBy", SqlDbType.SmallInt).Value = this.linktoUserMasterIdUpdatedBy;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region DeleteAll
        public static posRecordStatus DeleteAllCategoryMaster(string categoryMasterIds)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posCategoryMaster_DeleteAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@CategoryMasterIds", SqlDbType.VarChar).Value = categoryMasterIds;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region Select
        public bool SelectCategoryMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posCategoryMaster_Select", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@CategoryMasterId", SqlDbType.SmallInt).Value = this.CategoryMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                bool IsSelected = SetClassPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                return IsSelected;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return false;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region SelectAll
        public List<posCategoryMasterDAL> SelectAllCategoryMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posCategoryMaster_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@CategoryName", SqlDbType.VarChar).Value = this.CategoryName;
                SqlCmd.Parameters.Add("@IsEnabled", SqlDbType.Bit).Value = this.IsEnabled;
                SqlCmd.Parameters.Add("@IsRawMaterial", SqlDbType.Bit).Value = this.IsRawMaterial;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCmd.Parameters.Add("@IsHiddenForCustomer", SqlDbType.SmallInt).Value = this.IsHiddenForCustomer;
                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<posCategoryMasterDAL> lstCategoryMasterDAL = SetListPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                return lstCategoryMasterDAL;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public static List<posCategoryMasterDAL> SelectAllCategoryMasterCategoryName(bool IsRawMaterial, short linktoBusinessMasterId)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posCategoryMasterCategoryName_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@IsRowMaterial", SqlDbType.Bit).Value = IsRawMaterial;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = linktoBusinessMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<posCategoryMasterDAL> lstCategoryMasterDAL = new List<posCategoryMasterDAL>();
                posCategoryMasterDAL objCategoryMasterDAL = null;
                while (SqlRdr.Read())
                {
                    objCategoryMasterDAL = new posCategoryMasterDAL();
                    objCategoryMasterDAL.CategoryMasterId = Convert.ToInt16(SqlRdr["CategoryMasterId"]);
                    objCategoryMasterDAL.CategoryName = Convert.ToString(SqlRdr["CategoryName"]);
                    lstCategoryMasterDAL.Add(objCategoryMasterDAL);
                }
                SqlRdr.Close();
                SqlCon.Close();

                return lstCategoryMasterDAL;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public static List<posCategoryMasterDAL> SelectAllCategoryMasterByMostSellingCategory(DateTime FromDate, DateTime ToDate, short linktoBusinessMasterId)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posCategoryMasterByMostSellingCategory_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@FromDate", SqlDbType.DateTime).Value = FromDate;
                SqlCmd.Parameters.Add("@ToDate", SqlDbType.DateTime).Value = ToDate;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = linktoBusinessMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<posCategoryMasterDAL> lstCategoryMasterDAL = new List<posCategoryMasterDAL>();
                posCategoryMasterDAL objCategoryMasterDAL = null;
                while (SqlRdr.Read())
                {
                    objCategoryMasterDAL = new posCategoryMasterDAL();
                    objCategoryMasterDAL.CategoryMasterId = Convert.ToInt16(SqlRdr["CategoryMasterId"]);
                    objCategoryMasterDAL.CategoryName = Convert.ToString(SqlRdr["CategoryName"]);
                    lstCategoryMasterDAL.Add(objCategoryMasterDAL);
                }
                SqlRdr.Close();
                SqlCon.Close();

                return lstCategoryMasterDAL;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion
    }
}
