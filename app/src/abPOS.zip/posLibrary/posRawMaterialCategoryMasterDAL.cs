using System;
using System.Data;
using System.Data.SqlClient;
using System.Collections.Generic;

namespace posLibrary
{
	/// <summary>
	/// Class for posRawMaterialCategoryMaster
	/// </summary>
	public class posRawMaterialCategoryMasterDAL
	{
		#region Properties
		public short RawMaterialCategoryMasterId { get; set; }
		public string RawMaterialCategoryName { get; set; }
		public short? linktoRawMaterialCategoryMasterIdParent { get; set; }
		public string Description { get; set; }
		public short linktoBusinessMasterId { get; set; }
		public short? SortOrder { get; set; }
		public bool? IsEnabled { get; set; }
		public bool IsDeleted { get; set; }
		public DateTime CreateDateTime { get; set; }
		public short linktoUserMasterIdCreatedBy { get; set; }
		public DateTime? UpdateDateTime { get; set; }
		public short? linktoUserMasterIdUpdatedBy { get; set; }

		/// Extra
		public string RawMaterialCategoryParent { get; set; }
		#endregion

		#region Class Methods
		private bool SetClassPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
		{
			if (sqlRdr.Read())
			{
				this.RawMaterialCategoryMasterId = Convert.ToInt16(sqlRdr["RawMaterialCategoryMasterId"]);
				this.RawMaterialCategoryName = Convert.ToString(sqlRdr["RawMaterialCategoryName"]);
				if (sqlRdr["linktoRawMaterialCategoryMasterIdParent"] != DBNull.Value)
				{
					this.linktoRawMaterialCategoryMasterIdParent = Convert.ToInt16(sqlRdr["linktoRawMaterialCategoryMasterIdParent"]);
				}
				this.Description = Convert.ToString(sqlRdr["Description"]);
				this.linktoBusinessMasterId = Convert.ToInt16(sqlRdr["linktoBusinessMasterId"]);
				if (sqlRdr["SortOrder"] != DBNull.Value)
				{
					this.SortOrder = Convert.ToInt16(sqlRdr["SortOrder"]);
				}
				if (sqlRdr["IsEnabled"] != DBNull.Value)
				{
					this.IsEnabled = Convert.ToBoolean(sqlRdr["IsEnabled"]);
				}
				this.IsDeleted = Convert.ToBoolean(sqlRdr["IsDeleted"]);
				this.CreateDateTime = Convert.ToDateTime(sqlRdr["CreateDateTime"]);
				this.linktoUserMasterIdCreatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdCreatedBy"]);
				if (sqlRdr["UpdateDateTime"] != DBNull.Value)
				{
					this.UpdateDateTime = Convert.ToDateTime(sqlRdr["UpdateDateTime"]);
				}
				if (sqlRdr["linktoUserMasterIdUpdatedBy"] != DBNull.Value)
				{
					this.linktoUserMasterIdUpdatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdUpdatedBy"]);
				}

				/// Extra
				this.RawMaterialCategoryParent = Convert.ToString(sqlRdr["RawMaterialCategoryParent"]);
				return true;
			}
			return false;
		}

		private List<posRawMaterialCategoryMasterDAL> SetListPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
		{
			List<posRawMaterialCategoryMasterDAL> lstRawMaterialCategoryMaster = new List<posRawMaterialCategoryMasterDAL>();
			posRawMaterialCategoryMasterDAL objRawMaterialCategoryMaster = null;
			while (sqlRdr.Read())
			{
				objRawMaterialCategoryMaster = new posRawMaterialCategoryMasterDAL();
				objRawMaterialCategoryMaster.RawMaterialCategoryMasterId = Convert.ToInt16(sqlRdr["RawMaterialCategoryMasterId"]);
				objRawMaterialCategoryMaster.RawMaterialCategoryName = Convert.ToString(sqlRdr["RawMaterialCategoryName"]);
				if (sqlRdr["linktoRawMaterialCategoryMasterIdParent"] != DBNull.Value)
				{
					objRawMaterialCategoryMaster.linktoRawMaterialCategoryMasterIdParent = Convert.ToInt16(sqlRdr["linktoRawMaterialCategoryMasterIdParent"]);
				}
				objRawMaterialCategoryMaster.Description = Convert.ToString(sqlRdr["Description"]);
				objRawMaterialCategoryMaster.linktoBusinessMasterId = Convert.ToInt16(sqlRdr["linktoBusinessMasterId"]);
				if (sqlRdr["SortOrder"] != DBNull.Value)
				{
					objRawMaterialCategoryMaster.SortOrder = Convert.ToInt16(sqlRdr["SortOrder"]);
				}
				if (sqlRdr["IsEnabled"] != DBNull.Value)
				{
					objRawMaterialCategoryMaster.IsEnabled = Convert.ToBoolean(sqlRdr["IsEnabled"]);
				}
				objRawMaterialCategoryMaster.IsDeleted = Convert.ToBoolean(sqlRdr["IsDeleted"]);
				objRawMaterialCategoryMaster.CreateDateTime = Convert.ToDateTime(sqlRdr["CreateDateTime"]);
				objRawMaterialCategoryMaster.linktoUserMasterIdCreatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdCreatedBy"]);
				if (sqlRdr["UpdateDateTime"] != DBNull.Value)
				{
					objRawMaterialCategoryMaster.UpdateDateTime = Convert.ToDateTime(sqlRdr["UpdateDateTime"]);
				}
				if (sqlRdr["linktoUserMasterIdUpdatedBy"] != DBNull.Value)
				{
					objRawMaterialCategoryMaster.linktoUserMasterIdUpdatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdUpdatedBy"]);
				}

				/// Extra
				objRawMaterialCategoryMaster.RawMaterialCategoryParent = Convert.ToString(sqlRdr["RawMaterialCategoryParent"]);
				lstRawMaterialCategoryMaster.Add(objRawMaterialCategoryMaster);
			}
			return lstRawMaterialCategoryMaster;
		}
		#endregion

		#region Insert
		public posRecordStatus InsertRawMaterialCategoryMaster()
		{
			SqlConnection SqlCon = null;
			SqlCommand SqlCmd = null;
			try
			{
				SqlCon = posObjectFactoryDAL.CreateConnection();
				SqlCmd = new SqlCommand("posRawMaterialCategoryMaster_Insert", SqlCon);
				SqlCmd.CommandType = CommandType.StoredProcedure;

				SqlCmd.Parameters.Add("@RawMaterialCategoryMasterId", SqlDbType.SmallInt).Direction = ParameterDirection.Output;
				SqlCmd.Parameters.Add("@RawMaterialCategoryName", SqlDbType.VarChar).Value = this.RawMaterialCategoryName;
				SqlCmd.Parameters.Add("@linktoRawMaterialCategoryMasterIdParent", SqlDbType.SmallInt).Value = this.linktoRawMaterialCategoryMasterIdParent;
				SqlCmd.Parameters.Add("@Description", SqlDbType.VarChar).Value = this.Description;
				SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
				SqlCmd.Parameters.Add("@SortOrder", SqlDbType.SmallInt).Value = this.SortOrder;
				SqlCmd.Parameters.Add("@IsEnabled", SqlDbType.Bit).Value = this.IsEnabled;
				SqlCmd.Parameters.Add("@IsDeleted", SqlDbType.Bit).Value = this.IsDeleted;
				SqlCmd.Parameters.Add("@CreateDateTime", SqlDbType.DateTime).Value = this.CreateDateTime;
				SqlCmd.Parameters.Add("@linktoUserMasterIdCreatedBy", SqlDbType.SmallInt).Value = this.linktoUserMasterIdCreatedBy;
				SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

				SqlCon.Open();
				SqlCmd.ExecuteNonQuery();
				SqlCon.Close();

				this.RawMaterialCategoryMasterId = Convert.ToInt16(SqlCmd.Parameters["@RawMaterialCategoryMasterId"].Value);
				posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
				return rs;
			}
			catch (Exception ex)
			{
				posGlobalsDAL.SaveError(ex);
				return posRecordStatus.Error;
			}
			finally
			{
				posObjectFactoryDAL.DisposeCommand(SqlCmd);
				posObjectFactoryDAL.DisposeConnection(SqlCon);
			}
		}
		#endregion

		#region Update
		public posRecordStatus UpdateRawMaterialCategoryMaster()
		{
			SqlConnection SqlCon = null;
			SqlCommand SqlCmd = null;
			try
			{
				SqlCon = posObjectFactoryDAL.CreateConnection();
				SqlCmd = new SqlCommand("posRawMaterialCategoryMaster_Update", SqlCon);
				SqlCmd.CommandType = CommandType.StoredProcedure;

				SqlCmd.Parameters.Add("@RawMaterialCategoryMasterId", SqlDbType.SmallInt).Value = this.RawMaterialCategoryMasterId;
				SqlCmd.Parameters.Add("@RawMaterialCategoryName", SqlDbType.VarChar).Value = this.RawMaterialCategoryName;
				SqlCmd.Parameters.Add("@linktoRawMaterialCategoryMasterIdParent", SqlDbType.SmallInt).Value = this.linktoRawMaterialCategoryMasterIdParent;
				SqlCmd.Parameters.Add("@Description", SqlDbType.VarChar).Value = this.Description;
				SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
				SqlCmd.Parameters.Add("@SortOrder", SqlDbType.SmallInt).Value = this.SortOrder;
				SqlCmd.Parameters.Add("@IsEnabled", SqlDbType.Bit).Value = this.IsEnabled;
				SqlCmd.Parameters.Add("@IsDeleted", SqlDbType.Bit).Value = this.IsDeleted;
				SqlCmd.Parameters.Add("@UpdateDateTime", SqlDbType.DateTime).Value = this.UpdateDateTime;
				SqlCmd.Parameters.Add("@linktoUserMasterIdUpdatedBy", SqlDbType.SmallInt).Value = this.linktoUserMasterIdUpdatedBy;
				SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

				SqlCon.Open();
				SqlCmd.ExecuteNonQuery();
				SqlCon.Close();

				posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
				return rs;
			}
			catch (Exception ex)
			{
				posGlobalsDAL.SaveError(ex);
				return posRecordStatus.Error;
			}
			finally
			{
				posObjectFactoryDAL.DisposeCommand(SqlCmd);
				posObjectFactoryDAL.DisposeConnection(SqlCon);
			}
		}
		#endregion

		#region DeleteAll

		public static posRecordStatus DeleteAllRawMaterialCategoryMaster(string rawMaterialCategoryMasterIds)
		{
			SqlConnection SqlCon = null;
			SqlCommand SqlCmd = null;
			try
			{
				SqlCon = posObjectFactoryDAL.CreateConnection();
				SqlCmd = new SqlCommand("posRawMaterialCategoryMaster_DeleteAll", SqlCon);
				SqlCmd.CommandType = CommandType.StoredProcedure;

				SqlCmd.Parameters.Add("@RawMaterialCategoryMasterIds", SqlDbType.VarChar).Value = rawMaterialCategoryMasterIds;
				SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

				SqlCon.Open();
				SqlCmd.ExecuteNonQuery();
				SqlCon.Close();

				posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
				return rs;
			}
			catch (Exception ex)
			{
				posGlobalsDAL.SaveError(ex);
				return posRecordStatus.Error;
			}
			finally
			{
				posObjectFactoryDAL.DisposeCommand(SqlCmd);
				posObjectFactoryDAL.DisposeConnection(SqlCon);
			}
		}
		#endregion

		#region Select
		public bool SelectRawMaterialCategoryMaster()
		{
			SqlConnection SqlCon = null;
			SqlCommand SqlCmd = null;
			SqlDataReader SqlRdr = null;
			try
			{
				SqlCon = posObjectFactoryDAL.CreateConnection();
				SqlCmd = new SqlCommand("posRawMaterialCategoryMaster_Select", SqlCon);
				SqlCmd.CommandType = CommandType.StoredProcedure;

				SqlCmd.Parameters.Add("@RawMaterialCategoryMasterId", SqlDbType.SmallInt).Value = this.RawMaterialCategoryMasterId;

				SqlCon.Open();
				SqlRdr = SqlCmd.ExecuteReader();
				bool IsSelected = SetClassPropertiesFromSqlDataReader(SqlRdr);
				SqlRdr.Close();
				SqlCon.Close();

				return IsSelected;
			}
			catch (Exception ex)
			{
				posGlobalsDAL.SaveError(ex);
				return false;
			}
			finally
			{
				posObjectFactoryDAL.DisposeDataReader(SqlRdr);
				posObjectFactoryDAL.DisposeCommand(SqlCmd);
				posObjectFactoryDAL.DisposeConnection(SqlCon);
			}
		}
		#endregion

		#region SelectAll

		public List<posRawMaterialCategoryMasterDAL> SelectAllRawMaterialCategoryMaster()
		{
			SqlConnection SqlCon = null;
			SqlCommand SqlCmd = null;
			SqlDataReader SqlRdr = null;
			try
			{
				SqlCon = posObjectFactoryDAL.CreateConnection();
				SqlCmd = new SqlCommand("posRawMaterialCategoryMaster_SelectAll", SqlCon);
				SqlCmd.CommandType = CommandType.StoredProcedure;

				SqlCmd.Parameters.Add("@RawMaterialCategoryName", SqlDbType.VarChar).Value = this.RawMaterialCategoryName;
				SqlCmd.Parameters.Add("@IsEnabled", SqlDbType.Bit).Value = this.IsEnabled;

				SqlCon.Open();
				SqlRdr = SqlCmd.ExecuteReader();
				List<posRawMaterialCategoryMasterDAL> lstRawMaterialCategoryMasterDAL = SetListPropertiesFromSqlDataReader(SqlRdr);
				SqlRdr.Close();
				SqlCon.Close();

				return lstRawMaterialCategoryMasterDAL;
			}
			catch (Exception ex)
			{
				posGlobalsDAL.SaveError(ex);
				return null;
			}
			finally
			{
				posObjectFactoryDAL.DisposeDataReader(SqlRdr);
				posObjectFactoryDAL.DisposeCommand(SqlCmd);
				posObjectFactoryDAL.DisposeConnection(SqlCon);
			}
		}

		public static List<posRawMaterialCategoryMasterDAL> SelectAllRawMaterialCategoryMasterRawMaterialCategoryName()
		{
			SqlConnection SqlCon = null;
			SqlCommand SqlCmd = null;
			SqlDataReader SqlRdr = null;
			try
			{
				SqlCon = posObjectFactoryDAL.CreateConnection();
				SqlCmd = new SqlCommand("posRawMaterialCategoryMasterRawMaterialCategoryName_SelectAll", SqlCon);
				SqlCmd.CommandType = CommandType.StoredProcedure;

				SqlCon.Open();
				SqlRdr = SqlCmd.ExecuteReader();
				List<posRawMaterialCategoryMasterDAL> lstRawMaterialCategoryMasterDAL = new List<posRawMaterialCategoryMasterDAL>();
				posRawMaterialCategoryMasterDAL objRawMaterialCategoryMasterDAL = null;
				while (SqlRdr.Read())
				{
					objRawMaterialCategoryMasterDAL = new posRawMaterialCategoryMasterDAL();
					objRawMaterialCategoryMasterDAL.RawMaterialCategoryMasterId = Convert.ToInt16(SqlRdr["RawMaterialCategoryMasterId"]);
					objRawMaterialCategoryMasterDAL.RawMaterialCategoryName = Convert.ToString(SqlRdr["RawMaterialCategoryName"]);
					lstRawMaterialCategoryMasterDAL.Add(objRawMaterialCategoryMasterDAL);
				}
				SqlRdr.Close();
				SqlCon.Close();

				return lstRawMaterialCategoryMasterDAL;
			}
			catch (Exception ex)
			{
				posGlobalsDAL.SaveError(ex);
				return null;
			}
			finally
			{
				posObjectFactoryDAL.DisposeDataReader(SqlRdr);
				posObjectFactoryDAL.DisposeCommand(SqlCmd);
				posObjectFactoryDAL.DisposeConnection(SqlCon);
			}
		}
		#endregion
	}
}
