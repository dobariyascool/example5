using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq.Expressions;
using System.Net;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using abHelper;
using ComponentFactory.Krypton.Toolkit;
using Microsoft.Win32;

namespace posLibrary
{
    /// <summary>
    /// Class for Globals
    /// Author              : 
    /// Create date         :
    /// Modified by         :
    /// Last modified by    :
    /// Last modified date  :
    /// </summary>

    #region posGlobalsDAL
    public class posGlobalsDAL
    {
        public const bool IsWindowsAuthentication = false;
        public static string DatabaseName = "abPOS";
        public static string ServerName;
        public static string InstanceName;
        public static string UserName;
        public static string Password;

        public static string UniqueId;

        public static string NetworkPath;

        public const string UniqueKey = "yyyy-MM-dd_HH.mm.ss.ffff";
        public const string LibAuthKey = "oXCLhAqcT8LQQBvBVYCRmNnB3P5Le8UamDEBeDX1abs=";

        public static string MachineId;
        public static short UserLimit = 1;

        public static posUser UserInfo;

        //DateTime Format
        public static string DateFormat = "MM'/'dd'/'yyyy";   //"MM'/'dd'/'yyyy";
        public static string TimeFormat = "hh':'mm tt";

        public static bool AutoOpenSelectBox = true;

        public static Color CheckedRowBackColor = SystemColors.Control;
        public static Font ControlFont = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
        public static Font ControlFontBold = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
        public static Font ControlFontLarge = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));

        public static List<posSettingMasterDAL> Settings;
        public static List<posUserRightsTranDAL> Permissions;

        #region Private Variables
        private static DateTime SoftwareDate;
        #endregion

        public static void SaveError(Exception ex, bool showMessage = true)
        {
            System.Threading.ThreadAbortException tae = ex as System.Threading.ThreadAbortException;
            if (tae != null)
            {
                return;
            }
            try
            {
                /// Insert error into ErrorLog table
                posErrorLogDAL _objErrorLogDAL = new posErrorLogDAL();
                _objErrorLogDAL.ErrorDateTime = DateTime.Now;
                _objErrorLogDAL.ErrorMessage = ex.Message;
                _objErrorLogDAL.ErrorStackTrace = ex.StackTrace;

                if (_objErrorLogDAL.InsertErrorLog() == posRecordStatus.Error)
                {
                    /// Write error into ErrorLog file if error not inserted
                    string _strErrorLogFile = Application.StartupPath + "\\error.txt";
                    StringBuilder _sb = new StringBuilder();
                    _sb.AppendLine("Error DateTime    : " + DateTime.Now.ToString("s"));
                    _sb.AppendLine("Error Message     : " + ex.Message);
                    _sb.AppendLine("Error StackTrace  : " + ex.StackTrace);
                    _sb.AppendLine(string.Empty.PadRight(100, '-'));
                    File.AppendAllText(_strErrorLogFile, _sb.ToString());
                }
            }
            catch
            {
            }
            if (showMessage)
            {
                posMessagesDAL.ShowMessage("An unexpected error occurred." + Environment.NewLine + Environment.NewLine + ex.Message, posMessageIcon.Error);
            }
        }

        public static bool CheckDatabaseConnection()
        {
            SqlConnection SqlCon = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCon.Open();
                SqlCon.Close();
                return true;
            }
            catch
            {
                posObjectFactoryDAL.DisposeConnection(SqlCon);
                return false;
            }
        }

        public static void LoginNetwork()
        {
            try
            {
                //string InstallType = posGlobalsDAL.ReadRegistryKey("InstallType");
                //if (InstallType == "Client")
                //{
                //    abHelper.NetworkAuth obj = new abHelper.NetworkAuth(posGlobalsDAL.LibAuthKey);
                //    obj.DomainName = posGlobalsDAL.GetSetting(posSetting.SERVER_PATH);
                //    obj.UserName = posGlobalsDAL.GetSetting(posSetting.SERVER_USER_NAME);
                //    obj.Password = posGlobalsDAL.GetSetting(posSetting.SERVER_PASSWORD);
                //    obj.LoginNetwork();
                //}
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
            }
        }

        public static string GetSetting(posSetting objSetting, short? linktoBusinessMasterId = null)
        {
            try
            {
                if (Settings == null || Settings.Count == 0)
                {
                    posSettingMasterDAL objSettingMasterDAL = new posSettingMasterDAL();
                    if (linktoBusinessMasterId != null)
                    {
                        objSettingMasterDAL.linktoBusinessMasterId = linktoBusinessMasterId.Value;
                    }
                    else if (posGlobalsDAL.UserInfo != null)
                    {
                        objSettingMasterDAL.linktoBusinessMasterId = posGlobalsDAL.UserInfo.BusinessMasterId;
                    }
                    Settings = objSettingMasterDAL.SelectAllSettingMaster();
                }
                if (Settings != null && Settings.Count > 0)
                {
                    return Settings.Find(f => f.SettingMasterId == (short)objSetting).Value;
                }
                return null;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
        }

        public static bool GetPermission(posUserRights objUserRights)
        {
            try
            {
                if (posGlobalsDAL.UserInfo.IsAdmin == true)
                {
                    return true;
                }
                if (Permissions == null)
                {
                    posUserRightsTranDAL objUserRightsTranDAL = new posUserRightsTranDAL();
                    objUserRightsTranDAL.linktoRoleMasterId = posGlobalsDAL.UserInfo.RoleMasterId;
                    Permissions = objUserRightsTranDAL.SelectAllUserRightsTranRoleWise();
                }
                if (Permissions != null)
                {
                    if (Permissions.Find(f => f.linktoUserRightsMasterId == (short)objUserRights) != null)
                    {
                        return true;
                    }
                    return false;
                }
                else
                {
                    posMessagesDAL.ShowMessage(posMessagesDAL.SelectAllFail, posMessageIcon.Error);
                    return false;
                }
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return false;
            }
        }

        public static bool CheckForInternetConnection()
        {
            try
            {
                using (var client = new WebClient())
                using (var stream = client.OpenRead("http://www.google.com"))
                {
                    return true;
                }
            }
            catch
            {
                posMessagesDAL.ShowMessage("Internet connection not available, Please check network cable or wifi is on and try again.", posMessageIcon.Error);
                return false;
            }
        }

        public static string ReadRegistryKey(string keyName)
        {
            MachineRegistry objReg = new MachineRegistry(posGlobalsDAL.LibAuthKey);
            objReg.BaseRegistryHive = RegistryHive.LocalMachine;
            objReg.BaseRegistryView = RegistryView.Registry32; /// RegistryView.Registry32 WORK IN BOTH 32 and 64 BIT
            objReg.SubRegistryKey = @"SOFTWARE\ArrayBit\CentralPOS";

            return objReg.ReadRegistryValue(keyName);
        }

        public static DateTime GetCurrentDateTime()
        {
            return DateTime.Now;
        }

        public static void ChangeSoftwareDate(DateTime softwareDate)
        {
            SoftwareDate = softwareDate.Date;
        }

        public static DateTime GetSoftwareDateTime(bool isSelect = false)
        {
            posCounterDayEndTranDAL objCounterDayEndTranDAL = null;
            try
            {
                if (isSelect == true || SoftwareDate == new DateTime())
                {
                    SoftwareDate = DateTime.Now.Date;

                    objCounterDayEndTranDAL = new posCounterDayEndTranDAL();
                    objCounterDayEndTranDAL.linktoCounterMasterId = posGlobalsDAL.UserInfo.CounterMasterId;
                    if (objCounterDayEndTranDAL.SelectCounterDayEndTran())
                    {
                        if (objCounterDayEndTranDAL.DayEndDateTime != null)
                        {
                            SoftwareDate = objCounterDayEndTranDAL.DayEndDateTime.Date.AddDays(1);
                        }
                    }
                }
                return new DateTime(SoftwareDate.Year, SoftwareDate.Month, SoftwareDate.Day, DateTime.Now.Hour, DateTime.Now.Minute, DateTime.Now.Second);
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return DateTime.Now;
            }
            finally
            {
                objCounterDayEndTranDAL = null;
            }
        }

        public static string GetPropertyName<T>(Expression<Func<T, object>> expression)
        {
            var body = expression.Body as MemberExpression;

            if (body == null)
            {
                body = ((UnaryExpression)expression.Body).Operand as MemberExpression;
            }

            return body.Member.Name;
        }

        public static bool CreateThumbImages(string imageName, string imageSavePath)
        {
            try
            {
                int xswidth = 320;
                int xsheight = 180;

                int smwidth = 640;
                int smheight = 360;

                int mdwidth = 960;
                int mdheight = 540;

                int lgwidth = 1280;
                int lgheight = 720;

                int xlwidth = 1920;
                int xlheight = 1080;

                abHelper.ImageProcessing img = new ImageProcessing(posGlobalsDAL.LibAuthKey);
                // for extra small device 

                img.CreateThumbnail(imageSavePath + imageName, imageSavePath + "xs_" + imageName, xswidth, xsheight, false);

                // for small device 

                img.CreateThumbnail(imageSavePath + imageName, imageSavePath + "sm_" + imageName, smwidth, smheight, false);

                // for medium device 

                img.CreateThumbnail(imageSavePath + imageName, imageSavePath + "md_" + imageName, mdwidth, mdheight, false);

                // for large device 
                img.CreateThumbnail(imageSavePath + imageName, imageSavePath + "lg_" + imageName, lgwidth, lgheight, false);

                // for extra large device 
                img.CreateThumbnail(imageSavePath + imageName, imageSavePath + "xl_" + imageName, xlwidth, xlheight, false);

                File.Delete(imageSavePath + imageName);
                return true;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return false;
            }
        }

        public static bool DeleteThumbImages(string imageName, string imageSavePath)
        {
            try
            {
                // for extra small device 
                if (File.Exists(imageSavePath + "xs_" + imageName))
                {
                    File.Delete(imageSavePath + "xs_" + imageName);
                }

                // for small device 
                if (File.Exists(imageSavePath + "sm_" + imageName))
                {
                    File.Delete(imageSavePath + "sm_" + imageName);
                }

                // for medium device 
                if (File.Exists(imageSavePath + "md_" + imageName))
                {
                    File.Delete(imageSavePath + "md_" + imageName);
                }

                // for large device 
                if (File.Exists(imageSavePath + "lg_" + imageName))
                {
                    File.Delete(imageSavePath + "lg_" + imageName);
                }

                // for extra large device 
                if (File.Exists(imageSavePath + "xl_" + imageName))
                {
                    File.Delete(imageSavePath + "xl_" + imageName);
                }

                return true;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return false;
            }
        }

        public static T DeepCopy<T>(T obj)
        {
            using (MemoryStream stream = new MemoryStream())
            {
                BinaryFormatter formatter = new BinaryFormatter();
                formatter.Serialize(stream, obj);
                stream.Position = 0;

                return (T)formatter.Deserialize(stream);
            }
        }

        public static byte[] ImageToByteArray(Image image)
        {
            MemoryStream ms = new MemoryStream();
            image.Save(ms, System.Drawing.Imaging.ImageFormat.Jpeg);
            return ms.ToArray();
        }

        public static Image ByteArrayToImage(byte[] byteArray)
        {
            MemoryStream ms = new MemoryStream(byteArray);
            Image returnImage = Image.FromStream(ms);
            return returnImage;
        }
    }
    #endregion

    #region Enum

    public enum posOfferType
    {
        General_Offer = 1,
        On_Selected_Items = 2,
        Buy_Get_Item_Free = 3,
        Buy_Get_Item_Discount = 4
    }

    public enum posWaiterType
    {
        Captain = 1,
        Waiter = 2,
        Delivery_Person = 3
    }

    public enum posOrderType
    {
        Dine_In = 1,
        Take_Away = 2,
        Home_Delivery = 3
    }

    public enum posTableStatus
    {
        Vacant = 1,
        Occupied = 2,
        Dirty = 3,
        Block = 4,
    }

    public enum posTableType
    {
        Square = 0,
        Rounded = 1,
    }

    public enum posFormStatus
    {
        None,
        OK,
        Cancel,
        Back,
        Error,
        Timeout,
        Exit
    }

    public enum posRecordStatus
    {
        RecordNotFound = -3,
        RecordAlreadyExist = -2,
        Error = -1,
        Success = 0
    }

    public enum posMessageIcon
    {
        None = 0,
        Success = 64,
        Error = 16,
        Warning = 48
    }

    public enum posValidateType
    {
        Required,
        Email,
        Number,
        Decimal,
        URL,
        Percentage,
        Phone,
    }

    public enum posSetting
    {
        Theme = 1,
        Show_Confirmation_on_Exit = 2,
        Is_Automatic_Backup = 3,
        Backup_Path = 4,
        Backup_Path_2 = 5,
        Allow_Blank_Password = 6,
        Server_User_Name = 7,
        Server_Password = 8,
        Server_Path = 9,
        Default_Country = 10,
        Default_State = 11,
        Default_City = 12,
        Short_Date = 13,
        Long_Date = 14,
        Short_Time = 15,
        Long_Time = 16,
        Auto_Correct_User_Inputs = 17,
        Currency = 18,
        Same_Tax_for_all_Items = 19,
        Tax_on_Gross_Amount = 20
        //MARGIN_LEFT = 1,
        //MARGIN_RIGHT = 2,
        //MARGIN_TOP = 3,
        //MARGIN_BOTTOM = 4,
        //DEFAULT_PRINTER = 5,
        //PAGE_SIZE = 6,
        //THEME = 7,
        //SHOW_CONFIRMATION_ON_EXIT = 8,
        //BACKUP_PATH = 9,
        //IS_AUTOMATIC_BACKUP = 10,
        //BACKUP_PATH2 = 11,
        //ALLOW_BLANK_PASSWORD = 12,
        //AUTOMATICALLY_OPEN_SELECTBOX = 13,
        //SHOW_PRINT_PREVIEW = 14,
        //SHOW_PRINT_HEADER = 15,
        //SHOW_LOGO = 16,
        ////HEADER_LINE1 = 17,
        ////HEADER_LINE2 = 18,
        ////HEADER_LINE3 = 19,
        ////HEADER_ALIGN = 20,
        ////LEFT_FOOTER_LINE1 = 21,
        ////LEFT_FOOTER_LINE2 = 22,
        ////LEFT_FOOTER_LINE3 = 23,
        ////CENTER_FOOTER_LINE1 = 24,
        ////CENTER_FOOTER_LINE2 = 25,
        ////CENTER_FOOTER_LINE3 = 26,
        ////RIGHT_FOOTER_LINE1 = 27,
        ////RIGHT_FOOTER_LINE2 = 28,
        ////RIGHT_FOOTER_LINE3 = 29,
        ////SUMMARY_LINE1 = 30,
        ////SUMMARY_LINE2 = 31,
        ////SUMMARY_LINE3 = 32,
        ////IS_PRINT = 33,
        ////IS_MAIL = 34,
        ////IS_SMS = 35,
        //HOST = 36,
        //HOST_PORT = 37,
        //HOST_EMAIL = 38,
        //HOST_PASSWORD = 39,
        //IS_ENABLE_SSL = 40,
        //SENDER_ID = 41,
        //SENDER_PORT = 42,
        //SENDER_USERNAME = 43,
        //SENDER_PASSWORD = 44,
        //NUMBER_OF_COPIES = 45,
        ////SHOW_LOGO_ON_HOMESCREEN = 46,
        ////AUTO_CORRECT_USER_INPUTS = 47,
        ////ALLOW_ENTRY_WITHOUT_AGE = 48,
        ////ALLOW_ENTRY_WITHOUT_SEX = 49,
        ////DEFAULT_SAMPLE_TYPE = 50,
        ////MON_TO_SAT_CHARGE_TYPE = 51,
        ////SUNDAY_CHARGE_TYPE = 52,
        ////PRINT_PATIENT_RECEIPT = 53,
        ////CELL_COUNTER_TEXT = 54,
        ////ANALYZER_TEXT = 55,
        //SERVER_USER_NAME = 56,
        //SERVER_PASSWORD = 57,
        //SERVER_PATH = 58,
        //DEFAULT_COUNTRY = 59,
        //DEFAULT_STATE = 60,
        //DEFAULT_CITY = 61,
        ////HEADER_LINE1_FONT = 62,
        ////HEADER_OTHER_FONT = 63,
        ////HEADER_LINE1_COLOR = 64,
        ////HEADER_OTHER_COLOR = 65,
        ////IS_HEADER_LINE1_BOLD = 66,
        ////IS_HEADER_OTHER_LINE_BOLD = 67,
        ////IS_HEADER_LINE1_ITALIC = 68,
        ////IS_HEADER_OTHER_LINE_ITALIC = 69,
        ////IS_HEADER_LINE1_UNDERLINE = 70,
        ////IS_HEADER_OTHER_LINE_UNDERLINE = 71,
        ////CONTENT_FONT = 72,
        ////CONTENT_COLOR = 73,
        ////IS_CONTENT_BOLD = 74,
        ////IS_CONTENT_ITALIC = 75,
        ////IS_CONTENT_UNDERLINE = 76,
        ////FOOTER_FONT = 77,
        ////IS_SHOW_REPORT_VALIDATION_ALERTS = 78,
        //SHORT_DATE = 79,
        //LONG_DATE = 80,
        //SHORT_TIME = 81,
        //LONG_TIME = 82,
        ////COUNT_PCV = 83
    }

    public enum posUserRights
    {
        Configure_Business = 1,
        Item_Rate_and_Tax = 2,
        Master_Configuration = 3,
        Change_Settings = 4,
        Change_Financial_Year = 5,
        Cash_Drawer = 6,
        Allow_Day_End = 7,
        Allow_date_change = 8,
        Add_past_date_Entry = 9,
        Edit_past_date_Entry = 10,
        Delete_past_date_Entry = 11,
        Add_KOT = 12,
        Edit_KOT = 13,
        Delete_KOT = 14,
        Add_Sales = 15,
        Edit_Sales = 16,
        Delete_Sales = 17,
        Add_Purchase = 18,
        Edit_Purchase = 19,
        Delete_Purchase = 20,
        Add_Issue = 21,
        Edit_Issue = 22,
        Delete_Issue = 23,
        Add_Adjustment = 24,
        Edit_Adjustment = 25,
        Delete_Adjustment = 26,
        Add_Booking = 27,
        Edit_Booking = 28,
        Delete_Booking = 29,
        Add_Account_Entry = 30,
        Edit_Account_Entry = 31,
        Delete_Account_Entry = 32,
        Allow_Add_Items_KOT_to_Sale = 33,
        Allow_Edit_Items_KOT_to_Sale = 34,
        Allow_non_zero_Balance_Sale = 35,
        Allow_Rate_Change = 36,
        Allow_Discount_Change = 37,
        Allow_Tax_AddLess_Change = 38,
        User_Shift_Report = 39,
        Daily_Purchase = 40,
        Daily_Sales = 41,
        Daily_Collection = 42,
        Daily_Profit_and_Loss = 43,
        Monthly_Purchase = 44,
        Monthly_Sales = 45,
        Monthly_Collection = 46,
        Monthly_Profit_and_Loss = 47,
        Item_Stock = 48,
        Stock_In_Hand = 49,
        Most_Sold_Items = 50
    }

    public enum posCustomerstatus
    {
        Waiting = 1,
        Assigned = 2,
        Cancelled = 3,
        NotAvailable = 4
    }

    public enum AddLessCalculatedOn
    {
        GrossAmount = 0,
        NetAmount = 1
    }

    public enum posOrderStatus
    {
        Placed = 1,
        Cooking = 2,
        Ready = 3,
        Served = 4,
        Cancelled = 5,
        Dispached = 6,
        Delivered = 7

    }

    public enum posReportDateFilter
    {
        Day = 0,
        Month = 1,
        Financial_Year = 2,
        Date_Range = 3
    }

    public enum posReportPrintSize
    {
        _58_mm = 1,
        _80_mm = 2,
        _A4 = 3
    }

    public enum posItemType
    {
        Item = 0,
        Raw_Material = 1,
        Modifier = 2,
        Combo_Item = 3
    }

    public enum posFeedbackQuestionType
    {
        Input = 1,
        Rating = 2,
        Single_Select = 3,
        Multi_Select = 4
    }

    public enum posCustomerType
    {
        Customer = 1,
        Registered_User = 2,
        Creditor = 3
    }

    public class posDropDownItem
    {
        public static string Select = "- SELECT -";
        public static string All = "- ALL -";
    }

    public enum posOfferItemType
    {
        OnEach = 1,
        BuyItems = 2,
        GetItems = 3
    }

    public enum posCounterSetting
    {
        Phone = 1,
        Fax = 2,
        Email = 3,
        Thank_You_Message = 4,
        Payment_Type = 5,
        Day_End_Time = 6,
        Waiter = 7,
        Captain = 8,
        Customer_Required = 9,
        Persons_Adult_Children = 10,
        Table = 11,
        KOT = 12,
        Show_Item_Image = 13,
        Show_Item_Modifiers = 14,
        KOT_No_Type = 15,
        KOT_Numbering = 16,
        KOT_No_Prefix = 17,
        KOT_No_Deigits = 18,
        Bill_No_Type = 19,
        Sales_Numbering = 20,
        Sales_Bill_No_Prefix = 21,
        Sales_Bill_No_Digit = 22,
        Comp_Sales_No_Prefix = 23,
        Comp_Sales_No_Digit = 24,
        Token = 25,
        Show_Suggested_Items = 26
    }

    public enum posBusinessInfoQuestionType
    {
        Input = 1,
        Single_Select = 2,
        Multi_Select = 3
    }

    public enum posSourceType
    {
        Desktop = 1,
        Web = 2,
        Android_App = 3,
        Android_Web = 4,
        IOS_App = 5,
        IOS_Web = 6
    }

    public enum posOptionValue
    {
        Veg = 1,
        Non_Veg = 2,
        Jain = 3
    }

    public enum posPaymentTypeCategory
    {
        Cash = 1,
        Bank = 2,
        Card = 3,
        Complementary = 4,
        Others = 5
    }
    #endregion

    #region posMessageDAL
    public class posMessagesDAL
    {
        public static string NotLoggedIn = "You are not logged in or your login session expired, Please login again.";
        public static string Exception = "There was some problem processing your request, Please try after some time.";
        public static string AlreadyExist = "Record already exist.";
        public static string NotFound = "No record found.";
        public static string InsertSuccess = "Record saved successfully.";
        public static string InsertFail = "Failed to save record.";
        public static string UpdateSuccess = "Record updated successfully.";
        public static string UpdateFail = "Failed to update record.";
        public static string DeleteSuccess = "Record deleted successfully.";
        public static string DeleteFail = "Failed to delete record.";
        public static string SelectFail = "Failed to get record.";
        public static string SelectAllFail = "Failed to get record(s).";
        public static string InsertAllSuccess = "Record(s) saved successfully.";
        public static string InsertAllFail = "Failed to save record(s).";
        public static string UpdateAllSuccess = "Record(s) updated successfully.";
        public static string UpdateAllFail = "Failed to update record(s).";
        public static string DeleteAllSuccess = "Record(s) deleted successfully.";
        public static string DeleteAllFail = "Failed to delete record(s).";
        public static string SelectRecord = "Please select atleast one record.";
        public static string DeleteRecord = "Delete selected record?";
        public static string DeleteAllRecords = "Delete {0} record(s)?";
        public static string DataLostWarning = "Do you want to save the changes you made?";
        public static string AlreadyInUse = "You can not delete {0} because it is in use.";

        public static void ShowMessage(string message, posMessageIcon messageIcon)
        {
            KryptonMessageBox.Show(message, Application.ProductName, MessageBoxButtons.OK, (MessageBoxIcon)messageIcon);
        }
    }
    #endregion

    #region posValidationDAL
    public class posValidationDAL
    {
        public static bool ValidateInput(string input, posValidateType type)
        {
            if (type == posValidateType.Required)
            {
                if (string.IsNullOrEmpty(input.Trim()))
                {
                    return false;
                }
                else if (input.Equals(posDropDownItem.Select))
                {
                    return false;
                }
            }
            else if (!string.IsNullOrEmpty(input) && type == posValidateType.Number)
            {
                long Number;
                bool isNumber;
                isNumber = long.TryParse(input, out Number);
                if (!isNumber)
                {
                    return false;
                }
            }
            else if (!string.IsNullOrEmpty(input) && type == posValidateType.Decimal)
            {
                decimal Number;
                bool isNumber;
                isNumber = decimal.TryParse(input, out Number);
                if (!isNumber)
                {
                    return false;
                }
            }
            else if (!string.IsNullOrEmpty(input) && type == posValidateType.Email)
            {
                Regex regex = new Regex(@"\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*");
                Match match = regex.Match(input);
                if (!match.Success)
                {
                    return false;
                }
            }
            else if (!string.IsNullOrEmpty(input) && type == posValidateType.URL)
            {
                Regex regex = new Regex(@"http(s)?://([\w-]+\.)+[\w-]+(/[\w- ./?%&=]*)?");
                Match match = regex.Match(input);
                if (!match.Success)
                {
                    return false;
                }
            }
            else if (!string.IsNullOrEmpty(input) && type == posValidateType.Percentage)
            {
                decimal Number;
                bool isNumber;
                isNumber = decimal.TryParse(input, out Number);
                if (!isNumber)
                {
                    return false;
                }
                if (Number < 0 || Number > 100)
                {
                    return false;
                }
            }
            else if (!string.IsNullOrEmpty(input) && type == posValidateType.Phone)
            {
                Regex regex = new Regex("^\\d{10,15}$");
                Match match = regex.Match(input);
                if (!match.Success)
                {
                    return false;
                }
            }
            return true;
        }
    }
    #endregion

    #region posErrorStatus

    public class ErrorStatus
    {
        public int ErrorCode { get; set; }
        public long ErrorNumber { get; set; }
        public string ErrorMsg { get; set; }

        public ErrorStatus()
        {
            this.ErrorMsg = string.Empty;
        }
    }

    #endregion

    [Serializable]
    #region  OrderItemDAL
    public class posOrderItemDAL : posItemRateTranDAL
    {
        public int OrderId { get; set; }
        public int ItemMasterId { get; set; }
        public string Remark { get; set; }
        public bool IsRemark { get; set; }
        public int linktoItemMasterIdModifier { get; set; }
        public int SrNo { get; set; }
        public string ItemName { get; set; }
        public int Quantity { get; set; }
        public double Amount { get; set; }
        public double DiscountPercentage { get; set; }
        public bool IsDiscountPercentage { get; set; }
        public double DiscountAmount { get; set; }
        public double TaxAmt1 { get; set; }
        public double TaxAmt2 { get; set; }
        public double TaxAmt3 { get; set; }
        public double TaxAmt4 { get; set; }
        public double TaxAmt5 { get; set; }
        public double AddLessAmount { get; set; }
        public string ItemOptions { get; set; }
        public int linktoOfferMasterId { get; set; }
        public short? RateIndex { get; set; }

        public List<posOrderItemDAL> SelectAllItemMasterKOTItemByOrderMasterID(string orderMasterIDs)
        {

            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;

            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posItemMasterKOTItemByOrderMasterID_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@OrderMasterIDs", SqlDbType.VarChar).Value = orderMasterIDs;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<posOrderItemDAL> lstOrderItemDAL = new List<posOrderItemDAL>();
                posOrderItemDAL objOrderItemDAL = null;
                while (SqlRdr.Read())
                {
                    objOrderItemDAL = new posOrderItemDAL();
                    objOrderItemDAL.OrderId = Convert.ToInt32(SqlRdr["OrderId"]);
                    objOrderItemDAL.ItemMasterId = Convert.ToInt32(SqlRdr["ItemMasterId"]);
                    objOrderItemDAL.ItemName = Convert.ToString(SqlRdr["ItemName"]);
                    objOrderItemDAL.Quantity = Convert.ToInt16(SqlRdr["Quantity"]);
                    objOrderItemDAL.linktoItemMasterIdModifier = Convert.ToInt32(SqlRdr["ItemMasterIdModifier"]);
                    objOrderItemDAL.SaleRate = Convert.ToDouble(SqlRdr["Rate"]);
                    objOrderItemDAL.MRP = objOrderItemDAL.SaleRate;
                    objOrderItemDAL.Rate1 = objOrderItemDAL.SaleRate;
                    objOrderItemDAL.Rate2 = objOrderItemDAL.SaleRate;
                    objOrderItemDAL.Rate3 = objOrderItemDAL.SaleRate;
                    objOrderItemDAL.Rate4 = objOrderItemDAL.SaleRate;
                    objOrderItemDAL.Rate5 = objOrderItemDAL.SaleRate;
                    objOrderItemDAL.Tax1 = Convert.ToDecimal(SqlRdr["Tax1"]);
                    objOrderItemDAL.Tax2 = Convert.ToDecimal(SqlRdr["Tax2"]);
                    objOrderItemDAL.Tax3 = Convert.ToDecimal(SqlRdr["Tax3"]);
                    objOrderItemDAL.Tax4 = Convert.ToDecimal(SqlRdr["Tax4"]);
                    objOrderItemDAL.Tax5 = Convert.ToDecimal(SqlRdr["Tax5"]);
                    //objOrderItemDAL.Rate1WithTax = Double.Parse(SqlRdr["Rate1WithTax"].ToString());
                    //objOrderItemDAL.Rate2WithTax = Double.Parse(SqlRdr["Rate2WithTax"].ToString());
                    //objOrderItemDAL.Rate3WithTax = Double.Parse(SqlRdr["Rate3WithTax"].ToString());
                    //objOrderItemDAL.Rate4WithTax = Double.Parse(SqlRdr["Rate4WithTax"].ToString());
                    //objOrderItemDAL.Rate5WithTax = Double.Parse(SqlRdr["Rate5WithTax"].ToString());
                    objOrderItemDAL.Remark = Convert.ToString(SqlRdr["ItemRemark"]);
                    if (SqlRdr["RateIndex"] != DBNull.Value)
                    {
                        objOrderItemDAL.RateIndex = Convert.ToInt16(SqlRdr["RateIndex"]);
                    }
                    lstOrderItemDAL.Add(objOrderItemDAL);
                }

                SqlRdr.Close();
                SqlCon.Close();
                return lstOrderItemDAL;

            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public List<posOrderItemDAL> SelectAllposSalesMasterSalesItemBySalesMasterID(long SalesMasterId)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;

            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posSalesMasterSalesItemBySalesMasterID_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@SalesMasterId", SqlDbType.BigInt).Value = SalesMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<posOrderItemDAL> lstOrderItemDAL = new List<posOrderItemDAL>();
                posOrderItemDAL objOrderItemDAL = null;
                while (SqlRdr.Read())
                {
                    objOrderItemDAL = new posOrderItemDAL();
                    objOrderItemDAL.OrderId = Convert.ToInt32(SqlRdr["OrderId"]);
                    objOrderItemDAL.ItemMasterId = Convert.ToInt32(SqlRdr["ItemMasterId"]);
                    objOrderItemDAL.ItemName = Convert.ToString(SqlRdr["ItemName"]);
                    objOrderItemDAL.Quantity = Convert.ToInt16(SqlRdr["Quantity"]);
                    objOrderItemDAL.linktoItemMasterIdModifier = Convert.ToInt32(SqlRdr["ItemMasterIdModifier"]);
                    objOrderItemDAL.MRP = Double.Parse(SqlRdr["MRP"].ToString());
                    objOrderItemDAL.Rate1 = Double.Parse(SqlRdr["Rate1"].ToString());
                    objOrderItemDAL.Rate2 = Double.Parse(SqlRdr["Rate2"].ToString());
                    objOrderItemDAL.Rate3 = Double.Parse(SqlRdr["Rate3"].ToString());
                    objOrderItemDAL.Rate4 = Double.Parse(SqlRdr["Rate4"].ToString());
                    objOrderItemDAL.Rate5 = Double.Parse(SqlRdr["Rate5"].ToString());
                    objOrderItemDAL.Tax1 = Convert.ToDecimal(SqlRdr["Tax1"]);
                    objOrderItemDAL.Tax2 = Convert.ToDecimal(SqlRdr["Tax2"]);
                    objOrderItemDAL.Tax3 = Convert.ToDecimal(SqlRdr["Tax3"]);
                    objOrderItemDAL.Tax4 = Convert.ToDecimal(SqlRdr["Tax4"]);
                    objOrderItemDAL.Tax5 = Convert.ToDecimal(SqlRdr["Tax5"]);
                    //objOrderItemDAL.Rate1WithTax = Double.Parse(SqlRdr["Rate1WithTax"].ToString());
                    //objOrderItemDAL.Rate2WithTax = Double.Parse(SqlRdr["Rate2WithTax"].ToString());
                    //objOrderItemDAL.Rate3WithTax = Double.Parse(SqlRdr["Rate3WithTax"].ToString());
                    //objOrderItemDAL.Rate4WithTax = Double.Parse(SqlRdr["Rate4WithTax"].ToString());
                    //objOrderItemDAL.Rate5WithTax = Double.Parse(SqlRdr["Rate5WithTax"].ToString());
                    objOrderItemDAL.Remark = Convert.ToString(SqlRdr["ItemRemark"]);
                    if (SqlRdr["RateIndex"] != DBNull.Value)
                    {
                        objOrderItemDAL.RateIndex = Convert.ToInt16(SqlRdr["RateIndex"]);
                    }
                    lstOrderItemDAL.Add(objOrderItemDAL);
                }

                SqlRdr.Close();
                SqlCon.Close();
                return lstOrderItemDAL;

            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
    }
    #endregion
}
