using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace posLibrary
{
    /// <summary>
    /// Class for posSupplierItemTran
    /// </summary>
    public class posSupplierItemTranDAL
    {
        #region Properties
        public int SupplierItemTranId { get; set; }
        public short linktoSupplierMasterId { get; set; }
        public int linktoItemMasterId { get; set; }

        //Extra

        public string ItemNameWithCode { get; set; }
        public short ItemType { get; set; }
        public string CategoryName { get; set; }
        public bool IsSelected { get; set; }
        public string ShortName { get; set; }
        public string Unit { get; set; }
        #endregion

        #region Class Methods
        private List<posSupplierItemTranDAL> SetListPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            List<posSupplierItemTranDAL> lstSupplierItemTran = new List<posSupplierItemTranDAL>();
            posSupplierItemTranDAL objSupplierItemTran = null;
            while (sqlRdr.Read())
            {
                objSupplierItemTran = new posSupplierItemTranDAL();
                if (sqlRdr["SupplierItemTranId"] != DBNull.Value)
                {
                    objSupplierItemTran.SupplierItemTranId = Convert.ToInt32(sqlRdr["SupplierItemTranId"]);
                    objSupplierItemTran.IsSelected = true;
                }
                else
                {
                    objSupplierItemTran.IsSelected = false;
                }
                objSupplierItemTran.linktoItemMasterId = Convert.ToInt32(sqlRdr["ItemMasterId"]);
                // Extra
                objSupplierItemTran.ItemNameWithCode = Convert.ToString(sqlRdr["ItemName"]) + " (" + Convert.ToString(sqlRdr["ItemCode"]) + ")";
                objSupplierItemTran.CategoryName = Convert.ToString(sqlRdr["CategoryName"]);
                objSupplierItemTran.ShortName = Convert.ToString(sqlRdr["ShortName"]);
                objSupplierItemTran.Unit = Convert.ToString(sqlRdr["Unit"]);
                lstSupplierItemTran.Add(objSupplierItemTran);
            }
            return lstSupplierItemTran;
        }
        #endregion

        #region Insert
        public posRecordStatus InsertAllSupplierItemTran(string linktoItemMasterIds)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posSupplierItemTran_InsertAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@linktoSupplierMasterId", SqlDbType.SmallInt).Value = this.linktoSupplierMasterId;
                SqlCmd.Parameters.Add("@linktoItemMasterIds", SqlDbType.VarChar).Value = linktoItemMasterIds;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public static posRecordStatus InsertAllSupplierItemTran(int linktoSupplierMasterId, int linktoItemMasterId,SqlConnection sqlCon,SqlTransaction sqlTran)
        { 
            SqlCommand SqlCmd = null;
            try
            { 
                SqlCmd = new SqlCommand("posSupplierItemTran_Insert", sqlCon,sqlTran);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@linktoSupplierMasterId", SqlDbType.SmallInt).Value = linktoSupplierMasterId;
                SqlCmd.Parameters.Add("@linktoItemMasterId", SqlDbType.VarChar).Value = linktoItemMasterId;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output; 
             
                SqlCmd.ExecuteNonQuery(); 

                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd); 
            }
        }
        #endregion

        #region SelectAll

        public List<posSupplierItemTranDAL> SelectAllSupplierItemTran(short linktoBusinessMasterId)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posSupplierItemTran_SelectAll", SqlCon);

                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@linktoSupplierMasterId", SqlDbType.SmallInt).Value = this.linktoSupplierMasterId;
                SqlCmd.Parameters.Add("@ItemType", SqlDbType.SmallInt).Value = this.ItemType;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = linktoBusinessMasterId;

                SqlCon.Open();

                SqlRdr = SqlCmd.ExecuteReader();
                List<posSupplierItemTranDAL> lstSupplierItemTranDAL = SetListPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                return lstSupplierItemTranDAL;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion
    }
}
