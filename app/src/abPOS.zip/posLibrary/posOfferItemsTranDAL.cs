using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace posLibrary
{
    /// <summary>
    /// Class for posOfferItemsTran
    /// </summary>
    public class posOfferItemsTranDAL
    {
        #region Properties
        public int OfferItemsTranId { get; set; }
        public int linktoOfferMasterId { get; set; }
        public int? linktoItemMasterId { get; set; }

        /// Extra
        public string Offer { get; set; }
        public string Item { get; set; }
        public string ItemCode { get; set; }
        public string ShortDescription { get; set; }
        public short OfferItemType { get; set; }
        public string CounterMasterIds { get; set; }

        #endregion

        #region Insert
        public posRecordStatus InsertOfferItemsTran(SqlConnection SqlCon, SqlTransaction sqlTran)
        {
            SqlCommand SqlCmd = null;
            try
            {
                posRecordStatus rs = posRecordStatus.Error;

                SqlCmd = new SqlCommand("posOfferItemsTran_Insert", SqlCon, sqlTran);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@OfferItemsTranId", SqlDbType.Int).Direction = ParameterDirection.Output;
                SqlCmd.Parameters.Add("@linktoOfferMasterId", SqlDbType.SmallInt).Value = this.linktoOfferMasterId;
                SqlCmd.Parameters.Add("@linktoItemMasterId", SqlDbType.Int).Value = this.linktoItemMasterId;
                SqlCmd.Parameters.Add("@OfferItemType", SqlDbType.SmallInt).Value = this.OfferItemType;

                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCmd.ExecuteNonQuery();

                this.OfferItemsTranId = Convert.ToInt32(SqlCmd.Parameters["@OfferItemsTranId"].Value);
                rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;

                return rs;

            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
            }
        }
        #endregion

        #region Delete
        public posRecordStatus DeleteOfferItemsTran(SqlConnection SqlCon, SqlTransaction sqlTran)
        {
            SqlCommand SqlCmd = null;
            try
            {
                SqlCmd = new SqlCommand("posOfferItemsTran_Delete", SqlCon, sqlTran);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@linktoOfferMasterId", SqlDbType.Int).Value = this.linktoOfferMasterId;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCmd.ExecuteNonQuery();

                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
            }
        }
        #endregion

        #region SelectAll
        public List<posOfferItemsTranDAL> SelectAllOfferItemsTranByOffer()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posOfferItemsTranByOffer_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;
                SqlCmd.Parameters.Add("@linktoOfferMasterId", SqlDbType.Int).Value = this.linktoOfferMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<posOfferItemsTranDAL> lstOfferItems = new List<posOfferItemsTranDAL>();
                posOfferItemsTranDAL objOfferItems = null;
                while (SqlRdr.Read())
                {
                    objOfferItems = new posOfferItemsTranDAL();
                    objOfferItems.linktoOfferMasterId = Convert.ToInt32(SqlRdr["linktoOfferMasterId"]);
                    if (SqlRdr["linktoItemMasterId"] != DBNull.Value)
                    {
                        objOfferItems.linktoItemMasterId = Convert.ToInt32(SqlRdr["linktoItemMasterId"]);
                    }
                    objOfferItems.Item = Convert.ToString(SqlRdr["ItemName"]);
                    objOfferItems.ItemCode = Convert.ToString(SqlRdr["ItemCode"]);
                    objOfferItems.ShortDescription = Convert.ToString(SqlRdr["ShortDescription"]);
                    objOfferItems.OfferItemType = Convert.ToInt16(SqlRdr["OfferItemType"]);
                    lstOfferItems.Add(objOfferItems);
                }

                SqlRdr.Close();
                SqlCon.Close();
                return lstOfferItems;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion
    }
}
