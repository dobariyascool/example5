using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace posLibrary
{
    /// <summary>
    /// Class for posItemSuggestedTran
    /// </summary>
    public class posItemSuggestedTranDAL
    {
        #region Properties
        public int ItemSuggestedTranId { get; set; }
        public int linktoItemMasterId { get; set; }
        public int linktoItemMasterIdSuggested { get; set; }

        /// Extra
        public int ItemMasterId { get; set; }
        public string ItemName { get; set; }
        public string ItemCode { get; set; }
        public string ShortName { get; set; }
        public string ImageName { get; set; }
        public string xs_ImagePhysicalName { get; set; }
        public string sm_ImagePhysicalName { get; set; }
        public string md_ImagePhysicalName { get; set; }
        public string lg_ImagePhysicalName { get; set; }
        public string xl_ImagePhysicalName { get; set; }
        public string CategoryName { get; set; }
        public int linktoCategoryMasterId { get; set; }
        public string SuggestedItems { get; set; }
        public bool IsSelected { get; set; }
        #endregion

        #region Insert
        public posRecordStatus InsertItemSuggestedAllTran(string suggestedItemMasterIDs)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posItemSuggestedTran_Insert", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                //SqlCmd.Parameters.Add("@ItemSuggestedTranId", SqlDbType.Int).Direction = ParameterDirection.Output;
                SqlCmd.Parameters.Add("@linktoItemMasterId", SqlDbType.Int).Value = this.linktoItemMasterId;
                SqlCmd.Parameters.Add("@SuggestedItemMasterIDs", SqlDbType.VarChar).Value = suggestedItemMasterIDs;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                //    this.ItemSuggestedTranId = Convert.ToInt32(SqlCmd.Parameters["@ItemSuggestedTranId"].Value);
                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region DeleteAll
        public static posRecordStatus DeleteAllItemSuggestedTran(string itemSuggestedTranIds)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posItemSuggestedTran_DeleteAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@ItemMasterIDs", SqlDbType.VarChar).Value = itemSuggestedTranIds;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region SelectAll
        public List<posItemSuggestedTranDAL> SelectAllItemSuggestedTran(short linktoBusinessMasterId)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader sqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posItemSuggestionTran_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@ItemMasterId", SqlDbType.Int).Value = this.linktoItemMasterId;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.Int).Value = linktoBusinessMasterId;
                SqlCon.Open();
                sqlRdr = SqlCmd.ExecuteReader();

                List<posItemSuggestedTranDAL> lstItemSuggestedTranDAL = new List<posItemSuggestedTranDAL>();
                posItemSuggestedTranDAL objItemSuggestedTran = null;
                while (sqlRdr.Read())
                {
                    objItemSuggestedTran = new posItemSuggestedTranDAL();
                    if (sqlRdr["ItemSuggestedTranId"] != DBNull.Value)
                    {
                        objItemSuggestedTran.IsSelected = true;
                        objItemSuggestedTran.ItemSuggestedTranId = Convert.ToInt32(sqlRdr["ItemSuggestedTranId"]);
                    }
                    else
                    {
                        objItemSuggestedTran.IsSelected = false;
                    }
                    if (sqlRdr["linktoItemMasterId"] != DBNull.Value)
                    {
                        objItemSuggestedTran.linktoItemMasterId = Convert.ToInt32(sqlRdr["linktoItemMasterId"]);
                    }
                    if (sqlRdr["linktoItemMasterIdSuggested"] != DBNull.Value)
                    {
                        objItemSuggestedTran.linktoItemMasterIdSuggested = Convert.ToInt32(sqlRdr["linktoItemMasterIdSuggested"]);
                    }
                    objItemSuggestedTran.ItemMasterId = Convert.ToInt32(sqlRdr["ItemMasterId"]);
                    objItemSuggestedTran.ItemName = Convert.ToString(sqlRdr["ItemName"]) + " (" + Convert.ToString(sqlRdr["ItemCode"]) + ")";
                    objItemSuggestedTran.ItemCode = Convert.ToString(sqlRdr["ItemCode"]);
                    objItemSuggestedTran.CategoryName = Convert.ToString(sqlRdr["CategoryName"]);
                    lstItemSuggestedTranDAL.Add(objItemSuggestedTran);
                }
                sqlRdr.Close();
                SqlCon.Close();

                return lstItemSuggestedTranDAL;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(sqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public static List<posItemSuggestedTranDAL> SelectAllItemSuggestedTranItemNames(short linktoBusinessMasterId)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader sqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posItemSuggestionTranItemNames_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = linktoBusinessMasterId;
                SqlCon.Open();
                sqlRdr = SqlCmd.ExecuteReader();

                List<posItemSuggestedTranDAL> lstItemSuggestedTranDAL = new List<posItemSuggestedTranDAL>();
                posItemSuggestedTranDAL objItemSuggestedTran = null;
                while (sqlRdr.Read())
                {
                    objItemSuggestedTran = new posItemSuggestedTranDAL();

                    objItemSuggestedTran.linktoItemMasterId = Convert.ToInt32(sqlRdr["linktoItemMasterId"]);
                    objItemSuggestedTran.linktoCategoryMasterId = Convert.ToInt32(sqlRdr["linktoCategoryMasterId"]);
                    objItemSuggestedTran.ItemName = Convert.ToString(sqlRdr["ItemName"]);
                    objItemSuggestedTran.SuggestedItems = Convert.ToString(sqlRdr["SuggestedItems"]);

                    lstItemSuggestedTranDAL.Add(objItemSuggestedTran);
                }
                sqlRdr.Close();
                SqlCon.Close();

                return lstItemSuggestedTranDAL;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(sqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public List<posItemSuggestedTranDAL> SelectAllItemSuggestedTranByItemMasterId(short counterMasterId)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader sqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posItemSuggestionTranByItemMasterId_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@linktoItemMastreId", SqlDbType.Int).Value = this.linktoItemMasterId;
                SqlCmd.Parameters.Add("@CounterMasterId", SqlDbType.SmallInt).Value = counterMasterId;

                SqlCon.Open();
                sqlRdr = SqlCmd.ExecuteReader();

                List<posItemSuggestedTranDAL> lstItemSuggestedTranDAL = new List<posItemSuggestedTranDAL>();
                posItemSuggestedTranDAL objItemSuggestedTran = null;
                while (sqlRdr.Read())
                {
                    objItemSuggestedTran = new posItemSuggestedTranDAL();
                    objItemSuggestedTran.ItemMasterId = Convert.ToInt32(sqlRdr["ItemMasterId"]);
                    objItemSuggestedTran.ItemName = Convert.ToString(sqlRdr["ItemName"]);
                    objItemSuggestedTran.ItemCode = Convert.ToString(sqlRdr["ItemCode"]);
                    objItemSuggestedTran.ShortName = Convert.ToString(sqlRdr["ShortName"]);
                    if (sqlRdr["ImageName"] != DBNull.Value)
                    {
                        objItemSuggestedTran.ImageName = Convert.ToString(sqlRdr["ImageName"]);

                        objItemSuggestedTran.xs_ImagePhysicalName = "xs_" + Convert.ToString(sqlRdr["ImageName"]);
                        objItemSuggestedTran.sm_ImagePhysicalName = "sm_" + Convert.ToString(sqlRdr["ImageName"]);
                        objItemSuggestedTran.md_ImagePhysicalName = "md_" + Convert.ToString(sqlRdr["ImageName"]);
                        objItemSuggestedTran.lg_ImagePhysicalName = "lg_" + Convert.ToString(sqlRdr["ImageName"]);
                        objItemSuggestedTran.xl_ImagePhysicalName = "xl_" + Convert.ToString(sqlRdr["ImageName"]);

                    }
                    lstItemSuggestedTranDAL.Add(objItemSuggestedTran);
                }
                sqlRdr.Close();
                SqlCon.Close();

                return lstItemSuggestedTranDAL;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(sqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion
    }
}
