using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace posLibrary
{
    /// <summary>
    /// Class for posAccountCategoryMaster
    /// </summary>
    public class posAccountCategoryMasterDAL
    {
        #region Properties
        public int AccountCategoryMasterId { get; set; }
        public string ShortName { get; set; }
        public string AccountCategoryName { get; set; }
        public string Description { get; set; }
        public bool? IsIncome { get; set; }
        public short linktoBusinessMasterId { get; set; }

        #endregion

        #region Class Methods
        private bool SetClassPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            if (sqlRdr.Read())
            {
                this.AccountCategoryMasterId = Convert.ToInt32(sqlRdr["AccountCategoryMasterId"]);
                this.ShortName = Convert.ToString(sqlRdr["ShortName"]);
                this.AccountCategoryName = Convert.ToString(sqlRdr["AccountCategoryName"]);
                this.Description = Convert.ToString(sqlRdr["Description"]);
                if (sqlRdr["IsIncome"] != DBNull.Value)
                {
                    this.IsIncome = Convert.ToBoolean(sqlRdr["IsIncome"]);
                }
                return true;
            }
            return false;
        }

        private List<posAccountCategoryMasterDAL> SetListPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            List<posAccountCategoryMasterDAL> lstAccountCategoryMaster = new List<posAccountCategoryMasterDAL>();
            posAccountCategoryMasterDAL objAccountCategoryMaster = null;
            while (sqlRdr.Read())
            {
                objAccountCategoryMaster = new posAccountCategoryMasterDAL();
                objAccountCategoryMaster.AccountCategoryMasterId = Convert.ToInt32(sqlRdr["AccountCategoryMasterId"]);
                objAccountCategoryMaster.ShortName = Convert.ToString(sqlRdr["ShortName"]);
                objAccountCategoryMaster.AccountCategoryName = Convert.ToString(sqlRdr["AccountCategoryName"]);
                objAccountCategoryMaster.Description = Convert.ToString(sqlRdr["Description"]);
                if (sqlRdr["IsIncome"] != DBNull.Value)
                {
                    objAccountCategoryMaster.IsIncome = Convert.ToBoolean(sqlRdr["IsIncome"]);
                }

                /// Extra
                lstAccountCategoryMaster.Add(objAccountCategoryMaster);
            }
            return lstAccountCategoryMaster;
        }
        #endregion

        #region Insert
        public posRecordStatus InsertAccountCategoryMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posAccountCategoryMaster_Insert", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@AccountCategoryMasterId", SqlDbType.Int).Direction = ParameterDirection.Output;
                SqlCmd.Parameters.Add("@ShortName", SqlDbType.VarChar).Value = this.ShortName;
                SqlCmd.Parameters.Add("@AccountCategoryName", SqlDbType.VarChar).Value = this.AccountCategoryName;
                SqlCmd.Parameters.Add("@Description", SqlDbType.VarChar).Value = this.Description;
                SqlCmd.Parameters.Add("@IsIncome", SqlDbType.Bit).Value = this.IsIncome;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                this.AccountCategoryMasterId = Convert.ToInt32(SqlCmd.Parameters["@AccountCategoryMasterId"].Value);
                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region Update
        public posRecordStatus UpdateAccountCategoryMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posAccountCategoryMaster_Update", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@AccountCategoryMasterId", SqlDbType.Int).Value = this.AccountCategoryMasterId;
                SqlCmd.Parameters.Add("@ShortName", SqlDbType.VarChar).Value = this.ShortName;
                SqlCmd.Parameters.Add("@AccountCategoryName", SqlDbType.VarChar).Value = this.AccountCategoryName;
                SqlCmd.Parameters.Add("@Description", SqlDbType.VarChar).Value = this.Description;
                SqlCmd.Parameters.Add("@IsIncome", SqlDbType.Bit).Value = this.IsIncome;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region DeleteAll
        public posRecordStatus DeleteAllAccountCategoryMaster(string accountCategoryMasterIds)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posAccountCategoryMaster_DeleteAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@AccountCategoryMasterIds", SqlDbType.VarChar).Value = accountCategoryMasterIds;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region Select
        public bool SelectAccountCategoryMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posAccountCategoryMaster_Select", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@AccountCategoryMasterId", SqlDbType.Int).Value = this.AccountCategoryMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                bool IsSelected = SetClassPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                return IsSelected;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return false;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        #endregion

        #region SelectAll
        public List<posAccountCategoryMasterDAL> SelectAllAccountCategoryMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posAccountCategoryMaster_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@AccountCategoryName", SqlDbType.VarChar).Value = this.AccountCategoryName;
                SqlCmd.Parameters.Add("@IsIncome", SqlDbType.Bit).Value = this.IsIncome;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<posAccountCategoryMasterDAL> lstAccountCategoryMasterDAL = SetListPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                return lstAccountCategoryMasterDAL;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public static List<posAccountCategoryMasterDAL> SelectAllAccountCategoryMasterAccountCategoryName(short linktoBusinessMasterId)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posAccountCategoryMasterAccountCategoryName_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = linktoBusinessMasterId;
                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<posAccountCategoryMasterDAL> lstAccountCategoryMasterDAL = new List<posAccountCategoryMasterDAL>();
                posAccountCategoryMasterDAL objAccountCategoryMasterDAL = null;
                while (SqlRdr.Read())
                {
                    objAccountCategoryMasterDAL = new posAccountCategoryMasterDAL();
                    objAccountCategoryMasterDAL.AccountCategoryMasterId = Convert.ToInt32(SqlRdr["AccountCategoryMasterId"]);
                    objAccountCategoryMasterDAL.AccountCategoryName = Convert.ToString(SqlRdr["AccountCategoryName"]);
                    lstAccountCategoryMasterDAL.Add(objAccountCategoryMasterDAL);
                }
                SqlRdr.Close();
                SqlCon.Close();

                return lstAccountCategoryMasterDAL;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion
    }
}
