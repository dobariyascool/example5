using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace posLibrary
{
    /// <summary>
    /// Class for posSettingMaster
    /// </summary>
    public class posSettingMasterDAL
    {
        #region Properties
        public short SettingMasterId { get; set; }
        public string Setting { get; set; }
        public string Value { get; set; }
        public string DefaultValue { get; set; }
        public short linktoBusinessMasterId { get; set; }
        #endregion

        #region Class Methods
        private List<posSettingMasterDAL> SetListPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            List<posSettingMasterDAL> lstSettingMaster = new List<posSettingMasterDAL>();
            posSettingMasterDAL objSettingMaster = null;
            while (sqlRdr.Read())
            {
                objSettingMaster = new posSettingMasterDAL();
                objSettingMaster.SettingMasterId = Convert.ToInt16(sqlRdr["SettingMasterId"]);
                objSettingMaster.Setting = Convert.ToString(sqlRdr["Setting"]);
                objSettingMaster.Value = Convert.ToString(sqlRdr["Value"]);
                objSettingMaster.DefaultValue = Convert.ToString(sqlRdr["DefaultValue"]);
                lstSettingMaster.Add(objSettingMaster);
            }
            return lstSettingMaster;
        }
        #endregion

        #region Update
        public posRecordStatus UpdateSettingMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();

                SqlCmd = new SqlCommand("posSettingMaster_Update", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@SettingMasterId", SqlDbType.SmallInt).Value = this.SettingMasterId;
                SqlCmd.Parameters.Add("@Value", SqlDbType.VarChar).Value = this.Value;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public posRecordStatus UpdateSettingMaster(List<posSettingMasterDAL> lstSettingMasterDAL)
         {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCon.Open();

                foreach (posSettingMasterDAL _objSetting in lstSettingMasterDAL)
                {
                    SqlCmd = new SqlCommand("posSettingMaster_Update", SqlCon);
                    SqlCmd.CommandType = CommandType.StoredProcedure;

                    SqlCmd.Parameters.Add("@SettingMasterId", SqlDbType.SmallInt).Value = _objSetting.SettingMasterId;
                    SqlCmd.Parameters.Add("@Value", SqlDbType.VarChar).Value = _objSetting.Value;
                    SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                    SqlCmd.ExecuteNonQuery();
                }

                SqlCon.Close();
                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public posRecordStatus UpdateSettingMasterBySettingName(SqlConnection SqlCon, SqlTransaction SqlTran, List<posSettingMasterDAL> lstSettingMasterDAL)
        {
            SqlCommand SqlCmd = null;
            posRecordStatus rs = posRecordStatus.Error;
            try
            {
                SqlCmd = new SqlCommand("posSettingMasterBySettingName_Update", SqlCon, SqlTran);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                foreach (posSettingMasterDAL objSetting in lstSettingMasterDAL)
                {
                    SqlCmd.Parameters.Clear();
                    SqlCmd.Parameters.Add("@Setting", SqlDbType.VarChar).Value = objSetting.Setting;
                    SqlCmd.Parameters.Add("@Value", SqlDbType.VarChar).Value = objSetting.Value;
                    SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                    SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                    SqlCmd.ExecuteNonQuery();

                    rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                    if (rs != posRecordStatus.Success)
                    {
                        return rs;
                    }
                }
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
            }
        }
        #endregion

        #region Select

        public string SelectTableAssignmentSetting()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            string Value = string.Empty;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posSettingMasterTableAssignByBusinessId_Select", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCmd.Parameters.Add("@SettingMasterId", SqlDbType.SmallInt).Value = this.SettingMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                if (SqlRdr.Read())
                {
                    Value = Convert.ToString(SqlRdr["Value"]);
                }
                SqlRdr.Close();
                SqlCon.Close();

                return Value;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        #endregion

        #region SelectAll
        public List<posSettingMasterDAL> SelectAllSettingMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posSettingMaster_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<posSettingMasterDAL> lstSettingMasterDAL = SetListPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                return lstSettingMasterDAL;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion
    }
}
