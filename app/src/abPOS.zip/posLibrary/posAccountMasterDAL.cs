using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace posLibrary
{
    /// <summary>
    /// Class for posAccountMaster
    /// </summary>
    public class posAccountMasterDAL
    {
        #region Properties
        public int AccountMasterId { get; set; }
        public short linktoBusinessMasterId { get; set; }
        public int linktoAccountCategoryMasterId { get; set; }
        public string AccountName { get; set; }
        public string AccountNumber { get; set; }
        public double OpeningBalance { get; set; }
        public bool IsCredit { get; set; }
        public double CreditLimit { get; set; }
        public string Description { get; set; }
        public string Address { get; set; }
        public short? linktoCountryMasterId { get; set; }
        public short? linktoStateMasterId { get; set; }
        public int? linktoCityMasterId { get; set; }
        public int? linktoAreaMasterId { get; set; }
        public string Zipcode { get; set; }
        public string Phone1 { get; set; }
        public string Phone2 { get; set; }
        public string Fax { get; set; }
        public string Email1 { get; set; }
        public string Email2 { get; set; }
        public string TIN { get; set; }
        public string CST { get; set; }
        public string PAN { get; set; }
        public string TDS { get; set; }
        public bool IsDeleted { get; set; }
        public DateTime CreateDateTime { get; set; }
        public short linktoUserMasterIdCreatedBy { get; set; }
        public DateTime? UpdateDateTime { get; set; }
        public short? linktoUserMasterIdUpdatedBy { get; set; }

        /// Extra
        public string AccountCategory { get; set; }
        public string Country { get; set; }
        public string State { get; set; }
        public string City { get; set; }
        public string Area { get; set; }
        #endregion

        #region Class Methods
        private bool SetClassPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            if (sqlRdr.Read())
            {
                this.AccountMasterId = Convert.ToInt32(sqlRdr["AccountMasterId"]);
                this.linktoBusinessMasterId = Convert.ToInt16(sqlRdr["linktoBusinessMasterId"]);
                this.linktoAccountCategoryMasterId = Convert.ToInt32(sqlRdr["linktoAccountCategoryMasterId"]);
                this.AccountName = Convert.ToString(sqlRdr["AccountName"]);
                this.AccountNumber = Convert.ToString(sqlRdr["AccountNumber"]);
                this.OpeningBalance = Convert.ToDouble(sqlRdr["OpeningBalance"]);
                this.IsCredit = Convert.ToBoolean(sqlRdr["IsCredit"]);
                this.CreditLimit = Convert.ToDouble(sqlRdr["CreditLimit"]);
                this.Description = Convert.ToString(sqlRdr["Description"]);
                this.Address = Convert.ToString(sqlRdr["Address"]);
                if (sqlRdr["linktoCountryMasterId"] != DBNull.Value)
                {
                    this.linktoCountryMasterId = Convert.ToInt16(sqlRdr["linktoCountryMasterId"]);
                }
                if (sqlRdr["linktoStateMasterId"] != DBNull.Value)
                {
                    this.linktoStateMasterId = Convert.ToInt16(sqlRdr["linktoStateMasterId"]);
                }
                if (sqlRdr["linktoCityMasterId"] != DBNull.Value)
                {
                    this.linktoCityMasterId = Convert.ToInt32(sqlRdr["linktoCityMasterId"]);
                }
                if (sqlRdr["linktoAreaMasterId"] != DBNull.Value)
                {
                    this.linktoAreaMasterId = Convert.ToInt32(sqlRdr["linktoAreaMasterId"]);
                }
                this.Zipcode = Convert.ToString(sqlRdr["Zipcode"]);
                this.Phone1 = Convert.ToString(sqlRdr["Phone1"]);
                this.Phone2 = Convert.ToString(sqlRdr["Phone2"]);
                this.Fax = Convert.ToString(sqlRdr["Fax"]);
                this.Email1 = Convert.ToString(sqlRdr["Email1"]);
                this.Email2 = Convert.ToString(sqlRdr["Email2"]);
                this.TIN = Convert.ToString(sqlRdr["TIN"]);
                this.CST = Convert.ToString(sqlRdr["CST"]);
                this.PAN = Convert.ToString(sqlRdr["PAN"]);
                this.TDS = Convert.ToString(sqlRdr["TDS"]);
                this.IsDeleted = Convert.ToBoolean(sqlRdr["IsDeleted"]);
                this.CreateDateTime = Convert.ToDateTime(sqlRdr["CreateDateTime"]);
                this.linktoUserMasterIdCreatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdCreatedBy"]);
                if (sqlRdr["UpdateDateTime"] != DBNull.Value)
                {
                    this.UpdateDateTime = Convert.ToDateTime(sqlRdr["UpdateDateTime"]);
                }
                if (sqlRdr["linktoUserMasterIdUpdatedBy"] != DBNull.Value)
                {
                    this.linktoUserMasterIdUpdatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdUpdatedBy"]);
                }

                /// Extra
                this.AccountCategory = Convert.ToString(sqlRdr["AccountCategory"]);
                this.Country = Convert.ToString(sqlRdr["Country"]);
                this.State = Convert.ToString(sqlRdr["State"]);
                this.City = Convert.ToString(sqlRdr["City"]);
                this.Area = Convert.ToString(sqlRdr["Area"]);
                return true;
            }
            return false;
        }

        private List<posAccountMasterDAL> SetListPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            List<posAccountMasterDAL> lstAccountMaster = new List<posAccountMasterDAL>();
            posAccountMasterDAL objAccountMaster = null;
            while (sqlRdr.Read())
            {
                objAccountMaster = new posAccountMasterDAL();
                objAccountMaster.AccountMasterId = Convert.ToInt32(sqlRdr["AccountMasterId"]);
                objAccountMaster.linktoBusinessMasterId = Convert.ToInt16(sqlRdr["linktoBusinessMasterId"]);
                objAccountMaster.linktoAccountCategoryMasterId = Convert.ToInt32(sqlRdr["linktoAccountCategoryMasterId"]);
                objAccountMaster.AccountName = Convert.ToString(sqlRdr["AccountName"]);
                objAccountMaster.AccountNumber = Convert.ToString(sqlRdr["AccountNumber"]);
                objAccountMaster.OpeningBalance = Convert.ToDouble(sqlRdr["OpeningBalance"]);
                objAccountMaster.IsCredit = Convert.ToBoolean(sqlRdr["IsCredit"]);
                objAccountMaster.CreditLimit = Convert.ToDouble(sqlRdr["CreditLimit"]);
                objAccountMaster.Description = Convert.ToString(sqlRdr["Description"]);
                objAccountMaster.Address = Convert.ToString(sqlRdr["Address"]);
                if (sqlRdr["linktoCountryMasterId"] != DBNull.Value)
                {
                    objAccountMaster.linktoCountryMasterId = Convert.ToInt16(sqlRdr["linktoCountryMasterId"]);
                }
                if (sqlRdr["linktoStateMasterId"] != DBNull.Value)
                {
                    objAccountMaster.linktoStateMasterId = Convert.ToInt16(sqlRdr["linktoStateMasterId"]);
                }
                if (sqlRdr["linktoCityMasterId"] != DBNull.Value)
                {
                    objAccountMaster.linktoCityMasterId = Convert.ToInt32(sqlRdr["linktoCityMasterId"]);
                }
                if (sqlRdr["linktoAreaMasterId"] != DBNull.Value)
                {
                    objAccountMaster.linktoAreaMasterId = Convert.ToInt32(sqlRdr["linktoAreaMasterId"]);
                }
                objAccountMaster.Zipcode = Convert.ToString(sqlRdr["Zipcode"]);
                objAccountMaster.Phone1 = Convert.ToString(sqlRdr["Phone1"]);
                objAccountMaster.Phone2 = Convert.ToString(sqlRdr["Phone2"]);
                objAccountMaster.Fax = Convert.ToString(sqlRdr["Fax"]);
                objAccountMaster.Email1 = Convert.ToString(sqlRdr["Email1"]);
                objAccountMaster.Email2 = Convert.ToString(sqlRdr["Email2"]);
                objAccountMaster.TIN = Convert.ToString(sqlRdr["TIN"]);
                objAccountMaster.CST = Convert.ToString(sqlRdr["CST"]);
                objAccountMaster.PAN = Convert.ToString(sqlRdr["PAN"]);
                objAccountMaster.TDS = Convert.ToString(sqlRdr["TDS"]);
                objAccountMaster.IsDeleted = Convert.ToBoolean(sqlRdr["IsDeleted"]);
                objAccountMaster.CreateDateTime = Convert.ToDateTime(sqlRdr["CreateDateTime"]);
                objAccountMaster.linktoUserMasterIdCreatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdCreatedBy"]);
                if (sqlRdr["UpdateDateTime"] != DBNull.Value)
                {
                    objAccountMaster.UpdateDateTime = Convert.ToDateTime(sqlRdr["UpdateDateTime"]);
                }
                if (sqlRdr["linktoUserMasterIdUpdatedBy"] != DBNull.Value)
                {
                    objAccountMaster.linktoUserMasterIdUpdatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdUpdatedBy"]);
                }

                /// Extra
                objAccountMaster.AccountCategory = Convert.ToString(sqlRdr["AccountCategory"]);
                objAccountMaster.Country = Convert.ToString(sqlRdr["Country"]);
                objAccountMaster.State = Convert.ToString(sqlRdr["State"]);
                objAccountMaster.City = Convert.ToString(sqlRdr["City"]);
                objAccountMaster.Area = Convert.ToString(sqlRdr["Area"]);
                lstAccountMaster.Add(objAccountMaster);
            }
            return lstAccountMaster;
        }
        #endregion

        #region Insert
        public posRecordStatus InsertAccountMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posAccountMaster_Insert", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@AccountMasterId", SqlDbType.Int).Direction = ParameterDirection.Output;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCmd.Parameters.Add("@linktoAccountCategoryMasterId", SqlDbType.Int).Value = this.linktoAccountCategoryMasterId;
                SqlCmd.Parameters.Add("@AccountName", SqlDbType.VarChar).Value = this.AccountName;
                SqlCmd.Parameters.Add("@AccountNumber", SqlDbType.VarChar).Value = this.AccountNumber;
                SqlCmd.Parameters.Add("@OpeningBalance", SqlDbType.Money).Value = this.OpeningBalance;
                SqlCmd.Parameters.Add("@IsCredit", SqlDbType.Bit).Value = this.IsCredit;
                SqlCmd.Parameters.Add("@CreditLimit", SqlDbType.Money).Value = this.CreditLimit;
                SqlCmd.Parameters.Add("@Description", SqlDbType.VarChar).Value = this.Description;
                SqlCmd.Parameters.Add("@Address", SqlDbType.VarChar).Value = this.Address;
                SqlCmd.Parameters.Add("@linktoCountryMasterId", SqlDbType.SmallInt).Value = this.linktoCountryMasterId;
                SqlCmd.Parameters.Add("@linktoStateMasterId", SqlDbType.SmallInt).Value = this.linktoStateMasterId;
                SqlCmd.Parameters.Add("@linktoCityMasterId", SqlDbType.Int).Value = this.linktoCityMasterId;
                SqlCmd.Parameters.Add("@linktoAreaMasterId", SqlDbType.Int).Value = this.linktoAreaMasterId;
                SqlCmd.Parameters.Add("@Zipcode", SqlDbType.VarChar).Value = this.Zipcode;
                SqlCmd.Parameters.Add("@Phone1", SqlDbType.VarChar).Value = this.Phone1;
                SqlCmd.Parameters.Add("@Phone2", SqlDbType.VarChar).Value = this.Phone2;
                SqlCmd.Parameters.Add("@Fax", SqlDbType.VarChar).Value = this.Fax;
                SqlCmd.Parameters.Add("@Email1", SqlDbType.VarChar).Value = this.Email1;
                SqlCmd.Parameters.Add("@Email2", SqlDbType.VarChar).Value = this.Email2;
                SqlCmd.Parameters.Add("@TIN", SqlDbType.VarChar).Value = this.TIN;
                SqlCmd.Parameters.Add("@CST", SqlDbType.VarChar).Value = this.CST;
                SqlCmd.Parameters.Add("@PAN", SqlDbType.VarChar).Value = this.PAN;
                SqlCmd.Parameters.Add("@TDS", SqlDbType.VarChar).Value = this.TDS;
                SqlCmd.Parameters.Add("@IsDeleted", SqlDbType.Bit).Value = this.IsDeleted;
                SqlCmd.Parameters.Add("@CreateDateTime", SqlDbType.DateTime).Value = this.CreateDateTime;
                SqlCmd.Parameters.Add("@linktoUserMasterIdCreatedBy", SqlDbType.SmallInt).Value = this.linktoUserMasterIdCreatedBy;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                this.AccountMasterId = Convert.ToInt32(SqlCmd.Parameters["@AccountMasterId"].Value);
                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region Update
        public posRecordStatus UpdateAccountMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posAccountMaster_Update", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@AccountMasterId", SqlDbType.Int).Value = this.AccountMasterId;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCmd.Parameters.Add("@linktoAccountCategoryMasterId", SqlDbType.Int).Value = this.linktoAccountCategoryMasterId;
                SqlCmd.Parameters.Add("@AccountName", SqlDbType.VarChar).Value = this.AccountName;
                SqlCmd.Parameters.Add("@AccountNumber", SqlDbType.VarChar).Value = this.AccountNumber;
                SqlCmd.Parameters.Add("@OpeningBalance", SqlDbType.Money).Value = this.OpeningBalance;
                SqlCmd.Parameters.Add("@IsCredit", SqlDbType.Bit).Value = this.IsCredit;
                SqlCmd.Parameters.Add("@CreditLimit", SqlDbType.Money).Value = this.CreditLimit;
                SqlCmd.Parameters.Add("@Description", SqlDbType.VarChar).Value = this.Description;
                SqlCmd.Parameters.Add("@Address", SqlDbType.VarChar).Value = this.Address;
                SqlCmd.Parameters.Add("@linktoCountryMasterId", SqlDbType.SmallInt).Value = this.linktoCountryMasterId;
                SqlCmd.Parameters.Add("@linktoStateMasterId", SqlDbType.SmallInt).Value = this.linktoStateMasterId;
                SqlCmd.Parameters.Add("@linktoCityMasterId", SqlDbType.Int).Value = this.linktoCityMasterId;
                SqlCmd.Parameters.Add("@linktoAreaMasterId", SqlDbType.Int).Value = this.linktoAreaMasterId;
                SqlCmd.Parameters.Add("@Zipcode", SqlDbType.VarChar).Value = this.Zipcode;
                SqlCmd.Parameters.Add("@Phone1", SqlDbType.VarChar).Value = this.Phone1;
                SqlCmd.Parameters.Add("@Phone2", SqlDbType.VarChar).Value = this.Phone2;
                SqlCmd.Parameters.Add("@Fax", SqlDbType.VarChar).Value = this.Fax;
                SqlCmd.Parameters.Add("@Email1", SqlDbType.VarChar).Value = this.Email1;
                SqlCmd.Parameters.Add("@Email2", SqlDbType.VarChar).Value = this.Email2;
                SqlCmd.Parameters.Add("@TIN", SqlDbType.VarChar).Value = this.TIN;
                SqlCmd.Parameters.Add("@CST", SqlDbType.VarChar).Value = this.CST;
                SqlCmd.Parameters.Add("@PAN", SqlDbType.VarChar).Value = this.PAN;
                SqlCmd.Parameters.Add("@TDS", SqlDbType.VarChar).Value = this.TDS;
                SqlCmd.Parameters.Add("@IsDeleted", SqlDbType.Bit).Value = this.IsDeleted;
                SqlCmd.Parameters.Add("@UpdateDateTime", SqlDbType.DateTime).Value = this.UpdateDateTime;
                SqlCmd.Parameters.Add("@linktoUserMasterIdUpdatedBy", SqlDbType.SmallInt).Value = this.linktoUserMasterIdUpdatedBy;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region DeleteAll
        public posRecordStatus DeleteAllAccountMaster(string accountMasterIds)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posAccountMaster_DeleteAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@AccountMasterIds", SqlDbType.VarChar).Value = accountMasterIds;
                SqlCmd.Parameters.Add("@UpdateDateTime", SqlDbType.DateTime).Value = this.UpdateDateTime;
                SqlCmd.Parameters.Add("@linktoUserMasterIdUpdatedBy", SqlDbType.SmallInt).Value = this.linktoUserMasterIdUpdatedBy;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region Select
        public bool SelectAccountMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posAccountMaster_Select", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@AccountMasterId", SqlDbType.Int).Value = this.AccountMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                bool IsSelected = SetClassPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                return IsSelected;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return false;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region SelectAll
        public List<posAccountMasterDAL> SelectAllAccountMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posAccountMaster_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                if (this.linktoAccountCategoryMasterId > 0)
                {
                    SqlCmd.Parameters.Add("@linktoAccountCategoryMasterId", SqlDbType.Int).Value = this.linktoAccountCategoryMasterId;
                }
                SqlCmd.Parameters.Add("@AccountName", SqlDbType.VarChar).Value = this.AccountName;
                SqlCmd.Parameters.Add("@AccountNumber", SqlDbType.VarChar).Value = this.AccountNumber;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<posAccountMasterDAL> lstAccountMasterDAL = SetListPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                return lstAccountMasterDAL;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public static List<posAccountMasterDAL> SelectAllAccountMasterAccountName(short linktoBusinessMasterId)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posAccountMasterAccountName_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = linktoBusinessMasterId;
                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<posAccountMasterDAL> lstAccountMasterDAL = new List<posAccountMasterDAL>();
                posAccountMasterDAL objAccountMasterDAL = null;
                while (SqlRdr.Read())
                {
                    objAccountMasterDAL = new posAccountMasterDAL();
                    objAccountMasterDAL.AccountMasterId = Convert.ToInt32(SqlRdr["AccountMasterId"]);
                    objAccountMasterDAL.AccountName = Convert.ToString(SqlRdr["AccountName"]);
                    lstAccountMasterDAL.Add(objAccountMasterDAL);
                }
                SqlRdr.Close();
                SqlCon.Close();

                return lstAccountMasterDAL;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public List<posAccountMasterDAL> SelectAllAccountMasterAccountNameByAccountCategoryMasterId()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posAccountMasterAccountNameByAccountCategoryMasterId_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;


                SqlCmd.Parameters.Add("@linktoAccountCategoryMasterId", SqlDbType.Int).Value = this.linktoAccountCategoryMasterId;
                SqlCmd.Parameters.Add("@linktobusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<posAccountMasterDAL> lstAccountMasterDAL = new List<posAccountMasterDAL>();
                posAccountMasterDAL objAccountMasterDAL = null;
                while (SqlRdr.Read())
                {
                    objAccountMasterDAL = new posAccountMasterDAL();
                    objAccountMasterDAL.AccountMasterId = Convert.ToInt32(SqlRdr["AccountMasterId"]);
                    objAccountMasterDAL.AccountName = Convert.ToString(SqlRdr["AccountName"]);
                    lstAccountMasterDAL.Add(objAccountMasterDAL);
                }
                SqlRdr.Close();
                SqlCon.Close();

                return lstAccountMasterDAL;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion
    }
}
