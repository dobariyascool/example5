using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace posLibrary
{
    /// <summary>
    /// Class for posCounterItemRateTran
    /// </summary>
    public class posCounterItemRateTranDAL
    {
        #region Properties
        public short CounterItemRateTranId { get; set; }
        public short linktoCounterMasterId { get; set; }
        public short? DineInRateIndex { get; set; }
        public short? TakeAwayRateIndex { get; set; }
        public short? HomeDeliveryRateIndex { get; set; }

        /// Extra
        public string Counter { get; set; }
        public string DineInRateName { get; set; }
        public string TakeAwayRateName { get; set; }
        public string HomeDeliveryRateName { get; set; }
        public short RateIndex { get; set; }
        public string RateName { get; set; }
        #endregion

        #region Class Methods
        private List<posCounterItemRateTranDAL> SetListPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            List<posCounterItemRateTranDAL> lstCounterItemRateTran = new List<posCounterItemRateTranDAL>();
            posCounterItemRateTranDAL objCounterItemRateTran = null;
            while (sqlRdr.Read())
            {
                objCounterItemRateTran = new posCounterItemRateTranDAL();
                objCounterItemRateTran.CounterItemRateTranId = Convert.ToInt16(sqlRdr["CounterItemRateTranId"]);
                objCounterItemRateTran.linktoCounterMasterId = Convert.ToInt16(sqlRdr["linktoCounterMasterId"]);
                if (sqlRdr["DineInRateIndex"] != DBNull.Value)
                {
                    objCounterItemRateTran.DineInRateIndex = Convert.ToInt16(sqlRdr["DineInRateIndex"]);
                }
                if (sqlRdr["TakeAwayRateIndex"] != DBNull.Value)
                {
                    objCounterItemRateTran.TakeAwayRateIndex = Convert.ToInt16(sqlRdr["TakeAwayRateIndex"]);
                }
                if (sqlRdr["HomeDeliveryRateIndex"] != DBNull.Value)
                {
                    objCounterItemRateTran.HomeDeliveryRateIndex = Convert.ToInt16(sqlRdr["HomeDeliveryRateIndex"]);
                }

                /// Extra
                objCounterItemRateTran.Counter = Convert.ToString(sqlRdr["CounterName"]);
                objCounterItemRateTran.DineInRateName = Convert.ToString(sqlRdr["DineInRateName"]);
                objCounterItemRateTran.TakeAwayRateName = Convert.ToString(sqlRdr["TakeAwayRateName"]);
                objCounterItemRateTran.HomeDeliveryRateName = Convert.ToString(sqlRdr["HomeDeliveryRateName"]);

                lstCounterItemRateTran.Add(objCounterItemRateTran);
            }
            return lstCounterItemRateTran;
        }
        #endregion

        #region Insert
        public posRecordStatus InsertCounterItemRateTran()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posCounterItemRateTran_Insert", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@CounterItemRateTranId", SqlDbType.SmallInt).Direction = ParameterDirection.Output;
                SqlCmd.Parameters.Add("@linktoCounterMasterId", SqlDbType.SmallInt).Value = this.linktoCounterMasterId;
                SqlCmd.Parameters.Add("@DineInRateIndex", SqlDbType.SmallInt).Value = this.DineInRateIndex;
                SqlCmd.Parameters.Add("@TakeAwayRateIndex", SqlDbType.SmallInt).Value = this.TakeAwayRateIndex;
                SqlCmd.Parameters.Add("@HomeDeliveryRateIndex", SqlDbType.SmallInt).Value = this.HomeDeliveryRateIndex;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                this.CounterItemRateTranId = Convert.ToInt16(SqlCmd.Parameters["@CounterItemRateTranId"].Value);
                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region Update
        public posRecordStatus UpdateCounterItemRateTran()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posCounterItemRateTran_Update", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@CounterItemRateTranId", SqlDbType.SmallInt).Value = this.CounterItemRateTranId;
                SqlCmd.Parameters.Add("@linktoCounterMasterId", SqlDbType.SmallInt).Value = this.linktoCounterMasterId;
                SqlCmd.Parameters.Add("@DineInRateIndex", SqlDbType.SmallInt).Value = this.DineInRateIndex;
                SqlCmd.Parameters.Add("@TakeAwayRateIndex", SqlDbType.SmallInt).Value = this.TakeAwayRateIndex;
                SqlCmd.Parameters.Add("@HomeDeliveryRateIndex", SqlDbType.SmallInt).Value = this.HomeDeliveryRateIndex;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region Delete
        public posRecordStatus DeleteCounterItemRateTran()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posCounterItemRateTran_Delete", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@CounterItemRateTranId", SqlDbType.SmallInt).Value = this.CounterItemRateTranId;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region Select
        public bool SelectCounterItemRateTranByCounterANDOrderType(short linktoOrderTypeMasterId, short linktoBusinessMasterId)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posCounterItemRateTran_Select", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@linktoCounterMasterId", SqlDbType.Int).Value = this.linktoCounterMasterId;
                SqlCmd.Parameters.Add("@linktoOrderTypeMasterId", SqlDbType.Int).Value = linktoOrderTypeMasterId;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.Int).Value = linktoBusinessMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                bool IsSelected = false;
                if (SqlRdr.Read())
                {
                    if (SqlRdr["ItemRateIndex"] != DBNull.Value)
                    {
                        this.RateIndex = Convert.ToInt16(SqlRdr["ItemRateIndex"]);
                        this.RateName = Convert.ToString(SqlRdr["RateName"]);
                        IsSelected = true;
                    }
                }
                SqlRdr.Close();
                SqlCon.Close();

                return IsSelected;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return false;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region SelectAll
        public List<posCounterItemRateTranDAL> SelectAllCounterItemRateTran(short linktoBusinessMasterId)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posCounterItemRateTran_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = linktoBusinessMasterId;
                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<posCounterItemRateTranDAL> lstCounterItemRateTranDAL = SetListPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                return lstCounterItemRateTranDAL;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion
    }
}
