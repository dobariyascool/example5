﻿using System;
using System.Collections.Generic;

namespace posLibrary
{
    public class posUser
    {
        #region Properties
        public posBusinessMasterDAL BusinessInfo;
        public List<posCounterSettingValueTranDAL> CounterSettings;

        public short UserMasterId
        {
            get;
            set;
        }
        public string Username
        {
            get;
            set;
        }
        public short RoleMasterId
        {
            get;
            set;
        }
        public bool IsAdmin
        {
            get;
            set;
        }
        public short CounterMasterId
        {
            get;
            set;
        }
        public string CounterName
        {
            get;
            set;
        }
        public short BusinessTypeMasterId
        {
            get;
            set;
        }
        public short BusinessMasterId
        {
            get;
            set;
        }
        public DateTime AcYearFromDate
        {
            get;
            set;
        }
        public DateTime AcYearToDate
        {
            get;
            set;
        }
        #endregion

        public posUser(posBusinessMasterDAL objBusiness, short userMasterId, string userName, short roleMasterId, bool isAdmin, short counterMasterId, string counterName, DateTime AcYearFromDate, DateTime AcYearToDate)
        {
            this.BusinessInfo = objBusiness;

            this.UserMasterId = userMasterId;
            this.Username = userName;
            this.BusinessMasterId = objBusiness.BusinessMasterId;
            this.RoleMasterId = roleMasterId;
            this.IsAdmin = isAdmin;
            this.CounterMasterId = counterMasterId;
            this.BusinessTypeMasterId = objBusiness.linktoBusinessTypeMasterId;
            this.CounterName = counterName;
            this.AcYearFromDate = AcYearFromDate;
            this.AcYearToDate = AcYearToDate;
        }
    }
}
