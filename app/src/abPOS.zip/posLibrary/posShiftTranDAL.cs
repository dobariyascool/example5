using System;
using System.Data;
using System.Data.SqlClient;

namespace posLibrary
{
	/// <summary>
	/// Class for posShiftTran
	/// </summary>
	public class posShiftTranDAL
	{
		#region Properties
		public int ShiftTranId { get; set; }
		public int linktoShiftMasterId { get; set; }
		public double DebitAmount { get; set; }
		public double CreditAmount { get; set; }
        public string Remark { get; set; }
		public DateTime CreateDateTime { get; set; }

		/// Extra
        public int linktoUserMasterId { get; set; }
        
		#endregion

		#region Insert
		public posRecordStatus InsertShiftTran()
		{
			SqlConnection SqlCon = null;
			SqlCommand SqlCmd = null;
			try
			{ 
				SqlCon = posObjectFactoryDAL.CreateConnection();
				SqlCmd = new SqlCommand("posShiftTran_Insert", SqlCon);
				SqlCmd.CommandType = CommandType.StoredProcedure;

				SqlCmd.Parameters.Add("@ShiftTranId", SqlDbType.Int).Direction = ParameterDirection.Output; 
				SqlCmd.Parameters.Add("@DebitAmount", SqlDbType.Money).Value = this.DebitAmount;
				SqlCmd.Parameters.Add("@CreditAmount", SqlDbType.Money).Value = this.CreditAmount;
                SqlCmd.Parameters.Add("@Remark", SqlDbType.VarChar).Value = this.Remark; 
				SqlCmd.Parameters.Add("@CreateDateTime", SqlDbType.DateTime).Value = this.CreateDateTime;
                SqlCmd.Parameters.Add("@linktoUserMasterId", SqlDbType.Int).Value = this.linktoUserMasterId;

				SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

				SqlCon.Open();
				SqlCmd.ExecuteNonQuery();
				SqlCon.Close();

				this.ShiftTranId = Convert.ToInt32(SqlCmd.Parameters["@ShiftTranId"].Value);
				posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
				return rs;
			}
			catch (Exception ex)
			{
				posGlobalsDAL.SaveError(ex);
				return posRecordStatus.Error;
			}
			finally
			{
				posObjectFactoryDAL.DisposeCommand(SqlCmd);
				posObjectFactoryDAL.DisposeConnection(SqlCon);
			}
		}
		#endregion
	}
}
