using System;
using System.Data;
using System.Data.SqlClient;
using System.Collections.Generic;

namespace posLibrary
{
	/// <summary>
	/// Class for posWaiterNotificationMaster
	/// </summary>
	public class posWaiterNotificationMasterDAL
	{
		#region Properties
		public long WaiterNotificationMasterId { get; set; }
		public DateTime NotificationDateTime { get; set; }
		public short linktoTableMasterId { get; set; }
		public string Message { get; set; }

		/// Extra
        public string TableName { get; set; }
        public short WaiterNotificationTranId { get; set; }
		#endregion

        #region Class Methods
        private bool SetClassPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            if (sqlRdr.Read())
            {
                this.WaiterNotificationMasterId = Convert.ToInt64(sqlRdr["WaiterNotificationMasterId"]);
                this.Message = Convert.ToString(sqlRdr["Message"]);
                this.linktoTableMasterId = Convert.ToInt16(sqlRdr["linktoTableMasterId"]);
                this.NotificationDateTime = Convert.ToDateTime(sqlRdr["NotificationDateTime"]);

                /// Extra
                this.TableName = Convert.ToString(sqlRdr["TableName"]);
                return true;
            }
            return false;
        }

        private List<posWaiterNotificationMasterDAL> SetListPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            List<posWaiterNotificationMasterDAL> lstWaiterNotificationMaster = new List<posWaiterNotificationMasterDAL>();
            posWaiterNotificationMasterDAL objWaiterNotificationMaster = null;
            while (sqlRdr.Read())
            {
                objWaiterNotificationMaster = new posWaiterNotificationMasterDAL();
                objWaiterNotificationMaster.WaiterNotificationMasterId = Convert.ToInt64(sqlRdr["WaiterNotificationMasterId"]);
                objWaiterNotificationMaster.Message = Convert.ToString(sqlRdr["Message"]);
                objWaiterNotificationMaster.linktoTableMasterId = Convert.ToInt16(sqlRdr["linktoTableMasterId"]);
                objWaiterNotificationMaster.NotificationDateTime = Convert.ToDateTime(sqlRdr["NotificationDateTime"]);

                /// Extra
                objWaiterNotificationMaster.TableName = Convert.ToString(sqlRdr["TableName"]);
                if (sqlRdr["WaiterNotificationTranId"] != DBNull.Value)
                {
                    objWaiterNotificationMaster.WaiterNotificationTranId = Convert.ToInt16(sqlRdr["WaiterNotificationTranId"]);
                }
                lstWaiterNotificationMaster.Add(objWaiterNotificationMaster);
            }
            return lstWaiterNotificationMaster;
        }
        #endregion

        #region Insert
        public posRecordStatus InsertWaiterNotificationMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posWaiterNotificationMaster_Insert", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@WaiterNotificationMasterId", SqlDbType.BigInt).Direction = ParameterDirection.Output;
                SqlCmd.Parameters.Add("@Message", SqlDbType.VarChar).Value = this.Message;
                SqlCmd.Parameters.Add("@linktoTableMasterId", SqlDbType.SmallInt).Value = this.linktoTableMasterId;
                SqlCmd.Parameters.Add("@NotificationDateTime", SqlDbType.DateTime).Value = this.NotificationDateTime;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                this.WaiterNotificationMasterId = Convert.ToInt16(SqlCmd.Parameters["@WaiterNotificationMasterId"].Value);
                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region SelectAll
        public List<posWaiterNotificationMasterDAL> SelectAllWaitingMasterNotification(short linktoWaiterMasterId)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posWaiterNotificationMaster_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@linktoWaiterMasterId", SqlDbType.SmallInt).Value = linktoWaiterMasterId;
                SqlCmd.Parameters.Add("@FromDate", SqlDbType.DateTime).Value = NotificationDateTime;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<posWaiterNotificationMasterDAL> lstWaiterNotificationMasterDAL = SetListPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                return lstWaiterNotificationMasterDAL;
            }
            catch (Exception ex)
            {

                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion
	}
}
