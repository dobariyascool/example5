using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace posLibrary
{
    /// <summary>
    /// Class for labCountryMaster
    /// </summary>
    public class posCountryMasterDAL
    {
        #region Properties
        public short CountryMasterId { get; set; }
        public string CountryName { get; set; }
        public string CountryCode { get; set; }
        public bool IsEnabled { get; set; }
        public DateTime? UpdateDateTime { get; set; }
        public short? linktoUserMasterIdUpdatedBy { get; set; }

        #endregion

        #region Class Methods
        private bool SetClassPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            if (sqlRdr.Read())
            {
                this.CountryMasterId = Convert.ToInt16(sqlRdr["CountryMasterId"]);
                this.CountryName = Convert.ToString(sqlRdr["CountryName"]);
                this.CountryCode = Convert.ToString(sqlRdr["CountryCode"]);
                this.IsEnabled = Convert.ToBoolean(sqlRdr["IsEnabled"]);
                return true;
            }
            return false;
        }

        private List<posCountryMasterDAL> SetListPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            List<posCountryMasterDAL> lstCountryMaster = new List<posCountryMasterDAL>();
            posCountryMasterDAL objCountryMaster = null;
            while (sqlRdr.Read())
            {
                objCountryMaster = new posCountryMasterDAL();
                objCountryMaster.CountryMasterId = Convert.ToInt16(sqlRdr["CountryMasterId"]);
                objCountryMaster.CountryName = Convert.ToString(sqlRdr["CountryName"]);
                objCountryMaster.CountryCode = Convert.ToString(sqlRdr["CountryCode"]);
                objCountryMaster.IsEnabled = Convert.ToBoolean(sqlRdr["IsEnabled"]);
                lstCountryMaster.Add(objCountryMaster);
            }
            return lstCountryMaster;
        }
        #endregion

        #region Update
        public posRecordStatus UpdateCountryMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posCountryMaster_Update", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@CountryMasterId", SqlDbType.SmallInt).Value = this.CountryMasterId;
                SqlCmd.Parameters.Add("@IsEnabled", SqlDbType.Bit).Value = this.IsEnabled;
                SqlCmd.Parameters.Add("@UpdateDateTime", SqlDbType.DateTime).Value = this.UpdateDateTime;
                SqlCmd.Parameters.Add("@linktoUserMasterIdUpdatedBy", SqlDbType.SmallInt).Value = this.linktoUserMasterIdUpdatedBy;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region Select
        public bool SelectCountryMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posCountryMaster_Select", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@CountryMasterId", SqlDbType.SmallInt).Value = this.CountryMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                bool IsSelected = SetClassPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                return IsSelected;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return false;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region SelectAll
        public List<posCountryMasterDAL> SelectAllCountryMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posCountryMaster_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@IsEnabled", SqlDbType.Bit).Value = this.IsEnabled;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<posCountryMasterDAL> lstCountryMasterDAL = SetListPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                return lstCountryMasterDAL;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public static List<posCountryMasterDAL> SelectAllCountryMasterCountryName()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posCountryMasterCountryName_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<posCountryMasterDAL> lstCountryMasterDAL = new List<posCountryMasterDAL>();
                posCountryMasterDAL objCountryMasterDAL = null;
                while (SqlRdr.Read())
                {
                    objCountryMasterDAL = new posCountryMasterDAL();
                    objCountryMasterDAL.CountryMasterId = Convert.ToInt16(SqlRdr["CountryMasterId"]);
                    objCountryMasterDAL.CountryName = Convert.ToString(SqlRdr["CountryName"]);
                    lstCountryMasterDAL.Add(objCountryMasterDAL);
                }
                SqlRdr.Close();
                SqlCon.Close();

                return lstCountryMasterDAL;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion
    }
}
