using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace posLibrary
{
    /// <summary>
    /// Class for posCustomerAddressTran
    /// </summary>
    public class posCustomerAddressTranDAL
    {
        #region Properties
        public int CustomerAddressTranId { get; set; }
        public int linktoCustomerMasterId { get; set; }
        public int TMPCustomerAddressTranId { get; set; }
        public string Address { get; set; }
        public short? linktoCountryMasterId { get; set; }
        public short? linktoStateMasterId { get; set; }
        public int? linktoCityMasterId { get; set; }
        public int? linktoAreaMasterId { get; set; }
        public string ZipCode { get; set; }
        public bool IsPrimary { get; set; }
        public DateTime CreateDateTime { get; set; }
        public short linktoUserMasterIdCreatedBy { get; set; }
        public bool IsDeleted { get; set; }
       

        /// Extra
        public string Customer { get; set; }
        public string Country { get; set; }
        public string State { get; set; }
        public string City { get; set; }
        public string Area { get; set; }
        #endregion

        #region Class Methods
        private List<posCustomerAddressTranDAL> SetListPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            List<posCustomerAddressTranDAL> lstCustomerAddressTran = new List<posCustomerAddressTranDAL>();
            posCustomerAddressTranDAL objCustomerAddressTran = null;
            int TmpCustomerAddressTranId = 1;
            while (sqlRdr.Read())
            {
                objCustomerAddressTran = new posCustomerAddressTranDAL();
                objCustomerAddressTran.CustomerAddressTranId = Convert.ToInt32(sqlRdr["CustomerAddressTranId"]);
                objCustomerAddressTran.linktoCustomerMasterId = Convert.ToInt32(sqlRdr["linktoCustomerMasterId"]);
                objCustomerAddressTran.Address = Convert.ToString(sqlRdr["Address"]);
                if (sqlRdr["linktoCountryMasterId"] != DBNull.Value)
                {
                    objCustomerAddressTran.linktoCountryMasterId = Convert.ToInt16(sqlRdr["linktoCountryMasterId"]);
                }
                if (sqlRdr["linktoStateMasterId"] != DBNull.Value)
                {
                    objCustomerAddressTran.linktoStateMasterId = Convert.ToInt16(sqlRdr["linktoStateMasterId"]);
                }
                if (sqlRdr["linktoCityMasterId"] != DBNull.Value)
                {
                    objCustomerAddressTran.linktoCityMasterId = Convert.ToInt32(sqlRdr["linktoCityMasterId"]);
                }
                if (sqlRdr["linktoAreaMasterId"] != DBNull.Value)
                {
                    objCustomerAddressTran.linktoAreaMasterId = Convert.ToInt32(sqlRdr["linktoAreaMasterId"]);
                }
                objCustomerAddressTran.ZipCode = Convert.ToString(sqlRdr["ZipCode"]);
                objCustomerAddressTran.IsPrimary = Convert.ToBoolean(sqlRdr["IsPrimary"]);
                objCustomerAddressTran.CreateDateTime = Convert.ToDateTime(sqlRdr["CreateDateTime"]);
                objCustomerAddressTran.linktoUserMasterIdCreatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdCreatedBy"]);
                objCustomerAddressTran.IsDeleted = Convert.ToBoolean(sqlRdr["IsDeleted"]);

                /// Extra
                objCustomerAddressTran.Customer = Convert.ToString(sqlRdr["Customer"]);
                objCustomerAddressTran.Country = Convert.ToString(sqlRdr["Country"]);
                objCustomerAddressTran.State = Convert.ToString(sqlRdr["State"]);
                objCustomerAddressTran.City = Convert.ToString(sqlRdr["City"]);
                objCustomerAddressTran.Area = Convert.ToString(sqlRdr["Area"]);

                objCustomerAddressTran.TMPCustomerAddressTranId = TmpCustomerAddressTranId;
                lstCustomerAddressTran.Add(objCustomerAddressTran);
                TmpCustomerAddressTranId++;
            }
            return lstCustomerAddressTran;
        }
        #endregion

        #region Insert
        public posRecordStatus InsertCustomerAddressTran(SqlConnection SqlCon, SqlTransaction sqlTran)
        {
            SqlCommand SqlCmd = null;
            try
            {
                SqlCmd = new SqlCommand("posCustomerAddressTran_Insert", SqlCon, sqlTran);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@CustomerAddressTranId", SqlDbType.Int).Direction = ParameterDirection.Output;
                SqlCmd.Parameters.Add("@linktoCustomerMasterId", SqlDbType.Int).Value = this.linktoCustomerMasterId;
                SqlCmd.Parameters.Add("@Address", SqlDbType.VarChar).Value = this.Address;
                SqlCmd.Parameters.Add("@linktoCountryMasterId", SqlDbType.SmallInt).Value = this.linktoCountryMasterId;
                SqlCmd.Parameters.Add("@linktoStateMasterId", SqlDbType.SmallInt).Value = this.linktoStateMasterId;
                SqlCmd.Parameters.Add("@linktoCityMasterId", SqlDbType.Int).Value = this.linktoCityMasterId;
                SqlCmd.Parameters.Add("@linktoAreaMasterId", SqlDbType.Int).Value = this.linktoAreaMasterId;
                SqlCmd.Parameters.Add("@ZipCode", SqlDbType.VarChar).Value = this.ZipCode;
                SqlCmd.Parameters.Add("@IsPrimary", SqlDbType.Bit).Value = this.IsPrimary;
                SqlCmd.Parameters.Add("@CreateDateTime", SqlDbType.DateTime).Value = this.CreateDateTime;
                SqlCmd.Parameters.Add("@linktoUserMasterIdCreatedBy", SqlDbType.SmallInt).Value = this.linktoUserMasterIdCreatedBy;
                SqlCmd.Parameters.Add("@IsDeleted", SqlDbType.Bit).Value = this.IsDeleted;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCmd.ExecuteNonQuery();

                this.CustomerAddressTranId = Convert.ToInt32(SqlCmd.Parameters["@CustomerAddressTranId"].Value);
                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
            }
        }
        #endregion

        #region Update
        public posRecordStatus UpdateCustomerAddressTran(SqlConnection SqlCon, SqlTransaction sqlTran)
        {
            SqlCommand SqlCmd = null;
            try
            {
                SqlCmd = new SqlCommand("posCustomerAddressTran_Update", SqlCon, sqlTran);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@CustomerAddressTranId", SqlDbType.Int).Value = this.CustomerAddressTranId;
                SqlCmd.Parameters.Add("@linktoCustomerMasterId", SqlDbType.Int).Value = this.linktoCustomerMasterId;
                SqlCmd.Parameters.Add("@Address", SqlDbType.VarChar).Value = this.Address;
                SqlCmd.Parameters.Add("@linktoCountryMasterId", SqlDbType.SmallInt).Value = this.linktoCountryMasterId;
                SqlCmd.Parameters.Add("@linktoStateMasterId", SqlDbType.SmallInt).Value = this.linktoStateMasterId;
                SqlCmd.Parameters.Add("@linktoCityMasterId", SqlDbType.Int).Value = this.linktoCityMasterId;
                SqlCmd.Parameters.Add("@linktoAreaMasterId", SqlDbType.Int).Value = this.linktoAreaMasterId;
                SqlCmd.Parameters.Add("@ZipCode", SqlDbType.VarChar).Value = this.ZipCode;
                SqlCmd.Parameters.Add("@IsPrimary", SqlDbType.Bit).Value = this.IsPrimary;
                SqlCmd.Parameters.Add("@IsDeleted", SqlDbType.Bit).Value = this.IsDeleted;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCmd.ExecuteNonQuery();
                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
            }
        }
        #endregion    
               
        #region SelectAll
        public List<posCustomerAddressTranDAL> SelectAllCustomerAddressTran()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posCustomerAddressTran_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@linktoCustomerMasterId", SqlDbType.Int).Value = this.linktoCustomerMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<posCustomerAddressTranDAL> lstCustomerAddressTranDAL = SetListPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                return lstCustomerAddressTranDAL;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion
    }
}
