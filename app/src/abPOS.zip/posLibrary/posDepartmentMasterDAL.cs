using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;

namespace posLibrary
{
    /// <summary>
    /// Class for posDepartmentMaster
    /// </summary>
    public class posDepartmentMasterDAL
    {
        #region Properties
        public short DepartmentMasterId { get; set; }
        public string ShortName { get; set; }
        public string DepartmentName { get; set; }
        public string Description { get; set; }
        public bool IsEnabled { get; set; }
        public bool IsDeleted { get; set; }
        public DateTime? UpdateDateTime { get; set; }
        public short? linktoUserMasterIdUpdatedBy { get; set; }
        public short linktoBusinessMasterId { get; set; }
        public bool IsSync { get; set; }
        public short? SyncId { get; set; }
        public DateTime? TransactionDateTime { get; set; }
        #endregion

        #region Class Methods
        private bool SetClassPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            if (sqlRdr.Read())
            {
                this.DepartmentMasterId = Convert.ToInt16(sqlRdr["DepartmentMasterId"]);
                this.ShortName = Convert.ToString(sqlRdr["ShortName"]);
                this.DepartmentName = Convert.ToString(sqlRdr["DepartmentName"]);
                this.Description = Convert.ToString(sqlRdr["Description"]);
                if (sqlRdr["IsEnabled"] != DBNull.Value)
                {
                    this.IsEnabled = Convert.ToBoolean(sqlRdr["IsEnabled"]);
                }
                this.IsDeleted = Convert.ToBoolean(sqlRdr["IsDeleted"]);
                if (sqlRdr["UpdateDateTime"] != DBNull.Value)
                {
                    this.UpdateDateTime = Convert.ToDateTime(sqlRdr["UpdateDateTime"]);
                }
                if (sqlRdr["linktoUserMasterIdUpdatedBy"] != DBNull.Value)
                {
                    this.linktoUserMasterIdUpdatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdUpdatedBy"]);
                }
                if (sqlRdr["SyncId"] != DBNull.Value)
                {
                    this.SyncId = Convert.ToInt16(sqlRdr["SyncId"]);
                }
                return true;
            }
            return false;
        }

        private List<posDepartmentMasterDAL> SetListPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            List<posDepartmentMasterDAL> lstDepartmentMaster = new List<posDepartmentMasterDAL>();
            posDepartmentMasterDAL objDepartmentMaster = null;
            while (sqlRdr.Read())
            {
                objDepartmentMaster = new posDepartmentMasterDAL();
                objDepartmentMaster.DepartmentMasterId = Convert.ToInt16(sqlRdr["DepartmentMasterId"]);
                objDepartmentMaster.ShortName = Convert.ToString(sqlRdr["ShortName"]);
                objDepartmentMaster.DepartmentName = Convert.ToString(sqlRdr["DepartmentName"]);
                objDepartmentMaster.Description = Convert.ToString(sqlRdr["Description"]);
                if (sqlRdr["IsEnabled"] != DBNull.Value)
                {
                    objDepartmentMaster.IsEnabled = Convert.ToBoolean(sqlRdr["IsEnabled"]);
                }
                objDepartmentMaster.IsDeleted = Convert.ToBoolean(sqlRdr["IsDeleted"]);
                if (sqlRdr["UpdateDateTime"] != DBNull.Value)
                {
                    objDepartmentMaster.UpdateDateTime = Convert.ToDateTime(sqlRdr["UpdateDateTime"]);
                }
                if (sqlRdr["linktoUserMasterIdUpdatedBy"] != DBNull.Value)
                {
                    objDepartmentMaster.linktoUserMasterIdUpdatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdUpdatedBy"]);
                }
                lstDepartmentMaster.Add(objDepartmentMaster);
            }
            return lstDepartmentMaster;
        }
        #endregion

        #region Insert
        public posRecordStatus InsertDepartmentMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posDepartmentMaster_Insert", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@DepartmentMasterId", SqlDbType.SmallInt).Direction = ParameterDirection.Output;
                SqlCmd.Parameters.Add("@ShortName", SqlDbType.VarChar).Value = this.ShortName;
                SqlCmd.Parameters.Add("@DepartmentName", SqlDbType.VarChar).Value = this.DepartmentName;
                SqlCmd.Parameters.Add("@Description", SqlDbType.VarChar).Value = this.Description;
                SqlCmd.Parameters.Add("@IsEnabled", SqlDbType.Bit).Value = this.IsEnabled;
                SqlCmd.Parameters.Add("@IsDeleted", SqlDbType.Bit).Value = this.IsDeleted;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCmd.Parameters.Add("@IsSync", SqlDbType.Bit).Value = this.IsSync;
                if (SyncId > 0)
                {
                    SqlCmd.Parameters.Add("@SyncId", SqlDbType.SmallInt).Value = this.SyncId;
                }
                SqlCmd.Parameters.Add("@TransactionDateTime", SqlDbType.DateTime).Value = this.TransactionDateTime;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                this.DepartmentMasterId = Convert.ToInt16(SqlCmd.Parameters["@DepartmentMasterId"].Value);
                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public posRecordStatus InsertDepartmentMaster(SqlConnection SqlCon, SqlTransaction SqlTran, List<posDepartmentMasterDAL> lstDepartmentMasterDAL)
        {
            SqlCommand SqlCmd = null;
            try
            {
                posRecordStatus rs = posRecordStatus.Error;
                SqlCmd = new SqlCommand("posDepartmentMaster_Insert", SqlCon, SqlTran);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                foreach (posDepartmentMasterDAL objDepartmentMasterDAL in lstDepartmentMasterDAL)
                {
                    SqlCmd.Parameters.Clear();
                    SqlCmd.Parameters.Add("@DepartmentMasterId", SqlDbType.SmallInt).Direction = ParameterDirection.Output;
                    SqlCmd.Parameters.Add("@ShortName", SqlDbType.VarChar).Value = objDepartmentMasterDAL.ShortName;
                    SqlCmd.Parameters.Add("@DepartmentName", SqlDbType.VarChar).Value = objDepartmentMasterDAL.DepartmentName;
                    SqlCmd.Parameters.Add("@Description", SqlDbType.VarChar).Value = objDepartmentMasterDAL.Description;
                    SqlCmd.Parameters.Add("@IsEnabled", SqlDbType.Bit).Value = objDepartmentMasterDAL.IsEnabled;
                    SqlCmd.Parameters.Add("@IsDeleted", SqlDbType.Bit).Value = objDepartmentMasterDAL.IsDeleted;
                    SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                    SqlCmd.Parameters.Add("@IsSync", SqlDbType.Bit).Value = objDepartmentMasterDAL.IsSync;
                    if (objDepartmentMasterDAL.SyncId > 0)
                    {
                        SqlCmd.Parameters.Add("@SyncId", SqlDbType.SmallInt).Value = objDepartmentMasterDAL.SyncId;
                    }
                    SqlCmd.Parameters.Add("@TransactionDateTime", SqlDbType.DateTime).Value = objDepartmentMasterDAL.TransactionDateTime;
                    SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                    SqlCmd.ExecuteNonQuery();

                    this.DepartmentMasterId = Convert.ToInt16(SqlCmd.Parameters["@DepartmentMasterId"].Value);
                    rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                    if (rs != posRecordStatus.Success)
                    {
                        return rs;
                    }
                }
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
            }
        }
        #endregion

        #region Update
        public posRecordStatus UpdateDepartmentMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posDepartmentMaster_Update", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@DepartmentMasterId", SqlDbType.SmallInt).Value = this.DepartmentMasterId;
                SqlCmd.Parameters.Add("@ShortName", SqlDbType.VarChar).Value = this.ShortName;
                SqlCmd.Parameters.Add("@DepartmentName", SqlDbType.VarChar).Value = this.DepartmentName;
                SqlCmd.Parameters.Add("@Description", SqlDbType.VarChar).Value = this.Description;
                SqlCmd.Parameters.Add("@IsEnabled", SqlDbType.Bit).Value = this.IsEnabled;
                SqlCmd.Parameters.Add("@IsDeleted", SqlDbType.Bit).Value = this.IsDeleted;
                SqlCmd.Parameters.Add("@UpdateDateTime", SqlDbType.DateTime).Value = this.UpdateDateTime;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCmd.Parameters.Add("@linktoUserMasterIdUpdatedBy", SqlDbType.SmallInt).Value = this.linktoUserMasterIdUpdatedBy;
                SqlCmd.Parameters.Add("@IsSync", SqlDbType.Bit).Value = this.IsSync;
                if (SyncId > 0)
                {
                    SqlCmd.Parameters.Add("@SyncId", SqlDbType.SmallInt).Value = this.SyncId;
                }
                SqlCmd.Parameters.Add("@TransactionDateTime", SqlDbType.DateTime).Value = this.TransactionDateTime;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region DeleteAll
        public static posRecordStatus DeleteAllDepartmentMaster(string departmentMasterIds, short linktoUserMasterIdUpdatedBy, DateTime UpdateDateTime)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posDepartmentMaster_DeleteAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@DepartmentMasterIds", SqlDbType.VarChar).Value = departmentMasterIds;
                SqlCmd.Parameters.Add("@UpdateDateTime", SqlDbType.DateTime).Value = UpdateDateTime;
                SqlCmd.Parameters.Add("@linktoUserMasterIdUpdatedBy", SqlDbType.SmallInt).Value = linktoUserMasterIdUpdatedBy;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region Select
        public bool SelectDepartmentMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posDepartmentMaster_Select", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@DepartmentMasterId", SqlDbType.SmallInt).Value = this.DepartmentMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                bool IsSelected = SetClassPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                return IsSelected;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return false;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region SelectAll
        public List<posDepartmentMasterDAL> SelectAllDepartmentMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posDepartmentMaster_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@IsEnabled", SqlDbType.Bit).Value = this.IsEnabled;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<posDepartmentMasterDAL> lstDepartmentMasterDAL = SetListPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                return lstDepartmentMasterDAL;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public static List<posDepartmentMasterDAL> SelectAllDepartmentMasterDepartmentName(short linktoBusinessMasterId)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posDepartmentMasterDepartmentName_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = linktoBusinessMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<posDepartmentMasterDAL> lstDepartmentMasterDAL = new List<posDepartmentMasterDAL>();
                posDepartmentMasterDAL objDepartmentMasterDAL = null;
                while (SqlRdr.Read())
                {
                    objDepartmentMasterDAL = new posDepartmentMasterDAL();
                    objDepartmentMasterDAL.DepartmentMasterId = Convert.ToInt16(SqlRdr["DepartmentMasterId"]);
                    objDepartmentMasterDAL.DepartmentName = Convert.ToString(SqlRdr["DepartmentName"]);
                    lstDepartmentMasterDAL.Add(objDepartmentMasterDAL);
                }
                SqlRdr.Close();
                SqlCon.Close();

                return lstDepartmentMasterDAL;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region Sync
        public bool GetAllDepartmentMaster()
        {
            poswServiceSyncReference.ServiceClient objServiceSync = null;
            List<poswServiceSyncReference.DepartmentMaster> lstDepartmentMaster = null;
            List<poswServiceSyncReference.poswResponseDAL> lstResponse = null;
            try
            {
                objServiceSync = new poswServiceSyncReference.ServiceClient();
                lstDepartmentMaster = objServiceSync.SelectAllDepartmentMaster(this.linktoBusinessMasterId).ToList();
                if (lstDepartmentMaster == null)
                {
                    return false;
                }
                if (lstDepartmentMaster.Count == 0)
                {
                    return true;
                }

                lstResponse = UpdateDepartmentMasterSyncId(lstDepartmentMaster);
                if (lstResponse == null)
                {
                    return false;
                }
                objServiceSync = new poswServiceSyncReference.ServiceClient();
                return objServiceSync.UpdateDepartmentMasterResponse(lstResponse.ToArray());
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return false;
            }
            finally
            {
                objServiceSync = null;
                lstDepartmentMaster = null;
                lstResponse = null;
            }
        }

        public List<poswServiceSyncReference.poswResponseDAL> UpdateDepartmentMasterSyncId(List<poswServiceSyncReference.DepartmentMaster> lstDepartmentMaster)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            List<poswServiceSyncReference.poswResponseDAL> lstResponse = null;
            poswServiceSyncReference.poswResponseDAL objResponse = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posDepartmentMasterSyncId_Update", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCon.Open();

                lstResponse = new List<poswServiceSyncReference.poswResponseDAL>();

                foreach (poswServiceSyncReference.DepartmentMaster obj in lstDepartmentMaster)
                {
                    SqlCmd.Parameters.Clear();
                    SqlCmd.Parameters.Add("@DepartmentMasterId", SqlDbType.SmallInt).Value = obj.DepartmentMasterId;
                    SqlCmd.Parameters.Add("@ShortName", SqlDbType.VarChar).Value = obj.ShortName;
                    SqlCmd.Parameters.Add("@DepartmentName", SqlDbType.VarChar).Value = obj.DepartmentName;
                    SqlCmd.Parameters.Add("@Description", SqlDbType.VarChar).Value = obj.Description;
                    SqlCmd.Parameters.Add("@IsEnabled", SqlDbType.Bit).Value = obj.IsEnabled;
                    SqlCmd.Parameters.Add("@IsDeleted", SqlDbType.Bit).Value = obj.IsDeleted;
                    SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = obj.linktoBusinessMasterId;
                    SqlCmd.Parameters.Add("@CurrentDateTime", SqlDbType.DateTime).Value = posGlobalsDAL.GetCurrentDateTime();
                    SqlCmd.Parameters.Add("@TransactionDateTime", SqlDbType.DateTime).Value = obj.TransactionDateTime;

                    SqlRdr = SqlCmd.ExecuteReader();

                    if (SqlRdr.Read())
                    {
                        objResponse = new poswServiceSyncReference.poswResponseDAL();
                        objResponse.Id = Convert.ToInt16(SqlRdr["posw_DepartmentMasterId"]);
                        objResponse.SyncId = Convert.ToInt16(SqlRdr["pos_DepartmentMasterId"]);
                        lstResponse.Add(objResponse);
                    }

                    SqlRdr.Close();
                }

                SqlCon.Close();

                return lstResponse;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public bool SendAllDepartmentMaster()
        {
            poswServiceSyncReference.ServiceClient objServiceSync = null;
            List<poswServiceSyncReference.poswDepartmentMasterDAL> lstDepartmentMaster = null;
            List<poswServiceSyncReference.poswResponseDAL> lstResponse = null;
            try
            {
                posDepartmentMasterDAL objDepartmentMasterDAL = new posDepartmentMasterDAL();
                objDepartmentMasterDAL.linktoBusinessMasterId = this.linktoBusinessMasterId;
                lstDepartmentMaster = objDepartmentMasterDAL.SelectAllDepartmentMasterForSync();
                if (lstDepartmentMaster == null)
                {
                    return false;
                }
                if (lstDepartmentMaster.Count == 0)
                {
                    return true;
                }

                objServiceSync = new poswServiceSyncReference.ServiceClient();
                lstResponse = objServiceSync.SyncAllDepartmentMaster(lstDepartmentMaster.ToArray()).ToList();
                if (lstResponse == null)
                {
                    return false;
                }
                if (UpdateDepartmentMasterResponse(lstResponse) == false)
                {
                    return false;
                }
                return true;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return false;
            }
            finally
            {
                objServiceSync = null;
                lstDepartmentMaster = null;
                lstResponse = null;
            }
        }

        public List<poswServiceSyncReference.poswDepartmentMasterDAL> SelectAllDepartmentMasterForSync()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            List<poswServiceSyncReference.poswDepartmentMasterDAL> lstDepartmentMaster = null;
            poswServiceSyncReference.poswDepartmentMasterDAL objDepartmentMaster = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posDepartmentMasterForSync_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();

                lstDepartmentMaster = new List<poswServiceSyncReference.poswDepartmentMasterDAL>();

                while (SqlRdr.Read())
                {
                    objDepartmentMaster = new poswServiceSyncReference.poswDepartmentMasterDAL();
                    objDepartmentMaster.DepartmentMasterId = Convert.ToInt16(SqlRdr["DepartmentMasterId"]);
                    objDepartmentMaster.ShortName = Convert.ToString(SqlRdr["ShortName"]);
                    objDepartmentMaster.DepartmentName = Convert.ToString(SqlRdr["DepartmentName"]);
                    objDepartmentMaster.Description = Convert.ToString(SqlRdr["Description"]);
                    if (SqlRdr["IsEnabled"] != DBNull.Value)
                    {
                        objDepartmentMaster.IsEnabled = Convert.ToBoolean(SqlRdr["IsEnabled"]);
                    }
                    objDepartmentMaster.IsDeleted = Convert.ToBoolean(SqlRdr["IsDeleted"]);
                    objDepartmentMaster.linktoBusinessMasterId = Convert.ToInt16(SqlRdr["linktoBusinessMasterId"]);
                    if (SqlRdr["IsSync"] != DBNull.Value)
                    {
                        objDepartmentMaster.IsSync = Convert.ToBoolean(SqlRdr["IsSync"]);
                    }
                    if (SqlRdr["SyncId"] != DBNull.Value)
                    {
                        objDepartmentMaster.SyncId = Convert.ToInt16(SqlRdr["SyncId"]);
                    }
                    if (SqlRdr["TransactionDateTime"] != DBNull.Value)
                    {
                        objDepartmentMaster.TransactionDateTime = Convert.ToDateTime(SqlRdr["TransactionDateTime"]);
                    }
                    lstDepartmentMaster.Add(objDepartmentMaster);
                }

                SqlRdr.Close();
                SqlCon.Close();

                return lstDepartmentMaster;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        private bool UpdateDepartmentMasterResponse(List<poswServiceSyncReference.poswResponseDAL> lstResponse)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posDepartmentMasterSync_Update", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;
                SqlCon.Open();

                foreach (poswServiceSyncReference.poswResponseDAL obj in lstResponse)
                {
                    SqlCmd.Parameters.Clear();
                    SqlCmd.Parameters.Add("@DepartmentMasterId", SqlDbType.SmallInt).Value = obj.Id;
                    SqlCmd.Parameters.Add("@SyncId", SqlDbType.SmallInt).Value = obj.SyncId;

                    SqlCmd.ExecuteNonQuery();
                }

                SqlCon.Close();
                return true;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return false;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion
    }
}
