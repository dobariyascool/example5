using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace posLibrary
{
    /// <summary>
    /// Class for labRoleMaster
    /// </summary>
    public class posRoleMasterDAL
    {
        #region Properties
        public short RoleMasterId { get; set; }
        public string Role { get; set; }
        public string Description { get; set; }
        public bool IsEnabled { get; set; }
        public short linktoBusinessMasterId { get; set; }
        public bool IsDeleted { get; set; }
        public DateTime CreateDateTime { get; set; }
        public short linktoUserMasterIdCreatedBy { get; set; }
        public DateTime? UpdateDateTime { get; set; }
        public short? linktoUserMasterIdUpdatedBy { get; set; }

        #endregion

        #region Class Methods
        private bool SetClassPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            if (sqlRdr.Read())
            {
                this.RoleMasterId = Convert.ToInt16(sqlRdr["RoleMasterId"]);
                this.Role = Convert.ToString(sqlRdr["Role"]);
                this.Description = Convert.ToString(sqlRdr["Description"]);
                this.IsEnabled = Convert.ToBoolean(sqlRdr["IsEnabled"]);
                return true;
            }
            return false;
        }

        private List<posRoleMasterDAL> SetListPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            List<posRoleMasterDAL> lstRoleMaster = new List<posRoleMasterDAL>();
            posRoleMasterDAL objRoleMaster = null;
            while (sqlRdr.Read())
            {
                objRoleMaster = new posRoleMasterDAL();
                objRoleMaster.RoleMasterId = Convert.ToInt16(sqlRdr["RoleMasterId"]);
                objRoleMaster.Role = Convert.ToString(sqlRdr["Role"]);
                objRoleMaster.Description = Convert.ToString(sqlRdr["Description"]);
                objRoleMaster.IsEnabled = Convert.ToBoolean(sqlRdr["IsEnabled"]);
                objRoleMaster.linktoBusinessMasterId = Convert.ToInt16(sqlRdr["linktoBusinessMasterId"]);
                lstRoleMaster.Add(objRoleMaster);
            }
            return lstRoleMaster;
        }
        #endregion

        #region Insert
        public posRecordStatus InsertRoleMaster(List<posUserRightsMasterDAL> lstUserRightsMasterDAL = null)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlTransaction SqlTran = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCon.Open();
                SqlTran = SqlCon.BeginTransaction();
                SqlCmd = new SqlCommand("posRoleMaster_Insert", SqlCon, SqlTran);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@RoleMasterId", SqlDbType.SmallInt).Direction = ParameterDirection.Output;
                SqlCmd.Parameters.Add("@Role", SqlDbType.VarChar).Value = this.Role;
                SqlCmd.Parameters.Add("@Description", SqlDbType.VarChar).Value = this.Description;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCmd.Parameters.Add("@IsEnabled", SqlDbType.Bit).Value = this.IsEnabled;
                SqlCmd.Parameters.Add("@IsDeleted", SqlDbType.Bit).Value = this.IsDeleted;
                SqlCmd.Parameters.Add("@CreateDateTime", SqlDbType.DateTime).Value = this.CreateDateTime;
                SqlCmd.Parameters.Add("@linktoUserMasterIdCreatedBy", SqlDbType.SmallInt).Value = this.linktoUserMasterIdCreatedBy;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCmd.ExecuteNonQuery();

                this.RoleMasterId = Convert.ToInt16(SqlCmd.Parameters["@RoleMasterId"].Value);
                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;

                if (rs == posRecordStatus.Success)
                {
                    string ids = string.Empty;
                    foreach (posUserRightsMasterDAL item in lstUserRightsMasterDAL.FindAll(f => f.IsUpdated == true))
                    {
                        ids += item.UserRightsMasterId.ToString() + ",";
                    }

                    if (!string.IsNullOrEmpty(ids))
                    {
                        ids = ids.Remove(ids.Length - 1);

                        posUserRightsTranDAL objUserRightsTranDAL = new posUserRightsTranDAL();
                        objUserRightsTranDAL.linktoRoleMasterId = this.RoleMasterId;

                        if (objUserRightsTranDAL.InsertAllUserRightsTran(ids, SqlCon, SqlTran) == posRecordStatus.Error)
                        {
                            SqlTran.Rollback();
                            return posRecordStatus.Error;
                        }
                    }
                    SqlTran.Commit();
                }
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region Update
        public posRecordStatus UpdateRoleMaster(List<posUserRightsMasterDAL> lstUserRightsMasterDAL = null)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlTransaction SqlTran = null;

            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCon.Open();
                SqlTran = SqlCon.BeginTransaction();
                SqlCmd = new SqlCommand("posRoleMaster_Update", SqlCon, SqlTran);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@RoleMasterId", SqlDbType.SmallInt).Value = this.RoleMasterId;
                SqlCmd.Parameters.Add("@Role", SqlDbType.VarChar).Value = this.Role;
                SqlCmd.Parameters.Add("@Description", SqlDbType.VarChar).Value = this.Description;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCmd.Parameters.Add("@IsEnabled", SqlDbType.Bit).Value = this.IsEnabled;
                SqlCmd.Parameters.Add("@IsDeleted", SqlDbType.Bit).Value = this.IsDeleted;
                SqlCmd.Parameters.Add("@UpdateDateTime", SqlDbType.DateTime).Value = this.UpdateDateTime;
                SqlCmd.Parameters.Add("@linktoUserMasterIdUpdatedBy", SqlDbType.SmallInt).Value = this.linktoUserMasterIdUpdatedBy;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCmd.ExecuteNonQuery();

                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;

                if (rs == posRecordStatus.Success)
                {
                    string ids = string.Empty;

                    foreach (posUserRightsMasterDAL item in lstUserRightsMasterDAL.FindAll(f => f.IsUpdated == true))
                    {
                        ids += item.UserRightsMasterId.ToString() + ",";
                    }

                    if (!string.IsNullOrEmpty(ids))
                    {
                        ids = ids.Remove(ids.Length - 1);

                        posUserRightsTranDAL objUserRightsTranDAL = new posUserRightsTranDAL();
                        objUserRightsTranDAL.linktoRoleMasterId = this.RoleMasterId;

                        if (objUserRightsTranDAL.UpdateAllUserRightsTran(ids, SqlCon, SqlTran) == posRecordStatus.Error)
                        {
                            SqlTran.Rollback();
                            return posRecordStatus.Error;
                        }
                    }
                    SqlTran.Commit();
                }

                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region DeleteAll
        public static posRecordStatus DeleteAllRoleMaster(string RoleMasterIds, short linktoUserMasterIdUpdatedBy, DateTime UpdateDateTime)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posRoleMaster_DeleteAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@RoleMasterIds", SqlDbType.VarChar).Value = RoleMasterIds;
                SqlCmd.Parameters.Add("@UpdateDateTime", SqlDbType.DateTime).Value = UpdateDateTime;
                SqlCmd.Parameters.Add("@linktoUserMasterIdUpdatedBy", SqlDbType.SmallInt).Value = linktoUserMasterIdUpdatedBy;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region Select
        public bool SelectRoleMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posRoleMaster_Select", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@RoleMasterId", SqlDbType.SmallInt).Value = this.RoleMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                bool IsSelected = SetClassPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                return IsSelected;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return false;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

        #region SelectAll
        public List<posRoleMasterDAL> SelectAllRoleMaster()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posRoleMaster_SelectAll", SqlCon);
                SqlCmd.Parameters.Add("@IsEnabled", SqlDbType.Bit).Value = this.IsEnabled;
                SqlCmd.Parameters.Add("@linktoBusinessMasterId", SqlDbType.SmallInt).Value = this.linktoBusinessMasterId;
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<posRoleMasterDAL> lstRoleMasterDAL = SetListPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                return lstRoleMasterDAL;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }

        public static List<posRoleMasterDAL> SelectAllRoleMasterRole(short linktoBusinessMasterId)
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posRoleMasterRole_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;
                SqlCmd.Parameters.Add("linktoBusinessMasterId", SqlDbType.SmallInt).Value = linktoBusinessMasterId;
                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<posRoleMasterDAL> lstRoleMasterDAL = new List<posRoleMasterDAL>();
                posRoleMasterDAL objRoleMasterDAL = null;
                while (SqlRdr.Read())
                {
                    objRoleMasterDAL = new posRoleMasterDAL();
                    objRoleMasterDAL.RoleMasterId = Convert.ToInt16(SqlRdr["RoleMasterId"]);
                    objRoleMasterDAL.Role = Convert.ToString(SqlRdr["Role"]);
                    lstRoleMasterDAL.Add(objRoleMasterDAL);
                }
                SqlRdr.Close();
                SqlCon.Close();

                return lstRoleMasterDAL;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion
    }
}
