using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace posLibrary
{
	/// <summary>
	/// Class for posItemUsageTran
	/// </summary>
	public class posItemUsageTranDAL
	{
		#region Properties
		public int ItemUsageTranId { get; set; }
		public int linktoItemMasterId { get; set; }
		public int linktoItemMasterIdUse { get; set; }
		public short linktoUnitMasterIdUse { get; set; }
		public double Quantity { get; set; }

		/// Extra
		public string Item { get; set; }
		public string ItemUse { get; set; }
		public string UnitUse { get; set; }
		#endregion

		#region Class Methods
		private bool SetClassPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
		{
			if (sqlRdr.Read())
			{
				this.ItemUsageTranId = Convert.ToInt32(sqlRdr["ItemUsageTranId"]);
				this.linktoItemMasterId = Convert.ToInt32(sqlRdr["linktoItemMasterId"]);
				this.linktoItemMasterIdUse = Convert.ToInt32(sqlRdr["linktoItemMasterIdUse"]);
				this.linktoUnitMasterIdUse = Convert.ToInt16(sqlRdr["linktoUnitMasterIdUse"]);
				this.Quantity = Convert.ToDouble(sqlRdr["Quantity"]);

				/// Extra
				this.Item = Convert.ToString(sqlRdr["Item"]);
				this.ItemUse = Convert.ToString(sqlRdr["ItemUse"]);
				this.UnitUse = Convert.ToString(sqlRdr["UnitUse"]);
				return true;
			}
			return false;
		}

		private List<posItemUsageTranDAL> SetListPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
		{
			List<posItemUsageTranDAL> lstItemUsageTran = new List<posItemUsageTranDAL>();
			posItemUsageTranDAL objItemUsageTran = null;
			while (sqlRdr.Read())
			{
				objItemUsageTran = new posItemUsageTranDAL();
				objItemUsageTran.ItemUsageTranId = Convert.ToInt32(sqlRdr["ItemUsageTranId"]);
				objItemUsageTran.linktoItemMasterId = Convert.ToInt32(sqlRdr["linktoItemMasterId"]);
				objItemUsageTran.linktoItemMasterIdUse = Convert.ToInt32(sqlRdr["linktoItemMasterIdUse"]);
				objItemUsageTran.linktoUnitMasterIdUse = Convert.ToInt16(sqlRdr["linktoUnitMasterIdUse"]);
				objItemUsageTran.Quantity = Convert.ToDouble(sqlRdr["Quantity"]);

				/// Extra
				objItemUsageTran.Item = Convert.ToString(sqlRdr["Item"]);
				objItemUsageTran.ItemUse = Convert.ToString(sqlRdr["ItemUse"]);
				objItemUsageTran.UnitUse = Convert.ToString(sqlRdr["UnitUse"]);
				lstItemUsageTran.Add(objItemUsageTran);
			}
			return lstItemUsageTran;
		}
		#endregion

		#region Insert
		public posRecordStatus InsertItemUsageTran()
		{
			SqlConnection SqlCon = null;
			SqlCommand SqlCmd = null;
			try
			{
				SqlCon = posObjectFactoryDAL.CreateConnection();
				SqlCmd = new SqlCommand("posItemUsageTran_Insert", SqlCon);
				SqlCmd.CommandType = CommandType.StoredProcedure;

				SqlCmd.Parameters.Add("@ItemUsageTranId", SqlDbType.Int).Direction = ParameterDirection.Output;
				SqlCmd.Parameters.Add("@linktoItemMasterId", SqlDbType.Int).Value = this.linktoItemMasterId;
				SqlCmd.Parameters.Add("@linktoItemMasterIdUse", SqlDbType.Int).Value = this.linktoItemMasterIdUse;
				SqlCmd.Parameters.Add("@linktoUnitMasterIdUse", SqlDbType.SmallInt).Value = this.linktoUnitMasterIdUse;
				SqlCmd.Parameters.Add("@Quantity", SqlDbType.Decimal).Value = this.Quantity;
				SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

				SqlCon.Open();
				SqlCmd.ExecuteNonQuery();
				SqlCon.Close();

				this.ItemUsageTranId = Convert.ToInt32(SqlCmd.Parameters["@ItemUsageTranId"].Value);
				posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
				return rs;
			}
			catch (Exception ex)
			{
				posGlobalsDAL.SaveError(ex);
				return posRecordStatus.Error;
			}
			finally
			{
				posObjectFactoryDAL.DisposeCommand(SqlCmd);
				posObjectFactoryDAL.DisposeConnection(SqlCon);
			}
		}
		#endregion

		#region Update
		public posRecordStatus UpdateItemUsageTran()
		{
			SqlConnection SqlCon = null;
			SqlCommand SqlCmd = null;
			try
			{
				SqlCon = posObjectFactoryDAL.CreateConnection();
				SqlCmd = new SqlCommand("posItemUsageTran_Update", SqlCon);
				SqlCmd.CommandType = CommandType.StoredProcedure;

				SqlCmd.Parameters.Add("@ItemUsageTranId", SqlDbType.Int).Value = this.ItemUsageTranId;
				SqlCmd.Parameters.Add("@linktoItemMasterId", SqlDbType.Int).Value = this.linktoItemMasterId;
				SqlCmd.Parameters.Add("@linktoItemMasterIdUse", SqlDbType.Int).Value = this.linktoItemMasterIdUse;
				SqlCmd.Parameters.Add("@linktoUnitMasterIdUse", SqlDbType.SmallInt).Value = this.linktoUnitMasterIdUse;
				SqlCmd.Parameters.Add("@Quantity", SqlDbType.Decimal).Value = this.Quantity;
				SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

				SqlCon.Open();
				SqlCmd.ExecuteNonQuery();
				SqlCon.Close();

				posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
				return rs;
			}
			catch (Exception ex)
			{
				posGlobalsDAL.SaveError(ex);
				return posRecordStatus.Error;
			}
			finally
			{
				posObjectFactoryDAL.DisposeCommand(SqlCmd);
				posObjectFactoryDAL.DisposeConnection(SqlCon);
			}
		}
		#endregion

        #region Delete
        public posRecordStatus DeleteItemUsageTran()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posItemUsageTran_Delete", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@ItemUsageTranId", SqlDbType.Int).Value = this.ItemUsageTranId;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();

                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion

	    #region Select
		public bool SelectItemUsageTran()
		{
			SqlConnection SqlCon = null;
			SqlCommand SqlCmd = null;
			SqlDataReader SqlRdr = null;
			try
			{
				SqlCon = posObjectFactoryDAL.CreateConnection();
				SqlCmd = new SqlCommand("posItemUsageTran_Select", SqlCon);
				SqlCmd.CommandType = CommandType.StoredProcedure;

				SqlCmd.Parameters.Add("@ItemUsageTranId", SqlDbType.Int).Value = this.ItemUsageTranId;

				SqlCon.Open();
				SqlRdr = SqlCmd.ExecuteReader();
				bool IsSelected = SetClassPropertiesFromSqlDataReader(SqlRdr);
				SqlRdr.Close();
				SqlCon.Close();

				return IsSelected;
			}
			catch (Exception ex)
			{
				posGlobalsDAL.SaveError(ex);
				return false;
			}
			finally
			{
				posObjectFactoryDAL.DisposeDataReader(SqlRdr);
				posObjectFactoryDAL.DisposeCommand(SqlCmd);
				posObjectFactoryDAL.DisposeConnection(SqlCon);
			}
		}
		#endregion

		#region SelectAll
		public List<posItemUsageTranDAL> SelectAllItemUsageTran()
		{
			SqlConnection SqlCon = null;
			SqlCommand SqlCmd = null;
			SqlDataReader SqlRdr = null;
			try
			{
				SqlCon = posObjectFactoryDAL.CreateConnection();
				SqlCmd = new SqlCommand("posItemUsageTran_SelectAll", SqlCon);
				SqlCmd.CommandType = CommandType.StoredProcedure;
                SqlCmd.Parameters.Add("@linktoItemMasterId", SqlDbType.Int).Value = this.linktoItemMasterId;

				SqlCon.Open();
				SqlRdr = SqlCmd.ExecuteReader();
				List<posItemUsageTranDAL> lstItemUsageTranDAL = SetListPropertiesFromSqlDataReader(SqlRdr);
				SqlRdr.Close();
				SqlCon.Close();

				return lstItemUsageTranDAL;
			}
			catch (Exception ex)
			{
				posGlobalsDAL.SaveError(ex);
				return null;
			}
			finally
			{
				posObjectFactoryDAL.DisposeDataReader(SqlRdr);
				posObjectFactoryDAL.DisposeCommand(SqlCmd);
				posObjectFactoryDAL.DisposeConnection(SqlCon);
			}
		}
		#endregion
	}
}
