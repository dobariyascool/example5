using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace posLibrary
{
    /// <summary>
    /// Class for posBookingPaymentTran
    /// </summary>
    public class posBookingPaymentTranDAL
    {
        #region Properties
        public long BookingPaymentTranId { get; set; }
        public int linktoBookingMasterId { get; set; }
        public short linktoPaymentTypeMasterId { get; set; }
        public int? linktoCustomerMasterId { get; set; }
        public DateTime PaymentDateTime { get; set; }
        public double AmountPaid { get; set; }
        public string Remark { get; set; }
        public bool IsDeleted { get; set; }
        public DateTime CreateDateTime { get; set; }
        public short linktoUserMasterIdCreatedBy { get; set; }
        public DateTime? UpdateDateTime { get; set; }
        public short? linktoUserMasterIdUpdatedBy { get; set; }

        /// Extra
        public int Booking { get; set; }
        public string PaymentType { get; set; }
        public string Customer { get; set; }

        public int BookingIdTemp { get; set; }
        #endregion

        #region Class Methods
        private bool SetClassPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            if (sqlRdr.Read())
            {
                this.BookingPaymentTranId = Convert.ToInt64(sqlRdr["BookingPaymentTranId"]);
                this.linktoBookingMasterId = Convert.ToInt32(sqlRdr["linktoBookingMasterId"]);
                this.linktoPaymentTypeMasterId = Convert.ToInt16(sqlRdr["linktoPaymentTypeMasterId"]);
                if (sqlRdr["linktoCustomerMasterId"] != DBNull.Value)
                {
                    this.linktoCustomerMasterId = Convert.ToInt32(sqlRdr["linktoCustomerMasterId"]);
                }
                this.PaymentDateTime = Convert.ToDateTime(sqlRdr["PaymentDateTime"]);
                this.AmountPaid = Convert.ToDouble(sqlRdr["AmountPaid"]);
                this.Remark = Convert.ToString(sqlRdr["Remark"]);
                this.IsDeleted = Convert.ToBoolean(sqlRdr["IsDeleted"]);
                this.CreateDateTime = Convert.ToDateTime(sqlRdr["CreateDateTime"]);
                this.linktoUserMasterIdCreatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdCreatedBy"]);
                if (sqlRdr["UpdateDateTime"] != DBNull.Value)
                {
                    this.UpdateDateTime = Convert.ToDateTime(sqlRdr["UpdateDateTime"]);
                }
                if (sqlRdr["linktoUserMasterIdUpdatedBy"] != DBNull.Value)
                {
                    this.linktoUserMasterIdUpdatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdUpdatedBy"]);
                }

                /// Extra
                this.Booking = Convert.ToInt32(sqlRdr["Booking"]);
                this.PaymentType = Convert.ToString(sqlRdr["PaymentType"]);
                this.Customer = Convert.ToString(sqlRdr["Customer"]);
                return true;
            }
            return false;
        }

        private List<posBookingPaymentTranDAL> SetListPropertiesFromSqlDataReader(SqlDataReader sqlRdr)
        {
            List<posBookingPaymentTranDAL> lstBookingPaymentTran = new List<posBookingPaymentTranDAL>();
            posBookingPaymentTranDAL objBookingPaymentTran = null;
            int Count = 1;
            while (sqlRdr.Read())
            {
                objBookingPaymentTran = new posBookingPaymentTranDAL();
                objBookingPaymentTran.BookingPaymentTranId = Convert.ToInt64(sqlRdr["BookingPaymentTranId"]);
                objBookingPaymentTran.linktoBookingMasterId = Convert.ToInt32(sqlRdr["linktoBookingMasterId"]);
                objBookingPaymentTran.linktoPaymentTypeMasterId = Convert.ToInt16(sqlRdr["linktoPaymentTypeMasterId"]);
                if (sqlRdr["linktoCustomerMasterId"] != DBNull.Value)
                {
                    objBookingPaymentTran.linktoCustomerMasterId = Convert.ToInt32(sqlRdr["linktoCustomerMasterId"]);
                }
                objBookingPaymentTran.PaymentDateTime = Convert.ToDateTime(sqlRdr["PaymentDateTime"]);
                objBookingPaymentTran.AmountPaid = Convert.ToDouble(sqlRdr["AmountPaid"]);
                objBookingPaymentTran.Remark = Convert.ToString(sqlRdr["Remark"]);
                objBookingPaymentTran.IsDeleted = Convert.ToBoolean(sqlRdr["IsDeleted"]);
                objBookingPaymentTran.CreateDateTime = Convert.ToDateTime(sqlRdr["CreateDateTime"]);
                objBookingPaymentTran.linktoUserMasterIdCreatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdCreatedBy"]);
                if (sqlRdr["UpdateDateTime"] != DBNull.Value)
                {
                    objBookingPaymentTran.UpdateDateTime = Convert.ToDateTime(sqlRdr["UpdateDateTime"]);
                }
                if (sqlRdr["linktoUserMasterIdUpdatedBy"] != DBNull.Value)
                {
                    objBookingPaymentTran.linktoUserMasterIdUpdatedBy = Convert.ToInt16(sqlRdr["linktoUserMasterIdUpdatedBy"]);
                }

                /// Extra                
                objBookingPaymentTran.PaymentType = Convert.ToString(sqlRdr["PaymentType"]);
                //objBookingPaymentTran.Customer = Convert.ToString(sqlRdr["Customer"]);
                objBookingPaymentTran.BookingIdTemp = Count;

                lstBookingPaymentTran.Add(objBookingPaymentTran);
                Count++;
            }
            return lstBookingPaymentTran;
        }
        #endregion

        #region Insert
        public posRecordStatus InsertBookingPaymentTran(SqlConnection SqlCon, SqlTransaction sqlTran)
        {
            SqlCommand SqlCmd = null;
            try
            {
                SqlCmd = new SqlCommand("posBookingPaymentTran_Insert", SqlCon, sqlTran);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@BookingPaymentTranId", SqlDbType.BigInt).Direction = ParameterDirection.Output;
                SqlCmd.Parameters.Add("@linktoBookingMasterId", SqlDbType.Int).Value = this.linktoBookingMasterId;
                SqlCmd.Parameters.Add("@linktoPaymentTypeMasterId", SqlDbType.SmallInt).Value = this.linktoPaymentTypeMasterId;
                SqlCmd.Parameters.Add("@linktoCustomerMasterId", SqlDbType.Int).Value = this.linktoCustomerMasterId;
                SqlCmd.Parameters.Add("@PaymentDateTime", SqlDbType.DateTime).Value = this.PaymentDateTime;
                SqlCmd.Parameters.Add("@AmountPaid", SqlDbType.Money).Value = this.AmountPaid;
                SqlCmd.Parameters.Add("@Remark", SqlDbType.VarChar).Value = this.Remark;
                SqlCmd.Parameters.Add("@IsDeleted", SqlDbType.Bit).Value = this.IsDeleted;
                SqlCmd.Parameters.Add("@CreateDateTime", SqlDbType.DateTime).Value = this.CreateDateTime;
                SqlCmd.Parameters.Add("@linktoUserMasterIdCreatedBy", SqlDbType.SmallInt).Value = this.linktoUserMasterIdCreatedBy;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;

                SqlCmd.ExecuteNonQuery();

                this.BookingPaymentTranId = Convert.ToInt64(SqlCmd.Parameters["@BookingPaymentTranId"].Value);
                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
            }
        }
        #endregion

        #region Update
        public posRecordStatus UpdateBookingPaymentTran(SqlConnection SqlCon, SqlTransaction sqlTran)
        {

            SqlCommand SqlCmd = null;
            try
            {

                SqlCmd = new SqlCommand("posBookingPaymentTran_Update", SqlCon, sqlTran);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@BookingPaymentTranId", SqlDbType.BigInt).Value = this.BookingPaymentTranId;
                SqlCmd.Parameters.Add("@linktoBookingMasterId", SqlDbType.Int).Value = this.linktoBookingMasterId;
                SqlCmd.Parameters.Add("@linktoPaymentTypeMasterId", SqlDbType.SmallInt).Value = this.linktoPaymentTypeMasterId;
                SqlCmd.Parameters.Add("@linktoCustomerMasterId", SqlDbType.Int).Value = this.linktoCustomerMasterId;
                SqlCmd.Parameters.Add("@PaymentDateTime", SqlDbType.DateTime).Value = this.PaymentDateTime;
                SqlCmd.Parameters.Add("@AmountPaid", SqlDbType.Money).Value = this.AmountPaid;
                SqlCmd.Parameters.Add("@Remark", SqlDbType.VarChar).Value = this.Remark;
                SqlCmd.Parameters.Add("@IsDeleted", SqlDbType.Bit).Value = this.IsDeleted;
                SqlCmd.Parameters.Add("@UpdateDateTime", SqlDbType.DateTime).Value = this.UpdateDateTime;
                SqlCmd.Parameters.Add("@linktoUserMasterIdUpdatedBy", SqlDbType.SmallInt).Value = this.linktoUserMasterIdUpdatedBy;
                SqlCmd.Parameters.Add("@Status", SqlDbType.SmallInt).Direction = ParameterDirection.Output;


                SqlCmd.ExecuteNonQuery();


                posRecordStatus rs = (posRecordStatus)(short)SqlCmd.Parameters["@Status"].Value;
                return rs;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return posRecordStatus.Error;
            }
            finally
            {
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
            }
        }
        #endregion

        #region SelectAll
        public List<posBookingPaymentTranDAL> SelectAllBookingPaymentTran()
        {
            SqlConnection SqlCon = null;
            SqlCommand SqlCmd = null;
            SqlDataReader SqlRdr = null;
            try
            {
                SqlCon = posObjectFactoryDAL.CreateConnection();
                SqlCmd = new SqlCommand("posBookingPaymentTran_SelectAll", SqlCon);
                SqlCmd.CommandType = CommandType.StoredProcedure;

                SqlCmd.Parameters.Add("@linktoBookingMasterId", SqlDbType.SmallInt).Value = this.linktoBookingMasterId;

                SqlCon.Open();
                SqlRdr = SqlCmd.ExecuteReader();
                List<posBookingPaymentTranDAL> lstBookingPaymentTranDAL = SetListPropertiesFromSqlDataReader(SqlRdr);
                SqlRdr.Close();
                SqlCon.Close();

                return lstBookingPaymentTranDAL;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                posObjectFactoryDAL.DisposeDataReader(SqlRdr);
                posObjectFactoryDAL.DisposeCommand(SqlCmd);
                posObjectFactoryDAL.DisposeConnection(SqlCon);
            }
        }
        #endregion
    }
}
