﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Text;
using posLibrary;
using posService.Model;

namespace posService
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "Service1" in code, svc and config file together.
    public class Service : IService
    {
        public Service()
        {
            posGlobalsDAL.ServerName = "10.0.0.100";
            posGlobalsDAL.InstanceName = "";
            posGlobalsDAL.UserName = "ab";
            posGlobalsDAL.Password = "ab";
        }

        #region Insert
        public ErrorStatus InsertWaitingMaster(WaitingMaster waitingMaster)
        {
            ErrorStatus objErrorStatus = new ErrorStatus();
            try
            {
                posWaitingMasterDAL objWaitingMasterDAL = new posWaitingMasterDAL();

                objWaitingMasterDAL.WaitingMasterId = waitingMaster.WaitingMasterId;
                objWaitingMasterDAL.PersonName = waitingMaster.PersonName;
                objWaitingMasterDAL.PersonMobile = waitingMaster.PersonMobile;
                objWaitingMasterDAL.NoOfPersons = waitingMaster.NoOfPersons;
                objWaitingMasterDAL.linktoWaitingStatusMasterId = waitingMaster.linktoWaitingStatusMasterId;
                objWaitingMasterDAL.CreateDateTime = DateTime.ParseExact(waitingMaster.CreateDateTime, "s", System.Globalization.DateTimeFormatInfo.InvariantInfo);
                objWaitingMasterDAL.linktoUserMasterIdCreatedBy = waitingMaster.linktoUserMasterIdCreatedBy;
                objWaitingMasterDAL.linktoBusinessMasterId = waitingMaster.linktoBusinessMasterId;

                posRecordStatus rs = objWaitingMasterDAL.InsertWaitingMaster();
                if (rs == posRecordStatus.Success)
                {
                    objErrorStatus.ErrorCode = (int)rs;
                    return objErrorStatus;
                }
                else
                {
                    objErrorStatus.ErrorCode = (int)rs;
                    return objErrorStatus;
                }
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                objErrorStatus.ErrorCode = (int)posRecordStatus.Error;
                return objErrorStatus;
            }
        }

        public ErrorStatus InsertCustomerMaster(CustomerMaster customerMaster)
        {
            ErrorStatus objErrorStatus = new ErrorStatus();
            try
            {
                posCustomerMasterDAL objCustomerMasterDAL = new posCustomerMasterDAL();
                posCustomerAddressTranDAL objCustomerAddressTranDAL = new posCustomerAddressTranDAL();

                objCustomerMasterDAL.CustomerName = customerMaster.CustomerName;
                objCustomerMasterDAL.ShortName = customerMaster.ShortName;
                objCustomerMasterDAL.Email1 = customerMaster.Email1;
                objCustomerMasterDAL.Password = customerMaster.Password;
                objCustomerMasterDAL.Phone1 = customerMaster.Phone1;
                if (customerMaster.BirthDate != null)
                {
                    objCustomerMasterDAL.Birthdate = DateTime.ParseExact(customerMaster.BirthDate, "yyyy-MM-dd", System.Globalization.DateTimeFormatInfo.InvariantInfo);
                }
                objCustomerMasterDAL.Gender = customerMaster.Gender;
                objCustomerMasterDAL.CreateDateTime = DateTime.ParseExact(customerMaster.CreateDateTime, "s", System.Globalization.DateTimeFormatInfo.InvariantInfo);
                objCustomerMasterDAL.LastLoginDateTime = DateTime.ParseExact(customerMaster.LastLoginDateTime, "s", System.Globalization.DateTimeFormatInfo.InvariantInfo);
                objCustomerMasterDAL.CustomerType = customerMaster.CustomerType;
                objCustomerMasterDAL.linktoSourceMasterId = customerMaster.linktoSourceMasterId;
                objCustomerMasterDAL.linktoBusinessMasterId = customerMaster.linktoBusinessMasterId;
                objCustomerMasterDAL.IsFavourite = false;
                objCustomerMasterDAL.IsCredit = false;
                objCustomerMasterDAL.IsEnabled = customerMaster.IsEnabled;

                objCustomerAddressTranDAL.linktoCityMasterId = customerMaster.linktoCityMasterId;
                objCustomerAddressTranDAL.linktoAreaMasterId = customerMaster.linktoAreaMasterId;
                objCustomerAddressTranDAL.CreateDateTime = DateTime.ParseExact(customerMaster.CreateDateTime, "s", System.Globalization.DateTimeFormatInfo.InvariantInfo);

                posRecordStatus rs = objCustomerMasterDAL.InsertCustomerMaster(objCustomerAddressTranDAL);
                if (rs == posRecordStatus.Success)
                {
                    objErrorStatus.ErrorNumber = objCustomerMasterDAL.CustomerMasterId;
                }
                else if (rs == posRecordStatus.RecordAlreadyExist)
                {
                    objErrorStatus.ErrorNumber = (long)posRecordStatus.RecordAlreadyExist;
                    objErrorStatus.ErrorCode = (int)rs;
                }
                else
                {
                    objErrorStatus.ErrorNumber = (long)posRecordStatus.Error;
                    objErrorStatus.ErrorCode = (int)rs;
                }
                return objErrorStatus;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                objErrorStatus.ErrorCode = (int)posRecordStatus.Error;
                return objErrorStatus;
            }
        }

        public ErrorStatus InsertFeedbackMaster(FeedbackMaster feedbackMaster, List<FeedbackTran> lstFeedbackTran)
        {
            ErrorStatus objErrorStatus = new ErrorStatus();
            List<posFeedbackTranDAL> lstFeedbackTranDAL = new List<posFeedbackTranDAL>();
            try
            {
                posFeedbackMasterDAL objFeedbackMasterDAL = new posFeedbackMasterDAL();

                objFeedbackMasterDAL.Name = feedbackMaster.Name;
                objFeedbackMasterDAL.Email = feedbackMaster.Email;
                objFeedbackMasterDAL.Phone = feedbackMaster.Phone;
                objFeedbackMasterDAL.Feedback = feedbackMaster.Feedback;
                objFeedbackMasterDAL.FeedbackDateTime = DateTime.ParseExact(feedbackMaster.FeedbackDateTime, "s", System.Globalization.DateTimeFormatInfo.InvariantInfo);
                objFeedbackMasterDAL.linktoFeedbackTypeMasterId = feedbackMaster.linktoFeedbackTypeMasterId;
                objFeedbackMasterDAL.linktoCustomerMasterId = feedbackMaster.linktoCustomerMasterId;
                objFeedbackMasterDAL.linktoBusinessMasterId = feedbackMaster.linktoBusinessMasterId;

                if (lstFeedbackTran != null && lstFeedbackTran.Count > 0)
                {
                    foreach (FeedbackTran objFeedbackTran in lstFeedbackTran)
                    {
                        posFeedbackTranDAL objFeedbackTranDAL = new posFeedbackTranDAL();
                        objFeedbackTranDAL.linktoFeedbackQuestionMasterId = objFeedbackTran.linktoFeedbackQuestionMasterId;
                        objFeedbackTranDAL.linktoFeedbackAnswerMasterId = objFeedbackTran.linktoFeedbackAnswerMasterId;
                        objFeedbackTranDAL.Answer = objFeedbackTran.Answer;
                        lstFeedbackTranDAL.Add(objFeedbackTranDAL);
                    }
                }

                objFeedbackMasterDAL.lstFeedbackTranDAL = lstFeedbackTranDAL;
                posRecordStatus rs = objFeedbackMasterDAL.InsertFeedbackMaster();
                objErrorStatus.ErrorCode = (int)rs;
                return objErrorStatus;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                objErrorStatus.ErrorCode = (int)posRecordStatus.Error;
                return objErrorStatus;
            }
        }

        public ErrorStatus InsertOrderMaster(OrderMaster orderMaster, List<ItemMaster> lstOrderItemTran, List<TaxMaster> lstTaxMaster)
        {
            ErrorStatus objErrorStatus = new ErrorStatus();
            List<posOrderItemDAL> lstOrderItemTranDAL = new List<posOrderItemDAL>();
            List<posOrderItemDAL> lstOrderItemModifierTranDAL = new List<posOrderItemDAL>();
            //List<posOrderTaxTranDAL> lstOrderTaxTranDAL = new List<posOrderTaxTranDAL>();
            int cnt = 0;
            try
            {
                posOrderMasterDAL objOrderMasterDAL = new posOrderMasterDAL();
                //    objOrderMasterDAL.OrderNumber = orderMaster.OrderNumber;
                objOrderMasterDAL.OrderDateTime = DateTime.ParseExact(orderMaster.OrderDateTime, "s", System.Globalization.DateTimeFormatInfo.InvariantInfo);
                objOrderMasterDAL.linktoCounterMasterId = orderMaster.linktoCounterMasterId;
                objOrderMasterDAL.linktoTableMasterIds = orderMaster.linktoTableMasterIds;
                objOrderMasterDAL.linktoWaiterMasterId = orderMaster.linktoWaiterMasterId;
                objOrderMasterDAL.linktoCustomerMasterId = orderMaster.linktoCustomerMasterId;
                objOrderMasterDAL.linktoOrderTypeMasterId = orderMaster.linktoOrderTypeMasterId;
                objOrderMasterDAL.linktoOrderStatusMasterId = orderMaster.linktoOrderStatusMasterId;
                objOrderMasterDAL.linktoBusinessMasterId = orderMaster.linktoBusinessMasterId;
                objOrderMasterDAL.TotalAmount = orderMaster.TotalAmount;
                objOrderMasterDAL.TotalTax = orderMaster.TotalTax;
                objOrderMasterDAL.DiscountAmount = orderMaster.Discount;
                objOrderMasterDAL.ExtraAmount = orderMaster.ExtraAmount;
                objOrderMasterDAL.TotalItemPoint = orderMaster.TotalItemPoint;
                objOrderMasterDAL.TotalDeductedPoint = orderMaster.TotalDeductedPoint;
                objOrderMasterDAL.Remark = orderMaster.Remark;
                objOrderMasterDAL.NetAmount = orderMaster.NetAmount;
                if (orderMaster.RateIndex != 0)
                {
                    objOrderMasterDAL.RateIndex = orderMaster.RateIndex;
                }
                objOrderMasterDAL.CreateDateTime = DateTime.ParseExact(orderMaster.CreateDateTime, "s", System.Globalization.DateTimeFormatInfo.InvariantInfo);
                objOrderMasterDAL.linktoUserMasterIdCreatedBy = orderMaster.linktoUserMasterIdCreatedBy;
                objOrderMasterDAL.PrintCount = orderMaster.PrintCount;
                objOrderMasterDAL.linktoSourceMasterId = orderMaster.linktoSourceMasterId;


                foreach (ItemMaster objItemMaster in lstOrderItemTran)
                {

                    posOrderItemDAL objOrderItemDAL = new posOrderItemDAL();
                    objOrderItemDAL.ItemMasterId = objItemMaster.ItemMasterId;
                    objOrderItemDAL.Quantity = objItemMaster.Quantity;
                    objOrderItemDAL.Remark = objItemMaster.Remark;
                    objOrderItemDAL.SaleRate = objItemMaster.ActualSellPrice;
                    //if (objOrderMasterDAL.RateIndex == 1)
                    //{
                    //    objOrderItemDAL.Rate1 = objItemMaster.ActualSellPrice;
                    //}
                    //else if (objOrderMasterDAL.RateIndex == 2)
                    //{
                    //    objOrderItemDAL.Rate2 = objItemMaster.ActualSellPrice;
                    //}
                    //else if (objOrderMasterDAL.RateIndex == 3)
                    //{
                    //    objOrderItemDAL.Rate3 = objItemMaster.ActualSellPrice;
                    //}
                    //else if (objOrderMasterDAL.RateIndex == 4)
                    //{
                    //    objOrderItemDAL.Rate4 = objItemMaster.ActualSellPrice;
                    //}
                    //else if (objOrderMasterDAL.RateIndex == 5)
                    //{
                    //    objOrderItemDAL.Rate5 = objItemMaster.ActualSellPrice;
                    //}
                    //else
                    //{
                    //    objOrderItemDAL.MRP = objItemMaster.ActualSellPrice;
                    //}
                    objOrderItemDAL.TaxAmt1 = objItemMaster.Tax1;
                    objOrderItemDAL.TaxAmt2 = objItemMaster.Tax2;
                    objOrderItemDAL.TaxAmt3 = objItemMaster.Tax3;
                    objOrderItemDAL.TaxAmt4 = objItemMaster.Tax4;
                    objOrderItemDAL.TaxAmt5 = objItemMaster.Tax5;
                    objOrderItemDAL.IsRateTaxInclusive = objItemMaster.IsRateTaxInclusive;

                    if (objItemMaster.lstOrderItemModifierTran != null)
                    {
                        objOrderItemDAL.OrderId = cnt + 1;
                        foreach (ItemMaster objModifierItemMaster in objItemMaster.lstOrderItemModifierTran)
                        {
                            posOrderItemDAL objModifierItemMasterDAL = new posOrderItemDAL();
                            objModifierItemMasterDAL.ItemMasterId = objOrderItemDAL.ItemMasterId;
                            objModifierItemMasterDAL.linktoItemMasterIdModifier = Convert.ToInt16(objModifierItemMaster.ItemModifierMasterIds);
                            objModifierItemMasterDAL.OrderId = objOrderItemDAL.OrderId;
                            objModifierItemMasterDAL.MRP = objModifierItemMaster.ActualSellPrice;
                            lstOrderItemModifierTranDAL.Add(objModifierItemMasterDAL);
                        }
                    }
                    lstOrderItemTranDAL.Add(objOrderItemDAL);
                    cnt = cnt + 1;
                }

                //foreach (TaxMaster objTaxMaster in lstTaxMaster)
                //{
                //    posOrderTaxTranDAL objOrderTaxTranDAL = new posOrderTaxTranDAL();
                //    objOrderTaxTranDAL.linktoTaxMasterId = objTaxMaster.TaxMasterId;
                //    objOrderTaxTranDAL.TaxName = objTaxMaster.TaxName;
                //    objOrderTaxTranDAL.TaxRate = objTaxMaster.TaxRate;
                //    lstOrderTaxTranDAL.Add(objOrderTaxTranDAL);
                //}

                posRecordStatus rs = objOrderMasterDAL.InsertOrderMaster(lstOrderItemTranDAL, lstOrderItemModifierTranDAL);//, lstOrderTaxTranDAL);
                //posRecordStatus rs = posRecordStatus.Error;
                objErrorStatus.ErrorCode = (int)rs;
                objErrorStatus.ErrorNumber = objOrderMasterDAL.OrderMasterId;
                return objErrorStatus;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                objErrorStatus.ErrorCode = (int)posRecordStatus.Error;
                return objErrorStatus;
            }
        }

        public ErrorStatus InsertSalesMaster(SalesMaster salesMaster, List<ItemMaster> lstSalesItemTran, List<TaxMaster> lstTaxMaster, List<OrderMaster> lstOrderMaster)
        {
            ErrorStatus objErrorStatus = new ErrorStatus();
            List<posItemMasterDAL> lstSalesItemTranDAL = new List<posItemMasterDAL>();
            List<posItemMasterDAL> lstSalesItemModifierTranDAL = new List<posItemMasterDAL>();
            List<posSalesTaxTranDAL> lstSalesTaxTranDAL = new List<posSalesTaxTranDAL>();
            StringBuilder sb;
            int cnt = 0;
            try
            {
                posSalesMasterDAL objSalesMasterDAL = new posSalesMasterDAL();
                // objSalesMasterDAL.BillNumber = salesMaster.BillNumber;
                objSalesMasterDAL.BillDateTime = DateTime.ParseExact(salesMaster.BillDateTime, "s", System.Globalization.DateTimeFormatInfo.InvariantInfo);
                objSalesMasterDAL.linktoCounterMasterId = salesMaster.linktoCounterMasterId;
                objSalesMasterDAL.linktoTableMasterIds = salesMaster.linktoTableMasterIds;
                objSalesMasterDAL.linktoWaiterMasterId = salesMaster.linktoWaiterMasterId;
                objSalesMasterDAL.linktoCustomerMasterId = salesMaster.linktoCustomerMasterId;
                objSalesMasterDAL.linktoOrderStatusMasterId = salesMaster.linktoOrderStatusMasterId;
                objSalesMasterDAL.linktoOrderTypeMasterId = salesMaster.linktoOrderTypeMasterId;
                objSalesMasterDAL.linktoBusinessMasterId = salesMaster.linktoBusinessMasterId;
                objSalesMasterDAL.TotalAmount = salesMaster.TotalAmount;
                objSalesMasterDAL.TotalTax = salesMaster.TotalTax;
                objSalesMasterDAL.Rounding = salesMaster.Rounding;
                objSalesMasterDAL.DiscountPercentage = salesMaster.DiscountPercentage;
                objSalesMasterDAL.DiscountAmount = salesMaster.DiscountAmount;
                objSalesMasterDAL.ExtraAmount = salesMaster.ExtraAmount;
                objSalesMasterDAL.TotalItemDiscount = salesMaster.TotalItemDiscount;
                objSalesMasterDAL.TotalItemTax = salesMaster.TotalItemTax;
                objSalesMasterDAL.NetAmount = salesMaster.NetAmount;
                objSalesMasterDAL.PaidAmount = salesMaster.PaidAmount;
                objSalesMasterDAL.BalanceAmount = salesMaster.BalanceAmount;
                objSalesMasterDAL.IsComplimentary = false;
                objSalesMasterDAL.TotalItemPoint = salesMaster.TotalItemPoint;
                objSalesMasterDAL.TotalDeductedPoint = salesMaster.TotalDeductedPoint;
                objSalesMasterDAL.linktoBusinessMasterId = salesMaster.linktoBusinessMasterId;
                objSalesMasterDAL.CreateDateTime = DateTime.ParseExact(salesMaster.CreateDateTime, "s", System.Globalization.DateTimeFormatInfo.InvariantInfo);
                objSalesMasterDAL.linktoUserMasterIdCreatedBy = salesMaster.linktoUserMasterIdCreatedBy;
                objSalesMasterDAL.RateIndex = salesMaster.RateIndex;
                objSalesMasterDAL.linktoOfferMasterId = salesMaster.linktoOfferMasterId;
                objSalesMasterDAL.linktoSourceMasterId = salesMaster.linktoSourceMasterId;
                objSalesMasterDAL.OfferCode = salesMaster.OfferCode;


                foreach (ItemMaster objItemMaster in lstSalesItemTran)
                {
                    posItemMasterDAL objItemMasterDAL = new posItemMasterDAL();
                    objItemMasterDAL.ItemMasterId = objItemMaster.ItemMasterId;
                    objItemMasterDAL.linktoUnitMasterId = objItemMaster.linktoUnitMasterId;
                    objItemMasterDAL.ItemCode = objItemMaster.ItemCode;
                    objItemMasterDAL.ItemName = objItemMaster.ItemCode;
                    objItemMasterDAL.Quantity = objItemMaster.Quantity;
                    objItemMasterDAL.ActualSaleRate = objItemMaster.ActualSellPrice;
                    objItemMasterDAL.Remark = objItemMaster.Remark;
                    DateTime dt = DateTime.ParseExact(salesMaster.CreateDateTime, "s", System.Globalization.DateTimeFormatInfo.InvariantInfo);
                    objItemMasterDAL.CreateDateTime = dt;
                    objItemMasterDAL.linktoUserMasterIdCreatedBy = objItemMasterDAL.linktoUserMasterIdCreatedBy;

                    if (objItemMaster.lstOrderItemModifierTran != null)
                    {
                        //sb = new StringBuilder();
                        //objItemMaster.lstOrderItemModifierTran.ForEach(i => sb.Append(i.ItemModifierMasterIds + ","));
                        //objItemMasterDAL.ItemModifierMasterIds = sb.ToString();
                        objItemMasterDAL.KOTItemId = cnt + 1;
                        foreach (ItemMaster objModifierItemMaster in objItemMaster.lstOrderItemModifierTran)
                        {
                            posItemMasterDAL objModifierItemMasterDAL = new posItemMasterDAL();
                            objModifierItemMasterDAL.ItemMasterId = objItemMasterDAL.ItemMasterId;
                            objModifierItemMasterDAL.ItemModifierMasterIds = objModifierItemMaster.ItemModifierMasterIds;
                            objModifierItemMasterDAL.KOTItemId = objItemMasterDAL.KOTItemId;
                            objModifierItemMasterDAL.ActualSaleRate = objModifierItemMaster.ActualSellPrice;
                            lstSalesItemModifierTranDAL.Add(objModifierItemMasterDAL);
                        }
                    }
                    lstSalesItemTranDAL.Add(objItemMasterDAL);
                    cnt = cnt + 1;
                }

                foreach (TaxMaster objTaxMaster in lstTaxMaster)
                {
                    posSalesTaxTranDAL objSalesTaxTranDAL = new posSalesTaxTranDAL();
                    objSalesTaxTranDAL.linktoTaxMasterId = objTaxMaster.TaxMasterId;
                    objSalesTaxTranDAL.TaxName = objTaxMaster.TaxName;
                    objSalesTaxTranDAL.TaxRate = objTaxMaster.TaxRate;
                    lstSalesTaxTranDAL.Add(objSalesTaxTranDAL);
                }

                objSalesMasterDAL.lstSaleItemTranDAL = lstSalesItemTranDAL;
                objSalesMasterDAL.lstSaleItemModifierTranDAL = lstSalesItemModifierTranDAL;
                objSalesMasterDAL.lstSalesTaxTran = lstSalesTaxTranDAL;
                sb = new StringBuilder();
                lstOrderMaster.ForEach(i => sb.Append(i.OrderMasterId + ","));
                objSalesMasterDAL.OrderMasterIds = sb.ToString();


                posRecordStatus rs = objSalesMasterDAL.InsertSalesMaster();
                objErrorStatus.ErrorCode = (int)rs;
                return objErrorStatus;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                objErrorStatus.ErrorCode = (int)posRecordStatus.Error;
                return objErrorStatus;
            }
        }

        public ErrorStatus InsertWaiterNotification(WaiterNotificationMaster waiterNotificationMaster)
        {
            ErrorStatus objErrorStatus = new ErrorStatus();
            try
            {
                posWaiterNotificationMasterDAL objWaiterNotificationMasterDAL = new posWaiterNotificationMasterDAL();

                objWaiterNotificationMasterDAL.WaiterNotificationMasterId = waiterNotificationMaster.WaiterNotificationMasterId;
                objWaiterNotificationMasterDAL.Message = waiterNotificationMaster.Message;
                objWaiterNotificationMasterDAL.linktoTableMasterId = waiterNotificationMaster.linktoTableMasterId;
                objWaiterNotificationMasterDAL.NotificationDateTime = DateTime.ParseExact(waiterNotificationMaster.NotificationDateTime, "s", System.Globalization.DateTimeFormatInfo.InvariantInfo);

                posRecordStatus rs = objWaiterNotificationMasterDAL.InsertWaiterNotificationMaster();
                objErrorStatus.ErrorCode = (int)rs;
                return objErrorStatus;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                objErrorStatus.ErrorCode = (int)posRecordStatus.Error;
                return objErrorStatus;
            }
        }

        public ErrorStatus InsertWaiterNotificationTran(WaiterNotificationTran waiterNotificationTran)
        {
            ErrorStatus objErrorStatus = new ErrorStatus();
            try
            {
                posWaiterNotificationTranDAL objWaiterNotificationTranDAL = new posWaiterNotificationTranDAL();

                objWaiterNotificationTranDAL.WaiterNotificationTranId = waiterNotificationTran.WaiterNotificationTranId;
                objWaiterNotificationTranDAL.linktoWaiterNotificationMasterId = waiterNotificationTran.linktoWaiterNotificationMasterId;
                objWaiterNotificationTranDAL.linktoUserMasterId = waiterNotificationTran.linktoUserMasterId;

                posRecordStatus rs = objWaiterNotificationTranDAL.InsertWaiterNotificationTran();
                objErrorStatus.ErrorCode = (int)rs;
                return objErrorStatus;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                objErrorStatus.ErrorCode = (int)posRecordStatus.Error;
                return objErrorStatus;
            }
        }

        #endregion

        #region Update
        public ErrorStatus UpdateWaitingStatus(WaitingMaster waitingMaster)
        {
            ErrorStatus objErrorStatus = new ErrorStatus();
            try
            {
                posWaitingMasterDAL objWaitingMaster = new posWaitingMasterDAL();
                objWaitingMaster.WaitingMasterId = waitingMaster.WaitingMasterId;
                objWaitingMaster.linktoUserMasterIdUpdatedBy = waitingMaster.linktoUserMasterIdUpdatedBy;
                TimeZoneInfo tzIndia = TimeZoneInfo.FindSystemTimeZoneById("India Standard Time");
                objWaitingMaster.UpdateDateTime = TimeZoneInfo.ConvertTimeFromUtc(DateTime.Now.ToUniversalTime(), tzIndia);
                objWaitingMaster.linktoWaitingStatusMasterId = waitingMaster.linktoWaitingStatusMasterId;
                if (waitingMaster.linktoTableMasterId != 0)
                {
                    objWaitingMaster.linktoTableMasterId = waitingMaster.linktoTableMasterId;
                }
                posRecordStatus rs = objWaitingMaster.UpdateWaitingStatus();
                objErrorStatus.ErrorCode = (int)rs;
                return objErrorStatus;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                objErrorStatus.ErrorCode = (int)posRecordStatus.Error;
                return objErrorStatus;
            }
        }

        public ErrorStatus UpdateTableStatus(TableMaster tableMaster)
        {
            ErrorStatus objErrorStatus = new ErrorStatus();
            try
            {
                posTableMasterDAL objTableMaster = new posTableMasterDAL();
                objTableMaster.TableMasterId = tableMaster.TableMasterId;
                objTableMaster.linktoTableStatusMasterId = tableMaster.linktoTableStatusMasterId;
                objTableMaster.StatusUpdateDateTime = DateTime.ParseExact(tableMaster.StatusUpdateDateTime, "s", System.Globalization.DateTimeFormatInfo.InvariantInfo); ;
                posRecordStatus rs = objTableMaster.UpdateTableMasterTableStatus();
                objErrorStatus.ErrorCode = (int)rs;
                return objErrorStatus;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                objErrorStatus.ErrorCode = (int)posRecordStatus.Error;
                return objErrorStatus;
            }
        }


        public ErrorStatus UpdateCustomerMaster(CustomerMaster customerMaster)
        {
            ErrorStatus objErrorStatus = new ErrorStatus();
            try
            {
                posCustomerMasterDAL objCustomerMasterDAL = new posCustomerMasterDAL();
                objCustomerMasterDAL.CustomerMasterId = customerMaster.CustomerMasterId;
                objCustomerMasterDAL.Phone1 = customerMaster.Phone1;
                objCustomerMasterDAL.CustomerName = customerMaster.CustomerName;
                objCustomerMasterDAL.Gender = customerMaster.Gender;
                if (customerMaster.BirthDate != null)
                {
                    objCustomerMasterDAL.Birthdate = DateTime.ParseExact(customerMaster.BirthDate, "yyyy-MM-dd", System.Globalization.DateTimeFormatInfo.InvariantInfo);
                }
                objCustomerMasterDAL.UpdateDateTime = DateTime.ParseExact(customerMaster.UpdateDateTime, "s", System.Globalization.DateTimeFormatInfo.InvariantInfo);
                objCustomerMasterDAL.linktoUserMasterIdUpdatedBy = customerMaster.linktoUserMasterIdUpdatedBy;
                posRecordStatus rs = objCustomerMasterDAL.UpdateCustomerMasterbyId();
                if (rs == posRecordStatus.Success)
                {
                    objErrorStatus.ErrorCode = (int)rs;
                    return objErrorStatus;
                }
                else
                {
                    objErrorStatus.ErrorCode = (int)rs;
                    return objErrorStatus;
                }

            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                objErrorStatus.ErrorCode = (int)posRecordStatus.Error;
                return objErrorStatus;
            }
        }

        public ErrorStatus UpdateCustomerMasterPassword(CustomerMaster customerMaster)
        {
            ErrorStatus objErrorStatus = new ErrorStatus();
            try
            {
                posCustomerMasterDAL objCustomerMasterDAL = new posCustomerMasterDAL();
                objCustomerMasterDAL.CustomerMasterId = customerMaster.CustomerMasterId;
                objCustomerMasterDAL.Password = customerMaster.Password;
                objCustomerMasterDAL.UpdateDateTime = DateTime.ParseExact(customerMaster.UpdateDateTime, "s", System.Globalization.DateTimeFormatInfo.InvariantInfo);
                objCustomerMasterDAL.linktoUserMasterIdUpdatedBy = customerMaster.linktoUserMasterIdUpdatedBy;
                posRecordStatus rs = objCustomerMasterDAL.UpdateCustomerMasterPassword(customerMaster.OldPassword);
                if (rs == posRecordStatus.Success)
                {
                    objErrorStatus.ErrorCode = (int)rs;
                    return objErrorStatus;
                }
                else
                {
                    objErrorStatus.ErrorCode = (int)rs;
                    return objErrorStatus;
                }

            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                objErrorStatus.ErrorCode = (int)posRecordStatus.Error;
                return objErrorStatus;
            }
        }

        public ErrorStatus UpdateOrderItemTranStatus(OrderItemTran orderItemTran)
        {
            ErrorStatus objErrorStatus = new ErrorStatus();
            try
            {
                posOrderItemTranDAL objOrderItemTranDAL = new posOrderItemTranDAL();
                objOrderItemTranDAL.OrderItemTranIds = orderItemTran.OrderItemTranIds;
                objOrderItemTranDAL.linktoOrderStatusMasterId = orderItemTran.linktoOrderStatusMasterId;
                objOrderItemTranDAL.UpdateDateTime = DateTime.ParseExact(orderItemTran.UpdateDateTime, "s", System.Globalization.DateTimeFormatInfo.InvariantInfo);
                objOrderItemTranDAL.linktoUserMasterIdUpdatedBy = orderItemTran.linktoUserMasterIdUpdatedBy;
                posRecordStatus rs = objOrderItemTranDAL.UpdateOrderItemTranOrderStatus();
                objErrorStatus.ErrorCode = (int)rs;
                return objErrorStatus;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                objErrorStatus.ErrorCode = (int)posRecordStatus.Error;
                return objErrorStatus;
            }
        }

        public ErrorStatus UpdateOrderMasterStatus(OrderMaster orderMaster, string isUpdateTotal)
        {
            ErrorStatus objErrorStatus = new ErrorStatus();
            try
            {
                posOrderMasterDAL objOrderMasterDAL = new posOrderMasterDAL();
                objOrderMasterDAL.OrderMasterId = orderMaster.OrderMasterId;
                objOrderMasterDAL.UpdateDateTime = DateTime.ParseExact(orderMaster.UpdateDateTime, "s", System.Globalization.DateTimeFormatInfo.InvariantInfo);
                objOrderMasterDAL.linktoUserMasterIdUpdatedBy = orderMaster.linktoUserMasterIdUpdatedBy;
                objOrderMasterDAL.linktoWaiterMasterId = orderMaster.linktoWaiterMasterId;
                if (isUpdateTotal.Equals("0"))
                {
                    objOrderMasterDAL.linktoOrderStatusMasterId = Convert.ToInt16(orderMaster.linktoOrderStatusMasterId);
                    posRecordStatus rs = objOrderMasterDAL.UpdateOrderMasterOrderStatus();
                    objErrorStatus.ErrorCode = (int)rs;
                }
                else
                {
                    objOrderMasterDAL.TotalAmount = orderMaster.TotalAmount;
                    posRecordStatus rs = objOrderMasterDAL.UpdateOrderMasterTotalAmount();
                    objErrorStatus.ErrorCode = (int)rs;
                }

                return objErrorStatus;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                objErrorStatus.ErrorCode = (int)posRecordStatus.Error;
                return objErrorStatus;
            }
        }

        public ErrorStatus UpdateOrderMasterDiscount(string orderMasterIds, string discount, string isPercentage)
        {
            ErrorStatus objErrorStatus = new ErrorStatus();
            try
            {
                posOrderMasterDAL objOrderMasterDAL = new posOrderMasterDAL();

                if (isPercentage.Equals("0"))
                {
                    objOrderMasterDAL.isPercentage = false;
                }
                else if (isPercentage.Equals("1"))
                {
                    objOrderMasterDAL.isPercentage = true;
                }
                discount = discount.Replace("2E2", ".");
                objOrderMasterDAL.DiscountAmount = Convert.ToDouble(discount);

                posRecordStatus rs = objOrderMasterDAL.UpdateOrderMasterDiscount(orderMasterIds);
                objErrorStatus.ErrorCode = (int)rs;
                return objErrorStatus;


            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                objErrorStatus.ErrorCode = (int)posRecordStatus.Error;
                return objErrorStatus;
            }
        }
        #endregion

        #region Select
        public UserMaster SelectUserName(string username, string password, string linktoBusinessMasterId)
        {
            posUserMasterDAL objPosUserMasterDAL = null;
            try
            {
                objPosUserMasterDAL = new posUserMasterDAL();
                objPosUserMasterDAL.Username = username;
                if (linktoBusinessMasterId != "null")
                {
                    objPosUserMasterDAL.linktoBusinessMasterId = Convert.ToInt16(linktoBusinessMasterId);
                }
                if (objPosUserMasterDAL.SelectUserMasterByUsername())
                {
                    if (objPosUserMasterDAL.Password == password)
                    {
                        objPosUserMasterDAL.LastLoginDateTime = DateTime.Now;
                        objPosUserMasterDAL.UpdateUserMasterLastLoginDateTime();
                        UserMaster objUserMaster = new UserMaster();
                        objUserMaster.SetClassObject(objPosUserMasterDAL);
                        return objUserMaster;
                    }
                    else
                    {
                        return null;
                    }
                }
                return null;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
            finally
            {
                objPosUserMasterDAL = null;
            }
        }

        public CustomerMaster SelectCustomerMaster(string userName, string password, string customerMasterId)
        {
            string Name = null;
            string Password = null;
            try
            {
                posCustomerMasterDAL objCustomerMasterDAL = null;

                try
                {
                    objCustomerMasterDAL = new posCustomerMasterDAL();
                    if (customerMasterId != "null")
                    {

                        objCustomerMasterDAL.CustomerMasterId = Convert.ToInt32(customerMasterId);
                        objCustomerMasterDAL.SelectCustomerMaster();
                        CustomerMaster objCustomerMaster = new CustomerMaster();
                        objCustomerMaster.SetClassObject(objCustomerMasterDAL);
                        return objCustomerMaster;

                    }
                    else
                    {
                        Name = userName.Replace("2E", ".");
                        Password = password.Replace("2E", ".");

                        objCustomerMasterDAL.Email1 = System.Web.HttpUtility.UrlDecode(Name.ToString());
                        if (objCustomerMasterDAL.SelectCustomerMaster())
                        {

                            if (objCustomerMasterDAL.Password == Password)
                            {
                                CustomerMaster objCustomerMaster = new CustomerMaster();
                                objCustomerMaster.SetClassObject(objCustomerMasterDAL);
                                return objCustomerMaster;
                            }
                            else
                            {
                                return null;
                            }
                        }
                    }
                    return null;
                }
                catch (Exception ex)
                {
                    posGlobalsDAL.SaveError(ex);
                    return null;
                }
                finally
                {
                    objCustomerMasterDAL = null;
                }
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
        }

        public BusinessMaster SelectBusinessMasterByBusinessMasterId(string businessMasterId)
        {

            try
            {
                posBusinessMasterDAL objBusinessMasterDAL = new posBusinessMasterDAL();
                objBusinessMasterDAL.BusinessMasterId = Convert.ToInt16(businessMasterId);

                objBusinessMasterDAL.SelectBusinessMaster();

                BusinessMaster objBusinessMaster = new BusinessMaster();
                objBusinessMaster.SetClassObject(objBusinessMasterDAL);
                return objBusinessMaster;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
        }

        public ItemMaster SelectItemMaster(string counterMasterId, string linktoOrderTypeMasterId, string itemMasterId)
        {
            try
            {
                posItemMasterDAL objItemMasterDAL = new posItemMasterDAL();
                objItemMasterDAL.CounterMasterId = Convert.ToInt16(counterMasterId);
                objItemMasterDAL.ItemMasterId = Convert.ToInt16(itemMasterId);
                objItemMasterDAL.SelectItemMasterCounter(Convert.ToInt16(linktoOrderTypeMasterId));

                ItemMaster objItemMaster = new ItemMaster();
                objItemMaster.SetClassObject(objItemMasterDAL);
                return objItemMaster;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
        }

        public String SelectBillNumber()
        {
            try
            {
                posSalesMasterDAL objSalesMasterDAL = new posSalesMasterDAL();
                objSalesMasterDAL.SelectSalesMasterBillNumberAutoIncrement();
                return objSalesMasterDAL.BillNumber;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
        }

        public OfferMaster SelectOfferMaster(string offerMasterId)
        {
            posOfferMasterDAL objOfferMasterDAL = new posOfferMasterDAL();
            try
            {
                objOfferMasterDAL.OfferMasterId = Convert.ToInt16(offerMasterId);
                if (objOfferMasterDAL.SelectOfferMaster())
                {
                    OfferMaster objOffer = new OfferMaster();
                    objOffer.SetClassObject(objOfferMasterDAL);
                    return objOffer;
                }
                return null;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
        }

        public BusinessDescription SelectBusinessDescription(string businessMasterId, string keyword)
        {
            try
            {
                posBusinessDescriptionDAL objBusinessDescriptionDAL = new posBusinessDescriptionDAL();
                objBusinessDescriptionDAL.linktoBusinessMasterId = Convert.ToInt16(businessMasterId);
                objBusinessDescriptionDAL.Title = System.Web.HttpUtility.UrlDecode(keyword);

                objBusinessDescriptionDAL.SelectBusinessDescription();

                BusinessDescription objBusinessDescription = new BusinessDescription();
                objBusinessDescription.SetClassObject(objBusinessDescriptionDAL);
                return objBusinessDescription;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
        }

        public bool SelectOrderMasterByTableMasterId(string linktoTableMasterId, string linktoBusinessMasterId, string fromday, string frommonth, string fromyear)
        {
            try
            {
                posOrderMasterDAL objOrderMasterDAL = new posOrderMasterDAL();
                objOrderMasterDAL.linktoBusinessMasterId = Convert.ToInt16(linktoBusinessMasterId);
                objOrderMasterDAL.linktoTableMasterIds = linktoTableMasterId;
                objOrderMasterDAL.OrderDateTime = DateTime.ParseExact(frommonth + "/" + fromday + "/" + fromyear, "M/d/yyyy", DateTimeFormatInfo.InvariantInfo);
                return objOrderMasterDAL.SelectOrderMasterByTableMasterId();

            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return false;
            }
        }

        public AppThemeMaster SelectAppThemeMaster(string linktoBusinessMasterId)
        {
            try
            {
                posAppThemeMasterDAL objAppThemeMasterDAL = new posAppThemeMasterDAL();

                objAppThemeMasterDAL.linktoBusinessMasterId = Convert.ToInt32(linktoBusinessMasterId);

                objAppThemeMasterDAL.SelectAppThemeMaster();

                AppThemeMaster objAppThemeMaster = new AppThemeMaster();
                objAppThemeMaster.SetClassObject(objAppThemeMasterDAL);
                return objAppThemeMaster;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
        }

        public OfferMaster SelectOfferMasterOfferCodeVerification(OfferMaster objOfferMaster)
        {
            posOfferMasterDAL objOfferMasterDAL = new posOfferMasterDAL();
            try
            {
                objOfferMasterDAL.OfferCode = objOfferMaster.OfferCode;
                objOfferMasterDAL.MinimumBillAmount = objOfferMaster.MinimumBillAmount;
                objOfferMasterDAL.linktoBusinessMasterId = objOfferMaster.linktoBusinessMasterId;
                objOfferMasterDAL.linktoCustomerMasterId = objOfferMaster.linktoCustomerMasterId;

                if (objOfferMasterDAL.SelectOfferMasterOfferCodeVerification(Convert.ToInt16(objOfferMaster.linktoOrderTypeMasterIds)))
                {
                    OfferMaster objOffer = new OfferMaster();
                    objOffer.SetClassObject(objOfferMasterDAL);
                    return objOffer;
                }
                return null;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
        }

        public bool SelectTableAssignmentSetting(string linktoBusinessMasterId, string SettingMasterId)
        {
            try
            {
                posSettingMasterDAL objSettingMasterDAL = new posSettingMasterDAL();
                objSettingMasterDAL.linktoBusinessMasterId = Convert.ToInt16(linktoBusinessMasterId);
                objSettingMasterDAL.SettingMasterId = Convert.ToInt16(SettingMasterId);
                string temp = objSettingMasterDAL.SelectTableAssignmentSetting();
                if (temp == "True")
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return false;
            }
        }

        #endregion

        #region SelectAll
        public List<AreaMaster> SelectAllAreaMaster(string linktoBusinessMasterId, string linktoCityMasterId)
        {
            List<AreaMaster> lstAreaMaster = new List<AreaMaster>();
            try
            {
                posAreaMasterDAL objAreaMasterDAL = new posAreaMasterDAL();
                objAreaMasterDAL.IsEnabled = true;
                objAreaMasterDAL.linktoBusinessMasterId = Convert.ToInt16(linktoBusinessMasterId);
                objAreaMasterDAL.linktoCityMasterId = Convert.ToInt16(linktoCityMasterId);
                lstAreaMaster = AreaMaster.SetListObject(objAreaMasterDAL.SelectAllAreaMaster());
                return lstAreaMaster;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
        }

        public List<WaitingStatusMaster> SelectAllWaitingStatus()
        {
            List<WaitingStatusMaster> lstWaitingStatusMaster = new List<WaitingStatusMaster>();
            try
            {
                posWaitingStatusMasterDAL objWaitingStatusMasterDAL = new posWaitingStatusMasterDAL();
                lstWaitingStatusMaster = WaitingStatusMaster.SetListObject(objWaitingStatusMasterDAL.SelectAllWaitingStatusMaster());
                return lstWaitingStatusMaster;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
        }

        public List<WaitingMaster> SelectAllWaitingMasterByWaitingStatusMasterId(string linktoWaitingStatusMasterId, string fromday, string frommonth, string fromyear, string linktoBusinessMasterId, string OrderBy)
        {
            List<WaitingMaster> lstWaitingMaster = new List<WaitingMaster>();
            try
            {
                posWaitingMasterDAL objWaitingMasterDAL = new posWaitingMasterDAL();
                objWaitingMasterDAL.linktoWaitingStatusMasterId = Convert.ToInt16(linktoWaitingStatusMasterId);
                objWaitingMasterDAL.linktoBusinessMasterId = Convert.ToInt16(linktoBusinessMasterId);
                objWaitingMasterDAL.OrderBy = Convert.ToString(OrderBy);
                objWaitingMasterDAL.CreateDateTime = DateTime.ParseExact(frommonth + "/" + fromday + "/" + fromyear, "M/d/yyyy", DateTimeFormatInfo.InvariantInfo);
                lstWaitingMaster = WaitingMaster.SetListObject(objWaitingMasterDAL.SelectAllWaitingMasterByWaitingStatusId());
                return lstWaitingMaster;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
        }

        public List<TableMaster> SelectAllTableMaster(string linktoCounterMasterId, string linktoTableStatusMasterId, string linktoOrderTypeMasterId, string linktoBusinessMasterId, string fromday, string frommonth, string fromyear)
        {
            List<TableMaster> lstTableMaster = new List<TableMaster>();
            try
            {
                posTableMasterDAL objTableMasterDAL = new posTableMasterDAL();
                objTableMasterDAL.linktoCounterMasterId = Convert.ToInt16(linktoCounterMasterId);
                if (linktoTableStatusMasterId != "null")
                {
                    objTableMasterDAL.linktoTableStatusMasterId = Convert.ToInt16(linktoTableStatusMasterId);
                }
                if (linktoOrderTypeMasterId != "null")
                {
                    objTableMasterDAL.linktoOrderTypeMasterId = Convert.ToInt16(linktoOrderTypeMasterId);
                }
                objTableMasterDAL.CreateDateTime = DateTime.ParseExact(frommonth + "/" + fromday + "/" + fromyear, "M/d/yyyy", DateTimeFormatInfo.InvariantInfo);
                objTableMasterDAL.linktoBusinessMasterId = Convert.ToInt16(linktoBusinessMasterId);
                lstTableMaster = TableMaster.SetListObject(objTableMasterDAL.SelectAllTableMasterByBusinessMasterId());
                return lstTableMaster;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
        }

        public List<BusinessMaster> SelectAllBusinessMaster()
        {
            List<BusinessMaster> lstBusinessMaster = new List<BusinessMaster>();
            try
            {
                posBusinessMasterDAL objPosBusinessMasterDAL = new posBusinessMasterDAL();
                lstBusinessMaster = BusinessMaster.SetListObject(objPosBusinessMasterDAL.SelectAllBusinessMaster());
                return lstBusinessMaster;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
        }

        public List<BusinessGalleryTran> SelectAllBusinessGalleryTran(string linktoBusinessMasterId)
        {
            List<BusinessGalleryTran> lstBusinessGalleryTran = new List<BusinessGalleryTran>();
            try
            {
                posBusinessGalleryTranDAL objPosBusinessGalleryTranDAL = new posBusinessGalleryTranDAL();
                objPosBusinessGalleryTranDAL.linktoBusinessMasterId = Convert.ToInt16(linktoBusinessMasterId);
                lstBusinessGalleryTran = BusinessGalleryTran.SetListObject(objPosBusinessGalleryTranDAL.SelectAllBusinessGalleryTran());
                return lstBusinessGalleryTran;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
        }

        public List<BusinessHoursTran> SelectAllBusinessHoursTranByBusinessMasterId(string businessMasterId)
        {
            List<BusinessHoursTran> lstBusinessHoursTran = new List<BusinessHoursTran>();
            try
            {
                posBusinessHoursTranDAL objBusinessHoursTranDAL = new posBusinessHoursTranDAL();
                objBusinessHoursTranDAL.linktoBusinessMasterId = Convert.ToInt16(businessMasterId);
                lstBusinessHoursTran = BusinessHoursTran.SetListObject(objBusinessHoursTranDAL.SelectAllBusinessHoursTranBusinessWise());

                return lstBusinessHoursTran;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
        }

        public List<CategoryMaster> SelectAllCategoryMaster(string linktoBusinessMasterId, string isHiddenForCustomer)
        {
            List<CategoryMaster> lstCategoryMaster = new List<CategoryMaster>();
            try
            {
                posCategoryMasterDAL objCategoryMasterDAL = new posCategoryMasterDAL();
                objCategoryMasterDAL.IsEnabled = true;
                objCategoryMasterDAL.IsRawMaterial = false;
                if (Convert.ToBoolean(isHiddenForCustomer))
                {
                    objCategoryMasterDAL.IsHiddenForCustomer = true;
                }
                else
                {
                    objCategoryMasterDAL.IsHiddenForCustomer = false;
                }
                objCategoryMasterDAL.linktoBusinessMasterId = Convert.ToInt16(linktoBusinessMasterId);
                lstCategoryMaster = CategoryMaster.SetListObject(objCategoryMasterDAL.SelectAllCategoryMaster());
                return lstCategoryMaster;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
        }

        public List<ItemMaster> SelectAllItemMasterByCategoryMasterId(string linktoCounterMasterId, string linktoOrderTypeMasterId, string linktoCategoryMasterId, string itemTypeMasterIds, string linktoBusinessMasterId, string isFavorite, string itemMasterIds)
        {
            List<ItemMaster> lstItemMaster = new List<ItemMaster>();
            try
            {
                posItemMasterDAL objItemMasterDAL = new posItemMasterDAL();
                if (linktoCategoryMasterId != "null")
                {
                    objItemMasterDAL.linktoCategoryMasterId = Convert.ToInt16(linktoCategoryMasterId);
                }
                objItemMasterDAL.CounterMasterId = Convert.ToInt16(linktoCounterMasterId);
                objItemMasterDAL.linktoBusinessMasterId = Convert.ToInt16(linktoBusinessMasterId);
                if (!isFavorite.Equals("0"))
                {
                    objItemMasterDAL.IsFavourite = true;
                }

                lstItemMaster = ItemMaster.SetListObject(objItemMasterDAL.SelectAllItemMasterByCategoryMasterId(Convert.ToInt16(linktoOrderTypeMasterId), itemMasterIds));
                return lstItemMaster;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
        }

        public List<CounterMaster> SelectAllCounterMaster(string linktoBusinessMasterId, string linktoUserMasterId)
        {
            List<CounterMaster> lstCounterMaster = new List<CounterMaster>();
            try
            {
                posCounterMasterDAL objCounterMasterDAL = new posCounterMasterDAL();
                objCounterMasterDAL.IsEnabled = true;
                objCounterMasterDAL.linktoBusinessMasterId = Convert.ToInt16(linktoBusinessMasterId);
                lstCounterMaster = CounterMaster.SetListObject(objCounterMasterDAL.SelectAllCounterMaster(Convert.ToInt16(linktoUserMasterId)));
                return lstCounterMaster;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
        }

        public List<OrderMaster> SelectAllOrderMasterByOrderStatusMasterId(string linktoCounterMasterId, string linktoOrderStatusMasterId, string linktoTableMasterIds, string linktoOrderTypeMasterId, string fromday, string frommonth, string fromyear, string linktoBusinessMasterId)
        {
            List<OrderMaster> lstOrderMaster = new List<OrderMaster>();
            try
            {
                posOrderMasterDAL objOrderMasterDAL = new posOrderMasterDAL();
                objOrderMasterDAL.linktoCounterMasterId = Convert.ToInt16(linktoCounterMasterId);
                if (linktoOrderStatusMasterId != "null")
                {
                    objOrderMasterDAL.linktoOrderStatusMasterId = Convert.ToInt16(linktoOrderStatusMasterId);
                }
                if (linktoTableMasterIds != "null")
                {
                    objOrderMasterDAL.linktoTableMasterIds = linktoTableMasterIds;
                }
                if (linktoOrderTypeMasterId != "null")
                {
                    objOrderMasterDAL.linktoOrderTypeMasterId = Convert.ToInt16(linktoOrderTypeMasterId);
                }
                objOrderMasterDAL.linktoBusinessMasterId = Convert.ToInt16(linktoBusinessMasterId);
                objOrderMasterDAL.OrderDateTime = DateTime.ParseExact(frommonth + "/" + fromday + "/" + fromyear, "M/d/yyyy", DateTimeFormatInfo.InvariantInfo);

                lstOrderMaster = OrderMaster.SetListObject(objOrderMasterDAL.SelectAllOrderMasterByOrderStatus());
                return lstOrderMaster;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
        }

        public List<OrderMaster> SelectAllOrderMasterByFromDate(string linktoCounterMasterId, string fromday, string frommonth, string fromyear, string linktoBusinessMasterId)
        {
            List<OrderMaster> lstOrderMaster = new List<OrderMaster>();
            try
            {
                posOrderMasterDAL objOrderMasterDAL = new posOrderMasterDAL();
                objOrderMasterDAL.linktoCounterMasterId = Convert.ToInt16(linktoCounterMasterId);
                objOrderMasterDAL.linktoBusinessMasterId = Convert.ToInt16(linktoBusinessMasterId);
                objOrderMasterDAL.OrderDateTime = DateTime.ParseExact(frommonth + "/" + fromday + "/" + fromyear, "M/d/yyyy", DateTimeFormatInfo.InvariantInfo);

                lstOrderMaster = OrderMaster.SetListObject(objOrderMasterDAL.SelectAllOrderMasterByFromDate());
                return lstOrderMaster;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
        }

        public List<OrderItemTran> SelectAllOrderItemTranByOrderMasterId(string orderMasterId)
        {
            List<OrderItemTran> lstOrderItemTran = new List<OrderItemTran>();
            try
            {
                posOrderItemTranDAL objOrderItemTranDAL = new posOrderItemTranDAL();
                lstOrderItemTran = OrderItemTran.SetListObject(objOrderItemTranDAL.SelectAllOrderItemTranByOrderMasterId(orderMasterId));
                return lstOrderItemTran;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
        }

        public List<ItemRemarkMaster> SelectAllItemRemarkMaster(string linktoBusinessMasterId)
        {
            List<ItemRemarkMaster> lstItemRemarkMaster = new List<ItemRemarkMaster>();
            try
            {
                posItemRemarkMasterDAL objItemRemarkMasterDAL = new posItemRemarkMasterDAL();
                objItemRemarkMasterDAL.linktoBusinessMasterId = Convert.ToInt16(linktoBusinessMasterId);
                lstItemRemarkMaster = ItemRemarkMaster.SetListObject(objItemRemarkMasterDAL.SelectAllItemRemarkMaster());
                return lstItemRemarkMaster;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
        }

        public List<ItemMaster> SelectAllItemMasterModifier(string itemType, string linktoBusinessMasterId, string linktoItemMasterId)
        {
            List<ItemMaster> lstItemMaster = new List<ItemMaster>();
            List<posItemMasterDAL> lstItemMasterDAL = new List<posItemMasterDAL>();
            List<posItemModifierTranDAL> lstItemModifierTranDAL = new List<posItemModifierTranDAL>();
            try
            {
                posItemModifierTranDAL objItemModifierTranDAL = new posItemModifierTranDAL();
                objItemModifierTranDAL.linktoItemMasterId = Convert.ToInt16(linktoItemMasterId);
                lstItemModifierTranDAL = objItemModifierTranDAL.SelectAllItemModifierTran(Convert.ToInt16(linktoBusinessMasterId));
                lstItemModifierTranDAL.RemoveAll(i => i.ItemModifierTranId == 0);
                foreach (posItemModifierTranDAL objItemModifierTran in lstItemModifierTranDAL)
                {
                    posItemMasterDAL objItemMasterDAL = new posItemMasterDAL();
                    objItemMasterDAL.ItemMasterId = objItemModifierTran.linktoItemMasterModifierId;
                    objItemMasterDAL.ItemName = objItemModifierTran.ModifierName;
                    objItemMasterDAL.MRP = objItemModifierTran.ModifierRate;
                    objItemMasterDAL.linktoItemMasterId = objItemModifierTran.linktoItemMasterId;
                    lstItemMasterDAL.Add(objItemMasterDAL);
                }
                lstItemMaster = ItemMaster.SetListObject(lstItemMasterDAL);
                return lstItemMaster;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
        }

        public List<ItemMaster> SelectAllOrderItemByTableMasterIds(string fromday, string frommonth, string fromyear, string linktoTableMasterIds)
        {
            List<ItemMaster> lstItemMaster = new List<ItemMaster>();
            try
            {
                posItemMasterDAL objItemMasterDAL = new posItemMasterDAL();
                objItemMasterDAL.CreateDateTime = DateTime.ParseExact(frommonth + "/" + fromday + "/" + fromyear, "M/d/yyyy", DateTimeFormatInfo.InvariantInfo);
                lstItemMaster = ItemMaster.SetListObject(objItemMasterDAL.SelectAllItemMasterByTableMasterIds(linktoTableMasterIds));
                return lstItemMaster;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
        }

        public List<TaxMaster> SelectAllTaxMaster(string businessMasterId)
        {
            List<TaxMaster> lstTaxMaster = new List<TaxMaster>();
            try
            {
                posTaxMasterDAL objTaxMasterDAL = new posTaxMasterDAL();
                objTaxMasterDAL.IsEnabled = true;
                objTaxMasterDAL.linktoBusinessMasterId = Convert.ToInt16(businessMasterId);
                lstTaxMaster = TaxMaster.SetListObject(objTaxMasterDAL.SelectAllTaxMaster());
                return lstTaxMaster;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
        }

        public List<DiscountSelectionMaster> SelectAllDiscountMaster(string linktoBusinessMasterId)
        {
            List<DiscountSelectionMaster> lstDiscountSelectionMaster = new List<DiscountSelectionMaster>();
            try
            {
                posDiscountSelectionMasterDAL objDiscountSelectionMasterDAL = new posDiscountSelectionMasterDAL();

                objDiscountSelectionMasterDAL.linktoBusinessMasterId = Convert.ToInt16(linktoBusinessMasterId);

                lstDiscountSelectionMaster = DiscountSelectionMaster.SetListObject(objDiscountSelectionMasterDAL.SelectAllDiscountSelectionMaster());
                return lstDiscountSelectionMaster;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }

        }

        public List<OfferMaster> SelectAllOfferMaster(string fromday, string frommonth, string fromyear, string fromhour, string fromminute, string linktoBusinessMasterId)
        {
            List<OfferMaster> lstOfferMaster = new List<OfferMaster>();
            try
            {
                posOfferMasterDAL objOfferMasterDAL = new posOfferMasterDAL();
                objOfferMasterDAL.FromDate = DateTime.ParseExact(frommonth + "/" + fromday + "/" + fromyear + " " + fromhour + ":" + fromminute, "M/d/yyyy H:m", DateTimeFormatInfo.InvariantInfo);
                objOfferMasterDAL.linktoBusinessMasterId = Convert.ToInt16(linktoBusinessMasterId);
                lstOfferMaster = OfferMaster.SetListObject(objOfferMasterDAL.SelectAllOfferMasterByFromDate());
                return lstOfferMaster;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
        }

        public List<FeedbackAnswerMaster> SelectAllFeedbackAnswerMaster()
        {
            List<FeedbackAnswerMaster> lstFeedbackAnswerMaster = new List<FeedbackAnswerMaster>();
            try
            {
                posFeedbackAnswerMasterDAL objFeedbackAnswerMasterDAL = new posFeedbackAnswerMasterDAL();
                lstFeedbackAnswerMaster = FeedbackAnswerMaster.SetListObject(objFeedbackAnswerMasterDAL.SelectAllFeedbackAnswerMaster());
                return lstFeedbackAnswerMaster;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
        }

        public List<FeedbackQuestionMaster> SelectAllFeedbackQuestionMaster(string businessMasterId)
        {
            List<FeedbackQuestionMaster> lstFeedbackQuestionMaster = new List<FeedbackQuestionMaster>();
            try
            {
                posFeedbackQuestionMasterDAL objFeedbackQuestionMasterDAL = new posFeedbackQuestionMasterDAL();
                objFeedbackQuestionMasterDAL.IsEnabled = true;
                objFeedbackQuestionMasterDAL.linktoBusinessMasterId = Convert.ToInt16(businessMasterId);
                lstFeedbackQuestionMaster = FeedbackQuestionMaster.SetListObject(objFeedbackQuestionMasterDAL.SelectAllFeedbackQuestionMaster());
                return lstFeedbackQuestionMaster;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
        }

        public List<FeedbackQuestionGroupMaster> SelectAllFeedbackQuestionGroupMaster(string businessMasterId)
        {
            List<FeedbackQuestionGroupMaster> lstFeedbackQuestionGroupMaster = new List<FeedbackQuestionGroupMaster>();
            try
            {
                posFeedbackQuestionGroupMasterDAL objFeedbackQuestionGroupMasterDAL = new posFeedbackQuestionGroupMasterDAL();
                objFeedbackQuestionGroupMasterDAL.linktoBusinessMasterId = Convert.ToInt16(businessMasterId);
                lstFeedbackQuestionGroupMaster = FeedbackQuestionGroupMaster.SetListObject(objFeedbackQuestionGroupMasterDAL.SelectAllFeedbackQuestionGroupMaster());
                return lstFeedbackQuestionGroupMaster;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
        }

        public List<BusinessInfoAnswerMaster> SelectAllBusinessInfoAnswerMaster(string linktoBusinessTypeMasterId, string linktoBusinessMasterId)
        {
            List<BusinessInfoAnswerMaster> lstBusinessInfoAnswerMaster = new List<BusinessInfoAnswerMaster>();
            try
            {
                lstBusinessInfoAnswerMaster = BusinessInfoAnswerMaster.SetListObject(posBusinessInfoAnswerMasterDAL.SelectAllBusinessInfoAnswerMasterByBusinessMasterId(Convert.ToInt16(linktoBusinessTypeMasterId), Convert.ToInt16(linktoBusinessMasterId)));
                return lstBusinessInfoAnswerMaster;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
        }

        public List<OptionValueTran> SelectAllItemOption(string linktoItemMasterId)
        {
            List<OptionValueTran> lstOptionValueTran = new List<OptionValueTran>();
            try
            {
                posOptionValueTranDAL objOptionValueTranDAL = new posOptionValueTranDAL();
                lstOptionValueTran = OptionValueTran.SetListObject(objOptionValueTranDAL.SelectAllOptionValueTranByItemMasterId(Convert.ToInt32(linktoItemMasterId)));
                return lstOptionValueTran;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
        }

        public List<ItemMaster> SelectAllItemSuggested(string linktoItemMasterId, string linktoBusinessMasterId, string rateIndex, string isDineIn)
        {
            List<ItemMaster> lstItemMaster = new List<ItemMaster>();
            try
            {
                posItemMasterDAL objItemMasterDAL = new posItemMasterDAL();
                objItemMasterDAL.linktoBusinessMasterId = Convert.ToInt16(linktoBusinessMasterId);
                objItemMasterDAL.RateIndex = Convert.ToInt16(rateIndex);
                if (isDineIn.Equals("1"))
                {
                    objItemMasterDAL.IsDineInOnly = true;
                }
                else
                {
                    objItemMasterDAL.IsDineInOnly = false;
                }
                lstItemMaster = ItemMaster.SetListObject(objItemMasterDAL.SelectAllItemSuggested(Convert.ToInt32(linktoItemMasterId)));
                return lstItemMaster;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
        }

        public List<WaiterNotificationMaster> SelectAllWaiterNotificationMaster(string linktoWaiterMasterId, string fromday, string frommonth, string fromyear, string fromhour, string fromminute)
        {
            List<WaiterNotificationMaster> lstWaiterNotificationMaster = new List<WaiterNotificationMaster>();
            try
            {
                posWaiterNotificationMasterDAL objWaiterNotificationMasterDAL = new posWaiterNotificationMasterDAL();
                objWaiterNotificationMasterDAL.NotificationDateTime = DateTime.ParseExact(frommonth + "/" + fromday + "/" + fromyear + " " + fromhour + ":" + fromminute, "M/d/yyyy H:m", DateTimeFormatInfo.InvariantInfo);
                lstWaiterNotificationMaster = WaiterNotificationMaster.SetListObject(objWaiterNotificationMasterDAL.SelectAllWaitingMasterNotification(Convert.ToInt16(linktoWaiterMasterId)));
                return lstWaiterNotificationMaster;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
        }

        public List<AppThemeMaster> SelectAllAppThemeMaster()
        {
            List<AppThemeMaster> lstAppThemeMaster = new List<AppThemeMaster>();
            try
            {
                posAppThemeMasterDAL objAppThemeMasterDAL = new posAppThemeMasterDAL();
                lstAppThemeMaster = AppThemeMaster.SetListObject(objAppThemeMasterDAL.SelectAllAppThemeMaster());
                return lstAppThemeMaster;
            }
            catch (Exception ex)
            {
                posGlobalsDAL.SaveError(ex);
                return null;
            }
        }

        #endregion
    }
}
