using System;
using System.Collections.Generic;

namespace posLibrary
{
	/// <summary>
	/// Model for TableMaster
	/// </summary>
	public class TableMaster
	{

        public short TableMasterId { get; set; }
        public string TableName { get; set; }
        public string ShortName { get; set; }
        public string Description { get; set; }
        public short MinPerson { get; set; }
        public short MaxPerson { get; set; }
        public short linktoTableStatusMasterId { get; set; }
        public short linktoOrderTypeMasterId { get; set; }
        public short linktoSectionMasterId { get; set; }
        public int OriginX { get; set; }
        public int OriginY { get; set; }
        public double Height { get; set; }
        public double Width { get; set; }
        public string TableColor { get; set; }
        public string CreateDateTime { get; set; }
        public short linktoUserMasterIdCreatedBy { get; set; }
        public string UpdateDateTime { get; set; }
        public short? linktoUserMasterIdUpdatedBy { get; set; }
        public short linktoBusinessMasterId { get; set; }
        public bool IsEnabled { get; set; }
        public string StatusUpdateDateTime { get; set; }

		/// Extra
		public string TableStatus { get; set; }
        public string StatusColor { get; set; }
		public string Business { get; set; }
        public string WaitingPersonName { get; set; }


		internal void SetClassObject(posTableMasterDAL objTableMasterDAL)
		{
			this.TableMasterId = Convert.ToInt16(objTableMasterDAL.TableMasterId);
			this.TableName = Convert.ToString(objTableMasterDAL.TableName);
			this.ShortName = Convert.ToString(objTableMasterDAL.ShortName);
			this.Description = Convert.ToString(objTableMasterDAL.Description);
			this.MinPerson = Convert.ToInt16(objTableMasterDAL.MinPerson);
			this.MaxPerson = Convert.ToInt16(objTableMasterDAL.MaxPerson);
			this.linktoTableStatusMasterId = Convert.ToInt16(objTableMasterDAL.linktoTableStatusMasterId);
            this.linktoOrderTypeMasterId = Convert.ToInt16(objTableMasterDAL.linktoOrderTypeMasterId);
			this.OriginX = Convert.ToInt32(objTableMasterDAL.OriginX);
			this.OriginY = Convert.ToInt32(objTableMasterDAL.OriginY);
			this.Height = Convert.ToDouble(objTableMasterDAL.Height);
			this.Width = Convert.ToDouble(objTableMasterDAL.Width);
			this.TableColor = Convert.ToString(objTableMasterDAL.TableColor);
			this.CreateDateTime = objTableMasterDAL.CreateDateTime.ToString("s");
			this.linktoUserMasterIdCreatedBy = Convert.ToInt16(objTableMasterDAL.linktoUserMasterIdCreatedBy);
			if (objTableMasterDAL.UpdateDateTime != null)
			{
				this.UpdateDateTime = objTableMasterDAL.UpdateDateTime.Value.ToString("s");
			}
			if (objTableMasterDAL.linktoUserMasterIdUpdatedBy != null)
			{
				this.linktoUserMasterIdUpdatedBy = Convert.ToInt16(objTableMasterDAL.linktoUserMasterIdUpdatedBy.Value);
			}
			this.linktoBusinessMasterId = Convert.ToInt16(objTableMasterDAL.linktoBusinessMasterId);
			this.IsEnabled = Convert.ToBoolean(objTableMasterDAL.IsEnabled);

			/// Extra
			this.TableStatus = Convert.ToString(objTableMasterDAL.TableStatus);
            this.StatusColor = Convert.ToString(objTableMasterDAL.StatusColor);
            if (objTableMasterDAL.StatusUpdateDateTime != null)
            {
                this.StatusUpdateDateTime = objTableMasterDAL.StatusUpdateDateTime.Value.ToString("s");
            }
            this.WaitingPersonName = Convert.ToString(objTableMasterDAL.WaitingPersonName);
		}

		internal static List<TableMaster> SetListObject(List<posTableMasterDAL> lstTableMasterDAL)
		{
			List<TableMaster> lstTableMaster = new List<TableMaster>();
			TableMaster objTableMaster = null;
			foreach (posTableMasterDAL objTableMasterDAL in lstTableMasterDAL)
			{
				objTableMaster = new TableMaster();
				objTableMaster.TableMasterId = Convert.ToInt16(objTableMasterDAL.TableMasterId);
				objTableMaster.TableName = Convert.ToString(objTableMasterDAL.TableName);
				objTableMaster.ShortName = Convert.ToString(objTableMasterDAL.ShortName);
				objTableMaster.Description = Convert.ToString(objTableMasterDAL.Description);
				objTableMaster.MinPerson = Convert.ToInt16(objTableMasterDAL.MinPerson);
				objTableMaster.MaxPerson = Convert.ToInt16(objTableMasterDAL.MaxPerson);
				objTableMaster.linktoTableStatusMasterId = Convert.ToInt16(objTableMasterDAL.linktoTableStatusMasterId);
                objTableMaster.linktoOrderTypeMasterId = Convert.ToInt16(objTableMasterDAL.linktoOrderTypeMasterId);
				objTableMaster.OriginX = Convert.ToInt32(objTableMasterDAL.OriginX);
				objTableMaster.OriginY = Convert.ToInt32(objTableMasterDAL.OriginY);
				objTableMaster.Height = Convert.ToDouble(objTableMasterDAL.Height);
				objTableMaster.Width = Convert.ToDouble(objTableMasterDAL.Width);
				objTableMaster.TableColor = Convert.ToString(objTableMasterDAL.TableColor);
				objTableMaster.CreateDateTime = objTableMasterDAL.CreateDateTime.ToString("s");
				objTableMaster.linktoUserMasterIdCreatedBy = Convert.ToInt16(objTableMasterDAL.linktoUserMasterIdCreatedBy);
				if (objTableMasterDAL.UpdateDateTime != null)
				{
					objTableMaster.UpdateDateTime = objTableMasterDAL.UpdateDateTime.Value.ToString("s");
				}
				if (objTableMasterDAL.linktoUserMasterIdUpdatedBy != null)
				{
					objTableMaster.linktoUserMasterIdUpdatedBy = Convert.ToInt16(objTableMasterDAL.linktoUserMasterIdUpdatedBy.Value);
				}
				objTableMaster.linktoBusinessMasterId = Convert.ToInt16(objTableMasterDAL.linktoBusinessMasterId);
				objTableMaster.IsEnabled = Convert.ToBoolean(objTableMasterDAL.IsEnabled);

				/// Extra
				objTableMaster.TableStatus = Convert.ToString(objTableMasterDAL.TableStatus);
                objTableMaster.StatusColor = Convert.ToString(objTableMasterDAL.StatusColor);
                if (objTableMasterDAL.StatusUpdateDateTime != null)
                {
                    objTableMaster.StatusUpdateDateTime = objTableMasterDAL.StatusUpdateDateTime.Value.ToString("s");
                }
                objTableMaster.WaitingPersonName = Convert.ToString(objTableMasterDAL.WaitingPersonName);
				lstTableMaster.Add(objTableMaster);
			}
			return lstTableMaster;
		}
	}
}
