using System;
using System.Collections.Generic;

namespace posLibrary
{
	/// <summary>
	/// Model for SalesMaster
	/// </summary>
	public class SalesMaster
	{

        public long SalesMasterId { get; set; }
        public string BillNumber { get; set; }
        public string BillDateTime { get; set; }
        public short linktoCounterMasterId { get; set; }
        public string linktoTableMasterIds { get; set; }
        public int? linktoWaiterMasterId { get; set; }
        public int? linktoCustomerMasterId { get; set; }
        public short linktoOrderTypeMasterId { get; set; }
        public short? linktoOrderStatusMasterId { get; set; }
        public double TotalAmount { get; set; }
        public double TotalTax { get; set; }
        public double DiscountPercentage { get; set; }
        public double DiscountAmount { get; set; }
        public double ExtraAmount { get; set; }
        public double TotalItemDiscount { get; set; }
        public double TotalItemTax { get; set; }
        public double NetAmount { get; set; }
        public double PaidAmount { get; set; }
        public double BalanceAmount { get; set; }
        public string Remark { get; set; }
        public bool Iscomplimentary { get; set; }
        public short TotalItemPoint { get; set; }
        public short TotalDeductedPoint { get; set; }
        public short linktoBusinessMasterId { get; set; }
        public string CreateDateTime { get; set; }
        public short linktoUserMasterIdCreatedBy { get; set; }
        public string UpdateDateTime { get; set; }
        public short? linktoUserMasterIdUpdatedBy { get; set; }
        public short? linktoWaiterMasterIdCaptain { get; set; }
        public double Rounding { get; set; }
        public short RateIndex { get; set; }
        public string OfferCode { get; set; }
        public short linktoOfferMasterId { get; set; }    

		/// Extra
		public string Counter { get; set; }
		public string Waiter { get; set; }
		public string WaiterCaptain { get; set; }
		public string Customer { get; set; }
		public string OrderType { get; set; }
		public string OrderStatus { get; set; }
		public string Business { get; set; }
        public short linktoSourceMasterId { get; set; }


		internal void SetClassObject(posSalesMasterDAL objSalesMasterDAL)
		{
			this.SalesMasterId = Convert.ToInt64(objSalesMasterDAL.SalesMasterId);
			this.BillNumber = Convert.ToString(objSalesMasterDAL.BillNumber);
			if (objSalesMasterDAL.BillDateTime != null)
			{
				this.BillDateTime = objSalesMasterDAL.BillDateTime.Value.ToString("s");
			}
			this.linktoCounterMasterId = Convert.ToInt16(objSalesMasterDAL.linktoCounterMasterId);
			this.linktoTableMasterIds = Convert.ToString(objSalesMasterDAL.linktoTableMasterIds);
			if (objSalesMasterDAL.linktoWaiterMasterId != null)
			{
				this.linktoWaiterMasterId = Convert.ToInt32(objSalesMasterDAL.linktoWaiterMasterId.Value);
			}
			if (objSalesMasterDAL.linktoWaiterMasterIdCaptain != null)
			{
				this.linktoWaiterMasterIdCaptain = Convert.ToInt16(objSalesMasterDAL.linktoWaiterMasterIdCaptain.Value);
			}
			if (objSalesMasterDAL.linktoCustomerMasterId != null)
			{
				this.linktoCustomerMasterId = Convert.ToInt32(objSalesMasterDAL.linktoCustomerMasterId.Value);
			}
			this.linktoOrderTypeMasterId = Convert.ToInt16(objSalesMasterDAL.linktoOrderTypeMasterId);
            if (objSalesMasterDAL.linktoOrderStatusMasterId != null)
            {
                this.linktoOrderStatusMasterId = Convert.ToInt16(objSalesMasterDAL.linktoOrderStatusMasterId.Value);
            }
			this.TotalAmount = Convert.ToDouble(objSalesMasterDAL.TotalAmount);
			this.TotalTax = Convert.ToDouble(objSalesMasterDAL.TotalTax);
			this.DiscountPercentage = Convert.ToDouble(objSalesMasterDAL.DiscountPercentage);
			this.DiscountAmount = Convert.ToDouble(objSalesMasterDAL.DiscountAmount);
			this.ExtraAmount = Convert.ToDouble(objSalesMasterDAL.ExtraAmount);
			this.TotalItemDiscount = Convert.ToDouble(objSalesMasterDAL.TotalItemDiscount);
			this.TotalItemTax = Convert.ToDouble(objSalesMasterDAL.TotalItemTax);
			this.NetAmount = Convert.ToDouble(objSalesMasterDAL.NetAmount);
			this.PaidAmount = Convert.ToDouble(objSalesMasterDAL.PaidAmount);
			this.BalanceAmount = Convert.ToDouble(objSalesMasterDAL.BalanceAmount);
			this.Remark = Convert.ToString(objSalesMasterDAL.Remark);
			this.Iscomplimentary = Convert.ToBoolean(objSalesMasterDAL.IsComplimentary);
			this.TotalItemPoint = Convert.ToInt16(objSalesMasterDAL.TotalItemPoint);
			this.TotalDeductedPoint = Convert.ToInt16(objSalesMasterDAL.TotalDeductedPoint);
			this.linktoBusinessMasterId = Convert.ToInt16(objSalesMasterDAL.linktoBusinessMasterId);
			this.CreateDateTime = objSalesMasterDAL.CreateDateTime.ToString("s");
			this.linktoUserMasterIdCreatedBy = Convert.ToInt16(objSalesMasterDAL.linktoUserMasterIdCreatedBy);
			if (objSalesMasterDAL.UpdateDateTime != null)
			{
				this.UpdateDateTime = objSalesMasterDAL.UpdateDateTime.Value.ToString("s");
			}
			if (objSalesMasterDAL.linktoUserMasterIdUpdatedBy != null)
			{
				this.linktoUserMasterIdUpdatedBy = Convert.ToInt16(objSalesMasterDAL.linktoUserMasterIdUpdatedBy.Value);
			}          
            this.linktoOfferMasterId = Convert.ToInt16(objSalesMasterDAL.linktoOfferMasterId.Value);
            this.OfferCode = Convert.ToString(objSalesMasterDAL.OfferCode);
            this.linktoSourceMasterId = Convert.ToInt16(objSalesMasterDAL.linktoSourceMasterId.Value);

			/// Extra
			this.Counter = Convert.ToString(objSalesMasterDAL.Counter);
            this.Waiter = Convert.ToString(objSalesMasterDAL.Waiter);
			this.Customer = Convert.ToString(objSalesMasterDAL.Customer);
			this.OrderType = Convert.ToString(objSalesMasterDAL.OrderType);
			this.OrderStatus = Convert.ToString(objSalesMasterDAL.OrderStatus);
			this.Business = Convert.ToString(objSalesMasterDAL.Business);
		}

		internal static List<SalesMaster> SetListObject(List<posSalesMasterDAL> lstSalesMasterDAL)
		{
			List<SalesMaster> lstSalesMaster = new List<SalesMaster>();
			SalesMaster objSalesMaster = null;
			foreach (posSalesMasterDAL objSalesMasterDAL in lstSalesMasterDAL)
			{
				objSalesMaster = new SalesMaster();
				objSalesMaster.SalesMasterId = Convert.ToInt64(objSalesMasterDAL.SalesMasterId);
				objSalesMaster.BillNumber = Convert.ToString(objSalesMasterDAL.BillNumber);
				if (objSalesMasterDAL.BillDateTime != null)
				{
					objSalesMaster.BillDateTime = objSalesMasterDAL.BillDateTime.Value.ToString("s");
				}
				objSalesMaster.linktoCounterMasterId = Convert.ToInt16(objSalesMasterDAL.linktoCounterMasterId);
				objSalesMaster.linktoTableMasterIds = Convert.ToString(objSalesMasterDAL.linktoTableMasterIds);
				if (objSalesMasterDAL.linktoWaiterMasterId != null)
				{
					objSalesMaster.linktoWaiterMasterId = Convert.ToInt32(objSalesMasterDAL.linktoWaiterMasterId.Value);
				}
				if (objSalesMasterDAL.linktoWaiterMasterIdCaptain != null)
				{
					objSalesMaster.linktoWaiterMasterIdCaptain = Convert.ToInt16(objSalesMasterDAL.linktoWaiterMasterIdCaptain.Value);
				}
				if (objSalesMasterDAL.linktoCustomerMasterId != null)
				{
					objSalesMaster.linktoCustomerMasterId = Convert.ToInt32(objSalesMasterDAL.linktoCustomerMasterId.Value);
				}
				objSalesMaster.linktoOrderTypeMasterId = Convert.ToInt16(objSalesMasterDAL.linktoOrderTypeMasterId);
                if (objSalesMasterDAL.linktoOrderStatusMasterId != null)
                {
                    objSalesMaster.linktoOrderStatusMasterId = Convert.ToInt16(objSalesMasterDAL.linktoOrderStatusMasterId.Value);
                }
				objSalesMaster.TotalAmount = Convert.ToDouble(objSalesMasterDAL.TotalAmount);
				objSalesMaster.TotalTax = Convert.ToDouble(objSalesMasterDAL.TotalTax);
				objSalesMaster.DiscountPercentage = Convert.ToDouble(objSalesMasterDAL.DiscountPercentage);
				objSalesMaster.DiscountAmount = Convert.ToDouble(objSalesMasterDAL.DiscountAmount);
				objSalesMaster.ExtraAmount = Convert.ToDouble(objSalesMasterDAL.ExtraAmount);
				objSalesMaster.TotalItemDiscount = Convert.ToDouble(objSalesMasterDAL.TotalItemDiscount);
				objSalesMaster.TotalItemTax = Convert.ToDouble(objSalesMasterDAL.TotalItemTax);
				objSalesMaster.NetAmount = Convert.ToDouble(objSalesMasterDAL.NetAmount);
				objSalesMaster.PaidAmount = Convert.ToDouble(objSalesMasterDAL.PaidAmount);
				objSalesMaster.BalanceAmount = Convert.ToDouble(objSalesMasterDAL.BalanceAmount);
				objSalesMaster.Remark = Convert.ToString(objSalesMasterDAL.Remark);
				objSalesMaster.Iscomplimentary = Convert.ToBoolean(objSalesMasterDAL.IsComplimentary);
				objSalesMaster.TotalItemPoint = Convert.ToInt16(objSalesMasterDAL.TotalItemPoint);
				objSalesMaster.TotalDeductedPoint = Convert.ToInt16(objSalesMasterDAL.TotalDeductedPoint);
				objSalesMaster.linktoBusinessMasterId = Convert.ToInt16(objSalesMasterDAL.linktoBusinessMasterId);
				objSalesMaster.CreateDateTime = objSalesMasterDAL.CreateDateTime.ToString("s");
				objSalesMaster.linktoUserMasterIdCreatedBy = Convert.ToInt16(objSalesMasterDAL.linktoUserMasterIdCreatedBy);
				if (objSalesMasterDAL.UpdateDateTime != null)
				{
					objSalesMaster.UpdateDateTime = objSalesMasterDAL.UpdateDateTime.Value.ToString("s");
				}
				if (objSalesMasterDAL.linktoUserMasterIdUpdatedBy != null)
				{
					objSalesMaster.linktoUserMasterIdUpdatedBy = Convert.ToInt16(objSalesMasterDAL.linktoUserMasterIdUpdatedBy.Value);
				}
                objSalesMaster.linktoOfferMasterId = Convert.ToInt16(objSalesMasterDAL.linktoOfferMasterId.Value);
                objSalesMaster.OfferCode = Convert.ToString(objSalesMasterDAL.OfferCode);
                objSalesMaster.linktoSourceMasterId = Convert.ToInt16(objSalesMasterDAL.linktoSourceMasterId.Value);

				/// Extra
				objSalesMaster.Counter = Convert.ToString(objSalesMasterDAL.Counter);
				objSalesMaster.Waiter = Convert.ToString(objSalesMasterDAL.Waiter);
				objSalesMaster.Customer = Convert.ToString(objSalesMasterDAL.Customer);
				objSalesMaster.OrderType = Convert.ToString(objSalesMasterDAL.OrderType);
				objSalesMaster.OrderStatus = Convert.ToString(objSalesMasterDAL.OrderStatus);
				objSalesMaster.Business = Convert.ToString(objSalesMasterDAL.Business);
				lstSalesMaster.Add(objSalesMaster);
			}
			return lstSalesMaster;
		}
	}
}
