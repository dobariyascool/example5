using System;
using System.Collections.Generic;

namespace posLibrary
{
	/// <summary>
	/// Model for SalesTaxTran
	/// </summary>
	public class SalesTaxTran
	{
        public long SalesTaxTranId { get; set; }
        public long linktoSalesMasterId { get; set; }
        public short linktoTaxMasterId { get; set; }
        public string TaxName { get; set; }
        public decimal TaxRate { get; set; }
		
		internal void SetClassObject(posSalesTaxTranDAL objSalesTaxTranDAL)
		{
			this.SalesTaxTranId = Convert.ToInt64(objSalesTaxTranDAL.SalesTaxTranId);
			this.linktoSalesMasterId = Convert.ToInt64(objSalesTaxTranDAL.linktoSalesMasterId);
			this.linktoTaxMasterId = Convert.ToInt16(objSalesTaxTranDAL.linktoTaxMasterId);
			this.TaxName = Convert.ToString(objSalesTaxTranDAL.TaxName);
			this.TaxRate = Convert.ToDecimal(objSalesTaxTranDAL.TaxRate);
		}

		internal static List<SalesTaxTran> SetListObject(List<posSalesTaxTranDAL> lstSalesTaxTranDAL)
		{
			List<SalesTaxTran> lstSalesTaxTran = new List<SalesTaxTran>();
			SalesTaxTran objSalesTaxTran = null;
			foreach (posSalesTaxTranDAL objSalesTaxTranDAL in lstSalesTaxTranDAL)
			{
				objSalesTaxTran = new SalesTaxTran();
				objSalesTaxTran.SalesTaxTranId = Convert.ToInt64(objSalesTaxTranDAL.SalesTaxTranId);
				objSalesTaxTran.linktoSalesMasterId = Convert.ToInt64(objSalesTaxTranDAL.linktoSalesMasterId);
				objSalesTaxTran.linktoTaxMasterId = Convert.ToInt16(objSalesTaxTranDAL.linktoTaxMasterId);
				objSalesTaxTran.TaxName = Convert.ToString(objSalesTaxTranDAL.TaxName);
				objSalesTaxTran.TaxRate = Convert.ToDecimal(objSalesTaxTranDAL.TaxRate);

				lstSalesTaxTran.Add(objSalesTaxTran);
			}
			return lstSalesTaxTran;
		}
	}
}
