using System;
using System.Collections.Generic;

namespace posLibrary
{
    /// <summary>
    /// Model for AppThemeMaster
    /// </summary>
    public class AppThemeMaster
    {
        #region Properties
        public int AppThemeMasterId { get; set; }
        public string LogoImageName { get; set; }
        public string ProfileImageName { get; set; }
        public string BackImageName1 { get; set; }
        public string BackImageName2 { get; set; }
        public string WelcomeBackImage { get; set; }
        public string ContactMap { get; set; }
        public string ColorPrimary { get; set; }
        public string ColorPrimaryDark { get; set; }
        public string ColorPrimaryLight { get; set; }
        public string ColorAccent { get; set; }
        public string ColorAccentDark { get; set; }
        public string ColorAccentLight { get; set; }
        public string ColorTextPrimary { get; set; }
        public string ColorFloatingButton { get; set; }
        public string ColorButtonRipple { get; set; }
        public string ColorCardView { get; set; }
        public string ColorCardViewRipple { get; set; }
        public string ColorCardText { get; set; }
        public string ColorHeaderText { get; set; }

        /// Extra
        #endregion

        internal void SetClassObject(posAppThemeMasterDAL objAppThemeMasterDAL)
        {
            string ImageRetrievePath = System.Configuration.ConfigurationManager.AppSettings["possImageRetrievePath"] + "/AppTheme/";

            this.AppThemeMasterId = Convert.ToInt32(objAppThemeMasterDAL.AppThemeMasterId);
            this.LogoImageName = ImageRetrievePath + Convert.ToString(objAppThemeMasterDAL.LogoImageName);
            this.ProfileImageName = ImageRetrievePath + Convert.ToString(objAppThemeMasterDAL.ProfileImageName);
            this.BackImageName1 = ImageRetrievePath + Convert.ToString(objAppThemeMasterDAL.BackImageName1);
            this.BackImageName2 = ImageRetrievePath + Convert.ToString(objAppThemeMasterDAL.BackImageName2);
            this.WelcomeBackImage= ImageRetrievePath + Convert.ToString(objAppThemeMasterDAL.WelcomeBackImage);
            this.ContactMap = Convert.ToString(objAppThemeMasterDAL.ContactMap);
            this.ColorPrimary = Convert.ToString(objAppThemeMasterDAL.ColorPrimary);
            this.ColorPrimaryDark = Convert.ToString(objAppThemeMasterDAL.ColorPrimaryDark);
            this.ColorPrimaryLight = Convert.ToString(objAppThemeMasterDAL.ColorPrimaryLight);
            this.ColorAccent = Convert.ToString(objAppThemeMasterDAL.ColorAccent);
            this.ColorAccentDark = Convert.ToString(objAppThemeMasterDAL.ColorAccentDark);
            this.ColorAccentLight = Convert.ToString(objAppThemeMasterDAL.ColorAccentLight);
            this.ColorTextPrimary = Convert.ToString(objAppThemeMasterDAL.ColorTextPrimary);
            this.ColorFloatingButton = Convert.ToString(objAppThemeMasterDAL.ColorFloatingButton);
            this.ColorButtonRipple = Convert.ToString(objAppThemeMasterDAL.ColorButtonRipple);
            this.ColorCardView = Convert.ToString(objAppThemeMasterDAL.ColorCardView);
            this.ColorCardViewRipple = Convert.ToString(objAppThemeMasterDAL.ColorCardViewRipple);
            this.ColorCardText = Convert.ToString(objAppThemeMasterDAL.ColorCardText);
            this.ColorHeaderText = Convert.ToString(objAppThemeMasterDAL.ColorHeaderText);
        }

        internal static List<AppThemeMaster> SetListObject(List<posAppThemeMasterDAL> lstAppThemeMasterDAL)
        {
            string ImageRetrievePath = System.Configuration.ConfigurationManager.AppSettings["possImageRetrievePath"] + "/AppTheme/";

            List<AppThemeMaster> lstAppThemeMaster = new List<AppThemeMaster>();
            AppThemeMaster objAppThemeMaster = null;
            foreach (posAppThemeMasterDAL objAppThemeMasterDAL in lstAppThemeMasterDAL)
            {
                objAppThemeMaster = new AppThemeMaster();
                objAppThemeMaster.AppThemeMasterId = Convert.ToInt32(objAppThemeMasterDAL.AppThemeMasterId);
                objAppThemeMaster.LogoImageName = ImageRetrievePath + Convert.ToString(objAppThemeMasterDAL.LogoImageName);
                objAppThemeMaster.ProfileImageName = ImageRetrievePath + Convert.ToString(objAppThemeMasterDAL.ProfileImageName);
                objAppThemeMaster.BackImageName1 = ImageRetrievePath + Convert.ToString(objAppThemeMasterDAL.BackImageName1);
                objAppThemeMaster.BackImageName2 = ImageRetrievePath + Convert.ToString(objAppThemeMasterDAL.BackImageName2);
                objAppThemeMaster.WelcomeBackImage = ImageRetrievePath + Convert.ToString(objAppThemeMasterDAL.WelcomeBackImage); 
                objAppThemeMaster.ContactMap = Convert.ToString(objAppThemeMasterDAL.ContactMap);
                objAppThemeMaster.ColorPrimary = Convert.ToString(objAppThemeMasterDAL.ColorPrimary);
                objAppThemeMaster.ColorPrimaryDark = Convert.ToString(objAppThemeMasterDAL.ColorPrimaryDark);
                objAppThemeMaster.ColorPrimaryLight = Convert.ToString(objAppThemeMasterDAL.ColorPrimaryLight);
                objAppThemeMaster.ColorAccent = Convert.ToString(objAppThemeMasterDAL.ColorAccent);
                objAppThemeMaster.ColorAccentDark = Convert.ToString(objAppThemeMasterDAL.ColorAccentDark);
                objAppThemeMaster.ColorAccentLight = Convert.ToString(objAppThemeMasterDAL.ColorAccentLight);
                objAppThemeMaster.ColorTextPrimary = Convert.ToString(objAppThemeMasterDAL.ColorTextPrimary);
                objAppThemeMaster.ColorFloatingButton = Convert.ToString(objAppThemeMasterDAL.ColorFloatingButton);
                objAppThemeMaster.ColorButtonRipple = Convert.ToString(objAppThemeMasterDAL.ColorButtonRipple);
                objAppThemeMaster.ColorCardView = Convert.ToString(objAppThemeMasterDAL.ColorCardView);
                objAppThemeMaster.ColorCardViewRipple = Convert.ToString(objAppThemeMasterDAL.ColorCardViewRipple);
                objAppThemeMaster.ColorCardText = Convert.ToString(objAppThemeMasterDAL.ColorCardText);
                objAppThemeMaster.ColorHeaderText = Convert.ToString(objAppThemeMasterDAL.ColorHeaderText);
                lstAppThemeMaster.Add(objAppThemeMaster);
            }
            return lstAppThemeMaster;
        }
    }
}
