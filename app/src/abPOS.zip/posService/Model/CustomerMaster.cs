using System;
using System.Collections.Generic;

namespace posLibrary
{
	/// <summary>
	/// Model for CustomerMaster
	/// </summary>
	public class CustomerMaster
	{

        public int CustomerMasterId { get; set; }
        public short? CustomerType { get; set; }
        public string ShortName { get; set; }
        public string CustomerName { get; set; }
        public string Description { get; set; }
        public string ContactPersonName { get; set; }
        public string Designation { get; set; }
        public string Address { get; set; }
        public string BirthDate { get; set; }
        public string AnniversaryDate { get; set; }
        public short? linktoCityMasterId { get; set; }
        public short? linktoAreaMasterId { get; set; }
        public string ZipCode { get; set; }
        public string Phone1 { get; set; }
        public bool IsPhone1DND { get; set; }
        public string Phone2 { get; set; }
        public bool? IsPhone2DND { get; set; }
        public string Email1 { get; set; }
        public string Email2 { get; set; }
        public string Fax { get; set; }
        public string ImageName { get; set; }
        public bool? IsFavourite { get; set; }
        public bool? IsCredit { get; set; }
        public double OpeningBalance { get; set; }
        public short CreditDays { get; set; }
        public double CreditBalance { get; set; }
        public double CreditLimit { get; set; }
        public short linktoBusinessMasterId { get; set; }
        public string CreateDateTime { get; set; }
        public short linktoUserMasterIdCreatedBy { get; set; }
        public string UpdateDateTime { get; set; }
        public short? linktoUserMasterIdUpdatedBy { get; set; }
        public bool IsEnabled { get; set; }
        public bool IsDeleted { get; set; }
        public bool IsSelected { get; set; }
        public int linktoDiscountMasterId { get; set; }
        public string OfferCode { get; set; }

        public string MembershipCardNumber { get; set; }
        public string MembershipCardExpiryDate { get; set; }
        public bool IsMembershipCardUsedFirstTime { get; set; }
        public short? linktoMembershipTypeMasterId { get; set; }
        public short TotalPoints { get; set; }
        public short linktoSourceMasterId { get; set; }
        public string LastLoginDateTime { get; set; }
        public short linkSourceMasterId { get; set; }
        public string Gender { get; set; }
        public string Password { get; set; }
        public string Remark { get; set; }

		/// Extra
        public string City { get; set; }
        public string Area { get; set; }
        public string OldPassword { get; set; }

		internal void SetClassObject(posCustomerMasterDAL objCustomerMasterDAL)
		{
			this.CustomerMasterId = Convert.ToInt32(objCustomerMasterDAL.CustomerMasterId);
			this.ShortName = Convert.ToString(objCustomerMasterDAL.ShortName);
			this.CustomerName = Convert.ToString(objCustomerMasterDAL.CustomerName);
			this.Description = Convert.ToString(objCustomerMasterDAL.Description);
			this.ContactPersonName = Convert.ToString(objCustomerMasterDAL.ContactPersonName);
			this.Designation = Convert.ToString(objCustomerMasterDAL.Designation);
			this.Phone1 = Convert.ToString(objCustomerMasterDAL.Phone1);
			this.IsPhone1DND = Convert.ToBoolean(objCustomerMasterDAL.IsPhone1DND);
			this.Phone2 = Convert.ToString(objCustomerMasterDAL.Phone2);
			if (objCustomerMasterDAL.IsPhone2DND != null)
			{
				this.IsPhone2DND = Convert.ToBoolean(objCustomerMasterDAL.IsPhone2DND.Value);
			}
			this.Email1 = Convert.ToString(objCustomerMasterDAL.Email1);
			this.Email2 = Convert.ToString(objCustomerMasterDAL.Email2);
			this.Fax = Convert.ToString(objCustomerMasterDAL.Fax);
			this.ImageName = Convert.ToString(objCustomerMasterDAL.ImageName);
            if (objCustomerMasterDAL.Birthdate != null)
            {
                this.BirthDate = objCustomerMasterDAL.Birthdate.Value.ToString("yyyy-MM-dd");
            }
			if (objCustomerMasterDAL.AnniversaryDate != null)
			{
				this.AnniversaryDate = objCustomerMasterDAL.AnniversaryDate.Value.ToString("yyyy-MM-dd");
			}
			this.CustomerType = Convert.ToInt16(objCustomerMasterDAL.CustomerType);
			this.IsFavourite = Convert.ToBoolean(objCustomerMasterDAL.IsFavourite);
			this.IsCredit = Convert.ToBoolean(objCustomerMasterDAL.IsCredit);
			this.OpeningBalance = Convert.ToDouble(objCustomerMasterDAL.OpeningBalance);
			this.CreditDays = Convert.ToInt16(objCustomerMasterDAL.CreditDays);
			this.CreditBalance = Convert.ToDouble(objCustomerMasterDAL.CreditBalance);
			this.CreditLimit = Convert.ToDouble(objCustomerMasterDAL.CreditLimit);
			this.linktoBusinessMasterId = Convert.ToInt16(objCustomerMasterDAL.linktoBusinessMasterId);
			this.CreateDateTime = objCustomerMasterDAL.CreateDateTime.ToString("s");
			this.linktoUserMasterIdCreatedBy = Convert.ToInt16(objCustomerMasterDAL.linktoUserMasterIdCreatedBy);
			if (objCustomerMasterDAL.UpdateDateTime != null)
			{
				this.UpdateDateTime = objCustomerMasterDAL.UpdateDateTime.Value.ToString("s");
			}
			if (objCustomerMasterDAL.linktoUserMasterIdUpdatedBy != null)
			{
				this.linktoUserMasterIdUpdatedBy = Convert.ToInt16(objCustomerMasterDAL.linktoUserMasterIdUpdatedBy.Value);
			}
			this.IsEnabled = Convert.ToBoolean(objCustomerMasterDAL.IsEnabled);
			this.IsDeleted = Convert.ToBoolean(objCustomerMasterDAL.IsDeleted);
            if (objCustomerMasterDAL.linktoMembershipTypeMasterId != null)
            {
                this.linktoMembershipTypeMasterId = Convert.ToInt16(objCustomerMasterDAL.linktoMembershipTypeMasterId.Value);
            }
            this.Gender = Convert.ToString(objCustomerMasterDAL.Gender);
            this.Password = Convert.ToString(objCustomerMasterDAL.Password);
            this.linktoSourceMasterId = Convert.ToInt16(objCustomerMasterDAL.linktoSourceMasterId);
            if (objCustomerMasterDAL.LastLoginDateTime != null)
            {
                this.LastLoginDateTime = objCustomerMasterDAL.LastLoginDateTime.Value.ToString("s");
            }
            this.Remark = Convert.ToString(objCustomerMasterDAL.Remark);
            this.Area = Convert.ToString(objCustomerMasterDAL.Area);
            this.City = Convert.ToString(objCustomerMasterDAL.City);
            
            /// Extra
		}

		internal static List<CustomerMaster> SetListObject(List<posCustomerMasterDAL> lstCustomerMasterDAL)
		{
			List<CustomerMaster> lstCustomerMaster = new List<CustomerMaster>();
			CustomerMaster objCustomerMaster = null;
			foreach (posCustomerMasterDAL objCustomerMasterDAL in lstCustomerMasterDAL)
			{
				objCustomerMaster = new CustomerMaster();
				objCustomerMaster.CustomerMasterId = Convert.ToInt32(objCustomerMasterDAL.CustomerMasterId);
				objCustomerMaster.ShortName = Convert.ToString(objCustomerMasterDAL.ShortName);
				objCustomerMaster.CustomerName = Convert.ToString(objCustomerMasterDAL.CustomerName);
				objCustomerMaster.Description = Convert.ToString(objCustomerMasterDAL.Description);
				objCustomerMaster.ContactPersonName = Convert.ToString(objCustomerMasterDAL.ContactPersonName);
				objCustomerMaster.Designation = Convert.ToString(objCustomerMasterDAL.Designation);
				objCustomerMaster.Phone1 = Convert.ToString(objCustomerMasterDAL.Phone1);
				objCustomerMaster.IsPhone1DND = Convert.ToBoolean(objCustomerMasterDAL.IsPhone1DND);
				objCustomerMaster.Phone2 = Convert.ToString(objCustomerMasterDAL.Phone2);
				if (objCustomerMasterDAL.IsPhone2DND != null)
				{
					objCustomerMaster.IsPhone2DND = Convert.ToBoolean(objCustomerMasterDAL.IsPhone2DND.Value);
				}
				objCustomerMaster.Email1 = Convert.ToString(objCustomerMasterDAL.Email1);
				objCustomerMaster.Email2 = Convert.ToString(objCustomerMasterDAL.Email2);
				objCustomerMaster.Fax = Convert.ToString(objCustomerMasterDAL.Fax);
				objCustomerMaster.ImageName = Convert.ToString(objCustomerMasterDAL.ImageName);
                if (objCustomerMasterDAL.Birthdate != null)
                {
                   objCustomerMaster.BirthDate = objCustomerMasterDAL.Birthdate.Value.ToString("yyyy-MM-dd");
                }
                if (objCustomerMasterDAL.AnniversaryDate != null)
                {
                    objCustomerMaster.AnniversaryDate = objCustomerMasterDAL.AnniversaryDate.Value.ToString("yyyy-MM-dd");
                }
                objCustomerMaster.CustomerType = Convert.ToInt16(objCustomerMasterDAL.CustomerType);
                objCustomerMaster.IsFavourite = Convert.ToBoolean(objCustomerMasterDAL.IsFavourite);
                objCustomerMaster.IsCredit = Convert.ToBoolean(objCustomerMasterDAL.IsCredit);
                objCustomerMaster.OpeningBalance = Convert.ToDouble(objCustomerMasterDAL.OpeningBalance);
                objCustomerMaster.CreditDays = Convert.ToInt16(objCustomerMasterDAL.CreditDays);
                objCustomerMaster.CreditBalance = Convert.ToDouble(objCustomerMasterDAL.CreditBalance);
                objCustomerMaster.CreditLimit = Convert.ToDouble(objCustomerMasterDAL.CreditLimit);
                objCustomerMaster.linktoBusinessMasterId = Convert.ToInt16(objCustomerMasterDAL.linktoBusinessMasterId);
                objCustomerMaster.CreateDateTime = objCustomerMasterDAL.CreateDateTime.ToString("s");
                objCustomerMaster.linktoUserMasterIdCreatedBy = Convert.ToInt16(objCustomerMasterDAL.linktoUserMasterIdCreatedBy);
                if (objCustomerMasterDAL.UpdateDateTime != null)
                {
                    objCustomerMaster.UpdateDateTime = objCustomerMasterDAL.UpdateDateTime.Value.ToString("s");
                }
                if (objCustomerMasterDAL.linktoUserMasterIdUpdatedBy != null)
                {
                    objCustomerMaster.linktoUserMasterIdUpdatedBy = Convert.ToInt16(objCustomerMasterDAL.linktoUserMasterIdUpdatedBy.Value);
                }
                objCustomerMaster.IsEnabled = Convert.ToBoolean(objCustomerMasterDAL.IsEnabled);
                objCustomerMaster.IsDeleted = Convert.ToBoolean(objCustomerMasterDAL.IsDeleted);
                if (objCustomerMasterDAL.linktoMembershipTypeMasterId != null)
                {
                    objCustomerMaster.linktoMembershipTypeMasterId = Convert.ToInt16(objCustomerMasterDAL.linktoMembershipTypeMasterId.Value);
                }
                objCustomerMaster.MembershipCardNumber = Convert.ToString(objCustomerMasterDAL.MembershipCardNumber);
                objCustomerMaster.Gender = Convert.ToString(objCustomerMasterDAL.Gender);
                objCustomerMaster.Password = Convert.ToString(objCustomerMasterDAL.Password);
                objCustomerMaster.linktoSourceMasterId = Convert.ToInt16(objCustomerMasterDAL.linktoSourceMasterId);
                if (objCustomerMasterDAL.LastLoginDateTime != null)
                {
                    objCustomerMaster.LastLoginDateTime = objCustomerMasterDAL.LastLoginDateTime.Value.ToString("s");
                }
                objCustomerMaster.Remark = Convert.ToString(objCustomerMasterDAL.Remark);

                ///// Extra
                objCustomerMaster.Area = Convert.ToString(objCustomerMasterDAL.Area);
                objCustomerMaster.City = Convert.ToString(objCustomerMasterDAL.City);
				lstCustomerMaster.Add(objCustomerMaster);
			}
			return lstCustomerMaster;
		}
	}
}
