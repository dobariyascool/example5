using System;
using System.Collections.Generic;

namespace posLibrary
{
	/// <summary>
	/// Model for FeedbackQuestionMaster
	/// </summary>
	public class FeedbackQuestionMaster
	{

        public int FeedbackQuestionMasterId { get; set; }
        public short linktoBusinessMasterId { get; set; }
        public string FeedbackQuestion { get; set; }
        public short QuestionType { get; set; }
        public short? linktoFeedbackQuestionGroupMasterId { get; set; }
        public int? SortOrder { get; set; }
        public bool IsEnabled { get; set; }
        public bool IsDeleted { get; set; }
        public List<posFeedbackAnswerMasterDAL> lstFeedbackAnswerMasterDAL { get; set; }

        /// Extra
        public string QuestionTypeName { get; set; }
        public string QuestionGroupName { get; set; }
        

		internal void SetClassObject(posFeedbackQuestionMasterDAL objFeedbackQuestionMasterDAL)
		{
			this.FeedbackQuestionMasterId = Convert.ToInt32(objFeedbackQuestionMasterDAL.FeedbackQuestionMasterId);
			this.linktoBusinessMasterId = Convert.ToInt16(objFeedbackQuestionMasterDAL.linktoBusinessMasterId);
			this.FeedbackQuestion = Convert.ToString(objFeedbackQuestionMasterDAL.FeedbackQuestion);
			this.QuestionType = Convert.ToInt16(objFeedbackQuestionMasterDAL.QuestionType);
			if (objFeedbackQuestionMasterDAL.SortOrder != null)
			{
				this.SortOrder = Convert.ToInt32(objFeedbackQuestionMasterDAL.SortOrder.Value);
			}
			this.IsEnabled = Convert.ToBoolean(objFeedbackQuestionMasterDAL.IsEnabled);
			this.IsDeleted = Convert.ToBoolean(objFeedbackQuestionMasterDAL.IsDeleted);
            if (objFeedbackQuestionMasterDAL != null)
            {
                this.linktoFeedbackQuestionGroupMasterId = Convert.ToInt16(objFeedbackQuestionMasterDAL.linktoFeedbackQuestionGroupMasterId);
                this.QuestionGroupName = Convert.ToString(objFeedbackQuestionMasterDAL.QuestionGroupName);
            }

		}

		internal static List<FeedbackQuestionMaster> SetListObject(List<posFeedbackQuestionMasterDAL> lstFeedbackQuestionMasterDAL)
		{
			List<FeedbackQuestionMaster> lstFeedbackQuestionMaster = new List<FeedbackQuestionMaster>();
			FeedbackQuestionMaster objFeedbackQuestionMaster = null;
			foreach (posFeedbackQuestionMasterDAL objFeedbackQuestionMasterDAL in lstFeedbackQuestionMasterDAL)
			{
				objFeedbackQuestionMaster = new FeedbackQuestionMaster();
				objFeedbackQuestionMaster.FeedbackQuestionMasterId = Convert.ToInt32(objFeedbackQuestionMasterDAL.FeedbackQuestionMasterId);
				objFeedbackQuestionMaster.linktoBusinessMasterId = Convert.ToInt16(objFeedbackQuestionMasterDAL.linktoBusinessMasterId);
				objFeedbackQuestionMaster.FeedbackQuestion = Convert.ToString(objFeedbackQuestionMasterDAL.FeedbackQuestion);
				objFeedbackQuestionMaster.QuestionType = Convert.ToInt16(objFeedbackQuestionMasterDAL.QuestionType);
				if (objFeedbackQuestionMasterDAL.SortOrder != null)
				{
					objFeedbackQuestionMaster.SortOrder = Convert.ToInt32(objFeedbackQuestionMasterDAL.SortOrder.Value);
				}
				objFeedbackQuestionMaster.IsEnabled = Convert.ToBoolean(objFeedbackQuestionMasterDAL.IsEnabled);
				objFeedbackQuestionMaster.IsDeleted = Convert.ToBoolean(objFeedbackQuestionMasterDAL.IsDeleted);
                if (objFeedbackQuestionMasterDAL != null)
                {
                    objFeedbackQuestionMaster.linktoFeedbackQuestionGroupMasterId = Convert.ToInt16(objFeedbackQuestionMasterDAL.linktoFeedbackQuestionGroupMasterId);
                    objFeedbackQuestionMaster.QuestionGroupName = Convert.ToString(objFeedbackQuestionMasterDAL.QuestionGroupName);
                }
				lstFeedbackQuestionMaster.Add(objFeedbackQuestionMaster);
			}
			return lstFeedbackQuestionMaster;
		}
	}
}
