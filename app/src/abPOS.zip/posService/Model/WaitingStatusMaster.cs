using System;
using System.Collections.Generic;
using posLibrary;

namespace posService.Model
{
	/// <summary>
	/// Model for WaitingStatusMaster
	/// </summary>
	public class WaitingStatusMaster
	{
        public short WaitingStatusMasterId { get; set; }
        public string WaitingStatus { get; set; }
        public string StatusColor { get; set; }

		internal void SetClassObject(posWaitingStatusMasterDAL objWaitingStatusMasterDAL)
		{
			this.WaitingStatusMasterId = Convert.ToInt16(objWaitingStatusMasterDAL.WaitingStatusMasterId);
			this.WaitingStatus = Convert.ToString(objWaitingStatusMasterDAL.WaitingStatus);
			this.StatusColor = Convert.ToString(objWaitingStatusMasterDAL.StatusColor);
		}

		internal static List<WaitingStatusMaster> SetListObject(List<posWaitingStatusMasterDAL> lstWaitingStatusMasterDAL)
		{
			List<WaitingStatusMaster> lstWaitingStatusMaster = new List<WaitingStatusMaster>();
			WaitingStatusMaster objWaitingStatusMaster = null;
			foreach (posWaitingStatusMasterDAL objWaitingStatusMasterDAL in lstWaitingStatusMasterDAL)
			{
				objWaitingStatusMaster = new WaitingStatusMaster();
				objWaitingStatusMaster.WaitingStatusMasterId = Convert.ToInt16(objWaitingStatusMasterDAL.WaitingStatusMasterId);
				objWaitingStatusMaster.WaitingStatus = Convert.ToString(objWaitingStatusMasterDAL.WaitingStatus);
				objWaitingStatusMaster.StatusColor = Convert.ToString(objWaitingStatusMasterDAL.StatusColor);
				lstWaitingStatusMaster.Add(objWaitingStatusMaster);
			}
			return lstWaitingStatusMaster;
		}
	}
}
