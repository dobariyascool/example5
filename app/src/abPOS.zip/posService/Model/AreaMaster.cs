﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using posLibrary;

namespace posService.Model
{
    public class AreaMaster
    {

        public int AreaMasterId { get; set; }
        public string AreaName { get; set; }
        public string ZipCode { get; set; }
        public int linktoCityMasterId { get; set; }
        public bool IsEnabled { get; set; }

        /// Extra
        public string City { get; set; }

        internal void SetClassObject(posAreaMasterDAL objAreaMasterDAL)
        {
            this.AreaMasterId = Convert.ToInt32(objAreaMasterDAL.AreaMasterId);
            this.AreaName = Convert.ToString(objAreaMasterDAL.AreaName);
            this.ZipCode = Convert.ToString(objAreaMasterDAL.ZipCode);
            this.linktoCityMasterId = Convert.ToInt32(objAreaMasterDAL.linktoCityMasterId);
            this.IsEnabled = Convert.ToBoolean(objAreaMasterDAL.IsEnabled);
           
            /// Extra
            this.City = Convert.ToString(objAreaMasterDAL.CityName );
        }

        internal static List<AreaMaster> SetListObject(List<posAreaMasterDAL> lstAreaMasterDAL)
        {
            List<AreaMaster> lstAreaMaster = new List<AreaMaster>();
            AreaMaster objAreaMaster = null;
            foreach (posAreaMasterDAL objAreaMasterDAL in lstAreaMasterDAL)
            {
                objAreaMaster = new AreaMaster();
                objAreaMaster.AreaMasterId = Convert.ToInt32(objAreaMasterDAL.AreaMasterId);
                objAreaMaster.AreaName = Convert.ToString(objAreaMasterDAL.AreaName);
                objAreaMaster.ZipCode = Convert.ToString(objAreaMasterDAL.ZipCode);
                objAreaMaster.linktoCityMasterId = Convert.ToInt32(objAreaMasterDAL.linktoCityMasterId);
                objAreaMaster.IsEnabled = Convert.ToBoolean(objAreaMasterDAL.IsEnabled);

                /// Extra
                objAreaMaster.City = Convert.ToString(objAreaMasterDAL.CityName);
                lstAreaMaster.Add(objAreaMaster);
            }
            return lstAreaMaster;
        }
    }
}