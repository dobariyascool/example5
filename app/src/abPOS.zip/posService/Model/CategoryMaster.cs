﻿using System;
using System.Collections.Generic;
using posLibrary;

namespace posService.Model
{
    /// <summary>
    /// Model for CategoryMaster
    /// </summary>
    public class CategoryMaster
    {
        public short CategoryMasterId { get; set; }
        public string CategoryName { get; set; }
        public short linktoCategoryMasterIdParent { get; set; }
        public string ImageName { get; set; }
        public string CategoryColor { get; set; }
        public string Description { get; set; }
        //public bool IsNew { get; set; }
        public short linktoBusinessMasterId { get; set; }
        public short SortOrder { get; set; }
        public bool IsEnabled { get; set; }
        
        ///// Extra
        //public string Category { get; set; }


        internal void SetClassObject(posCategoryMasterDAL objCategoryMasterDAL)
        {
            this.CategoryMasterId = Convert.ToInt16(objCategoryMasterDAL.CategoryMasterId);
            this.CategoryName = Convert.ToString(objCategoryMasterDAL.CategoryName);
            if (objCategoryMasterDAL.linktoCategoryMasterIdParent != null)
            {
                this.linktoCategoryMasterIdParent = Convert.ToInt16(objCategoryMasterDAL.linktoCategoryMasterIdParent.Value);
            }
            this.ImageName = Convert.ToString(objCategoryMasterDAL.ImageName);
            this.CategoryColor = Convert.ToString(objCategoryMasterDAL.CategoryColor);
            this.Description = Convert.ToString(objCategoryMasterDAL.Description);
            //this.IsNew = Convert.ToBoolean(objCategoryMasterDAL.IsNew);
            this.linktoBusinessMasterId = Convert.ToInt16(objCategoryMasterDAL.linktoBusinessMasterId);
            if (objCategoryMasterDAL.SortOrder != null)
            {
                this.SortOrder = Convert.ToInt16(objCategoryMasterDAL.SortOrder.Value);
            }
            this.IsEnabled = Convert.ToBoolean(objCategoryMasterDAL.IsEnabled);
          
            ///// Extra
            //this.Category = Convert.ToString(objCategoryMasterDAL.Category);
        }

        internal static List<CategoryMaster> SetListObject(List<posCategoryMasterDAL> lstCategoryMasterDAL)
        {
            List<CategoryMaster> lstCategoryMaster = new List<CategoryMaster>();
            CategoryMaster objCategoryMaster = null;
            foreach (posCategoryMasterDAL objCategoryMasterDAL in lstCategoryMasterDAL)
            {
                objCategoryMaster = new CategoryMaster();
                objCategoryMaster.CategoryMasterId = Convert.ToInt16(objCategoryMasterDAL.CategoryMasterId);
                objCategoryMaster.CategoryName = Convert.ToString(objCategoryMasterDAL.CategoryName);
                if (objCategoryMasterDAL.linktoCategoryMasterIdParent != null)
                {
                    objCategoryMaster.linktoCategoryMasterIdParent = Convert.ToInt16(objCategoryMasterDAL.linktoCategoryMasterIdParent.Value);
                }
                objCategoryMaster.ImageName = Convert.ToString(objCategoryMasterDAL.ImageName);
                objCategoryMaster.CategoryColor = Convert.ToString(objCategoryMasterDAL.CategoryColor);
                objCategoryMaster.Description = Convert.ToString(objCategoryMasterDAL.Description);
                //objCategoryMaster.IsNew = Convert.ToBoolean(objCategoryMasterDAL.IsNew);
                objCategoryMaster.linktoBusinessMasterId = Convert.ToInt16(objCategoryMasterDAL.linktoBusinessMasterId);
                if (objCategoryMasterDAL.SortOrder != null)
                {
                    objCategoryMaster.SortOrder = Convert.ToInt16(objCategoryMasterDAL.SortOrder.Value);
                }
                objCategoryMaster.IsEnabled = Convert.ToBoolean(objCategoryMasterDAL.IsEnabled);
                ///// Extra
                //objCategoryMaster.Category = Convert.ToString(objCategoryMasterDAL.Category);
                lstCategoryMaster.Add(objCategoryMaster);
            }
            return lstCategoryMaster;
        }
    }
}
