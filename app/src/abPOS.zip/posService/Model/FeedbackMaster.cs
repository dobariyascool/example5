﻿using System;
using System.Collections.Generic;
using posLibrary;


namespace posService.Model
{
    /// <summary>
    /// Model for FeedbackMaster
    /// </summary>
    public class FeedbackMaster
    {
        public int FeedbackMasterId { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }
        public string Phone { get; set; }
        public string Feedback { get; set; }
        public string FeedbackDateTime { get; set; }
        public short linktoFeedbackTypeMasterId { get; set; }
        public int? linktoCustomerMasterId { get; set; }
        public short linktoBusinessMasterId { get; set; }
        
        /// Extra
        public string FeedbackType { get; set; }
        public string Business { get; set; }
        public List<posFeedbackTranDAL> lstFeedbackTranDAL { get; set; }

        internal void SetClassObject(posFeedbackMasterDAL objFeedbackMasterDAL)
        {
            this.FeedbackMasterId = Convert.ToInt32(objFeedbackMasterDAL.FeedbackMasterId);
            this.Name = Convert.ToString(objFeedbackMasterDAL.Name);
            this.Email = Convert.ToString(objFeedbackMasterDAL.Email);
            this.Phone = Convert.ToString(objFeedbackMasterDAL.Phone);
            this.Feedback = Convert.ToString(objFeedbackMasterDAL.Feedback);
            this.FeedbackDateTime = objFeedbackMasterDAL.FeedbackDateTime.ToString("s");
            this.linktoFeedbackTypeMasterId = Convert.ToInt16(objFeedbackMasterDAL.linktoFeedbackTypeMasterId);
            if (objFeedbackMasterDAL.linktoCustomerMasterId != null)
            {
                this.linktoCustomerMasterId = Convert.ToInt32(objFeedbackMasterDAL.linktoCustomerMasterId.Value);
            }
            this.linktoBusinessMasterId = Convert.ToInt16(objFeedbackMasterDAL.linktoBusinessMasterId);

            /// Extra
            this.FeedbackType = Convert.ToString(objFeedbackMasterDAL.FeedbackType);
        }

        internal static List<FeedbackMaster> SetListObject(List<posFeedbackMasterDAL> lstFeedbackMasterDAL)
        {
            List<FeedbackMaster> lstFeedbackMaster = new List<FeedbackMaster>();
            FeedbackMaster objFeedbackMaster = null;
            foreach (posFeedbackMasterDAL objFeedbackMasterDAL in lstFeedbackMasterDAL)
            {
                objFeedbackMaster = new FeedbackMaster();
                objFeedbackMaster.FeedbackMasterId = Convert.ToInt32(objFeedbackMasterDAL.FeedbackMasterId);
                objFeedbackMaster.Name = Convert.ToString(objFeedbackMasterDAL.Name);
                objFeedbackMaster.Email = Convert.ToString(objFeedbackMasterDAL.Email);
                objFeedbackMaster.Phone = Convert.ToString(objFeedbackMasterDAL.Phone);
                objFeedbackMaster.Feedback = Convert.ToString(objFeedbackMasterDAL.Feedback);
                objFeedbackMaster.FeedbackDateTime = objFeedbackMasterDAL.FeedbackDateTime.ToString("s");
                objFeedbackMaster.linktoFeedbackTypeMasterId = Convert.ToInt16(objFeedbackMasterDAL.linktoFeedbackTypeMasterId);
                if (objFeedbackMasterDAL.linktoCustomerMasterId != null)
                {
                    objFeedbackMaster.linktoCustomerMasterId = Convert.ToInt32(objFeedbackMasterDAL.linktoCustomerMasterId.Value);
                }
                objFeedbackMaster.linktoBusinessMasterId = Convert.ToInt16(objFeedbackMasterDAL.linktoBusinessMasterId);

                /// Extra
                objFeedbackMaster.FeedbackType = Convert.ToString(objFeedbackMasterDAL.FeedbackType);
                lstFeedbackMaster.Add(objFeedbackMaster);
            }
            return lstFeedbackMaster;
        }
    }
}