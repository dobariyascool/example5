using System;
using System.Collections.Generic;

namespace posLibrary
{
	/// <summary>
	/// Model for OfferMaster
	/// </summary>
	public class OfferMaster
	{

        public int OfferMasterId { get; set; }
        public short linktoOfferTypeMasterId { get; set; }
        public string OfferTitle { get; set; }
        public string OfferContent { get; set; }
        public string FromDate { get; set; }
        public string ToDate { get; set; }
        public string FromTime { get; set; }
        public string ToTime { get; set; }
        public double? MinimumBillAmount { get; set; }
        public double Discount { get; set; }
        public bool IsDiscountPercentage { get; set; }
        public int? RedeemCount { get; set; }
        public string OfferCode { get; set; }
        public string ImagePhysicalName { get; set; }
        public string CreateDateTime { get; set; }
        public short linktoUserMasterIdCreatedBy { get; set; }
        public string UpdateDateTime { get; set; }
        public short? linktoUserMasterIdUpdatedBy { get; set; }
        public short linktoBusinessMasterId { get; set; }
        public int linktoCustomerMasterId { get; set; }
        public string TermsAndConditions { get; set; }
        public bool IsEnabled { get; set; }
        public bool IsDeleted { get; set; }
        public bool IsForCustomers { get; set; }
        public string linktoOrderTypeMasterIds { get; set; }
        public int? BuyItemCount { get; set; }
        public int? GetItemCount { get; set; }
        public bool? IsOnline { get; set; }
        public bool? IsForApp { get; set; }

		/// Extra
        public string OfferType { get; set; }
		public string Business { get; set; }
		public short Counter { get; set; }
        public string xs_ImagePhysicalName { get; set; }
        public string sm_ImagePhysicalName { get; set; }
        public string md_ImagePhysicalName { get; set; }
        public string lg_ImagePhysicalName { get; set; }
        public string xl_ImagePhysicalName { get; set; }
        public string ValidDays { get; set; }
        public string ValidItems { get; set; }
        public string ValidBuyItems { get; set; }
        public string ValidGetItems { get; set; }
		//public short OrderType { get; set; }

		internal void SetClassObject(posOfferMasterDAL objOfferMasterDAL)
		{
            string ImageRetrievePath = System.Configuration.ConfigurationManager.AppSettings["possImageRetrievePath"] + "/Offer/";

			this.OfferMasterId = Convert.ToInt32(objOfferMasterDAL.OfferMasterId);
			this.linktoOfferTypeMasterId = Convert.ToInt16(objOfferMasterDAL.linktoOfferTypeMasterId);
			this.OfferTitle = Convert.ToString(objOfferMasterDAL.OfferTitle);
			this.OfferContent = Convert.ToString(objOfferMasterDAL.OfferContent);
			if (objOfferMasterDAL.FromDate != null)
			{
				this.FromDate = objOfferMasterDAL.FromDate.Value.ToString("yyyy-MM-dd");
			}
			if (objOfferMasterDAL.ToDate != null)
			{
				this.ToDate = objOfferMasterDAL.ToDate.Value.ToString("yyyy-MM-dd");
			}
			if (objOfferMasterDAL.FromTime != null)
			{
				this.FromTime = new DateTime().Add(objOfferMasterDAL.FromTime.Value).ToString("HH:mm:ss");
			}
			if (objOfferMasterDAL.ToTime != null)
			{
				this.ToTime = new DateTime().Add(objOfferMasterDAL.ToTime.Value).ToString("HH:mm:ss");
			}
			if (objOfferMasterDAL.MinimumBillAmount != null)
			{
				this.MinimumBillAmount = Convert.ToDouble(objOfferMasterDAL.MinimumBillAmount.Value);
			}
			this.Discount = Convert.ToDouble(objOfferMasterDAL.Discount);
            this.IsDiscountPercentage = Convert.ToBoolean(objOfferMasterDAL.IsDiscountPercentage);
			if (objOfferMasterDAL.RedeemCount != null)
			{
				this.RedeemCount = Convert.ToInt32(objOfferMasterDAL.RedeemCount.Value);
			}
			this.OfferCode = Convert.ToString(objOfferMasterDAL.OfferCode);
            if (objOfferMasterDAL.ImagePhysicalName != null && !objOfferMasterDAL.ImagePhysicalName.Equals(""))
            {
                this.ImagePhysicalName = Convert.ToString(ImageRetrievePath + objOfferMasterDAL.ImagePhysicalName);
            }
            if (objOfferMasterDAL.xs_ImagePhysicalName != null && !objOfferMasterDAL.xs_ImagePhysicalName.Equals("img/NoImage.png"))
            {
                this.ImagePhysicalName = Convert.ToString(ImageRetrievePath + objOfferMasterDAL.ImagePhysicalName);

                this.xs_ImagePhysicalName = Convert.ToString(ImageRetrievePath + objOfferMasterDAL.xs_ImagePhysicalName);
                this.sm_ImagePhysicalName = Convert.ToString(ImageRetrievePath + objOfferMasterDAL.sm_ImagePhysicalName);
                this.md_ImagePhysicalName = Convert.ToString(ImageRetrievePath + objOfferMasterDAL.md_ImagePhysicalName);
                this.lg_ImagePhysicalName = Convert.ToString(ImageRetrievePath + objOfferMasterDAL.lg_ImagePhysicalName);
                this.xl_ImagePhysicalName = Convert.ToString(ImageRetrievePath + objOfferMasterDAL.xl_ImagePhysicalName);

            }
			this.CreateDateTime = objOfferMasterDAL.CreateDateTime.ToString("s");
			this.linktoUserMasterIdCreatedBy = Convert.ToInt16(objOfferMasterDAL.linktoUserMasterIdCreatedBy);
			if (objOfferMasterDAL.UpdateDateTime != null)
			{
				this.UpdateDateTime = objOfferMasterDAL.UpdateDateTime.Value.ToString("s");
			}
			if (objOfferMasterDAL.linktoUserMasterIdUpdatedBy != null)
			{
				this.linktoUserMasterIdUpdatedBy = Convert.ToInt16(objOfferMasterDAL.linktoUserMasterIdUpdatedBy.Value);
			}
			this.linktoBusinessMasterId = Convert.ToInt16(objOfferMasterDAL.linktoBusinessMasterId);
            this.linktoCustomerMasterId = objOfferMasterDAL.linktoCustomerMasterId;
			this.TermsAndConditions = Convert.ToString(objOfferMasterDAL.TermsAndConditions);
			this.IsEnabled = Convert.ToBoolean(objOfferMasterDAL.IsEnabled);
			this.IsDeleted = Convert.ToBoolean(objOfferMasterDAL.IsDeleted);
			this.IsForCustomers = Convert.ToBoolean(objOfferMasterDAL.IsForCustomers);
		    this.BuyItemCount = Convert.ToInt32(objOfferMasterDAL.BuyItemCount);
		    this.GetItemCount = Convert.ToInt32(objOfferMasterDAL.GetItemCount);
		    this.linktoOrderTypeMasterIds = Convert.ToString(objOfferMasterDAL.linktoOrderTypeMasterIds);
			

			/// Extra
			this.OfferType = Convert.ToString(objOfferMasterDAL.OfferType);
			this.Business = Convert.ToString(objOfferMasterDAL.Business);
            this.ValidBuyItems = objOfferMasterDAL.ValidBuyItems;
            this.ValidDays = objOfferMasterDAL.ValidDays;
            this.ValidGetItems = objOfferMasterDAL.ValidGetItems;
            this.ValidItems = objOfferMasterDAL.ValidItems;
            this.IsForApp = Convert.ToBoolean(objOfferMasterDAL.IsForApp);
            this.IsOnline = Convert.ToBoolean(objOfferMasterDAL.IsOnline);
		}

		internal static List<OfferMaster> SetListObject(List<posOfferMasterDAL> lstOfferMasterDAL)
		{
           
			List<OfferMaster> lstOfferMaster = new List<OfferMaster>();
			OfferMaster objOfferMaster = null;

            string ImageRetrievePath = System.Configuration.ConfigurationManager.AppSettings["possImageRetrievePath"] + "/Offer/";

			foreach (posOfferMasterDAL objOfferMasterDAL in lstOfferMasterDAL)
			{
				objOfferMaster = new OfferMaster();
				objOfferMaster.OfferMasterId = Convert.ToInt32(objOfferMasterDAL.OfferMasterId);
				objOfferMaster.linktoOfferTypeMasterId = Convert.ToInt16(objOfferMasterDAL.linktoOfferTypeMasterId);
				objOfferMaster.OfferTitle = Convert.ToString(objOfferMasterDAL.OfferTitle);
				objOfferMaster.OfferContent = Convert.ToString(objOfferMasterDAL.OfferContent);
				if (objOfferMasterDAL.FromDate != null)
				{
					objOfferMaster.FromDate = objOfferMasterDAL.FromDate.Value.ToString("yyyy-MM-dd");
				}
				if (objOfferMasterDAL.ToDate != null)
				{
					objOfferMaster.ToDate = objOfferMasterDAL.ToDate.Value.ToString("yyyy-MM-dd");
				}
				if (objOfferMasterDAL.FromTime != null)
				{
                    objOfferMaster.FromTime = new DateTime().Add(objOfferMasterDAL.FromTime.Value).ToString("HH:mm:ss");
				}
				if (objOfferMasterDAL.ToTime != null)
				{
                    objOfferMaster.ToTime = new DateTime().Add(objOfferMasterDAL.ToTime.Value).ToString("HH:mm:ss");
				}
				if (objOfferMasterDAL.MinimumBillAmount != null)
				{
					objOfferMaster.MinimumBillAmount = Convert.ToDouble(objOfferMasterDAL.MinimumBillAmount.Value);
				}
				objOfferMaster.Discount = Convert.ToDouble(objOfferMasterDAL.Discount);
				objOfferMaster.IsDiscountPercentage = Convert.ToBoolean(objOfferMasterDAL.IsDiscountPercentage);
				if (objOfferMasterDAL.RedeemCount != null)
				{
					objOfferMaster.RedeemCount = Convert.ToInt32(objOfferMasterDAL.RedeemCount.Value);
				}
				objOfferMaster.OfferCode = Convert.ToString(objOfferMasterDAL.OfferCode);
                if (!objOfferMasterDAL.xs_ImagePhysicalName.Equals("img/NoImage.png"))
                {
                    objOfferMaster.ImagePhysicalName = Convert.ToString(ImageRetrievePath + objOfferMasterDAL.ImagePhysicalName);

                    objOfferMaster.xs_ImagePhysicalName = Convert.ToString(ImageRetrievePath + objOfferMasterDAL.xs_ImagePhysicalName);
                    objOfferMaster.sm_ImagePhysicalName = Convert.ToString(ImageRetrievePath + objOfferMasterDAL.sm_ImagePhysicalName);
                    objOfferMaster.md_ImagePhysicalName = Convert.ToString(ImageRetrievePath + objOfferMasterDAL.md_ImagePhysicalName);
                    objOfferMaster.lg_ImagePhysicalName = Convert.ToString(ImageRetrievePath + objOfferMasterDAL.lg_ImagePhysicalName);
                    objOfferMaster.xl_ImagePhysicalName = Convert.ToString(ImageRetrievePath + objOfferMasterDAL.xl_ImagePhysicalName);

                }
				objOfferMaster.CreateDateTime = objOfferMasterDAL.CreateDateTime.ToString("s");
				objOfferMaster.linktoUserMasterIdCreatedBy = Convert.ToInt16(objOfferMasterDAL.linktoUserMasterIdCreatedBy);
				if (objOfferMasterDAL.UpdateDateTime != null)
				{
					objOfferMaster.UpdateDateTime = objOfferMasterDAL.UpdateDateTime.Value.ToString("s");
				}
				if (objOfferMasterDAL.linktoUserMasterIdUpdatedBy != null)
				{
					objOfferMaster.linktoUserMasterIdUpdatedBy = Convert.ToInt16(objOfferMasterDAL.linktoUserMasterIdUpdatedBy.Value);
				}
				objOfferMaster.linktoBusinessMasterId = Convert.ToInt16(objOfferMasterDAL.linktoBusinessMasterId);
                objOfferMaster.linktoCustomerMasterId = objOfferMasterDAL.linktoCustomerMasterId;
				objOfferMaster.TermsAndConditions = Convert.ToString(objOfferMasterDAL.TermsAndConditions);
				objOfferMaster.IsEnabled = Convert.ToBoolean(objOfferMasterDAL.IsEnabled);
				objOfferMaster.IsDeleted = Convert.ToBoolean(objOfferMasterDAL.IsDeleted);
				objOfferMaster.IsForCustomers = Convert.ToBoolean(objOfferMasterDAL.IsForCustomers);
		        objOfferMaster.BuyItemCount = Convert.ToInt32(objOfferMasterDAL.BuyItemCount);
		        objOfferMaster.GetItemCount = Convert.ToInt16(objOfferMasterDAL.GetItemCount);
                objOfferMaster.linktoOrderTypeMasterIds = Convert.ToString(objOfferMasterDAL.linktoOrderTypeMasterIds);
				
				
				/// Extra
                objOfferMaster.OfferType = Convert.ToString(objOfferMasterDAL.OfferType);
                objOfferMaster.Business = Convert.ToString(objOfferMasterDAL.Business);
                objOfferMaster.ValidBuyItems = objOfferMasterDAL.ValidBuyItems;
                objOfferMaster.ValidDays = objOfferMasterDAL.ValidDays;
                objOfferMaster.ValidGetItems = objOfferMasterDAL.ValidGetItems;
                objOfferMaster.ValidItems = objOfferMasterDAL.ValidItems;
                objOfferMaster.IsForApp = Convert.ToBoolean(objOfferMasterDAL.IsForApp);
                objOfferMaster.IsOnline = Convert.ToBoolean(objOfferMasterDAL.IsOnline);
				lstOfferMaster.Add(objOfferMaster);
			}
			return lstOfferMaster;
		}
	}
}
