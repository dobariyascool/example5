using System;
using System.Collections.Generic;

namespace posLibrary
{
	/// <summary>
	/// Model for OrderMaster
	/// </summary>
	public class OrderMaster
	{

        public long OrderMasterId { get; set; }
        public string OrderNumber { get; set; }
        public string OrderDateTime { get; set; }
        public short linktoCounterMasterId { get; set; }
        public string linktoTableMasterIds { get; set; }
        public int? linktoCustomerMasterId { get; set; }
        public short linktoOrderTypeMasterId { get; set; }
        public short? linktoOrderStatusMasterId { get; set; }
        public double TotalAmount { get; set; }
        public double TotalTax { get; set; }
        public double Discount { get; set; }
        public double DiscountPercentage { get; set; }
        public double ExtraAmount { get; set; }
        public short TotalItemPoint { get; set; }
        public short TotalDeductedPoint { get; set; }
        public string Remark { get; set; }
        public long? linktoSalesMasterId { get; set; }
        public string CreateDateTime { get; set; }
        public short linktoUserMasterIdCreatedBy { get; set; }
        public string UpdateDateTime { get; set; }
        public short? linktoUserMasterIdUpdatedBy { get; set; }
        public short? linktoWaiterMasterId { get; set; }
        public short linktoBusinessMasterId { get; set; }
        public double NetAmount { get; set; }
        public short PrintCount { get; set; }
        public short linktoSourceMasterId { get; set; }

		/// Extra
		public string Counter { get; set; }
		public string Customer { get; set; }
		public string OrderType { get; set; }
        public string TableName { get; set; }
        public int TotalItem { get; set; }
        public int TotalKOT { get; set; }
        public short RateIndex { get; set; }
        

		internal void SetClassObject(posOrderMasterDAL objOrderMasterDAL)
		{
            string ImageRetrievePath = System.Configuration.ConfigurationManager.AppSettings["ImageRetrievePath"] + "/OrderType/";
			this.OrderMasterId = Convert.ToInt64(objOrderMasterDAL.OrderMasterId);
			this.OrderNumber = Convert.ToString(objOrderMasterDAL.OrderNumber);
			this.OrderDateTime = objOrderMasterDAL.OrderDateTime.ToString("s");
			this.linktoCounterMasterId = Convert.ToInt16(objOrderMasterDAL.linktoCounterMasterId);
			this.linktoTableMasterIds = Convert.ToString(objOrderMasterDAL.linktoTableMasterIds);
            if (objOrderMasterDAL.linktoWaiterMasterId != null)
            {
                this.linktoWaiterMasterId = Convert.ToInt16(objOrderMasterDAL.linktoWaiterMasterId);
            }
            this.linktoBusinessMasterId = Convert.ToInt16(objOrderMasterDAL.linktoBusinessMasterId);
			if (objOrderMasterDAL.linktoCustomerMasterId != null)
			{
				this.linktoCustomerMasterId = Convert.ToInt32(objOrderMasterDAL.linktoCustomerMasterId.Value);
			}
			this.linktoOrderTypeMasterId = Convert.ToInt16(objOrderMasterDAL.linktoOrderTypeMasterId);
            if (objOrderMasterDAL.linktoOrderStatusMasterId != null)
            {
                this.linktoOrderStatusMasterId = Convert.ToInt16(objOrderMasterDAL.linktoOrderStatusMasterId.Value);
            }
			this.TotalAmount = Convert.ToDouble(objOrderMasterDAL.TotalAmount);
			this.TotalTax = Convert.ToDouble(objOrderMasterDAL.TotalTax);
			this.Discount = Convert.ToDouble(objOrderMasterDAL.DiscountAmount);
            this.DiscountPercentage = Convert.ToDouble(objOrderMasterDAL.DiscountPercentage);
			this.ExtraAmount = Convert.ToDouble(objOrderMasterDAL.ExtraAmount);
			this.TotalItemPoint = Convert.ToInt16(objOrderMasterDAL.TotalItemPoint);
			this.TotalDeductedPoint = Convert.ToInt16(objOrderMasterDAL.TotalDeductedPoint);
			this.Remark = Convert.ToString(objOrderMasterDAL.Remark);
			if (objOrderMasterDAL.linktoSalesMasterId != null)
			{
				this.linktoSalesMasterId = Convert.ToInt64(objOrderMasterDAL.linktoSalesMasterId.Value);
			}
			this.CreateDateTime = objOrderMasterDAL.CreateDateTime.ToString("s");
			this.linktoUserMasterIdCreatedBy = Convert.ToInt16(objOrderMasterDAL.linktoUserMasterIdCreatedBy);
			if (objOrderMasterDAL.UpdateDateTime != null)
			{
				this.UpdateDateTime = objOrderMasterDAL.UpdateDateTime.Value.ToString("s");
			}
			if (objOrderMasterDAL.linktoUserMasterIdUpdatedBy != null)
			{
				this.linktoUserMasterIdUpdatedBy = Convert.ToInt16(objOrderMasterDAL.linktoUserMasterIdUpdatedBy.Value);
			}
            this.NetAmount = Convert.ToDouble(objOrderMasterDAL.NetAmount);

			/// Extra
			this.Counter = Convert.ToString(objOrderMasterDAL.Counter);
            this.Customer = Convert.ToString(objOrderMasterDAL.Customer);
			this.OrderType = Convert.ToString(objOrderMasterDAL.OrderType);
            this.TableName = Convert.ToString(objOrderMasterDAL.TableName);
            this.TotalItem = Convert.ToInt32(objOrderMasterDAL.TotalItem);
            this.TotalKOT = Convert.ToInt32(objOrderMasterDAL.TotalKOT);
            if (objOrderMasterDAL.PrintCount != null)
            {
                this.PrintCount = Convert.ToInt16(objOrderMasterDAL.PrintCount);
            }
            if (objOrderMasterDAL.linktoSourceMasterId != null)
            {
                this.linktoSourceMasterId = Convert.ToInt16(objOrderMasterDAL.linktoSourceMasterId);
            }
        }

		internal static List<OrderMaster> SetListObject(List<posOrderMasterDAL> lstOrderMasterDAL)
		{
			List<OrderMaster> lstOrderMaster = new List<OrderMaster>();
			OrderMaster objOrderMaster = null;
			foreach (posOrderMasterDAL objOrderMasterDAL in lstOrderMasterDAL)
			{
                string ImageRetrievePath = System.Configuration.ConfigurationManager.AppSettings["ImageRetrievePath"] + "/OrderType/";
				objOrderMaster = new OrderMaster();
				objOrderMaster.OrderMasterId = Convert.ToInt64(objOrderMasterDAL.OrderMasterId);
				objOrderMaster.OrderNumber = Convert.ToString(objOrderMasterDAL.OrderNumber);
				objOrderMaster.OrderDateTime = objOrderMasterDAL.OrderDateTime.ToString("s");
				objOrderMaster.linktoCounterMasterId = Convert.ToInt16(objOrderMasterDAL.linktoCounterMasterId);
				objOrderMaster.linktoTableMasterIds = Convert.ToString(objOrderMasterDAL.linktoTableMasterIds);
                if (objOrderMaster.linktoWaiterMasterId != null)
                {
                    objOrderMaster.linktoWaiterMasterId = Convert.ToInt16(objOrderMasterDAL.linktoWaiterMasterId);
                }
                objOrderMaster.linktoBusinessMasterId = Convert.ToInt16(objOrderMasterDAL.linktoBusinessMasterId);
				if (objOrderMasterDAL.linktoCustomerMasterId != null)
				{
					objOrderMaster.linktoCustomerMasterId = Convert.ToInt32(objOrderMasterDAL.linktoCustomerMasterId.Value);
				}
				objOrderMaster.linktoOrderTypeMasterId = Convert.ToInt16(objOrderMasterDAL.linktoOrderTypeMasterId);
                if (objOrderMasterDAL.linktoOrderStatusMasterId != null)
                {
                    objOrderMaster.linktoOrderStatusMasterId = Convert.ToInt16(objOrderMasterDAL.linktoOrderStatusMasterId.Value);
                }
				objOrderMaster.TotalAmount = Convert.ToDouble(objOrderMasterDAL.TotalAmount);
				objOrderMaster.TotalTax = Convert.ToDouble(objOrderMasterDAL.TotalTax);
				objOrderMaster.Discount = Convert.ToDouble(objOrderMasterDAL.DiscountAmount);
                objOrderMaster.DiscountPercentage = Convert.ToDouble(objOrderMasterDAL.DiscountPercentage);
				objOrderMaster.ExtraAmount = Convert.ToDouble(objOrderMasterDAL.ExtraAmount);
				objOrderMaster.TotalItemPoint = Convert.ToInt16(objOrderMasterDAL.TotalItemPoint);
				objOrderMaster.TotalDeductedPoint = Convert.ToInt16(objOrderMasterDAL.TotalDeductedPoint);
                objOrderMaster.NetAmount = Convert.ToDouble(objOrderMasterDAL.NetAmount);
				objOrderMaster.Remark = Convert.ToString(objOrderMasterDAL.Remark);
				if (objOrderMasterDAL.linktoSalesMasterId != null)
				{
					objOrderMaster.linktoSalesMasterId = Convert.ToInt64(objOrderMasterDAL.linktoSalesMasterId.Value);
				}
				objOrderMaster.CreateDateTime = objOrderMasterDAL.CreateDateTime.ToString("s");
				objOrderMaster.linktoUserMasterIdCreatedBy = Convert.ToInt16(objOrderMasterDAL.linktoUserMasterIdCreatedBy);
				if (objOrderMasterDAL.UpdateDateTime != null)
				{
					objOrderMaster.UpdateDateTime = objOrderMasterDAL.UpdateDateTime.Value.ToString("s");
				}
				if (objOrderMasterDAL.linktoUserMasterIdUpdatedBy != null)
				{
					objOrderMaster.linktoUserMasterIdUpdatedBy = Convert.ToInt16(objOrderMasterDAL.linktoUserMasterIdUpdatedBy.Value);
				}

				/// Extra
				objOrderMaster.Counter = Convert.ToString(objOrderMasterDAL.Counter);
                objOrderMaster.Customer = Convert.ToString(objOrderMasterDAL.Customer);
				objOrderMaster.OrderType = Convert.ToString(objOrderMasterDAL.OrderType);
                objOrderMaster.TableName = Convert.ToString(objOrderMasterDAL.TableName);
                objOrderMaster.TotalItem = Convert.ToInt32(objOrderMasterDAL.TotalItem);
                objOrderMaster.TotalKOT = Convert.ToInt32(objOrderMasterDAL.TotalKOT);
                if (objOrderMasterDAL.PrintCount != null)
                {
                    objOrderMaster.PrintCount = Convert.ToInt16(objOrderMasterDAL.PrintCount);
                }
                if (objOrderMasterDAL.linktoSourceMasterId != null)
                {
                    objOrderMaster.linktoSourceMasterId = Convert.ToInt16(objOrderMasterDAL.linktoSourceMasterId);
                }
				lstOrderMaster.Add(objOrderMaster);
			}
			return lstOrderMaster;
		}
	}
}
