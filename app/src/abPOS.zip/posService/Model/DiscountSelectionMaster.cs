using System;
using System.Collections.Generic;

namespace posLibrary
{
	/// <summary>
	/// Model for DiscountMaster
	/// </summary>
    public class DiscountSelectionMaster
	{

        public short DiscountMasterId { get; set; }
        public double Discount { get; set; }
        public bool IsPercentage { get; set; }
        public string DiscountTitle { get; set; }
        public short linktoBusinessMasterId { get; set; }

		/// Extra
		public string Business { get; set; }


		internal void SetClassObject(posDiscountSelectionMasterDAL objDiscountMasterDAL)
		{
			this.DiscountMasterId = Convert.ToInt16(objDiscountMasterDAL.DiscountSelectionMasterId);
			this.Discount = Convert.ToDouble(objDiscountMasterDAL.Discount);
			this.IsPercentage = Convert.ToBoolean(objDiscountMasterDAL.IsPercentage);
			this.DiscountTitle = Convert.ToString(objDiscountMasterDAL.DiscountTitle);
			this.linktoBusinessMasterId = Convert.ToInt16(objDiscountMasterDAL.linktoBusinessMasterId);

			/// Extra
			this.Business = Convert.ToString(objDiscountMasterDAL.Business);
		}

        internal static List<DiscountSelectionMaster> SetListObject(List<posDiscountSelectionMasterDAL> lstDiscountMasterDAL)
		{
            List<DiscountSelectionMaster> lstDiscountMaster = new List<DiscountSelectionMaster>();
            DiscountSelectionMaster objDiscountMaster = null;
			foreach (posDiscountSelectionMasterDAL objDiscountMasterDAL in lstDiscountMasterDAL)
			{
                objDiscountMaster = new DiscountSelectionMaster();
				objDiscountMaster.DiscountMasterId = Convert.ToInt16(objDiscountMasterDAL.DiscountSelectionMasterId);
				objDiscountMaster.Discount = Convert.ToDouble(objDiscountMasterDAL.Discount);
				objDiscountMaster.IsPercentage = Convert.ToBoolean(objDiscountMasterDAL.IsPercentage);
				objDiscountMaster.DiscountTitle = Convert.ToString(objDiscountMasterDAL.DiscountTitle);
				objDiscountMaster.linktoBusinessMasterId = Convert.ToInt16(objDiscountMasterDAL.linktoBusinessMasterId);

				/// Extra
				objDiscountMaster.Business = Convert.ToString(objDiscountMasterDAL.Business);
				lstDiscountMaster.Add(objDiscountMaster);
			}
			return lstDiscountMaster;
		}
	}
}
