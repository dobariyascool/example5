﻿using System;
using System.Collections.Generic;
using posLibrary;

namespace posService.Model
{
    /// <summary>
    /// Model for ItemMaster
    /// </summary>
    public class ItemMaster
    {
        public int ItemMasterId { get; set; }
        public string ItemName { get; set; }
        public string ShortName { get; set; }
        public string ItemCode { get; set; }
        public string ShortDescription { get; set; }
        public double MRP { get; set; }
        public short ItemPoint { get; set; }
        public short PriceByPoint { get; set; }
        //public short linktoItemTypeMasterId { get; set; }
        public short linktoUnitMasterId { get; set; }
        public string SearchWords { get; set; }
        public string ImageName { get; set; }
        public int SortOrder { get; set; }
        public string CreateDateTime { get; set; }
        public short linktoUserMasterIdCreatedBy { get; set; }
        public string UpdateDateTime { get; set; }
        public short linktoUserMasterIdUpdatedBy { get; set; }
        public short linktoBusinessMasterId { get; set; }
        public bool IsFavourite { get; set; }
        public string BarCode { get; set; }
       

        /// Extra
        //public string ItemType { get; set; }
        public string Category { get; set; }
        public string Unit { get; set; }
        public double SellPrice { get; set; }
        public int Quantity { get; set; }
        public string Remark { get; set; }
        public double ActualSellPrice { get; set; }
        public string ItemModifierMasterIds { get; set; }
        public List<ItemMaster> lstOrderItemModifierTran{ get; set; }
        public long linktoOrderMasterId { get; set; }
        public int KOTItemId { get; set; }
        public string OptionValueTranIds { get; set; }
        public bool IsDineInOnly { get; set; }
        public string xs_ImagePhysicalName { get; set; }
        public string sm_ImagePhysicalName { get; set; }
        public string md_ImagePhysicalName { get; set; }
        public string lg_ImagePhysicalName { get; set; }
        public string xl_ImagePhysicalName { get; set; }
        public double TaxRate { get; set; }
        public string Tax { get; set; }
        public short RateIndex { get; set; }
        public double Tax1 { get; set; }
        public double Tax2 { get; set; }
        public double Tax3 { get; set; }
        public double Tax4 { get; set; }
        public double Tax5 { get; set; }
        public double Discount { get; set; }
        public bool IsRateTaxInclusive { get; set; }

        internal void SetClassObject(posItemMasterDAL objItemMasterDAL)
        {

            string ImageRetrievePath = System.Configuration.ConfigurationManager.AppSettings["ImageRetrievePath"] + "/Item/";

            this.ItemMasterId = Convert.ToInt32(objItemMasterDAL.ItemMasterId);
            this.ItemName = Convert.ToString(objItemMasterDAL.ItemName);
            this.ShortName = Convert.ToString(objItemMasterDAL.ShortName);
            this.ItemCode = Convert.ToString(objItemMasterDAL.ItemCode);
            this.ShortDescription = Convert.ToString(objItemMasterDAL.ShortDescription);
            this.MRP = Convert.ToDouble(objItemMasterDAL.MRP);
            this.ItemPoint = Convert.ToInt16(objItemMasterDAL.ItemPoint);
            this.PriceByPoint = Convert.ToInt16(objItemMasterDAL.PriceByPoint);
           // this.linktoItemTypeMasterId = Convert.ToInt16(objItemMasterDAL.linktoItemTypeMasterId);
            this.linktoUnitMasterId = Convert.ToInt16(objItemMasterDAL.linktoUnitMasterId);
            this.SearchWords = Convert.ToString(objItemMasterDAL.SearchWords);
            if (objItemMasterDAL.ImageName != null && !objItemMasterDAL.ImageName.Equals(""))
            {
                this.ImageName = Convert.ToString(ImageRetrievePath + objItemMasterDAL.ImageName);
                this.xs_ImagePhysicalName = Convert.ToString(ImageRetrievePath + objItemMasterDAL.xs_ImagePhysicalName);
                this.sm_ImagePhysicalName = Convert.ToString(ImageRetrievePath + objItemMasterDAL.sm_ImagePhysicalName);
                this.md_ImagePhysicalName = Convert.ToString(ImageRetrievePath + objItemMasterDAL.md_ImagePhysicalName);
                this.lg_ImagePhysicalName = Convert.ToString(ImageRetrievePath + objItemMasterDAL.lg_ImagePhysicalName);
                this.xl_ImagePhysicalName = Convert.ToString(ImageRetrievePath + objItemMasterDAL.xl_ImagePhysicalName);
            }
            if (objItemMasterDAL.SortOrder != null)
            {
                this.SortOrder = Convert.ToInt32(objItemMasterDAL.SortOrder.Value);
            }
            this.CreateDateTime = objItemMasterDAL.CreateDateTime.ToString("s");
            this.linktoUserMasterIdCreatedBy = Convert.ToInt16(objItemMasterDAL.linktoUserMasterIdCreatedBy);
            if (objItemMasterDAL.UpdateDateTime != null)
            {
                this.UpdateDateTime = objItemMasterDAL.UpdateDateTime.Value.ToString("s");
            }
            if (objItemMasterDAL.linktoUserMasterIdUpdatedBy != null)
            {
                this.linktoUserMasterIdUpdatedBy = Convert.ToInt16(objItemMasterDAL.linktoUserMasterIdUpdatedBy.Value);
            }
            this.linktoBusinessMasterId = Convert.ToInt16(objItemMasterDAL.linktoBusinessMasterId);
            this.IsFavourite = Convert.ToBoolean(objItemMasterDAL.IsFavourite);
            //this.IsRowMaterial = Convert.ToBoolean(objItemMasterDAL.IsRowMaterial);
            this.BarCode = Convert.ToString(objItemMasterDAL.BarCode);

            /// Extra
            //this.ItemType = Convert.ToString(objItemMasterDAL.ItemType);
            this.Unit = Convert.ToString(objItemMasterDAL.Unit);
            this.SellPrice = Convert.ToDouble(objItemMasterDAL.SaleRate);
            this.Quantity = Convert.ToInt16(objItemMasterDAL.Quantity);
            this.ActualSellPrice = Convert.ToDouble(objItemMasterDAL.ActualSaleRate);
            this.ItemModifierMasterIds = objItemMasterDAL.ItemModifierMasterIds;
            this.linktoOrderMasterId = Convert.ToInt64(objItemMasterDAL.linktoOrderMasterId);
            this.Remark = Convert.ToString(objItemMasterDAL.Remark);
            this.OptionValueTranIds = Convert.ToString(objItemMasterDAL.OptionValueTranIds);
            this.IsDineInOnly = Convert.ToBoolean(objItemMasterDAL.IsDineInOnly);
            this.Tax = objItemMasterDAL.Tax;
            this.RateIndex = objItemMasterDAL.RateIndex;
            this.TaxRate = Convert.ToDouble(objItemMasterDAL.TaxRate);
            this.Category = Convert.ToString(objItemMasterDAL.CategoryName);
            this.Tax1 = Convert.ToDouble(objItemMasterDAL.Tax1);
            this.Tax2 = Convert.ToDouble(objItemMasterDAL.Tax2);
            this.Tax3 = Convert.ToDouble(objItemMasterDAL.Tax3);
            this.Tax4 = Convert.ToDouble(objItemMasterDAL.Tax4);
            this.Tax5 = Convert.ToDouble(objItemMasterDAL.Tax5);
            //this.Discount = Convert.ToDouble(objItemMasterDAL.Discount);
        }

        internal static List<ItemMaster> SetListObject(List<posItemMasterDAL> lstItemMasterDAL)
        {
            List<ItemMaster> lstItemMaster = new List<ItemMaster>();
            ItemMaster objItemMaster = null;
            string ImageRetrievePath = System.Configuration.ConfigurationManager.AppSettings["possImageRetrievePath"] + "/Item/";
            foreach (posItemMasterDAL objItemMasterDAL in lstItemMasterDAL)
            {
                objItemMaster = new ItemMaster();
                objItemMaster.ItemMasterId = Convert.ToInt32(objItemMasterDAL.ItemMasterId);
                objItemMaster.ItemName = Convert.ToString(objItemMasterDAL.ItemName);
                objItemMaster.ShortName = Convert.ToString(objItemMasterDAL.ShortName);
                objItemMaster.ItemCode = Convert.ToString(objItemMasterDAL.ItemCode);
                objItemMaster.ShortDescription = Convert.ToString(objItemMasterDAL.ShortDescription);
                objItemMaster.MRP = Convert.ToDouble(objItemMasterDAL.MRP);
                objItemMaster.ItemPoint = Convert.ToInt16(objItemMasterDAL.ItemPoint);
                objItemMaster.PriceByPoint = Convert.ToInt16(objItemMasterDAL.PriceByPoint);
                //objItemMaster.linktoItemTypeMasterId = Convert.ToInt16(objItemMasterDAL.linktoItemTypeMasterId);
                objItemMaster.linktoUnitMasterId = Convert.ToInt16(objItemMasterDAL.linktoUnitMasterId);
                objItemMaster.SearchWords = Convert.ToString(objItemMasterDAL.SearchWords);
                if (objItemMasterDAL.ImageName != null && !objItemMasterDAL.ImageName.Equals(""))
                {
                    objItemMaster.ImageName = Convert.ToString(ImageRetrievePath + objItemMasterDAL.ImageName);
                    objItemMaster.xs_ImagePhysicalName = Convert.ToString(ImageRetrievePath + objItemMasterDAL.xs_ImagePhysicalName);
                    objItemMaster.sm_ImagePhysicalName = Convert.ToString(ImageRetrievePath + objItemMasterDAL.sm_ImagePhysicalName);
                    objItemMaster.md_ImagePhysicalName = Convert.ToString(ImageRetrievePath + objItemMasterDAL.md_ImagePhysicalName);
                    objItemMaster.lg_ImagePhysicalName = Convert.ToString(ImageRetrievePath + objItemMasterDAL.lg_ImagePhysicalName);
                    objItemMaster.xl_ImagePhysicalName = Convert.ToString(ImageRetrievePath + objItemMasterDAL.xl_ImagePhysicalName);
                }
                if (objItemMasterDAL.SortOrder != null)
                {
                    objItemMaster.SortOrder = Convert.ToInt32(objItemMasterDAL.SortOrder.Value);
                }
                objItemMaster.CreateDateTime = objItemMasterDAL.CreateDateTime.ToString("s");
                objItemMaster.linktoUserMasterIdCreatedBy = Convert.ToInt16(objItemMasterDAL.linktoUserMasterIdCreatedBy);
                if (objItemMasterDAL.UpdateDateTime != null)
                {
                    objItemMaster.UpdateDateTime = objItemMasterDAL.UpdateDateTime.Value.ToString("s");
                }
                if (objItemMasterDAL.linktoUserMasterIdUpdatedBy != null)
                {
                    objItemMaster.linktoUserMasterIdUpdatedBy = Convert.ToInt16(objItemMasterDAL.linktoUserMasterIdUpdatedBy.Value);
                }
                objItemMaster.linktoBusinessMasterId = Convert.ToInt16(objItemMasterDAL.linktoBusinessMasterId);
                objItemMaster.IsFavourite = Convert.ToBoolean(objItemMasterDAL.IsFavourite);
                //objItemMaster.IsRowMaterial = Convert.ToBoolean(objItemMasterDAL.IsRowMaterial);
                objItemMaster.BarCode = Convert.ToString(objItemMasterDAL.BarCode);

                /// Extra
                //objItemMaster.ItemType = Convert.ToString(objItemMasterDAL.ItemType);
                objItemMaster.Unit = Convert.ToString(objItemMasterDAL.Unit);
                objItemMaster.Quantity = Convert.ToInt16(objItemMasterDAL.Quantity);
                objItemMaster.SellPrice = Convert.ToDouble(objItemMasterDAL.SaleRate);
                objItemMaster.ItemModifierMasterIds = objItemMasterDAL.ItemModifierMasterIds;
                objItemMaster.ActualSellPrice = Convert.ToDouble(objItemMasterDAL.ActualSaleRate);
                objItemMaster.linktoOrderMasterId = Convert.ToInt64(objItemMasterDAL.linktoOrderMasterId);
                objItemMaster.Remark = Convert.ToString(objItemMasterDAL.Remark);
                objItemMaster.OptionValueTranIds = Convert.ToString(objItemMasterDAL.OptionValueTranIds);
                objItemMaster.IsDineInOnly = Convert.ToBoolean(objItemMasterDAL.IsDineInOnly);
                objItemMaster.Tax = objItemMasterDAL.Tax;
                objItemMaster.RateIndex = objItemMasterDAL.RateIndex;
                objItemMaster.TaxRate = Convert.ToDouble(objItemMasterDAL.TaxRate);
                objItemMaster.Category = Convert.ToString(objItemMasterDAL.CategoryName);
                objItemMaster.Tax1 = Convert.ToDouble(objItemMasterDAL.Tax1);
                objItemMaster.Tax2 = Convert.ToDouble(objItemMasterDAL.Tax2);
                objItemMaster.Tax3 = Convert.ToDouble(objItemMasterDAL.Tax3);
                objItemMaster.Tax4 = Convert.ToDouble(objItemMasterDAL.Tax4);
                objItemMaster.Tax5 = Convert.ToDouble(objItemMasterDAL.Tax5);
                //objItemMaster.Discount = Convert.ToDouble(objItemMasterDAL.Discount);
                lstItemMaster.Add(objItemMaster);
            }
            return lstItemMaster;
        }
    }
}
