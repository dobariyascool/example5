using System;
using System.Collections.Generic;

namespace posLibrary
{
	/// <summary>
	/// Model for WaiterNotificationTran
	/// </summary>
	public class WaiterNotificationTran
	{

        #region Properties
        public long WaiterNotificationTranId { get; set; }
        public long linktoWaiterNotificationMasterId { get; set; }
        public short linktoUserMasterId { get; set; }

        /// Extra
        public long WaiterNotification { get; set; }
        public string User { get; set; }
        #endregion


		internal void SetClassObject(posWaiterNotificationTranDAL objWaiterNotificationTranDAL)
		{
			this.WaiterNotificationTranId = Convert.ToInt64(objWaiterNotificationTranDAL.WaiterNotificationTranId);
			this.linktoWaiterNotificationMasterId = Convert.ToInt64(objWaiterNotificationTranDAL.linktoWaiterNotificationMasterId);
			this.linktoUserMasterId = Convert.ToInt16(objWaiterNotificationTranDAL.linktoUserMasterId);

			/// Extra
			this.WaiterNotification = Convert.ToInt64(objWaiterNotificationTranDAL.WaiterNotification);
			this.User = Convert.ToString(objWaiterNotificationTranDAL.User);
		}

		internal static List<WaiterNotificationTran> SetListObject(List<posWaiterNotificationTranDAL> lstWaiterNotificationTranDAL)
		{
			List<WaiterNotificationTran> lstWaiterNotificationTran = new List<WaiterNotificationTran>();
			WaiterNotificationTran objWaiterNotificationTran = null;
			foreach (posWaiterNotificationTranDAL objWaiterNotificationTranDAL in lstWaiterNotificationTranDAL)
			{
				objWaiterNotificationTran = new WaiterNotificationTran();
				objWaiterNotificationTran.WaiterNotificationTranId = Convert.ToInt64(objWaiterNotificationTranDAL.WaiterNotificationTranId);
				objWaiterNotificationTran.linktoWaiterNotificationMasterId = Convert.ToInt64(objWaiterNotificationTranDAL.linktoWaiterNotificationMasterId);
				objWaiterNotificationTran.linktoUserMasterId = Convert.ToInt16(objWaiterNotificationTranDAL.linktoUserMasterId);

				/// Extra
				objWaiterNotificationTran.WaiterNotification = Convert.ToInt64(objWaiterNotificationTranDAL.WaiterNotification);
				objWaiterNotificationTran.User = Convert.ToString(objWaiterNotificationTranDAL.User);
				lstWaiterNotificationTran.Add(objWaiterNotificationTran);
			}
			return lstWaiterNotificationTran;
		}
	}
}
