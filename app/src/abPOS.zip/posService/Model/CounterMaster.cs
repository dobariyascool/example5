﻿using System;
using System.Collections.Generic;
using posLibrary;

namespace posService.Model
{
    public class CounterMaster
    {
        #region Properties
        public short CounterMasterId { get; set; }
        public string ShortName { get; set; }
        public string CounterName { get; set; }
        public string Description { get; set; }
        public string ImageName { get; set; }
        public string CounterColor { get; set; }
        public short linktoDepartmentMasterId { get; set; }
        public short linktoBusinessMasterId { get; set; }
        public bool IsEnabled { get; set; }
        public bool IsDeleted { get; set; }
        public string CreateDateTime { get; set; }

        /// Extra
        public string Department { get; set; }
        #endregion

        internal void SetClassObject(posCounterMasterDAL objCounterMasterDAL)
        {
            this.CounterMasterId = Convert.ToInt16(objCounterMasterDAL.CounterMasterId);
            this.ShortName = Convert.ToString(objCounterMasterDAL.ShortName);
            this.CounterName = Convert.ToString(objCounterMasterDAL.CounterName);
            if (objCounterMasterDAL.Description != null)
            {
                this.Description = Convert.ToString(objCounterMasterDAL.Description);
            }
            if (objCounterMasterDAL.ImageName != null)
            {
                this.ImageName = Convert.ToString(objCounterMasterDAL.ImageName);
            }
            if (objCounterMasterDAL.CounterColor != null)
            {
                this.CounterColor = Convert.ToString(objCounterMasterDAL.CounterColor);
            }
            this.linktoDepartmentMasterId = Convert.ToInt16(objCounterMasterDAL.linktoDepartmentMasterId);
            this.linktoBusinessMasterId = Convert.ToInt16(objCounterMasterDAL.linktoBusinessMasterId);
            this.IsEnabled = Convert.ToBoolean(objCounterMasterDAL.IsEnabled);
            this.IsDeleted = Convert.ToBoolean(objCounterMasterDAL.IsDeleted);
            this.CreateDateTime = objCounterMasterDAL.CreateDateTime.ToString("s");
            this.Department = Convert.ToString(objCounterMasterDAL.Department);
        }

        internal static List<CounterMaster> SetListObject(List<posCounterMasterDAL> lstCounterMasterDAL)
        {
            List<CounterMaster> lstCounterMaster = new List<CounterMaster>();
            CounterMaster objCounterMaster = null;
            foreach (posCounterMasterDAL objCounterMasterDAL in lstCounterMasterDAL)
            {
                objCounterMaster = new CounterMaster();
                objCounterMaster.CounterMasterId = Convert.ToInt16(objCounterMasterDAL.CounterMasterId);
                objCounterMaster.ShortName = Convert.ToString(objCounterMasterDAL.ShortName);
                objCounterMaster.CounterName = Convert.ToString(objCounterMasterDAL.CounterName);
                if (objCounterMasterDAL.Description != null)
                {
                    objCounterMaster.Description = Convert.ToString(objCounterMasterDAL.Description);
                }
                if (objCounterMasterDAL.ImageName != null)
                {
                    objCounterMaster.ImageName = Convert.ToString(objCounterMasterDAL.ImageName);
                }
                if (objCounterMasterDAL.CounterColor != null)
                {
                    objCounterMaster.CounterColor = Convert.ToString(objCounterMasterDAL.CounterColor);
                }
                objCounterMaster.linktoDepartmentMasterId = Convert.ToInt16(objCounterMasterDAL.linktoDepartmentMasterId);
                objCounterMaster.linktoBusinessMasterId = Convert.ToInt16(objCounterMasterDAL.linktoBusinessMasterId);
                objCounterMaster.IsEnabled = Convert.ToBoolean(objCounterMasterDAL.IsEnabled);
                objCounterMaster.IsDeleted = Convert.ToBoolean(objCounterMasterDAL.IsDeleted);
                objCounterMaster.CreateDateTime = objCounterMasterDAL.CreateDateTime.ToString("s");
                objCounterMaster.Department = Convert.ToString(objCounterMasterDAL.Department);
                lstCounterMaster.Add(objCounterMaster);
            }
            return lstCounterMaster;
        }
    }
}