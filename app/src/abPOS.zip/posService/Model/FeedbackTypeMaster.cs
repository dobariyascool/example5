﻿using System;
using System.Collections.Generic;
using posLibrary;

namespace posService.Model
{
    /// <summary>
    /// Model for FeedbackTypeMaster
    /// </summary>
    public class FeedbackTypeMaster
    {
        public short FeedbackTypeMasterId { get; set; }
        public string FeedbackType { get; set; }

        internal void SetClassObject(posFeedbackTypeMasterDAL objFeedbackTypeMasterDAL)
        {
            this.FeedbackTypeMasterId = Convert.ToInt16(objFeedbackTypeMasterDAL.FeedbackTypeMasterId);
            this.FeedbackType = Convert.ToString(objFeedbackTypeMasterDAL.FeedbackType);
        }

        internal static List<FeedbackTypeMaster> SetListObject(List<posFeedbackTypeMasterDAL> lstFeedbackTypeMasterDAL)
        {
            List<FeedbackTypeMaster> lstFeedbackTypeMaster = new List<FeedbackTypeMaster>();
            FeedbackTypeMaster objFeedbackTypeMaster = null;
            foreach (posFeedbackTypeMasterDAL objFeedbackTypeMasterDAL in lstFeedbackTypeMasterDAL)
            {
                objFeedbackTypeMaster = new FeedbackTypeMaster();
                objFeedbackTypeMaster.FeedbackTypeMasterId = Convert.ToInt16(objFeedbackTypeMasterDAL.FeedbackTypeMasterId);
                objFeedbackTypeMaster.FeedbackType = Convert.ToString(objFeedbackTypeMasterDAL.FeedbackType);
                lstFeedbackTypeMaster.Add(objFeedbackTypeMaster);
            }
            return lstFeedbackTypeMaster;
        }
    }
}