﻿using System;
using System.Collections.Generic;
using posLibrary;

namespace posService.Model
{
    public class UserMaster
    {

        public short UserMasterId { get; set; }
        public string Username { get; set; }
        public string Password { get; set; }
        public short linktoRoleMasterId { get; set; }
        public string CreateDateTime { get; set; }
        public short linktoUserMasterIdCreatedBy { get; set; }
        public string UpdateDateTime { get; set; }
        public short? linktoUserMasterIdUpdatedBy { get; set; }
        public string LastLoginDateTime { get; set; }
        public short LoginFailCount { get; set; }
        public string LastLockoutDateTime { get; set; }
        public string LastPasswordChangedDateTime { get; set; }
        public string Comment { get; set; }
        public bool IsEnabled { get; set; }
        public bool IsDeleted { get; set; }

        public short linktoUserTypeMasterId { get; set; }
        public short linktoBusinessMasterId { get; set; }
        public int WaiterMasterId { get; set; }
        public short linktoBusinessTypeMasterId { get; set; }
        public short linktoCityMasterId { get; set; }

        //Extra
        public string Role { get; set; }

        internal void SetClassObject(posUserMasterDAL objUserMasterDAL)
        {
            this.UserMasterId = Convert.ToInt16(objUserMasterDAL.UserMasterId);
            this.Username = Convert.ToString(objUserMasterDAL.Username);
            this.Password = Convert.ToString(objUserMasterDAL.Password);
            this.linktoUserTypeMasterId = Convert.ToInt16(objUserMasterDAL.linktoUserTypeMasterId);
            this.linktoRoleMasterId = Convert.ToInt16(objUserMasterDAL.linktoRoleMasterId);
            this.LoginFailCount= Convert.ToInt16(objUserMasterDAL.LoginFailCount);
            this.Role = Convert.ToString(objUserMasterDAL.Role);
            this.WaiterMasterId = Convert.ToInt32(objUserMasterDAL.WaiterMasterId);
            this.linktoBusinessMasterId = Convert.ToInt16(objUserMasterDAL.linktoBusinessMasterId);
            this.linktoBusinessTypeMasterId = Convert.ToInt16(objUserMasterDAL.linktoBusinessTypeMasterId);
            this.linktoCityMasterId = Convert.ToInt16(objUserMasterDAL.linktoCityMasterId);
        }

        internal static List<UserMaster> SetListObject(List<posUserMasterDAL> lstUserMasterDAL)
        {
            List<UserMaster> lstUserMaster = new List<UserMaster>();
            UserMaster objUserMaster = null;
            foreach (posUserMasterDAL objUserMasterDAL in lstUserMasterDAL)
            {
                objUserMaster = new UserMaster();
                objUserMaster.UserMasterId = Convert.ToInt16(objUserMasterDAL.UserMasterId);
                objUserMaster.Username = Convert.ToString(objUserMasterDAL.Username);
                objUserMaster.Password = Convert.ToString(objUserMasterDAL.Password);
                objUserMaster.linktoUserTypeMasterId = Convert.ToInt16(objUserMasterDAL.linktoUserTypeMasterId);
                objUserMaster.linktoRoleMasterId = Convert.ToInt16(objUserMasterDAL.linktoRoleMasterId);
                objUserMaster.Role = Convert.ToString(objUserMasterDAL.Role);
                objUserMaster.linktoBusinessMasterId = Convert.ToInt16(objUserMasterDAL.linktoBusinessMasterId);
                objUserMaster.linktoBusinessTypeMasterId = Convert.ToInt16(objUserMasterDAL.linktoBusinessTypeMasterId);
                objUserMaster.linktoCityMasterId = Convert.ToInt16(objUserMasterDAL.linktoCityMasterId);
                lstUserMaster.Add(objUserMaster);
            }
            return lstUserMaster;
        }

    }
}