using System;
using System.Collections.Generic;

namespace posLibrary
{
	/// <summary>
	/// Model for ItemRemarkMaster
	/// </summary>
	public class ItemRemarkMaster
	{

        public short ItemRemarkMasterId { get; set; }
        public string ItemRemark { get; set; }
        public short linktoBusinessMasterId { get; set; }

		/// Extra
		public string Business { get; set; }


		internal void SetClassObject(posItemRemarkMasterDAL objItemRemarkMasterDAL)
		{
			this.ItemRemarkMasterId = Convert.ToInt16(objItemRemarkMasterDAL.ItemRemarkMasterId);
			this.ItemRemark = Convert.ToString(objItemRemarkMasterDAL.ItemRemark);
			this.linktoBusinessMasterId = Convert.ToInt16(objItemRemarkMasterDAL.linktoBusinessMasterId);

			/// Extra
			this.Business = Convert.ToString(objItemRemarkMasterDAL.Business);
		}

		internal static List<ItemRemarkMaster> SetListObject(List<posItemRemarkMasterDAL> lstItemRemarkMasterDAL)
		{
			List<ItemRemarkMaster> lstItemRemarkMaster = new List<ItemRemarkMaster>();
			ItemRemarkMaster objItemRemarkMaster = null;
			foreach (posItemRemarkMasterDAL objItemRemarkMasterDAL in lstItemRemarkMasterDAL)
			{
				objItemRemarkMaster = new ItemRemarkMaster();
				objItemRemarkMaster.ItemRemarkMasterId = Convert.ToInt16(objItemRemarkMasterDAL.ItemRemarkMasterId);
				objItemRemarkMaster.ItemRemark = Convert.ToString(objItemRemarkMasterDAL.ItemRemark);
				objItemRemarkMaster.linktoBusinessMasterId = Convert.ToInt16(objItemRemarkMasterDAL.linktoBusinessMasterId);

				/// Extra
				objItemRemarkMaster.Business = Convert.ToString(objItemRemarkMasterDAL.Business);
				lstItemRemarkMaster.Add(objItemRemarkMaster);
			}
			return lstItemRemarkMaster;
		}
	}
}
