using System;
using System.Collections.Generic;

namespace posLibrary
{
	
	public class FeedbackQuestionGroupMaster
	{
        public short FeedbackQuestionGroupMasterId { get; set; }
        public short linktoBusinessMasterId { get; set; }
        public string GroupName { get; set; }
        public bool IsDeleted { get; set; }

		/// Extra
		public string Business { get; set; }
        public short TotalNullGroupFeedbackQuestion { get; set; }

		internal void SetClassObject(posFeedbackQuestionGroupMasterDAL objFeedbackQuestionGroupMasterDAL)
		{
			this.FeedbackQuestionGroupMasterId = Convert.ToInt16(objFeedbackQuestionGroupMasterDAL.FeedbackQuestionGroupMasterId);
			this.linktoBusinessMasterId = Convert.ToInt16(objFeedbackQuestionGroupMasterDAL.linktoBusinessMasterId);
			this.GroupName = Convert.ToString(objFeedbackQuestionGroupMasterDAL.GroupName);
			this.IsDeleted = Convert.ToBoolean(objFeedbackQuestionGroupMasterDAL.IsDeleted);

			/// Extra
			this.Business = Convert.ToString(objFeedbackQuestionGroupMasterDAL.Business);
            this.TotalNullGroupFeedbackQuestion = Convert.ToInt16(objFeedbackQuestionGroupMasterDAL.TotalNullGroupFeedbackQuestion);
		}

		internal static List<FeedbackQuestionGroupMaster> SetListObject(List<posFeedbackQuestionGroupMasterDAL> lstFeedbackQuestionGroupMasterDAL)
		{
			List<FeedbackQuestionGroupMaster> lstFeedbackQuestionGroupMaster = new List<FeedbackQuestionGroupMaster>();
			FeedbackQuestionGroupMaster objFeedbackQuestionGroupMaster = null;
			foreach (posFeedbackQuestionGroupMasterDAL objFeedbackQuestionGroupMasterDAL in lstFeedbackQuestionGroupMasterDAL)
			{
				objFeedbackQuestionGroupMaster = new FeedbackQuestionGroupMaster();
				objFeedbackQuestionGroupMaster.FeedbackQuestionGroupMasterId = Convert.ToInt16(objFeedbackQuestionGroupMasterDAL.FeedbackQuestionGroupMasterId);
				objFeedbackQuestionGroupMaster.linktoBusinessMasterId = Convert.ToInt16(objFeedbackQuestionGroupMasterDAL.linktoBusinessMasterId);
				objFeedbackQuestionGroupMaster.GroupName = Convert.ToString(objFeedbackQuestionGroupMasterDAL.GroupName);
				objFeedbackQuestionGroupMaster.IsDeleted = Convert.ToBoolean(objFeedbackQuestionGroupMasterDAL.IsDeleted);

				/// Extra
				objFeedbackQuestionGroupMaster.Business = Convert.ToString(objFeedbackQuestionGroupMasterDAL.Business);
                objFeedbackQuestionGroupMaster.TotalNullGroupFeedbackQuestion = Convert.ToInt16(objFeedbackQuestionGroupMasterDAL.TotalNullGroupFeedbackQuestion);
				lstFeedbackQuestionGroupMaster.Add(objFeedbackQuestionGroupMaster);
			}
			return lstFeedbackQuestionGroupMaster;
		}
	}
}
