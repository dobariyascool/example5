using System;
using System.Collections.Generic;

namespace posLibrary
{
	/// <summary>
	/// Model for WaiterNotificationMaster
	/// </summary>
	public class WaiterNotificationMaster
	{
        public long WaiterNotificationMasterId { get; set; }
        public string NotificationDateTime { get; set; }
        public short linktoTableMasterId { get; set; }
        public string Message { get; set; }
		/// Extra
        public string TableName { get; set; }
        public short WaiterNotificationTranId { get; set; }

		internal void SetClassObject(posWaiterNotificationMasterDAL objWaiterNotificationMasterDAL)
		{
			this.WaiterNotificationMasterId = Convert.ToInt64(objWaiterNotificationMasterDAL.WaiterNotificationMasterId);
			this.NotificationDateTime = objWaiterNotificationMasterDAL.NotificationDateTime.ToString("s");
			this.linktoTableMasterId = Convert.ToInt16(objWaiterNotificationMasterDAL.linktoTableMasterId);
			this.Message = Convert.ToString(objWaiterNotificationMasterDAL.Message);

			/// Extra
            this.TableName = Convert.ToString(objWaiterNotificationMasterDAL.TableName);
            this.WaiterNotificationTranId = Convert.ToInt16(objWaiterNotificationMasterDAL.WaiterNotificationTranId);
		}

		internal static List<WaiterNotificationMaster> SetListObject(List<posWaiterNotificationMasterDAL> lstWaiterNotificationMasterDAL)
		{
			List<WaiterNotificationMaster> lstWaiterNotificationMaster = new List<WaiterNotificationMaster>();
			WaiterNotificationMaster objWaiterNotificationMaster = null;
			foreach (posWaiterNotificationMasterDAL objWaiterNotificationMasterDAL in lstWaiterNotificationMasterDAL)
			{
				objWaiterNotificationMaster = new WaiterNotificationMaster();
				objWaiterNotificationMaster.WaiterNotificationMasterId = Convert.ToInt64(objWaiterNotificationMasterDAL.WaiterNotificationMasterId);
				objWaiterNotificationMaster.NotificationDateTime = objWaiterNotificationMasterDAL.NotificationDateTime.ToString("s");
				objWaiterNotificationMaster.linktoTableMasterId = Convert.ToInt16(objWaiterNotificationMasterDAL.linktoTableMasterId);
				objWaiterNotificationMaster.Message = Convert.ToString(objWaiterNotificationMasterDAL.Message);

				/// Extra
                objWaiterNotificationMaster.TableName = Convert.ToString(objWaiterNotificationMasterDAL.TableName);
                objWaiterNotificationMaster.WaiterNotificationTranId = Convert.ToInt16(objWaiterNotificationMasterDAL.WaiterNotificationTranId);
				lstWaiterNotificationMaster.Add(objWaiterNotificationMaster);
			}
			return lstWaiterNotificationMaster;
		}
	}
}
