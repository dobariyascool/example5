using System;
using System.Collections.Generic;

namespace posLibrary
{
	/// <summary>
	/// Model for OrderItemTran
	/// </summary>
	public class OrderItemTran
	{

        public long OrderItemTranId { get; set; }
        public long linktoOrderMasterId { get; set; }
        public int linktoItemMasterId { get; set; }
        public short Quantity { get; set; }
        public double Rate { get; set; }
        public short ItemPoint { get; set; }
        public short DeductedPoint { get; set; }
        public string ItemRemark { get; set; }
        public short? linktoOrderStatusMasterId { get; set; }
        public string UpdateDateTime { get; set; }
        public short? linktoUserMasterIdUpdatedBy { get; set; }

		/// Extra
		public string Order { get; set; }
		public string Item { get; set; }
		public string OrderStatus { get; set; }
        public string OrderMasterIds { get; set; }
        public string OrderItemTranIds { get; set; }
        public string ModifierRates { get; set; }
        public short RateIndex { get; set; }

		internal void SetClassObject(posOrderItemTranDAL objOrderItemTranDAL)
		{
			this.OrderItemTranId = Convert.ToInt64(objOrderItemTranDAL.OrderItemTranId);
			this.linktoOrderMasterId = Convert.ToInt64(objOrderItemTranDAL.linktoOrderMasterId);
			this.linktoItemMasterId = Convert.ToInt32(objOrderItemTranDAL.linktoItemMasterId);
			this.Quantity = Convert.ToInt16(objOrderItemTranDAL.Quantity);
			this.Rate = Convert.ToDouble(objOrderItemTranDAL.Rate);
			this.ItemPoint = Convert.ToInt16(objOrderItemTranDAL.ItemPoint);
			this.DeductedPoint = Convert.ToInt16(objOrderItemTranDAL.DeductedPoint);
			this.ItemRemark = Convert.ToString(objOrderItemTranDAL.ItemRemark);
            if(objOrderItemTranDAL.linktoOrderStatusMasterId != null)
            {
                this.linktoOrderStatusMasterId = Convert.ToInt16(objOrderItemTranDAL.linktoOrderStatusMasterId.Value);
            }
			
			if (objOrderItemTranDAL.UpdateDateTime != null)
			{
				this.UpdateDateTime = objOrderItemTranDAL.UpdateDateTime.Value.ToString("s");
			}
			if (objOrderItemTranDAL.linktoUserMasterIdUpdatedBy != null)
			{
				this.linktoUserMasterIdUpdatedBy = Convert.ToInt16(objOrderItemTranDAL.linktoUserMasterIdUpdatedBy.Value);
			}

			/// Extra
			this.Order = Convert.ToString(objOrderItemTranDAL.OrderNumber);
			this.Item = Convert.ToString(objOrderItemTranDAL.ItemName);
			this.OrderStatus = Convert.ToString(objOrderItemTranDAL.OrderStatus);
            this.OrderItemTranIds = Convert.ToString(objOrderItemTranDAL.OrderItemTranIds);
            this.ModifierRates = Convert.ToString(objOrderItemTranDAL.ModifierRates);
		}

		internal static List<OrderItemTran> SetListObject(List<posOrderItemTranDAL> lstOrderItemTranDAL)
		{
			List<OrderItemTran> lstOrderItemTran = new List<OrderItemTran>();
			OrderItemTran objOrderItemTran = null;
			foreach (posOrderItemTranDAL objOrderItemTranDAL in lstOrderItemTranDAL)
			{
				objOrderItemTran = new OrderItemTran();
				objOrderItemTran.OrderItemTranId = Convert.ToInt64(objOrderItemTranDAL.OrderItemTranId);
				objOrderItemTran.linktoOrderMasterId = Convert.ToInt64(objOrderItemTranDAL.linktoOrderMasterId);
				objOrderItemTran.linktoItemMasterId = Convert.ToInt32(objOrderItemTranDAL.linktoItemMasterId);
				objOrderItemTran.Quantity = Convert.ToInt16(objOrderItemTranDAL.Quantity);
				objOrderItemTran.Rate = Convert.ToDouble(objOrderItemTranDAL.Rate);
				objOrderItemTran.ItemPoint = Convert.ToInt16(objOrderItemTranDAL.ItemPoint);
				objOrderItemTran.DeductedPoint = Convert.ToInt16(objOrderItemTranDAL.DeductedPoint);
				objOrderItemTran.ItemRemark = Convert.ToString(objOrderItemTranDAL.ItemRemark);
                if (objOrderItemTranDAL.linktoOrderStatusMasterId != null)
                {
                    objOrderItemTran.linktoOrderStatusMasterId = Convert.ToInt16(objOrderItemTranDAL.linktoOrderStatusMasterId.Value);
                }
				if (objOrderItemTranDAL.UpdateDateTime != null)
				{
					objOrderItemTran.UpdateDateTime = objOrderItemTranDAL.UpdateDateTime.Value.ToString("s");
				}
				if (objOrderItemTranDAL.linktoUserMasterIdUpdatedBy != null)
				{
					objOrderItemTran.linktoUserMasterIdUpdatedBy = Convert.ToInt16(objOrderItemTranDAL.linktoUserMasterIdUpdatedBy.Value);
				}

				/// Extra
				objOrderItemTran.Order = Convert.ToString(objOrderItemTranDAL.OrderNumber);
				objOrderItemTran.Item = Convert.ToString(objOrderItemTranDAL.ItemName);
				objOrderItemTran.OrderStatus = Convert.ToString(objOrderItemTranDAL.OrderStatus);
                objOrderItemTran.OrderItemTranIds = Convert.ToString(objOrderItemTranDAL.OrderItemTranIds);
                objOrderItemTran.ModifierRates = Convert.ToString(objOrderItemTranDAL.ModifierRates);
                objOrderItemTran.RateIndex = Convert.ToInt16(objOrderItemTranDAL.RateIndex);
				lstOrderItemTran.Add(objOrderItemTran);
			}
			return lstOrderItemTran;
		}
	}
}
