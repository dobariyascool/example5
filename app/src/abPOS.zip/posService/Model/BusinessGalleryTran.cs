﻿using System;
using System.Collections.Generic;
using posLibrary;

namespace posService.Model
{
    /// <summary>
    /// Model for BusinessGalleryTran
    /// </summary>
    public class BusinessGalleryTran
    {
        public int BusinessGalleryTranId { get; set; }
        public string ImageTitle { get; set; }
        public string ImageName { get; set; }
        public string xs_ImagePhysicalName { get; set; }
        public string sm_ImagePhysicalName { get; set; }
        public string md_ImagePhysicalName { get; set; }
        public string lg_ImagePhysicalName { get; set; }
        public string xl_ImagePhysicalName { get; set; }
        public int linktoBusinessMasterId { get; set; }
        public short SortOrder { get; set; }

        public string Business { get; set; }

        internal void SetClassObject(posBusinessGalleryTranDAL objBusinessGalleryTranDAL)
        {
            string ImageRetrievePath = System.Configuration.ConfigurationManager.AppSettings["possImageRetrievePath"] + "/BusinessGallery/";

            this.BusinessGalleryTranId = Convert.ToInt32(objBusinessGalleryTranDAL.BusinessGalleryTranId);
            this.ImageTitle = Convert.ToString(objBusinessGalleryTranDAL.ImageTitle);
            if (objBusinessGalleryTranDAL.ImageName != null)
            {
                this.ImageName = ImageRetrievePath + objBusinessGalleryTranDAL.ImageName;

                this.xs_ImagePhysicalName = ImageRetrievePath + objBusinessGalleryTranDAL.xs_ImagePhysicalName;
                this.sm_ImagePhysicalName = ImageRetrievePath + objBusinessGalleryTranDAL.sm_ImagePhysicalName;
                this.md_ImagePhysicalName = ImageRetrievePath + objBusinessGalleryTranDAL.md_ImagePhysicalName;
                this.lg_ImagePhysicalName = ImageRetrievePath + objBusinessGalleryTranDAL.lg_ImagePhysicalName;
                this.xl_ImagePhysicalName = ImageRetrievePath + objBusinessGalleryTranDAL.xl_ImagePhysicalName;
            }
            this.linktoBusinessMasterId = Convert.ToInt32(objBusinessGalleryTranDAL.linktoBusinessMasterId);
            if (objBusinessGalleryTranDAL.SortOrder != null)
            {
                this.SortOrder = Convert.ToInt16(objBusinessGalleryTranDAL.SortOrder.Value);
            }

            this.Business = Convert.ToString(objBusinessGalleryTranDAL.Business);
        }

        internal static List<BusinessGalleryTran> SetListObject(List<posBusinessGalleryTranDAL> lstBusinessGalleryTranDAL)
        {
            List<BusinessGalleryTran> lstBusinessGalleryTran = new List<BusinessGalleryTran>();
            BusinessGalleryTran objBusinessGalleryTran = null;
            foreach (posBusinessGalleryTranDAL objBusinessGalleryTranDAL in lstBusinessGalleryTranDAL)
            {
                objBusinessGalleryTran = new BusinessGalleryTran();
                string ImageRetrievePath = System.Configuration.ConfigurationManager.AppSettings["possImageRetrievePath"] + "/BusinessGallery/";

                objBusinessGalleryTran.BusinessGalleryTranId = Convert.ToInt32(objBusinessGalleryTranDAL.BusinessGalleryTranId);
                objBusinessGalleryTran.ImageTitle = Convert.ToString(objBusinessGalleryTranDAL.ImageTitle);
                if (objBusinessGalleryTranDAL.ImageName != null)
                {
                    objBusinessGalleryTranDAL.ImageName = ImageRetrievePath + objBusinessGalleryTranDAL.ImageName;

                    objBusinessGalleryTran.xs_ImagePhysicalName = ImageRetrievePath + objBusinessGalleryTranDAL.xs_ImagePhysicalName;
                    objBusinessGalleryTran.sm_ImagePhysicalName = ImageRetrievePath + objBusinessGalleryTranDAL.sm_ImagePhysicalName;
                    objBusinessGalleryTran.md_ImagePhysicalName = ImageRetrievePath + objBusinessGalleryTranDAL.md_ImagePhysicalName;
                    objBusinessGalleryTran.lg_ImagePhysicalName = ImageRetrievePath + objBusinessGalleryTranDAL.lg_ImagePhysicalName;
                    objBusinessGalleryTran.xl_ImagePhysicalName = ImageRetrievePath + objBusinessGalleryTranDAL.xl_ImagePhysicalName;
                }
                objBusinessGalleryTran.linktoBusinessMasterId = Convert.ToInt32(objBusinessGalleryTranDAL.linktoBusinessMasterId);
                if (objBusinessGalleryTranDAL.SortOrder != null)
                {
                    objBusinessGalleryTran.SortOrder = Convert.ToInt16(objBusinessGalleryTranDAL.SortOrder.Value);
                }
                objBusinessGalleryTran.Business = Convert.ToString(objBusinessGalleryTranDAL.Business);
                lstBusinessGalleryTran.Add(objBusinessGalleryTran);
            }
            return lstBusinessGalleryTran;
        }
    }
}