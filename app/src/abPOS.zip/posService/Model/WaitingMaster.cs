using System;
using System.Collections.Generic;

namespace posLibrary
{
	/// <summary>
	/// Model for WaitingMaster
	/// </summary>
	public class WaitingMaster
	{

        public long WaitingMasterId { get; set; }
        public string PersonName { get; set; }
        public string PersonMobile { get; set; }
        public short NoOfPersons { get; set; }
        public short linktoWaitingStatusMasterId { get; set; }
        public string CreateDateTime { get; set; }
        public short linktoUserMasterIdCreatedBy { get; set; }
        public short linktoBusinessMasterId { get; set; }
        public short linktoTableMasterId { get; set; }
        public string UpdateDateTime { get; set; }
        public short linktoUserMasterIdUpdatedBy { get; set; }
		/// Extra
		public string WaitingStatus { get; set; }


		internal void SetClassObject(posWaitingMasterDAL objWaitingMasterDAL)
		{
			this.WaitingMasterId = Convert.ToInt64(objWaitingMasterDAL.WaitingMasterId);
			this.PersonName = Convert.ToString(objWaitingMasterDAL.PersonName);
			this.PersonMobile = Convert.ToString(objWaitingMasterDAL.PersonMobile);
			this.NoOfPersons = Convert.ToInt16(objWaitingMasterDAL.NoOfPersons);
			this.linktoWaitingStatusMasterId = Convert.ToInt16(objWaitingMasterDAL.linktoWaitingStatusMasterId);
			this.CreateDateTime = objWaitingMasterDAL.CreateDateTime.ToString("s");
			this.linktoUserMasterIdCreatedBy = Convert.ToInt16(objWaitingMasterDAL.linktoUserMasterIdCreatedBy);
            this.linktoBusinessMasterId = Convert.ToInt16(objWaitingMasterDAL.linktoBusinessMasterId);
            this.linktoTableMasterId = Convert.ToInt16(objWaitingMasterDAL.linktoTableMasterId);
            this.linktoUserMasterIdUpdatedBy = Convert.ToInt16(objWaitingMasterDAL.linktoUserMasterIdUpdatedBy);
            this.UpdateDateTime = objWaitingMasterDAL.UpdateDateTime.ToString();
			/// Extra
			this.WaitingStatus = Convert.ToString(objWaitingMasterDAL.WaitingStatus);
		}

		internal static List<WaitingMaster> SetListObject(List<posWaitingMasterDAL> lstWaitingMasterDAL)
		{
			List<WaitingMaster> lstWaitingMaster = new List<WaitingMaster>();
			WaitingMaster objWaitingMaster = null;
			foreach (posWaitingMasterDAL objWaitingMasterDAL in lstWaitingMasterDAL)
			{
				objWaitingMaster = new WaitingMaster();
				objWaitingMaster.WaitingMasterId = Convert.ToInt64(objWaitingMasterDAL.WaitingMasterId);
				objWaitingMaster.PersonName = Convert.ToString(objWaitingMasterDAL.PersonName);
				objWaitingMaster.PersonMobile = Convert.ToString(objWaitingMasterDAL.PersonMobile);
				objWaitingMaster.NoOfPersons = Convert.ToInt16(objWaitingMasterDAL.NoOfPersons);
				objWaitingMaster.linktoWaitingStatusMasterId = Convert.ToInt16(objWaitingMasterDAL.linktoWaitingStatusMasterId);
				objWaitingMaster.CreateDateTime = objWaitingMasterDAL.CreateDateTime.ToString("s");
				objWaitingMaster.linktoUserMasterIdCreatedBy = Convert.ToInt16(objWaitingMasterDAL.linktoUserMasterIdCreatedBy);
                objWaitingMaster.linktoBusinessMasterId = Convert.ToInt16(objWaitingMasterDAL.linktoBusinessMasterId);
                objWaitingMaster.linktoTableMasterId = Convert.ToInt16(objWaitingMasterDAL.linktoTableMasterId);
                objWaitingMaster.linktoUserMasterIdUpdatedBy = Convert.ToInt16(objWaitingMasterDAL.linktoUserMasterIdUpdatedBy);
                objWaitingMaster.UpdateDateTime = objWaitingMasterDAL.UpdateDateTime.ToString();
				/// Extra
				objWaitingMaster.WaitingStatus = Convert.ToString(objWaitingMasterDAL.WaitingStatus);
				lstWaitingMaster.Add(objWaitingMaster);
			}
			return lstWaitingMaster;
		}
	}
}
