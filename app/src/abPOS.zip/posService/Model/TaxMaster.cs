using System;
using System.Collections.Generic;

namespace posLibrary
{
	/// <summary>
	/// Model for TaxMaster
	/// </summary>
	public class TaxMaster
	{

        public short TaxMasterId { get; set; }
        public string TaxName { get; set; }
        public decimal TaxRate { get; set; }
        public short linktoBusinessMasterId { get; set; }
        public bool IsEnabled { get; set; }
        public string CreateDateTime { get; set; }
        public short linktoUserMasterIdCreatedBy { get; set; }
        public string UpdateDateTime { get; set; }
        public short? linktoUserMasterIdUpdatedBy { get; set; }

        /// Extra
        public string TaxRateString { get; set; }

		internal void SetClassObject(posTaxMasterDAL objTaxMasterDAL)
		{
			this.TaxMasterId = Convert.ToInt16(objTaxMasterDAL.TaxMasterId);
			this.TaxName = Convert.ToString(objTaxMasterDAL.TaxName);
            this.TaxRate = Convert.ToDecimal(objTaxMasterDAL.TaxRate);
			this.linktoBusinessMasterId = Convert.ToInt16(objTaxMasterDAL.linktoBusinessMasterId);
			this.IsEnabled = Convert.ToBoolean(objTaxMasterDAL.IsEnabled);
			this.CreateDateTime = objTaxMasterDAL.CreateDateTime.ToString("s");
			this.linktoUserMasterIdCreatedBy = Convert.ToInt16(objTaxMasterDAL.linktoUserMasterIdCreatedBy);
			if (objTaxMasterDAL.UpdateDateTime != null)
			{
				this.UpdateDateTime = objTaxMasterDAL.UpdateDateTime.Value.ToString("s");
			}
			if (objTaxMasterDAL.linktoUserMasterIdUpdatedBy != null)
			{
				this.linktoUserMasterIdUpdatedBy = Convert.ToInt16(objTaxMasterDAL.linktoUserMasterIdUpdatedBy.Value);
			}
		}

		internal static List<TaxMaster> SetListObject(List<posTaxMasterDAL> lstTaxMasterDAL)
		{
			List<TaxMaster> lstTaxMaster = new List<TaxMaster>();
			TaxMaster objTaxMaster = null;
			foreach (posTaxMasterDAL objTaxMasterDAL in lstTaxMasterDAL)
			{
				objTaxMaster = new TaxMaster();
				objTaxMaster.TaxMasterId = Convert.ToInt16(objTaxMasterDAL.TaxMasterId);
				objTaxMaster.TaxName = Convert.ToString(objTaxMasterDAL.TaxName);
                objTaxMaster.TaxRate = Convert.ToDecimal(objTaxMasterDAL.TaxRate);
				objTaxMaster.linktoBusinessMasterId = Convert.ToInt16(objTaxMasterDAL.linktoBusinessMasterId);
				objTaxMaster.IsEnabled = Convert.ToBoolean(objTaxMasterDAL.IsEnabled);
				objTaxMaster.CreateDateTime = objTaxMasterDAL.CreateDateTime.ToString("s");
				objTaxMaster.linktoUserMasterIdCreatedBy = Convert.ToInt16(objTaxMasterDAL.linktoUserMasterIdCreatedBy);
				if (objTaxMasterDAL.UpdateDateTime != null)
				{
					objTaxMaster.UpdateDateTime = objTaxMasterDAL.UpdateDateTime.Value.ToString("s");
				}
				if (objTaxMasterDAL.linktoUserMasterIdUpdatedBy != null)
				{
					objTaxMaster.linktoUserMasterIdUpdatedBy = Convert.ToInt16(objTaxMasterDAL.linktoUserMasterIdUpdatedBy.Value);
				}
				lstTaxMaster.Add(objTaxMaster);
			}
			return lstTaxMaster;
		}
	}
}
