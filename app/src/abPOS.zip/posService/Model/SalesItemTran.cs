using System;
using System.Collections.Generic;

namespace posLibrary
{
	/// <summary>
	/// Model for SalesItemTran
	/// </summary>
	public class SalesItemTran
	{

        public long SalesItemTranId { get; set; }
        public long linktoSalesMasterId { get; set; }
        public int linktoItemMasterId { get; set; }
        public short linktoUnitMasterId { get; set; }
        public string ItemCode { get; set; }
        public string ItemName { get; set; }
        public short Quantity { get; set; }
        public double Rate { get; set; }
        public double DiscountPercentage { get; set; }
        public double DiscountAmount { get; set; }
        public double Tax { get; set; }
        public bool IsRateTaxInclusive { get; set; }
        public double PurchaseRate { get; set; }
        public short ItemPoint { get; set; }
        public short DeductedPoint { get; set; }
        public string ItemRemark { get; set; }
        public short? linktoOrderStatusMasterId { get; set; }
        public string CreateDateTime { get; set; }
        public short linktoUserMasterIdCreatedBy { get; set; }
        public string UpdateDateTime { get; set; }
        public short? linktoUserMasterIdUpdatedBy { get; set; }

		/// Extra
		public long Sales { get; set; }
		public string Item { get; set; }
		public string Unit { get; set; }
		public string OrderStatus { get; set; }


		internal void SetClassObject(posSalesItemTranDAL objSalesItemTranDAL)
		{
			this.SalesItemTranId = Convert.ToInt64(objSalesItemTranDAL.SalesItemTranId);
			this.linktoSalesMasterId = Convert.ToInt64(objSalesItemTranDAL.linktoSalesMasterId);
			this.linktoItemMasterId = Convert.ToInt32(objSalesItemTranDAL.linktoItemMasterId);
			this.linktoUnitMasterId = Convert.ToInt16(objSalesItemTranDAL.linktoUnitMasterId);
			this.ItemCode = Convert.ToString(objSalesItemTranDAL.ItemCode);
			this.ItemName = Convert.ToString(objSalesItemTranDAL.ItemName);
			this.Quantity = Convert.ToInt16(objSalesItemTranDAL.Quantity);
			this.Rate = Convert.ToDouble(objSalesItemTranDAL.Rate);
			this.DiscountPercentage = Convert.ToDouble(objSalesItemTranDAL.DiscountPercentage);
			this.DiscountAmount = Convert.ToDouble(objSalesItemTranDAL.DiscountAmount);
			this.Tax = Convert.ToDouble(objSalesItemTranDAL.Tax);
			this.IsRateTaxInclusive = Convert.ToBoolean(objSalesItemTranDAL.IsRateTaxInclusive);
			this.PurchaseRate = Convert.ToDouble(objSalesItemTranDAL.PurchaseRate);
			this.ItemPoint = Convert.ToInt16(objSalesItemTranDAL.ItemPoint);
			this.DeductedPoint = Convert.ToInt16(objSalesItemTranDAL.DeductedPoint);
			this.ItemRemark = Convert.ToString(objSalesItemTranDAL.ItemRemark);
            if (objSalesItemTranDAL.linktoOrderStatusMasterId != null)
            {
                this.linktoOrderStatusMasterId = Convert.ToInt16(objSalesItemTranDAL.linktoOrderStatusMasterId.Value);
            }
			this.CreateDateTime = objSalesItemTranDAL.CreateDateTime.ToString("s");
			this.linktoUserMasterIdCreatedBy = Convert.ToInt16(objSalesItemTranDAL.linktoUserMasterIdCreatedBy);
			if (objSalesItemTranDAL.UpdateDateTime != null)
			{
				this.UpdateDateTime = objSalesItemTranDAL.UpdateDateTime.Value.ToString("s");
			}
			if (objSalesItemTranDAL.linktoUserMasterIdUpdatedBy != null)
			{
				this.linktoUserMasterIdUpdatedBy = Convert.ToInt16(objSalesItemTranDAL.linktoUserMasterIdUpdatedBy.Value);
			}

			/// Extra
			this.Sales = Convert.ToInt64(objSalesItemTranDAL.Sales);
			this.Item = Convert.ToString(objSalesItemTranDAL.ItemName);
			this.Unit = Convert.ToString(objSalesItemTranDAL.Unit);
			this.OrderStatus = Convert.ToString(objSalesItemTranDAL.OrderStatus);
		}

		internal static List<SalesItemTran> SetListObject(List<posSalesItemTranDAL> lstSalesItemTranDAL)
		{
			List<SalesItemTran> lstSalesItemTran = new List<SalesItemTran>();
			SalesItemTran objSalesItemTran = null;
			foreach (posSalesItemTranDAL objSalesItemTranDAL in lstSalesItemTranDAL)
			{
				objSalesItemTran = new SalesItemTran();
				objSalesItemTran.SalesItemTranId = Convert.ToInt64(objSalesItemTranDAL.SalesItemTranId);
				objSalesItemTran.linktoSalesMasterId = Convert.ToInt64(objSalesItemTranDAL.linktoSalesMasterId);
				objSalesItemTran.linktoItemMasterId = Convert.ToInt32(objSalesItemTranDAL.linktoItemMasterId);
				objSalesItemTran.linktoUnitMasterId = Convert.ToInt16(objSalesItemTranDAL.linktoUnitMasterId);
				objSalesItemTran.ItemCode = Convert.ToString(objSalesItemTranDAL.ItemCode);
				objSalesItemTran.ItemName = Convert.ToString(objSalesItemTranDAL.ItemName);
				objSalesItemTran.Quantity = Convert.ToInt16(objSalesItemTranDAL.Quantity);
				objSalesItemTran.Rate = Convert.ToDouble(objSalesItemTranDAL.Rate);
				objSalesItemTran.DiscountPercentage = Convert.ToDouble(objSalesItemTranDAL.DiscountPercentage);
				objSalesItemTran.DiscountAmount = Convert.ToDouble(objSalesItemTranDAL.DiscountAmount);
				objSalesItemTran.Tax = Convert.ToDouble(objSalesItemTranDAL.Tax);
				objSalesItemTran.IsRateTaxInclusive = Convert.ToBoolean(objSalesItemTranDAL.IsRateTaxInclusive);
				objSalesItemTran.PurchaseRate = Convert.ToDouble(objSalesItemTranDAL.PurchaseRate);
				objSalesItemTran.ItemPoint = Convert.ToInt16(objSalesItemTranDAL.ItemPoint);
				objSalesItemTran.DeductedPoint = Convert.ToInt16(objSalesItemTranDAL.DeductedPoint);
				objSalesItemTran.ItemRemark = Convert.ToString(objSalesItemTranDAL.ItemRemark);
				
				objSalesItemTran.CreateDateTime = objSalesItemTranDAL.CreateDateTime.ToString("s");
				objSalesItemTran.linktoUserMasterIdCreatedBy = Convert.ToInt16(objSalesItemTranDAL.linktoUserMasterIdCreatedBy);
				if (objSalesItemTranDAL.UpdateDateTime != null)
				{
					objSalesItemTran.UpdateDateTime = objSalesItemTranDAL.UpdateDateTime.Value.ToString("s");
				}
				if (objSalesItemTranDAL.linktoUserMasterIdUpdatedBy != null)
				{
					objSalesItemTran.linktoUserMasterIdUpdatedBy = Convert.ToInt16(objSalesItemTranDAL.linktoUserMasterIdUpdatedBy.Value);
				}
                if (objSalesItemTranDAL.linktoOrderStatusMasterId != null)
                {
                    objSalesItemTran.linktoOrderStatusMasterId = Convert.ToInt16(objSalesItemTranDAL.linktoOrderStatusMasterId.Value);
                }

				/// Extra
				objSalesItemTran.Sales = Convert.ToInt64(objSalesItemTranDAL.Sales);
				objSalesItemTran.Item = Convert.ToString(objSalesItemTranDAL.ItemName);
				objSalesItemTran.Unit = Convert.ToString(objSalesItemTranDAL.Unit);
				objSalesItemTran.OrderStatus = Convert.ToString(objSalesItemTranDAL.OrderStatus);
				lstSalesItemTran.Add(objSalesItemTran);
			}
			return lstSalesItemTran;
		}
	}
}
