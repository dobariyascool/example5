using System;
using System.Collections.Generic;

namespace posLibrary
{
	/// <summary>
	/// Model for OrderItemModifierTran
	/// </summary>
	public class OrderItemModifierTran
	{

        public long OrderItemModifierTranId { get; set; }
        public long linktoOrderItemTranId { get; set; }
        public int linktoItemMasterId { get; set; }
        public double Rate { get; set; }


		internal void SetClassObject(posOrderItemModifierTranDAL objOrderItemModifierTranDAL)
		{
			this.OrderItemModifierTranId = Convert.ToInt64(objOrderItemModifierTranDAL.OrderItemModifierTranId);
			this.linktoOrderItemTranId = Convert.ToInt64(objOrderItemModifierTranDAL.linktoOrderItemTranId);
            this.linktoItemMasterId = Convert.ToInt32(objOrderItemModifierTranDAL.linktoItemMasterId);
			this.Rate = Convert.ToDouble(objOrderItemModifierTranDAL.Rate);
		}

		internal static List<OrderItemModifierTran> SetListObject(List<posOrderItemModifierTranDAL> lstOrderItemModifierTranDAL)
		{
			List<OrderItemModifierTran> lstOrderItemModifierTran = new List<OrderItemModifierTran>();
			OrderItemModifierTran objOrderItemModifierTran = null;
			foreach (posOrderItemModifierTranDAL objOrderItemModifierTranDAL in lstOrderItemModifierTranDAL)
			{
				objOrderItemModifierTran = new OrderItemModifierTran();
				objOrderItemModifierTran.OrderItemModifierTranId = Convert.ToInt64(objOrderItemModifierTranDAL.OrderItemModifierTranId);
				objOrderItemModifierTran.linktoOrderItemTranId = Convert.ToInt64(objOrderItemModifierTranDAL.linktoOrderItemTranId);
                objOrderItemModifierTran.linktoItemMasterId = Convert.ToInt32(objOrderItemModifierTranDAL.linktoItemMasterId);
				objOrderItemModifierTran.Rate = Convert.ToDouble(objOrderItemModifierTranDAL.Rate);
				lstOrderItemModifierTran.Add(objOrderItemModifierTran);
			}
			return lstOrderItemModifierTran;
		}
	}
}
