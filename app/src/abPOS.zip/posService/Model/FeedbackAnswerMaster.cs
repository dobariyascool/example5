using System;
using System.Collections.Generic;

namespace posLibrary
{
	/// <summary>
	/// Model for FeedbackAnswerMaster
	/// </summary>
	public class FeedbackAnswerMaster
	{
        public int FeedbackAnswerMasterId { get; set; }
        public int linktoFeedbackQuestionMasterId { get; set; }
        public string Answer { get; set; }
        public bool IsDeleted { get; set; }

		/// Extra
		public string FeedbackQuestion { get; set; }


		internal void SetClassObject(posFeedbackAnswerMasterDAL objFeedbackAnswerMasterDAL)
		{
			this.FeedbackAnswerMasterId = Convert.ToInt32(objFeedbackAnswerMasterDAL.FeedbackAnswerMasterId);
			this.linktoFeedbackQuestionMasterId = Convert.ToInt32(objFeedbackAnswerMasterDAL.linktoFeedbackQuestionMasterId);
			this.Answer = Convert.ToString(objFeedbackAnswerMasterDAL.Answer);
			this.IsDeleted = Convert.ToBoolean(objFeedbackAnswerMasterDAL.IsDeleted);

			/// Extra
			this.FeedbackQuestion = Convert.ToString(objFeedbackAnswerMasterDAL.FeedbackQuestion);
		}

		internal static List<FeedbackAnswerMaster> SetListObject(List<posFeedbackAnswerMasterDAL> lstFeedbackAnswerMasterDAL)
		{
			List<FeedbackAnswerMaster> lstFeedbackAnswerMaster = new List<FeedbackAnswerMaster>();
			FeedbackAnswerMaster objFeedbackAnswerMaster = null;
			foreach (posFeedbackAnswerMasterDAL objFeedbackAnswerMasterDAL in lstFeedbackAnswerMasterDAL)
			{
				objFeedbackAnswerMaster = new FeedbackAnswerMaster();
				objFeedbackAnswerMaster.FeedbackAnswerMasterId = Convert.ToInt32(objFeedbackAnswerMasterDAL.FeedbackAnswerMasterId);
				objFeedbackAnswerMaster.linktoFeedbackQuestionMasterId = Convert.ToInt32(objFeedbackAnswerMasterDAL.linktoFeedbackQuestionMasterId);
				objFeedbackAnswerMaster.Answer = Convert.ToString(objFeedbackAnswerMasterDAL.Answer);
				objFeedbackAnswerMaster.IsDeleted = Convert.ToBoolean(objFeedbackAnswerMasterDAL.IsDeleted);

				/// Extra
				objFeedbackAnswerMaster.FeedbackQuestion = Convert.ToString(objFeedbackAnswerMasterDAL.FeedbackQuestion);
				lstFeedbackAnswerMaster.Add(objFeedbackAnswerMaster);
			}
			return lstFeedbackAnswerMaster;
		}
	}
}
