﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;
using posService.Model;
using posLibrary;

namespace posService
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the interface name "IService1" in both code and config file together.
    [ServiceContract]
    public interface IService
    {
        [OperationContract]
        [WebGet(UriTemplate = "SelectAllAreaMaster/{linktoBusinessMasterId}/{linktoCityMasterId}", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Wrapped)]
        List<AreaMaster> SelectAllAreaMaster(string linktoBusinessMasterId, string linktoCityMasterId);

        [OperationContract]
        [WebGet(UriTemplate = "SelectAllWaitingStatus", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Wrapped)]
        List<WaitingStatusMaster> SelectAllWaitingStatus();

        [OperationContract]
        [WebGet(UriTemplate = "SelectAllWaitingMasterByWaitingStatusMasterId/{linktoWaitingStatusMasterId}/{fromday}/{frommonth}/{fromyear}/{linktoBusinessMasterId}/{OrderBy}", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Wrapped)]
        List<WaitingMaster> SelectAllWaitingMasterByWaitingStatusMasterId(string linktoWaitingStatusMasterId, string fromday, string frommonth, string fromyear, string linktoBusinessMasterId, string OrderBy);

        [OperationContract]
        [WebGet(UriTemplate = "SelectAllTableMaster/{linktoCounterMasterId}/{linktoTableStatusMasterId}/{linktoOrderTypeMasterId}/{linktoBusinessMasterId}/{fromday}/{frommonth}/{fromyear}", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Wrapped)]
        List<TableMaster> SelectAllTableMaster(string linktoCounterMasterId, string linktoTableStatusMasterId, string linktoOrderTypeMasterId, string linktoBusinessMasterId, string fromday, string frommonth, string fromyear);

        [OperationContract]
        [WebGet(UriTemplate = "SelectAllBusinessMaster", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Wrapped)]
        List<BusinessMaster> SelectAllBusinessMaster();

        [OperationContract]
        [WebGet(UriTemplate = "SelectAllCategoryMaster/{linktoBusinessMasterId}/{isHiddenForCustomer}", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Wrapped)]
        List<CategoryMaster> SelectAllCategoryMaster(string linktoBusinessMasterId, string isHiddenForCustomer);

        [OperationContract]
        [WebGet(UriTemplate = "SelectAllBusinessGalleryTran/{linktoBusinessMasterId}", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Wrapped)]
        List<BusinessGalleryTran> SelectAllBusinessGalleryTran(string linktoBusinessMasterId);

        [OperationContract]
        [WebGet(UriTemplate = "SelectAllItemMasterByCategoryMasterId/{linktoCounterMasterId}/{linktoOrderTypeMasterId}/{linktoCategoryMasterId}/{itemTypeMasterIds}/{linktoBusinessMasterId}/{isFavorite}/{itemMasterIds}", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Wrapped)]
        List<ItemMaster> SelectAllItemMasterByCategoryMasterId(string linktoCounterMasterId, string linktoOrderTypeMasterId, string linktoCategoryMasterId, string itemTypeMasterIds, string linktoBusinessMasterId, string isFavorite, string itemMasterIds);

        [OperationContract]
        [WebGet(UriTemplate = "SelectAllBusinessHoursTranByBusinessMasterId/{businessMasterId}", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Wrapped)]
        List<BusinessHoursTran> SelectAllBusinessHoursTranByBusinessMasterId(string businessMasterId);

        [OperationContract]
        [WebGet(UriTemplate = "SelectAllCounterMaster/{linktoBusinessMasterId}/{linktoUserMasterId}", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Wrapped)]
        List<CounterMaster> SelectAllCounterMaster(string linktoBusinessMasterId, string linktoUserMasterId);

        [OperationContract]
        [WebGet(UriTemplate = "SelectAllOrderMasterByOrderStatusMasterId/{linktoCounterMasterId}/{linktoOrderStatusMasterId}/{linktoTableMasterIds}/{linktoOrderTypeMasterId}/{fromday}/{frommonth}/{fromyear}/{linktoBusinessMasterId}", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Wrapped)]
        List<OrderMaster> SelectAllOrderMasterByOrderStatusMasterId(string linktoCounterMasterId, string linktoOrderStatusMasterId, string linktoTableMasterIds, string linktoOrderTypeMasterId, string fromday, string frommonth, string fromyear, string linktoBusinessMasterId);

        [OperationContract]
        [WebGet(UriTemplate = "SelectAllOrderMasterByFromDate/{linktoCounterMasterId}/{fromday}/{frommonth}/{fromyear}/{linktoBusinessMasterId}", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Wrapped)]
        List<OrderMaster> SelectAllOrderMasterByFromDate(string linktoCounterMasterId, string fromday, string frommonth, string fromyear, string linktoBusinessMasterId);

        [OperationContract]
        [WebGet(UriTemplate = "SelectAllOrderItemTranByOrderMasterId/{orderMasterId}", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Wrapped)]
        List<OrderItemTran> SelectAllOrderItemTranByOrderMasterId(string orderMasterId);

        [OperationContract]
        [WebGet(UriTemplate = "SelectAllItemRemarkMaster/{linktoBusinessMasterId}", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Wrapped)]
        List<ItemRemarkMaster> SelectAllItemRemarkMaster(string linktoBusinessMasterId);

        [OperationContract]
        [WebGet(UriTemplate = "SelectAllItemMasterModifier/{itemType}/{linktoBusinessMasterId}/{linktoItemMasterId}", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Wrapped)]
        List<ItemMaster> SelectAllItemMasterModifier(string itemType, string linktoBusinessMasterId, string linktoItemMasterId);

        [OperationContract]
        [WebGet(UriTemplate = "SelectAllOrderItemByTableMasterIds/{fromday}/{frommonth}/{fromyear}/{linktoTableMasterIds}", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Wrapped)]
        List<ItemMaster> SelectAllOrderItemByTableMasterIds(string fromday, string frommonth, string fromyear, string linktoTableMasterIds);

        [OperationContract]
        [WebGet(UriTemplate = "SelectAllTaxMaster/{businessMasterId}", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Wrapped)]
        List<TaxMaster> SelectAllTaxMaster(string businessMasterId);

        [OperationContract]
        [WebGet(UriTemplate = "SelectAllDiscountMaster/{linktoBusinessMasterId}", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Wrapped)]
        List<DiscountSelectionMaster> SelectAllDiscountMaster(string linktoBusinessMasterId);

        [OperationContract]
        [WebGet(UriTemplate = "SelectAllOfferMaster/{fromday}/{frommonth}/{fromyear}/{fromhour}/{fromminute}/{linktoBusinessMasterId}", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Wrapped)]
        List<OfferMaster> SelectAllOfferMaster(string fromday, string frommonth, string fromyear, string fromhour, string fromminute, string linktoBusinessMasterId);

        [OperationContract]
        [WebGet(UriTemplate = "SelectAllFeedbackQuestionGroupMaster/{businessMasterId}", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Wrapped)]
        List<FeedbackQuestionGroupMaster> SelectAllFeedbackQuestionGroupMaster(string businessMasterId);

        [OperationContract]
        [WebGet(UriTemplate = "SelectAllFeedbackAnswerMaster", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Wrapped)]
        List<FeedbackAnswerMaster> SelectAllFeedbackAnswerMaster();

        [OperationContract]
        [WebGet(UriTemplate = "SelectAllFeedbackQuestionMaster/{businessMasterId}", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Wrapped)]
        List<FeedbackQuestionMaster> SelectAllFeedbackQuestionMaster(string businessMasterId);

        [OperationContract]
        [WebGet(UriTemplate = "SelectAllBusinessInfoAnswerMaster/{linktoBusinessTypeMasterId}/{linktoBusinessMasterId}", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Wrapped)]
        List<BusinessInfoAnswerMaster> SelectAllBusinessInfoAnswerMaster(string linktoBusinessTypeMasterId, string linktoBusinessMasterId);

        [OperationContract]
        [WebGet(UriTemplate = "SelectAllItemOption/{linktoItemMasterId}", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Wrapped)]
        List<OptionValueTran> SelectAllItemOption(string linktoItemMasterId);

        [OperationContract]
        [WebGet(UriTemplate = "SelectAllItemSuggested/{linktoItemMasterId}/{linktoBusinessMasterId}/{rateIndex}/{isDineIn}", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Wrapped)]
        List<ItemMaster> SelectAllItemSuggested(string linktoItemMasterId, string linktoBusinessMasterId, string rateIndex,string isDineIn);

        [OperationContract]
        [WebGet(UriTemplate = "SelectAllWaiterNotificationMaster/{linktoWaiterMasterId}/{fromday}/{frommonth}/{fromyear}/{fromhour}/{fromminute}", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Wrapped)]
        List<WaiterNotificationMaster> SelectAllWaiterNotificationMaster(string linktoWaiterMasterId, string fromday, string frommonth, string fromyear, string fromhour, string fromminute);

        [OperationContract]
        [WebGet(UriTemplate = "SelectAppThemeMaster/{linktoBusinessMasterId}", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Wrapped)]
        AppThemeMaster SelectAppThemeMaster(string linktoBusinessMasterId);

        [OperationContract]
        [WebGet(UriTemplate = "SelectAllAppThemeMaster", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Wrapped)]
        List<AppThemeMaster> SelectAllAppThemeMaster();

        [OperationContract]
        [WebGet(UriTemplate = "SelectUserName/{username}/{password}/{linktoBusinessMasterId}", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Wrapped)]
        UserMaster SelectUserName(string username, string password, string linktoBusinessMasterId);

        [OperationContract]
        [WebGet(UriTemplate = "SelectBusinessMasterByBusinessMasterId/{businessMasterId}", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Wrapped)]
        BusinessMaster SelectBusinessMasterByBusinessMasterId(string businessMasterId);

        [OperationContract]
        [WebGet(UriTemplate = "SelectItemMaster/{counterMasterId}/{linktoOrderTypeMasterId}/{itemMasterId}", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Wrapped)]
        ItemMaster SelectItemMaster(string counterMasterId, string linktoOrderTypeMasterId, string itemMasterId);

        [OperationContract]
        [WebGet(UriTemplate = "SelectBillNumber", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Wrapped)]
        String SelectBillNumber();

        [OperationContract]
        [WebGet(UriTemplate = "SelectCustomerMaster/{userName}/{password}/{customerMasterId}", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Wrapped)]
        CustomerMaster SelectCustomerMaster(string userName, string password, string customerMasterId);

        [OperationContract]
        [WebGet(UriTemplate = "SelectOfferMaster/{offerMasterId}", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Wrapped)]
        OfferMaster SelectOfferMaster(string offerMasterId);

        [OperationContract]
        [WebGet(UriTemplate = "SelectBusinessDescription/{businessMasterId}/{keyword}", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Wrapped)]
        BusinessDescription SelectBusinessDescription(string businessMasterId, string keyword);

        [OperationContract]
        [WebGet(UriTemplate = "SelectOrderMasterByTableMasterId/{linktoTableMasterId}/{linktoBusinessMasterId}/{fromday}/{frommonth}/{fromyear}", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Wrapped)]
        bool SelectOrderMasterByTableMasterId(string linktoTableMasterId, string linktoBusinessMasterId, string fromday, string frommonth, string fromyear);

        [OperationContract]
        [WebGet(UriTemplate = "SelectTableAssignmentSetting/{linktoBusinessMasterId}/{SettingMasterId}", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Wrapped)]
        bool SelectTableAssignmentSetting(string linktoBusinessMasterId, string SettingMasterId);

        [OperationContract]
        [WebInvoke(UriTemplate = "SelectOfferMasterOfferCodeVerification", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Wrapped)]
        OfferMaster SelectOfferMasterOfferCodeVerification(OfferMaster objOfferMaster);

        [OperationContract]
        [WebInvoke(UriTemplate = "InsertWaitingMaster", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Wrapped)]
        ErrorStatus InsertWaitingMaster(WaitingMaster waitingMaster);

        [OperationContract]
        [WebInvoke(UriTemplate = "InsertCustomerMaster", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Wrapped)]
        ErrorStatus InsertCustomerMaster(CustomerMaster customerMaster);

        [OperationContract]
        [WebInvoke(UriTemplate = "InsertFeedbackMaster", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Wrapped)]
        ErrorStatus InsertFeedbackMaster(FeedbackMaster feedbackMaster, List<FeedbackTran> lstFeedbackTran);

        [OperationContract]
        [WebInvoke(UriTemplate = "InsertOrderMaster", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Wrapped)]
        ErrorStatus InsertOrderMaster(OrderMaster orderMaster, List<ItemMaster> lstOrderItemTran,List<TaxMaster> lstTaxMaster);

        [OperationContract]
        [WebInvoke(UriTemplate = "InsertSalesMaster", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Wrapped)]
        ErrorStatus InsertSalesMaster(SalesMaster salesMaster, List<ItemMaster> lstSalesItemTran, List<TaxMaster> lstTaxMaster, List<OrderMaster> lstOrderMaster);

        [OperationContract]
        [WebInvoke(UriTemplate = "InsertWaiterNotification", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Wrapped)]
        ErrorStatus InsertWaiterNotification(WaiterNotificationMaster waiterNotificationMaster);

        [OperationContract]
        [WebInvoke(UriTemplate = "InsertWaiterNotificationTran", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Wrapped)]
        ErrorStatus InsertWaiterNotificationTran(WaiterNotificationTran waiterNotificationTran);

        [OperationContract]
        [WebInvoke(UriTemplate = "UpdateWaitingStatus", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Wrapped)]
        ErrorStatus UpdateWaitingStatus(WaitingMaster waitingMaster);

        [OperationContract]
        [WebInvoke(UriTemplate = "UpdateTableStatus", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Wrapped)]
        ErrorStatus UpdateTableStatus(TableMaster tableMaster);

        [OperationContract]
        [WebInvoke(UriTemplate = "UpdateOrderItemTranStatus", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Wrapped)]
        ErrorStatus UpdateOrderItemTranStatus(OrderItemTran orderItemTran);

        [OperationContract]
        [WebInvoke(UriTemplate = "UpdateOrderMasterStatus", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Wrapped)]
        ErrorStatus UpdateOrderMasterStatus(OrderMaster orderMaster, string isUpdateTotal);

        [OperationContract]
        [WebInvoke(UriTemplate = "UpdateCustomerMaster", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Wrapped)]
        ErrorStatus UpdateCustomerMaster(CustomerMaster customerMaster);

        [OperationContract]
        [WebInvoke(UriTemplate = "UpdateCustomerMasterPassword", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Wrapped)]
        ErrorStatus UpdateCustomerMasterPassword(CustomerMaster customerMaster);

        [OperationContract]
        [WebGet(UriTemplate = "UpdateOrderMasterDiscount/{orderMasterIds}/{discount}/{isPercentage}", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Wrapped)]
        ErrorStatus UpdateOrderMasterDiscount(string orderMasterIds, string discount, string isPercentage);
    }
}
